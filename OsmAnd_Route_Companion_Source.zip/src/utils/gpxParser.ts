import { RouteStop } from '../types/route';

/**
 * Cleanly extracts the house or building number from an address string.
 * Supports:
 * - Simple numbers: "123 Main St" -> "123"
 * - Letter suffixes: "123A Main St" -> "123A"
 * - Hyphenated / sub-numbers: "1402-B Willow Creek Rd", "45/2 Birchwood" -> "1402-B", "45/2"
 * - Strips route/stop sequence prefixes like "002 - 123 Main St", "Stop 2: 123 Main St"
 * - Handles suite/unit before or after: "Suite 100, 500 S 6th St" -> "500"
 * Returns empty string if no valid house number is found.
 */
export function extractHouseNumber(addressText: string | undefined | null): string {
  if (!addressText) return '';
  let text = addressText.trim();
  if (!text) return '';

  // 1. Ignore coordinate-only or unavailable location placeholders
  if (/^location\s*\(?/i.test(text) || /^lat/i.test(text) || text.toLowerCase() === 'location unavailable') {
    return '';
  }

  // 2. Strip leading stop-sequence indicators like "002 - ", "Stop 002: ", "Stop 2 - ", "#002 - "
  // Do NOT strip non-zero-padded hyphenated house numbers like "1402-B" or "12-A"
  text = text.replace(/^(?:stop\s*#?\d+\s*[-:–—]\s*|#?0+\d+\s*[-:–—]\s*)/i, '').trim();

  // 3. Strip leading "Unit/Apt/Suite" if it precedes the street address:
  // e.g., "Apt 4B, 123 Foster ville Road" -> "123 Foster ville Road"
  const unitPrefixMatch = text.match(/^(?:apt\.?|apartment|unit|suite|ste\.?|room|rm\.?)\s*#?[a-z0-9-]+\s*,\s*(.+)$/i);
  if (unitPrefixMatch) {
    text = unitPrefixMatch[1].trim();
  }

  // 4. Primary: Match house number at the beginning of address (most common and reliable):
  // e.g. "123 Foster ville Road", "#123 Foster ville Road", "123A Main St", "1402-B Willow Creek Rd"
  const leadingMatch = text.match(/^(?:#|no\.?\s*)?(\d+[A-Za-z]?(?:[-\/][A-Za-z0-9]+)?)\s+([A-Za-z0-9#])/i);
  if (leadingMatch) {
    // Verify it is not a zero-padded stop sequence that survived stripping (like "002")
    if (!/^0+\d+$/.test(leadingMatch[1])) {
      return leadingMatch[1];
    }
  }

  // 5. Look for house number preceding street name / street suffix indicators:
  // e.g. "500 S 6th St", "Suite 100, 500 S 6th St"
  const streetWithNumMatch = text.match(/(?:^|[,\s])(?:#|no\.?\s*)?(\d+[A-Za-z]?(?:[-\/][A-Za-z0-9]+)?)\s+(?:[NSEW]\.?\s+)?([A-Za-z0-9\s]+?\s+(?:st|street|rd|road|ave|avenue|ln|lane|dr|drive|blvd|boulevard|way|ct|court|cir|circle|pl|place|ter|terrace|pkwy|parkway))\b/i);
  if (streetWithNumMatch) {
    if (!/^0+\d+$/.test(streetWithNumMatch[1])) {
      return streetWithNumMatch[1];
    }
  }

  // 6. Generic pattern: any standalone number with optional letter suffix at start of string
  const startNumMatch = text.match(/^(?:#|no\.?\s*)?(\d+[A-Za-z]?(?:[-\/][A-Za-z0-9]+)?)\b/i);
  if (startNumMatch && !/^0+\d+$/.test(startNumMatch[1])) {
    return startNumMatch[1];
  }

  return '';
}

/**
 * Resolves the genuine house number for a RouteStop.
 * Prioritizes the customer's delivery address data (fullAddress, desc, cmt, address).
 * Explicitly rejects stop sequence numbers (such as "002" or orderIndex).
 * Returns '—' as a fallback if no valid house number is identifiable.
 */
export function getStopHouseNumber(stop: RouteStop | null | undefined, currentIndex?: number): string {
  if (!stop) return '—';

  // 1. Try extracting from delivery address sources first (the true source of truth)
  const addressSources = [
    stop.fullAddress,
    stop.desc,
    stop.cmt,
    stop.streetName,
    stop.notes,
  ];

  for (const source of addressSources) {
    if (source) {
      const extracted = extractHouseNumber(source);
      if (extracted) {
        return extracted;
      }
    }
  }

  // 2. If stop.houseNumber was previously set, verify it isn't just a stop sequence number
  if (stop.houseNumber && stop.houseNumber.trim()) {
    const candidate = stop.houseNumber.trim();
    const isStopSequence = 
      /^0+\d+$/.test(candidate) || // leading zeros e.g. "001", "002"
      (stop.orderIndex && candidate === String(stop.orderIndex)) ||
      (currentIndex !== undefined && candidate === String(currentIndex + 1));

    if (!isStopSequence) {
      return candidate;
    }
  }

  // 3. Check customer name only if it contains a street address pattern
  // e.g. "123 Foster ville Road"
  if (stop.name) {
    const extractedFromName = extractHouseNumber(stop.name);
    if (extractedFromName) {
      const isStopSequence = 
        /^0+\d+$/.test(extractedFromName) ||
        (stop.orderIndex && extractedFromName === String(stop.orderIndex)) ||
        (currentIndex !== undefined && extractedFromName === String(currentIndex + 1));
      if (!isStopSequence) {
        return extractedFromName;
      }
    }
  }

  // 4. Fallback when address has no identifiable house number
  return '—';
}

/**
 * Extracts a house/building number and street from an address or text string
 */
export function extractAddressComponents(text: string): { houseNumber: string; streetName: string; fullAddress: string } {
  const clean = (text || '').trim();
  if (!clean) {
    return { houseNumber: '', streetName: '', fullAddress: '' };
  }

  // If this text is coordinate-only or location placeholder, return empty house number
  if (/^location\s*\(?/i.test(clean) || clean.toLowerCase() === 'location unavailable') {
    return { houseNumber: '', streetName: clean, fullAddress: clean };
  }

  // Strip route/stop ordering prefix if present (e.g., "002 - ", "Stop 2: ", "#002 - ")
  let addressText = clean.replace(/^(?:stop\s*#?\d+\s*[-:–—]\s*|#?0+\d+\s*[-:–—]\s*)/i, '').trim();

  // Strip leading Unit/Apt/Suite if it precedes the address:
  // e.g., "Apt 4B, 123 Foster ville Road" -> "123 Foster ville Road"
  const unitPrefixMatch = addressText.match(/^(?:apt\.?|apartment|unit|suite|ste\.?|room|rm\.?)\s*#?[a-z0-9-]+\s*,\s*(.+)$/i);
  if (unitPrefixMatch) {
    addressText = unitPrefixMatch[1].trim();
  }

  const houseNumber = extractHouseNumber(addressText);

  let streetName = addressText;
  if (houseNumber) {
    const index = addressText.indexOf(houseNumber);
    if (index !== -1) {
      const afterHouse = addressText.slice(index + houseNumber.length).trim();
      const commaIndex = afterHouse.indexOf(',');
      if (commaIndex !== -1) {
        streetName = afterHouse.slice(0, commaIndex).trim();
      } else {
        streetName = afterHouse;
      }
    }
  }

  return {
    houseNumber,
    streetName: streetName || clean,
    fullAddress: clean,
  };
}

/**
 * Validates latitude and longitude values
 */
export function isValidCoordinate(lat: number, lon: number): boolean {
  return (
    !isNaN(lat) &&
    !isNaN(lon) &&
    lat >= -90 &&
    lat <= 90 &&
    lon >= -180 &&
    lon <= 180 &&
    !(lat === 0 && lon === 0)
  );
}

/**
 * Helper to get text content of a tag or namespaced tag safely from XML element
 */
function getTagText(parent: Element, tagName: string): string {
  // 1. Direct getElementsByTagName (e.g. 'name', 'desc', 'cmt')
  const el = parent.getElementsByTagName(tagName)[0];
  if (el?.textContent && el.textContent.trim()) {
    return el.textContent.trim();
  }

  // 2. Namespaced or child matches (e.g. 'osmand:housenumber', 'addr:housenumber')
  const children = Array.from(parent.children);
  for (const child of children) {
    if (child.localName === tagName || child.nodeName.endsWith(`:${tagName}`)) {
      if (child.textContent?.trim()) return child.textContent.trim();
    }
    // Inspect inside <extensions>
    for (const sub of Array.from(child.children)) {
      if (sub.localName === tagName || sub.nodeName.endsWith(`:${tagName}`)) {
        if (sub.textContent?.trim()) return sub.textContent.trim();
      }
    }
  }

  return '';
}

/**
 * Parses raw GPX XML and extracts customer stops in the exact order they appear in the file.
 * Safely handles OsmAnd marker extensions, custom namespaces, and distinguishes route sequence numbers from house numbers.
 */
export function parseGPX(gpxContent: string, routeNameDefault = 'Imported Route'): { stops: RouteStop[]; routeName: string } {
  const cleanedContent = (gpxContent || '').replace(/^\uFEFF/, '').trim();
  if (!cleanedContent) {
    throw new Error('File content is empty.');
  }

  let xmlDoc: Document;
  if (typeof DOMParser !== 'undefined') {
    const parser = new DOMParser();
    xmlDoc = parser.parseFromString(cleanedContent, 'text/xml');
  } else {
    throw new Error('DOMParser unavailable in current runtime');
  }

  // Check for XML parsererror
  const parserError = xmlDoc.getElementsByTagName('parsererror')[0];
  if (parserError) {
    throw new Error('Invalid GPX/XML format. Please verify the file contains valid route/waypoint XML.');
  }

  // Extract route/metadata name if present
  let routeName = routeNameDefault;
  const metaEl = xmlDoc.getElementsByTagName('metadata')[0];
  const metaName = metaEl ? getTagText(metaEl, 'name') : '';
  const gpxName = getTagText(xmlDoc.documentElement, 'name');
  if (metaName) {
    routeName = metaName;
  } else if (gpxName) {
    routeName = gpxName;
  }

  // Collect points in exact file order.
  let pointElements = Array.from(xmlDoc.getElementsByTagName('wpt'));
  if (pointElements.length === 0) {
    pointElements = Array.from(xmlDoc.getElementsByTagName('rtept'));
  }
  if (pointElements.length === 0) {
    pointElements = Array.from(xmlDoc.getElementsByTagName('trkpt'));
  }

  if (pointElements.length === 0) {
    throw new Error('No customer waypoints (<wpt> or <rtept>) found in this GPX file.');
  }

  const stops: RouteStop[] = [];

  pointElements.forEach((pt, index) => {
    // 1. Coordinates parsing & validation
    const latStr = pt.getAttribute('lat');
    const lonStr = pt.getAttribute('lon');
    const parsedLat = latStr ? parseFloat(latStr) : NaN;
    const parsedLon = lonStr ? parseFloat(lonStr) : NaN;

    const hasValidCoords = isValidCoordinate(parsedLat, parsedLon);
    const finalLat = hasValidCoords ? parsedLat : 0;
    const finalLon = hasValidCoords ? parsedLon : 0;

    // 2. Text fields parsing
    const rawName = getTagText(pt, 'name');
    const rawDesc = getTagText(pt, 'desc');
    const rawCmt = getTagText(pt, 'cmt');
    const rawAddress = getTagText(pt, 'address');
    const osmandHouseNum = getTagText(pt, 'housenumber');
    const osmandStreet = getTagText(pt, 'street');

    // 3. Disambiguate customer name, stop sequence, and delivery address:
    let customerName = rawName || `Customer #${index + 1}`;
    let addressCandidate = rawAddress || rawDesc || rawCmt;
    let potentialAddressFromName = '';

    // If rawName has a sequence prefix like "002 - Marcus Vance" or "002 - 123 Foster ville Road":
    if (rawName.includes(' - ') || rawName.includes(' – ')) {
      const parts = rawName.split(/\s*[-–]\s*/);
      if (parts.length >= 2) {
        // First part is a stop sequence (e.g. "001", "002", "Stop 1", "#2"):
        if (/^(?:stop\s*)?#?\d+$/i.test(parts[0].trim())) {
          customerName = parts.slice(1).join(' - ').trim();
          // If the remaining part is an address (e.g. "123 Foster ville Road")
          if (/^\d+[A-Za-z]?\s+[A-Za-z]/.test(customerName)) {
            potentialAddressFromName = customerName;
          }
        } else if (/^(?:stop\s*)?#?\d+$/i.test(parts[parts.length - 1].trim())) {
          // Trailing stop sequence e.g. "Marcus Vance - 002"
          customerName = parts.slice(0, parts.length - 1).join(' - ').trim();
        }
      }
    } else if (/^#?0*\d+$/.test(rawName.trim())) {
      // Name is just a sequence number e.g. "002"
      const num = parseInt(rawName.trim().replace('#', ''), 10);
      customerName = `Customer #${num || (index + 1)}`;
    }

    if (!addressCandidate && potentialAddressFromName) {
      addressCandidate = potentialAddressFromName;
    }

    // Fallback if no addressCandidate exists
    if (!addressCandidate) {
      addressCandidate = hasValidCoords
        ? `Location (${finalLat.toFixed(5)}, ${finalLon.toFixed(5)})`
        : 'Location unavailable';
    }

    // 4. Extract genuine house number and street from the delivery address:
    const { houseNumber: parsedHouseNumber, streetName: parsedStreet, fullAddress } = extractAddressComponents(addressCandidate);
    
    // Explicit OsmAnd housenumber tag check (reject if it's a zero-padded stop sequence)
    let finalHouseNumber = parsedHouseNumber;
    if (!finalHouseNumber && osmandHouseNum && !/^0+\d+$/.test(osmandHouseNum.trim())) {
      finalHouseNumber = osmandHouseNum.trim();
    }

    // If still not found and customerName has a street address pattern
    if (!finalHouseNumber && customerName) {
      const nameExtracted = extractAddressComponents(customerName);
      if (nameExtracted.houseNumber && !/^0+\d+$/.test(nameExtracted.houseNumber)) {
        finalHouseNumber = nameExtracted.houseNumber;
      }
    }

    const finalStreetName = osmandStreet || parsedStreet || '';

    stops.push({
      id: `stop-${index + 1}-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      orderIndex: index + 1,
      name: customerName,
      houseNumber: finalHouseNumber,
      fullAddress: fullAddress,
      streetName: finalStreetName,
      lat: finalLat,
      lon: finalLon,
      desc: rawDesc || undefined,
      cmt: rawCmt || undefined,
      status: 'pending',
    });
  });

  return { stops, routeName };
}

/**
 * Generates valid GPX XML from RouteStop array (for export/OsmAnd companion download)
 */
export function exportToGPX(stops: RouteStop[], routeName = 'Customer Route'): string {
  const gpxHeader = `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="OsmAnd Route Companion" xmlns="http://www.topografix.com/GPX/1/1" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.topografix.com/GPX/1/1 http://www.topografix.com/GPX/1/1/gpx.xsd">
  <metadata>
    <name>${escapeXml(routeName)}</name>
    <desc>Customer route stops in sequential order</desc>
    <time>${new Date().toISOString()}</time>
  </metadata>
`;

  const waypoints = stops.map((stop) => {
    return `  <wpt lat="${stop.lat}" lon="${stop.lon}">
    <name>${escapeXml(stop.name)}</name>
    <desc>${escapeXml(stop.fullAddress)}</desc>
    <cmt>${escapeXml(`House #${stop.houseNumber || 'N/A'} - Status: ${stop.status}`)}</cmt>
  </wpt>`;
  }).join('\n');

  const gpxFooter = `\n</gpx>`;
  return gpxHeader + waypoints + gpxFooter;
}

function escapeXml(unsafe: string): string {
  return (unsafe || '').replace(/[<>&'"]/g, (c) => {
    switch (c) {
      case '<': return '&lt;';
      case '>': return '&gt;';
      case '&': return '&amp;';
      case '\'': return '&apos;';
      case '"': return '&quot;';
      default: return c;
    }
  });
}
