/**
 * Turn-by-Turn Navigation & Real-time GPS Service
 * Uses device GPS hardware and OpenStreetMap (OSM) routing engine
 */

export interface NavManeuver {
  type: string; // 'turn', 'depart', 'arrive', 'continue', 'fork', 'roundabout', etc.
  modifier?: string; // 'left', 'right', 'slight left', 'slight right', 'sharp left', 'sharp right', 'straight', 'uturn'
  instruction: string; // "Turn right onto Maple Grove Ave"
  streetName: string;
  distanceMeters: number;
  location: [number, number]; // [lon, lat]
}

export interface NavigationState {
  currentManeuver: NavManeuver | null;
  distanceToManeuverMeters: number;
  totalDistanceToDestinationMeters: number;
  estimatedTimeSeconds: number;
  gpsActive: boolean;
  gpsAccuracyMeters: number | null;
  currentSpeedMph: number | null;
  currentHeading: number | null;
  lastUpdated: number;
  source: 'osm-live' | 'gps-direct' | 'simulated';
  error: string | null;
}

/**
 * Calculates distance in meters between two lat/lon points using the Haversine formula
 */
export function calculateDistanceMeters(lat1: number, lon1: number, lat2: number, lon2: number): number {
  if (
    isNaN(lat1) || isNaN(lon1) || isNaN(lat2) || isNaN(lon2) ||
    (lat1 === 0 && lon1 === 0) || (lat2 === 0 && lon2 === 0)
  ) {
    return Infinity;
  }
  const R = 6371000; // Earth's radius in meters
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) *
      Math.cos(lat2 * (Math.PI / 180)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Calculates compass bearing from point 1 to point 2 (0 - 360 degrees)
 */
export function calculateBearing(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const y = Math.sin((lon2 - lon1) * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180));
  const x =
    Math.cos(lat1 * (Math.PI / 180)) * Math.sin(lat2 * (Math.PI / 180)) -
    Math.sin(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * Math.cos((lon2 - lon1) * (Math.PI / 180));
  const brng = (Math.atan2(y, x) * 180) / Math.PI;
  return (brng + 360) % 360;
}

/**
 * Convert bearing degrees to cardinal direction name
 */
export function bearingToDirection(bearing: number): string {
  const directions = ['North', 'Northeast', 'East', 'Southeast', 'South', 'Southwest', 'West', 'Northwest'];
  const index = Math.round(bearing / 45) % 8;
  return directions[index];
}

/**
 * Format distance in feet and miles (or meters/km) for rapid driver glanceability
 */
export function formatDistance(meters: number, useMetric = false): string {
  if (isNaN(meters) || meters < 0) return '0 ft';

  if (useMetric) {
    if (meters < 1000) {
      return `${Math.round(meters)} m`;
    }
    return `${(meters / 1000).toFixed(1)} km`;
  }

  // Imperial (US) standard for in-vehicle navigation
  const feet = meters * 3.28084;
  if (feet < 1000) {
    // Round to nearest 50 ft if above 200 ft, else nearest 10 ft
    if (feet > 200) {
      return `${Math.round(feet / 50) * 50} ft`;
    }
    return `${Math.max(10, Math.round(feet / 10) * 10)} ft`;
  }

  const miles = feet / 5280;
  if (miles < 10) {
    return `${miles.toFixed(1)} mi`;
  }
  return `${Math.round(miles)} mi`;
}

/**
 * Format estimated travel duration in minutes and hours
 */
export function formatDuration(seconds: number): string {
  if (isNaN(seconds) || seconds <= 0) return '1 min';
  const mins = Math.round(seconds / 60);
  if (mins < 60) {
    return `${Math.max(1, mins)} min`;
  }
  const hours = Math.floor(mins / 60);
  const remMins = mins % 60;
  return remMins > 0 ? `${hours}h ${remMins}m` : `${hours}h`;
}

/**
 * Generates natural driver maneuver instructions from OSRM step
 */
export function buildInstructionText(type: string, modifier: string | undefined, streetName: string, destinationName: string): string {
  const street = streetName && streetName.trim() ? streetName.trim() : '';
  const mod = (modifier || '').toLowerCase();
  const t = (type || '').toLowerCase();

  if (t === 'arrive') {
    return destinationName ? `Arrive at ${destinationName}` : 'Arrive at destination';
  }
  if (t === 'depart') {
    return street ? `Head out onto ${street}` : 'Head toward destination';
  }
  if (t === 'merge') {
    return mod.includes('left')
      ? (street ? `Merge left onto ${street}` : 'Merge left')
      : (street ? `Merge right onto ${street}` : 'Merge right');
  }
  if (t === 'on ramp' || t === 'off ramp' || t === 'ramp') {
    return street ? `Take ramp onto ${street}` : 'Take ramp';
  }
  if (t === 'fork') {
    return mod.includes('left')
      ? (street ? `Keep left at fork onto ${street}` : 'Keep left at fork')
      : (street ? `Keep right at fork onto ${street}` : 'Keep right at fork');
  }
  if (t === 'roundabout' || t === 'rotary') {
    return street ? `Enter roundabout toward ${street}` : 'Enter roundabout';
  }
  if (t === 'end of road') {
    return mod.includes('left')
      ? (street ? `Turn left at end onto ${street}` : 'Turn left at end of road')
      : (street ? `Turn right at end onto ${street}` : 'Turn right at end of road');
  }

  switch (mod) {
    case 'left':
      return street ? `Turn left onto ${street}` : 'Turn left';
    case 'right':
      return street ? `Turn right onto ${street}` : 'Turn right';
    case 'slight left':
      return street ? `Bear slightly left onto ${street}` : 'Bear slightly left';
    case 'slight right':
      return street ? `Bear slightly right onto ${street}` : 'Bear slightly right';
    case 'sharp left':
      return street ? `Make a sharp left onto ${street}` : 'Sharp left';
    case 'sharp right':
      return street ? `Make a sharp right onto ${street}` : 'Sharp right';
    case 'uturn':
      return street ? `Make a U-turn onto ${street}` : 'Make a U-turn';
    case 'straight':
      return street ? `Continue straight on ${street}` : 'Continue straight';
    default:
      if (t === 'continue' || t === 'new name') {
        return street ? `Continue onto ${street}` : 'Continue straight';
      }
      return street ? `Proceed onto ${street}` : 'Proceed along route';
  }
}

/**
 * Fetches real turn-by-turn driving route steps from OpenStreetMap OSRM routing engine
 */
export async function fetchOsmRoute(
  startLat: number,
  startLon: number,
  destLat: number,
  destLon: number,
  destName: string
): Promise<{ maneuvers: NavManeuver[]; totalDistance: number; totalDuration: number; coordinates: [number, number][] }> {
  // Free, public OpenStreetMap road-network routing machine
  const url = `https://router.project-osrm.org/route/v1/driving/${startLon},${startLat};${destLon},${destLat}?steps=true&overview=full&geometries=geojson`;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 7000);

  try {
    const response = await fetch(url, { signal: controller.signal });
    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`Routing server returned HTTP ${response.status}`);
    }

    const data = await response.json();
    if (data.code !== 'Ok' || !data.routes || data.routes.length === 0) {
      throw new Error('No driving route found between coordinates');
    }

    const route = data.routes[0];
    const leg = route.legs?.[0];
    const steps = leg?.steps || [];
    const coordinates: [number, number][] = route.geometry?.coordinates || [];

    const maneuvers: NavManeuver[] = steps.map((s: any) => {
      const type = s.maneuver?.type || 'turn';
      const modifier = s.maneuver?.modifier;
      const streetName = s.name || '';
      const instruction = buildInstructionText(type, modifier, streetName, destName);
      const location: [number, number] = s.maneuver?.location || [destLon, destLat];

      return {
        type,
        modifier,
        instruction,
        streetName,
        distanceMeters: s.distance || 0,
        location,
      };
    });

    return {
      maneuvers,
      totalDistance: route.distance || 0,
      totalDuration: route.duration || 0,
      coordinates,
    };
  } catch (err: any) {
    clearTimeout(timeoutId);
    throw err;
  }
}
