import { useState, useEffect, useRef, useCallback } from 'react';
import { RouteStop } from '../types/route';
import { calculateDistanceMeters, calculateBearing } from './navigationService';
import { triggerHaptic } from './voiceAndHaptics';

export interface GpsLocation {
  lat: number;
  lon: number;
  accuracy: number;
  speed: number | null; // mph
  heading: number | null;
  timestamp: number;
}

export interface UseGpsTrackerReturn {
  location: GpsLocation | null;
  gpsStatus: 'acquiring' | 'locked' | 'denied';
  gpsErrorMsg: string | null;
  distanceToCurrentMeters: number | null;
  distanceToCurrentFeet: number | null;
  isWithinGeofence: boolean;
  isConfirmedArrival: boolean;
  isSharedLocationWithPrevious: boolean;
  isSharedLocationWithNext: boolean;
  autoArrivalStatus: string;
  arrivalRadiusMeters: number;
  isPassedWithoutCompletion: boolean;
  simulateApproachAndPass: () => void;
  simulateApproachAndArrive: () => void;
  simulateCurbsidePassThrough: () => void;
  isSimulatingGps: boolean;
  stopGpsSimulation: () => void;
}

// Configurable constants and safeguards
export const DEFAULT_ARRIVAL_RADIUS_METERS = 152.4; // 500 feet proximity window
export const CURBSIDE_STOP_RADIUS_METERS = 16.0; // ~52 feet curbside arrival zone
export const PASS_THROUGH_MIN_DISTANCE_METERS = 20.0; // ~65 feet closest point threshold
const MAX_ACCURACY_THRESHOLD_METERS = 25.0; // Filter out inaccurate GPS drift (> 82 ft)
const COOLDOWN_MS = 5000; // Minimum time between auto-advances (5 seconds)
const PASSING_DISTANCE_INCREASE_METERS = 20.0; // Distance must expand by 20m from closest point to confirm vehicle passed

/**
 * Validate latitude and longitude coordinates
 */
export function isValidCoordinate(lat: number, lon: number): boolean {
  return (
    !isNaN(lat) &&
    !isNaN(lon) &&
    lat >= -90 &&
    lat <= 90 &&
    lon >= -180 &&
    lon <= 180 &&
    !(lat === 0 && lon === 0)
  );
}

/**
 * Calculates whether the straight line path between two consecutive GPS fixes
 * passed within radiusMeters of destination coordinates.
 */
export function checkSegmentPassesPoint(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
  destLat: number,
  destLon: number,
  radiusMeters: number
): { passed: boolean; minDistance: number; t: number } {
  const latRad = (destLat * Math.PI) / 180;
  const cosLat = Math.cos(latRad);
  const mPerDegLat = 111132.92;
  const mPerDegLon = 111412.84 * cosLat;

  const x1 = (lon1 - destLon) * mPerDegLon;
  const y1 = (lat1 - destLat) * mPerDegLat;
  const x2 = (lon2 - destLon) * mPerDegLon;
  const y2 = (lat2 - destLat) * mPerDegLat;

  const dx = x2 - x1;
  const dy = y2 - y1;
  const lenSq = dx * dx + dy * dy;

  if (lenSq === 0) {
    const d = Math.sqrt(x1 * x1 + y1 * y1);
    return { passed: d <= radiusMeters, minDistance: d, t: 0 };
  }

  const t = -(x1 * dx + y1 * dy) / lenSq;

  if (t > 0 && t < 1) {
    const projX = x1 + t * dx;
    const projY = y1 + t * dy;
    const minDistance = Math.sqrt(projX * projX + projY * projY);
    return { passed: minDistance <= radiusMeters, minDistance, t };
  }

  const d1 = Math.sqrt(x1 * x1 + y1 * y1);
  const d2 = Math.sqrt(x2 * x2 + y2 * y2);
  const minDistance = Math.min(d1, d2);
  return { passed: minDistance <= radiusMeters, minDistance, t };
}

export function useGpsTracker(
  currentStop: RouteStop | null,
  previousStop: RouteStop | null,
  nextStop: RouteStop | null,
  onAutoAdvance: () => void,
  arrivalRadiusMeters: number = DEFAULT_ARRIVAL_RADIUS_METERS,
  roadRemainingMeters?: number | null
): UseGpsTrackerReturn {
  const [location, setLocation] = useState<GpsLocation | null>(null);
  const [gpsStatus, setGpsStatus] = useState<'acquiring' | 'locked' | 'denied'>('acquiring');
  const [gpsErrorMsg, setGpsErrorMsg] = useState<string | null>(null);
  const [arrivalStateDesc, setArrivalStateDesc] = useState<string>('Monitoring GPS');
  const [isPassedWithoutCompletion, setIsPassedWithoutCompletion] = useState<boolean>(false);

  const [isConfirmedArrival, setIsConfirmedArrival] = useState<boolean>(false);

  // Simulation state for phone/desktop indoor testing
  const [isSimulatingGps, setIsSimulatingGps] = useState(false);
  const simIntervalRef = useRef<number | null>(null);

  // Safeguard & Tracking Refs
  const minDistanceSeenRef = useRef<number>(Infinity);
  const enteredArrivalZoneRef = useRef<boolean>(false);
  const consecutiveInsideCountRef = useRef<number>(0);
  const consecutiveCloseCountRef = useRef<number>(0);
  const consecutivePassCountRef = useRef<number>(0);
  const lastLocationRef = useRef<GpsLocation | null>(null);
  const lastDistanceRef = useRef<number | null>(null);
  const lastAdvanceTimestampRef = useRef<number>(0);
  const lastAdvancedStopIdRef = useRef<string | null>(null);
  const isAdvancingRef = useRef<boolean>(false);
  const departurePendingRef = useRef<boolean>(false);
  const activeStopIdRef = useRef<string | null>(null);

  // Keep stable refs to latest props to prevent watchPosition re-binding
  const currentStopRef = useRef(currentStop);
  currentStopRef.current = currentStop;

  const previousStopRef = useRef(previousStop);
  previousStopRef.current = previousStop;

  const nextStopRef = useRef(nextStop);
  nextStopRef.current = nextStop;

  const onAutoAdvanceRef = useRef(onAutoAdvance);
  onAutoAdvanceRef.current = onAutoAdvance;

  const arrivalRadiusRef = useRef(arrivalRadiusMeters);
  arrivalRadiusRef.current = arrivalRadiusMeters;

  const roadRemainingMetersRef = useRef(roadRemainingMeters);
  roadRemainingMetersRef.current = roadRemainingMeters;

  // Shared location check (within 18m of previous/next stop)
  const isSharedLocationWithPrevious = Boolean(
    currentStop &&
    previousStop &&
    isValidCoordinate(currentStop.lat, currentStop.lon) &&
    isValidCoordinate(previousStop.lat, previousStop.lon) &&
    calculateDistanceMeters(currentStop.lat, currentStop.lon, previousStop.lat, previousStop.lon) < 18
  );

  const isSharedLocationWithNext = Boolean(
    currentStop &&
    nextStop &&
    isValidCoordinate(currentStop.lat, currentStop.lon) &&
    isValidCoordinate(nextStop.lat, nextStop.lon) &&
    calculateDistanceMeters(currentStop.lat, currentStop.lon, nextStop.lat, nextStop.lon) < 18
  );

  const isSharedLocationWithPreviousRef = useRef(isSharedLocationWithPrevious);
  isSharedLocationWithPreviousRef.current = isSharedLocationWithPrevious;

  // Reset tracking state whenever the active customer changes
  useEffect(() => {
    const newStopId = currentStop?.id || null;
    if (newStopId !== activeStopIdRef.current) {
      activeStopIdRef.current = newStopId;
      minDistanceSeenRef.current = Infinity;
      enteredArrivalZoneRef.current = false;
      consecutiveInsideCountRef.current = 0;
      consecutiveCloseCountRef.current = 0;
      consecutivePassCountRef.current = 0;
      lastDistanceRef.current = null;
      isAdvancingRef.current = false;
      setIsConfirmedArrival(false);
      setIsPassedWithoutCompletion(false);

      // If driver is currently inside arrival radius of the NEW stop at activation,
      // require departure/movement or dwell cooldown before allowing auto-advance.
      if (
        location &&
        currentStop &&
        isValidCoordinate(currentStop.lat, currentStop.lon)
      ) {
        const d = calculateDistanceMeters(location.lat, location.lon, currentStop.lat, currentStop.lon);
        if (d <= arrivalRadiusRef.current) {
          departurePendingRef.current = true;
        } else {
          departurePendingRef.current = false;
        }
      } else {
        departurePendingRef.current = false;
      }
    }
  }, [currentStop?.id]);

  /**
   * Core Arrival & Missed Stop Decision Engine
   * Evaluates current GPS location against verified coordinates of currentStop.
   * Separates 500-foot proximity window from confirmed arrival at the customer address.
   */
  const processLocationUpdate = useCallback((currentLoc: GpsLocation) => {
    const activeStop = currentStopRef.current;
    if (!activeStop) {
      setArrivalStateDesc('No Active Route');
      return;
    }

    // 1. Verify Destination Coordinates
    if (!isValidCoordinate(activeStop.lat, activeStop.lon)) {
      setArrivalStateDesc('Invalid Destination Coordinates (Manual Skip)');
      return;
    }

    // 2. Reject stale updates (> 4.5s old)
    if (Date.now() - currentLoc.timestamp > 4500) {
      return;
    }

    // 3. Filter out inaccurate GPS readings (> 30m error)
    if (currentLoc.accuracy > MAX_ACCURACY_THRESHOLD_METERS) {
      setArrivalStateDesc(`GPS Accuracy ±${Math.round(currentLoc.accuracy * 3.28084)} ft (Refining...)`);
      return;
    }

    const proximityRadius = arrivalRadiusRef.current || DEFAULT_ARRIVAL_RADIUS_METERS; // 500 ft proximity window
    const distToDestination = calculateDistanceMeters(
      currentLoc.lat,
      currentLoc.lon,
      activeStop.lat,
      activeStop.lon
    );
    const feetToDestination = Math.round(distToDestination * 3.28084);

    // Track minimum distance seen for this active stop
    if (distToDestination < minDistanceSeenRef.current) {
      minDistanceSeenRef.current = distToDestination;
    }

    const prevLoc = lastLocationRef.current;
    const prevDist = lastDistanceRef.current;
    const now = Date.now();

    // Check if path segment between prevLoc and currentLoc passed closer to verified customer coordinates
    if (prevLoc && isValidCoordinate(prevLoc.lat, prevLoc.lon)) {
      const segCheck = checkSegmentPassesPoint(
        prevLoc.lat,
        prevLoc.lon,
        currentLoc.lat,
        currentLoc.lon,
        activeStop.lat,
        activeStop.lon,
        PASS_THROUGH_MIN_DISTANCE_METERS
      );
      if (segCheck.passed && segCheck.minDistance < minDistanceSeenRef.current) {
        minDistanceSeenRef.current = segCheck.minDistance;
      }
    }

    // 4. Prevent immediate cascade / double advance
    if (isAdvancingRef.current) return;
    if (now - lastAdvanceTimestampRef.current < COOLDOWN_MS) return;
    if (lastAdvancedStopIdRef.current === activeStop.id) return;

    // 5. Shared Location Safeguard (Multi-unit building or shared entrance)
    if (isSharedLocationWithPreviousRef.current && lastAdvancedStopIdRef.current === previousStopRef.current?.id) {
      setArrivalStateDesc('Shared Address · Tap Skip when done');
      return;
    }

    // 6. Departure Latch (if activated while already near the stop)
    if (departurePendingRef.current) {
      if (distToDestination > proximityRadius * 1.1) {
        departurePendingRef.current = false;
      } else if (now - lastAdvanceTimestampRef.current > 8000 && !isSharedLocationWithPreviousRef.current) {
        departurePendingRef.current = false;
      } else {
        setArrivalStateDesc('Departing Previous Stop...');
        return;
      }
    }

    // 7. Parallel Road Rejection
    const roadDist = roadRemainingMetersRef.current;
    if (roadDist !== undefined && roadDist !== null && roadDist > Math.max(proximityRadius * 2.2, 160)) {
      setArrivalStateDesc(`Parallel Road / Route Distance ${Math.round(roadDist * 3.28084)} ft`);
      return;
    }

    // Dynamic Curbside Stop Radius adapted to device GPS accuracy
    // True curbside zone is 14m - 18m (~45 - 59 ft) around the verified customer house coordinates
    const curbsideRadius = Math.min(18.0, Math.max(14.0, currentLoc.accuracy * 0.9));
    const isWithinCurbside = distToDestination <= curbsideRadius;
    const isStoppedOrCrawling = currentLoc.speed !== null ? currentLoc.speed <= 2.5 : (prevDist !== null && Math.abs(distToDestination - prevDist) < 1.0);
    const isClosingDistance = prevDist !== null && distToDestination < prevDist - 1.2;
    const isMovingAway = prevDist !== null && distToDestination > prevDist + 1.2;

    let isReliablyArrived = false;
    let arrivalReason = '';

    // ========================================================
    // ARRIVAL DETECTION (Separated from 500-ft Proximity Window)
    // ========================================================

    // Case 1: Curbside / Driveway Stop or Standstill at Address
    if (isWithinCurbside) {
      if (isClosingDistance && distToDestination > 9.0) {
        // Vehicle is still approaching the curb/driveway from further back: do not trigger arrival yet!
        consecutiveCloseCountRef.current = 0;
        setArrivalStateDesc(`At address · Pulling up (${feetToDestination} ft)`);
      } else if (isStoppedOrCrawling) {
        consecutiveCloseCountRef.current += 1;
        // Require 3 consecutive stable readings at standstill (~3 seconds of stop at customer house)
        if (consecutiveCloseCountRef.current >= 3) {
          isReliablyArrived = true;
          arrivalReason = `Stopped curbside at address (${feetToDestination} ft)`;
        } else {
          setArrivalStateDesc(`At address · Stopped (${feetToDestination} ft, confirming...)`);
        }
      } else if (distToDestination <= 8.0) {
        // Direct doorstep / mailbox proximity (< 26 ft): require 2 consecutive fixes
        consecutiveCloseCountRef.current += 1;
        if (consecutiveCloseCountRef.current >= 2) {
          isReliablyArrived = true;
          arrivalReason = `At customer doorstep/driveway (${feetToDestination} ft)`;
        } else {
          setArrivalStateDesc(`At doorstep (${feetToDestination} ft)`);
        }
      } else {
        consecutiveCloseCountRef.current = 0;
        setArrivalStateDesc(`At address (${feetToDestination} ft)`);
      }
    } else {
      consecutiveCloseCountRef.current = 0;
    }

    // Case 2: Pass-Through Arrival (Rolled past address at delivery pace)
    // Vehicle came within closest approach threshold (minDistanceSeen <= PASS_THROUGH_MIN_DISTANCE_METERS)
    // and is now moving past the customer with destination behind the vehicle
    if (!isReliablyArrived && minDistanceSeenRef.current <= PASS_THROUGH_MIN_DISTANCE_METERS) {
      const hasPassedMin = distToDestination >= minDistanceSeenRef.current + 5.5;
      const isDeliveryPace = currentLoc.speed === null || currentLoc.speed <= 25.0;

      // Heading check: destination is behind vehicle
      const bearingToDest = calculateBearing(currentLoc.lat, currentLoc.lon, activeStop.lat, activeStop.lon);
      let isBehindVehicle = true;
      if (currentLoc.heading !== null) {
        const diff = Math.abs(currentLoc.heading - bearingToDest);
        const normalizedDiff = diff > 180 ? 360 - diff : diff;
        isBehindVehicle = normalizedDiff > 70;
      }

      if (hasPassedMin && isMovingAway && isBehindVehicle && isDeliveryPace) {
        consecutivePassCountRef.current += 1;
        if (consecutivePassCountRef.current >= 2) {
          isReliablyArrived = true;
          arrivalReason = `Passed customer address (${Math.round(minDistanceSeenRef.current * 3.28084)} ft min)`;
        }
      } else {
        consecutivePassCountRef.current = 0;
      }
    } else {
      consecutivePassCountRef.current = 0;
    }

    // Case 3: Still Approaching the House within the 500-ft Proximity Window
    // If vehicle is approaching, NEVER trigger arrival while closing distance!
    if (!isReliablyArrived && distToDestination <= proximityRadius) {
      setArrivalStateDesc(`Approaching customer: ${feetToDestination} ft`);
    }

    // Case 4: Missed Destination (Bypassed without arrival confirmation -> Turn around)
    if (!isReliablyArrived && minDistanceSeenRef.current <= proximityRadius) {
      const isExpandingSignificantly = distToDestination >= minDistanceSeenRef.current + PASSING_DISTANCE_INCREASE_METERS;
      const bearingToDest = calculateBearing(currentLoc.lat, currentLoc.lon, activeStop.lat, activeStop.lon);
      let headingPointsAway = false;
      if (currentLoc.heading !== null) {
        const diff = Math.abs(currentLoc.heading - bearingToDest);
        const normalizedDiff = diff > 180 ? 360 - diff : diff;
        headingPointsAway = normalizedDiff > 75;
      }

      // Fast pass (> 25 mph) or missed address without coming into curbside zone (> PASS_THROUGH_MIN_DISTANCE_METERS)
      if (isExpandingSignificantly && (isMovingAway || headingPointsAway) && (minDistanceSeenRef.current > PASS_THROUGH_MIN_DISTANCE_METERS || (currentLoc.speed !== null && currentLoc.speed > 25.0))) {
        setIsPassedWithoutCompletion(true);
        setArrivalStateDesc(`Missed stop (${feetToDestination} ft) · Recalculating...`);
        lastLocationRef.current = currentLoc;
        lastDistanceRef.current = distToDestination;
        return;
      }
    }

    // ========================================================
    // EXECUTE CONFIRMED ARRIVAL
    // ========================================================
    if (isReliablyArrived) {
      isAdvancingRef.current = true;
      lastAdvanceTimestampRef.current = now;
      lastAdvancedStopIdRef.current = activeStop.id;
      consecutiveCloseCountRef.current = 0;
      consecutivePassCountRef.current = 0;
      minDistanceSeenRef.current = Infinity;
      setIsPassedWithoutCompletion(false);
      setIsConfirmedArrival(true);

      setArrivalStateDesc(`Arrived: ${arrivalReason}`);
      triggerHaptic('complete');
      onAutoAdvanceRef.current();

      setTimeout(() => {
        setIsConfirmedArrival(false);
      }, 3000);
      return;
    }

    // General navigation tracking outside 500ft window
    if (distToDestination > proximityRadius) {
      setArrivalStateDesc(`${feetToDestination} ft to customer (Window: ${Math.round(proximityRadius * 3.28084)} ft)`);
    }

    lastLocationRef.current = currentLoc;
    lastDistanceRef.current = distToDestination;
  }, []);

  // Mount native Android GPS watcher
  useEffect(() => {
    if (typeof window === 'undefined' || !('geolocation' in navigator)) {
      setGpsStatus('denied');
      setGpsErrorMsg('GPS hardware not supported by this browser.');
      return;
    }

    setGpsStatus('acquiring');

    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        if (isSimulatingGps) return;

        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;
        const accuracy = pos.coords.accuracy || 8;
        const speed = pos.coords.speed !== null && pos.coords.speed >= 0
          ? Math.round(pos.coords.speed * 2.23694)
          : null;
        const heading = pos.coords.heading !== null && !isNaN(pos.coords.heading)
          ? pos.coords.heading
          : null;

        const currentLoc: GpsLocation = {
          lat,
          lon,
          accuracy,
          speed,
          heading,
          timestamp: pos.timestamp || Date.now(),
        };

        setLocation(currentLoc);
        setGpsStatus('locked');
        setGpsErrorMsg(null);

        processLocationUpdate(currentLoc);
      },
      (err) => {
        if (isSimulatingGps) return;
        setGpsStatus('denied');
        setGpsErrorMsg(err.message || 'GPS hardware access denied.');
      },
      {
        enableHighAccuracy: true,
        maximumAge: 1000,
        timeout: 10000,
      }
    );

    return () => {
      try {
        navigator.geolocation.clearWatch(watchId);
      } catch (e) {}
    };
  }, [processLocationUpdate, isSimulatingGps]);

  // Clean up any running simulation on unmount
  useEffect(() => {
    return () => {
      if (simIntervalRef.current) {
        window.clearInterval(simIntervalRef.current);
      }
    };
  }, []);

  /**
   * Interactive Simulator 1: Approach within 500ft proximity window, stop at address curbside, confirm arrival, and advance.
   */
  const simulateApproachAndArrive = useCallback(() => {
    const activeStop = currentStopRef.current;
    if (!activeStop || !isValidCoordinate(activeStop.lat, activeStop.lon)) return;

    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    setIsSimulatingGps(true);
    setGpsStatus('locked');
    setGpsErrorMsg(null);
    setIsPassedWithoutCompletion(false);
    setIsConfirmedArrival(false);

    const latMeters = 111132.92;
    const destLat = activeStop.lat;
    const destLon = activeStop.lon;

    // Approaching:
    // -130m (~425 ft): inside 500ft proximity window, NOT arrived
    // -75m (~245 ft): approaching customer, NOT arrived
    // -35m (~115 ft): approaching customer, NOT arrived
    // -14m (~45 ft): pulling up to address curbside
    // 0m (0 ft): pulled up to address, speed 0 (reading 1)
    // 0m (0 ft): stopped at address, speed 0 (reading 2)
    // 0m (0 ft): stopped at address, speed 0 (reading 3 -> confirms arrival and advances)
    const waypoints = [
      { offset: -130, speed: 25 },
      { offset: -75, speed: 20 },
      { offset: -35, speed: 12 },
      { offset: -14, speed: 3 },
      { offset: 0, speed: 0 },
      { offset: 0, speed: 0 },
      { offset: 0, speed: 0 },
    ];
    let step = 0;

    simIntervalRef.current = window.setInterval(() => {
      if (step >= waypoints.length) {
        if (simIntervalRef.current) {
          window.clearInterval(simIntervalRef.current);
          simIntervalRef.current = null;
        }
        setIsSimulatingGps(false);
        return;
      }

      const wp = waypoints[step];
      const simLat = destLat + (wp.offset / latMeters);
      const simLon = destLon;

      const simLoc: GpsLocation = {
        lat: simLat,
        lon: simLon,
        accuracy: 3,
        speed: wp.speed,
        heading: 0,
        timestamp: Date.now(),
      };

      setLocation(simLoc);
      processLocationUpdate(simLoc);

      step += 1;
    }, 1100);
  }, [processLocationUpdate]);

  /**
   * Interactive Simulator 2: Curbside Pass-Through Delivery (rolls past at delivery speed ~8-10 mph).
   * Confirms pass-through arrival as GPS readings cross the address threshold.
   */
  const simulateCurbsidePassThrough = useCallback(() => {
    const activeStop = currentStopRef.current;
    if (!activeStop || !isValidCoordinate(activeStop.lat, activeStop.lon)) return;

    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    setIsSimulatingGps(true);
    setGpsStatus('locked');
    setGpsErrorMsg(null);
    setIsPassedWithoutCompletion(false);
    setIsConfirmedArrival(false);

    const latMeters = 111132.92;
    const destLat = activeStop.lat;
    const destLon = activeStop.lon;

    // Rolls past address at curbside delivery pace (10 mph):
    // -60m -> -25m -> 0m (curbside pass) -> +12m (crossed threshold 1) -> +24m (crossed threshold 2)
    const waypoints = [
      { offset: -60, speed: 18 },
      { offset: -25, speed: 14 },
      { offset: 0, speed: 10 },  // Closest curbside approach
      { offset: 12, speed: 10 }, // 1st reading moving away past destination
      { offset: 24, speed: 10 }, // 2nd reading moving away past destination -> confirms pass-through arrival
    ];
    let step = 0;

    simIntervalRef.current = window.setInterval(() => {
      if (step >= waypoints.length) {
        if (simIntervalRef.current) {
          window.clearInterval(simIntervalRef.current);
          simIntervalRef.current = null;
        }
        setIsSimulatingGps(false);
        return;
      }

      const wp = waypoints[step];
      const simLat = destLat + (wp.offset / latMeters);
      const simLon = destLon + (6 / (latMeters * Math.cos(destLat * Math.PI / 180)));

      const simLoc: GpsLocation = {
        lat: simLat,
        lon: simLon,
        accuracy: 3,
        speed: wp.speed,
        heading: 0,
        timestamp: Date.now(),
      };

      setLocation(simLoc);
      processLocationUpdate(simLoc);

      step += 1;
    }, 1100);
  }, [processLocationUpdate]);

  /**
   * Interactive Simulator 3: Approach, DRIVE PAST at 28 mph without stopping,
   * triggers live OSRM route recalculation (Turn around as soon as possible)!
   */
  const simulateApproachAndPass = useCallback(() => {
    const activeStop = currentStopRef.current;
    if (!activeStop || !isValidCoordinate(activeStop.lat, activeStop.lon)) return;

    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    setIsSimulatingGps(true);
    setGpsStatus('locked');
    setGpsErrorMsg(null);

    const latMeters = 111132.92;
    const destLat = activeStop.lat;
    const destLon = activeStop.lon;

    // Passes from -100m south to +90m north at 28 mph without slowing down
    const waypoints = [
      { offset: -100, speed: 28 },
      { offset: -45, speed: 28 },
      { offset: 0, speed: 28 },  // Driven directly past at 28 mph
      { offset: 45, speed: 28 }, // Missed address, continuing down street
      { offset: 90, speed: 28 }, // Recalculation active
    ];
    let step = 0;

    simIntervalRef.current = window.setInterval(() => {
      if (step >= waypoints.length) {
        if (simIntervalRef.current) {
          window.clearInterval(simIntervalRef.current);
          simIntervalRef.current = null;
        }
        setIsSimulatingGps(false);
        return;
      }

      const wp = waypoints[step];
      const simLat = destLat + (wp.offset / latMeters);
      const simLon = destLon + (12 / (latMeters * Math.cos(destLat * Math.PI / 180)));

      const simLoc: GpsLocation = {
        lat: simLat,
        lon: simLon,
        accuracy: 4,
        speed: wp.speed,
        heading: 0, // Traveling North away from destination
        timestamp: Date.now(),
      };

      setLocation(simLoc);
      processLocationUpdate(simLoc);

      step += 1;
    }, 1200);
  }, [processLocationUpdate]);

  const stopGpsSimulation = useCallback(() => {
    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }
    setIsSimulatingGps(false);
  }, []);

  // Calculated reactive metrics for UI display
  let distanceToCurrentMeters: number | null = null;
  let distanceToCurrentFeet: number | null = null;
  let isWithinGeofence = false;

  if (location && currentStop && isValidCoordinate(currentStop.lat, currentStop.lon)) {
    distanceToCurrentMeters = calculateDistanceMeters(location.lat, location.lon, currentStop.lat, currentStop.lon);
    distanceToCurrentFeet = Math.round(distanceToCurrentMeters * 3.28084);
    isWithinGeofence = distanceToCurrentMeters <= arrivalRadiusMeters;
  }

  let finalArrivalStatus = arrivalStateDesc;
  if (gpsStatus === 'denied') {
    finalArrivalStatus = 'GPS Disabled';
  } else if (gpsStatus === 'acquiring') {
    finalArrivalStatus = 'Acquiring Satellites...';
  } else if (isConfirmedArrival) {
    finalArrivalStatus = `Arrived at Stop (${distanceToCurrentFeet} ft)`;
  } else if (isPassedWithoutCompletion) {
    finalArrivalStatus = `Passed stop (${distanceToCurrentFeet} ft) · Recalculating...`;
  } else if (isSimulatingGps) {
    finalArrivalStatus = `Simulating Road Progress (${distanceToCurrentFeet} ft)`;
  } else if (isWithinGeofence) {
    finalArrivalStatus = isSharedLocationWithPrevious
      ? 'Shared Address · Tap Skip when done'
      : `Customer nearby (${distanceToCurrentFeet} ft / ${Math.round(arrivalRadiusMeters * 3.28084)} ft window)`;
  }

  return {
    location,
    gpsStatus,
    gpsErrorMsg,
    distanceToCurrentMeters,
    distanceToCurrentFeet,
    isWithinGeofence,
    isConfirmedArrival,
    isSharedLocationWithPrevious,
    isSharedLocationWithNext,
    autoArrivalStatus: finalArrivalStatus,
    arrivalRadiusMeters,
    isPassedWithoutCompletion,
    simulateApproachAndPass,
    simulateApproachAndArrive,
    simulateCurbsidePassThrough,
    isSimulatingGps,
    stopGpsSimulation,
  };
}
