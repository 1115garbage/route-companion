import { useState, useEffect, useRef } from 'react';
import { RouteStop } from '../types/route';
import { calculateDistanceMeters } from './navigationService';
import { triggerHaptic } from './voiceAndHaptics';

export interface GpsLocation {
  lat: number;
  lon: number;
  accuracy: number;
  speed: number | null; // mph
  heading: number | null;
  timestamp: number;
}

export interface UseGpsTrackerReturn {
  location: GpsLocation | null;
  gpsStatus: 'acquiring' | 'locked' | 'denied';
  gpsErrorMsg: string | null;
  distanceToCurrentMeters: number | null;
  distanceToCurrentFeet: number | null;
  isWithinGeofence: boolean;
  isSharedLocationWithPrevious: boolean;
  isSharedLocationWithNext: boolean;
  autoArrivalStatus: string;
}

const GEOFENCE_THRESHOLD_METERS = 15.24; // Approximately 50 feet
const MAX_ACCURACY_THRESHOLD_METERS = 25.0; // Filter out drifted/inaccurate GPS readings (> ~80 ft accuracy)
const CONSECUTIVE_CONFIRMATIONS_REQUIRED = 2; // Safeguard against single-sample GPS drift
const COOLDOWN_MS = 4000; // Minimum time between auto-advances

export function useGpsTracker(
  currentStop: RouteStop | null,
  previousStop: RouteStop | null,
  nextStop: RouteStop | null,
  onAutoAdvance: () => void
): UseGpsTrackerReturn {
  const [location, setLocation] = useState<GpsLocation | null>(null);
  const [gpsStatus, setGpsStatus] = useState<'acquiring' | 'locked' | 'denied'>('acquiring');
  const [gpsErrorMsg, setGpsErrorMsg] = useState<string | null>(null);

  // Safeguards state
  const consecutiveWithinGeofenceCountRef = useRef(0);
  const lastAdvanceTimestampRef = useRef(0);
  const lastAdvancedStopIdRef = useRef<string | null>(null);

  // Check if current stop shares identical coordinates with previous or next stop (within 15m)
  const isSharedLocationWithPrevious = Boolean(
    currentStop &&
    previousStop &&
    calculateDistanceMeters(currentStop.lat, currentStop.lon, previousStop.lat, previousStop.lon) < GEOFENCE_THRESHOLD_METERS
  );

  const isSharedLocationWithNext = Boolean(
    currentStop &&
    nextStop &&
    calculateDistanceMeters(currentStop.lat, currentStop.lon, nextStop.lat, nextStop.lon) < GEOFENCE_THRESHOLD_METERS
  );

  // Reset consecutive confirmation count when currentStop changes
  useEffect(() => {
    consecutiveWithinGeofenceCountRef.current = 0;
  }, [currentStop?.id]);

  useEffect(() => {
    if (!('geolocation' in navigator)) {
      setGpsStatus('denied');
      setGpsErrorMsg('GPS hardware not supported by this browser.');
      return;
    }

    setGpsStatus('acquiring');

    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;
        const accuracy = pos.coords.accuracy || 10;
        const speed = pos.coords.speed !== null && pos.coords.speed >= 0 ? Math.round(pos.coords.speed * 2.23694) : null;
        const heading = pos.coords.heading;

        const currentLoc: GpsLocation = {
          lat,
          lon,
          accuracy,
          speed,
          heading,
          timestamp: pos.timestamp || Date.now(),
        };

        setLocation(currentLoc);
        setGpsStatus('locked');
        setGpsErrorMsg(null);

        // Run Auto-Arrival check if we have a valid current stop
        if (!currentStop) return;

        const dist = calculateDistanceMeters(lat, lon, currentStop.lat, currentStop.lon);

        // Safeguard 1: Ignore readings with poor accuracy (GPS drift spikes)
        if (accuracy > MAX_ACCURACY_THRESHOLD_METERS) {
          consecutiveWithinGeofenceCountRef.current = 0;
          return;
        }

        // Safeguard 2: Check if within ~50 feet (15.24m)
        if (dist <= GEOFENCE_THRESHOLD_METERS) {
          // Safeguard 3: Check if this stop shares identical coordinates with previous stop
          // If this stop has the exact same coordinates as the stop we just completed,
          // do NOT auto-advance immediately to prevent silently skipping! Require manual SKIP when done.
          if (isSharedLocationWithPrevious && lastAdvancedStopIdRef.current === previousStop?.id) {
            // Stay on this stop so driver sees it
            return;
          }

          // Safeguard 4: Prevent repeated triggers on the same stop
          if (lastAdvancedStopIdRef.current === currentStop.id) {
            return;
          }

          // Safeguard 5: Debounce cooldown
          const now = Date.now();
          if (now - lastAdvanceTimestampRef.current < COOLDOWN_MS) {
            return;
          }

          // Safeguard 6: Multi-sample confirmation (need consecutive fixes inside 50 ft)
          consecutiveWithinGeofenceCountRef.current += 1;

          if (consecutiveWithinGeofenceCountRef.current >= CONSECUTIVE_CONFIRMATIONS_REQUIRED) {
            lastAdvanceTimestampRef.current = now;
            lastAdvancedStopIdRef.current = currentStop.id;
            consecutiveWithinGeofenceCountRef.current = 0;

            triggerHaptic('complete');
            onAutoAdvance();
          }
        } else {
          // Outside geofence: reset consecutive counter
          consecutiveWithinGeofenceCountRef.current = 0;
        }
      },
      (err) => {
        if (err.code === err.PERMISSION_DENIED) {
          setGpsStatus('denied');
          setGpsErrorMsg('Location permission denied. Enable GPS in Android Settings.');
        } else {
          setGpsStatus('acquiring');
          setGpsErrorMsg('Acquiring satellite lock...');
        }
      },
      {
        enableHighAccuracy: true,
        maximumAge: 1000,
        timeout: 10000,
      }
    );

    return () => {
      navigator.geolocation.clearWatch(watchId);
    };
  }, [currentStop?.id, isSharedLocationWithPrevious, previousStop?.id, onAutoAdvance]);

  let distanceToCurrentMeters: number | null = null;
  let distanceToCurrentFeet: number | null = null;
  let isWithinGeofence = false;

  if (location && currentStop) {
    distanceToCurrentMeters = calculateDistanceMeters(location.lat, location.lon, currentStop.lat, currentStop.lon);
    distanceToCurrentFeet = Math.round(distanceToCurrentMeters * 3.28084);
    isWithinGeofence = distanceToCurrentMeters <= GEOFENCE_THRESHOLD_METERS;
  }

  let autoArrivalStatus = 'Monitoring GPS';
  if (gpsStatus === 'denied') {
    autoArrivalStatus = 'GPS Disabled';
  } else if (gpsStatus === 'acquiring') {
    autoArrivalStatus = 'Acquiring Satellites...';
  } else if (isWithinGeofence) {
    autoArrivalStatus = isSharedLocationWithPrevious
      ? 'Shared Location (Tap Skip when done)'
      : 'Within 50 ft · Arrived';
  } else if (distanceToCurrentFeet !== null) {
    autoArrivalStatus = `${distanceToCurrentFeet} ft to 50 ft geofence`;
  }

  return {
    location,
    gpsStatus,
    gpsErrorMsg,
    distanceToCurrentMeters,
    distanceToCurrentFeet,
    isWithinGeofence,
    isSharedLocationWithPrevious,
    isSharedLocationWithNext,
    autoArrivalStatus,
  };
}
