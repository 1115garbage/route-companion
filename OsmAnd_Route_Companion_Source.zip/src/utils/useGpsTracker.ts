import { useState, useEffect, useRef, useCallback } from 'react';
import { RouteStop } from '../types/route';
import { calculateDistanceMeters, calculateBearing } from './navigationService';
import { triggerHaptic } from './voiceAndHaptics';

export interface GpsLocation {
  lat: number;
  lon: number;
  accuracy: number;
  speed: number | null; // mph
  heading: number | null;
  timestamp: number;
}

export interface UseGpsTrackerReturn {
  location: GpsLocation | null;
  gpsStatus: 'acquiring' | 'locked' | 'denied';
  gpsErrorMsg: string | null;
  distanceToCurrentMeters: number | null;
  distanceToCurrentFeet: number | null;
  isWithinGeofence: boolean;
  isSharedLocationWithPrevious: boolean;
  isSharedLocationWithNext: boolean;
  autoArrivalStatus: string;
  arrivalRadiusMeters: number;
  isPassedWithoutCompletion: boolean;
  simulateApproachAndPass: () => void;
  simulateApproachAndArrive: () => void;
  simulateParallelRoadTest: () => void;
  isSimulatingGps: boolean;
  stopGpsSimulation: () => void;
}

// Configurable constants: 500 feet (~152.4 meters) default as requested
export const DEFAULT_ARRIVAL_RADIUS_METERS = 152.4; // 500 feet
const MAX_ACCURACY_THRESHOLD_METERS = 65.0; // Filter out gross cell-tower jumps (> 210 ft)
const COOLDOWN_MS = 6000; // Minimum time between auto-advances (6 seconds)
const PASSING_DISTANCE_INCREASE_METERS = 15.0; // Distance expansion after closest point to confirm pass

/**
 * Validate latitude and longitude coordinates
 */
export function isValidCoordinate(lat: number, lon: number): boolean {
  return (
    !isNaN(lat) &&
    !isNaN(lon) &&
    lat >= -90 &&
    lat <= 90 &&
    lon >= -180 &&
    lon <= 180 &&
    !(lat === 0 && lon === 0)
  );
}

/**
 * Calculates whether the straight line path between two consecutive GPS fixes
 * passed within radiusMeters of destination coordinates.
 * Prevents missing arrivals when GPS fixes jump across the arrival boundary at driving speed.
 */
export function checkSegmentPassesPoint(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
  destLat: number,
  destLon: number,
  radiusMeters: number
): { passed: boolean; minDistance: number; t: number } {
  const latRad = (destLat * Math.PI) / 180;
  const cosLat = Math.cos(latRad);
  const mPerDegLat = 111132.92;
  const mPerDegLon = 111412.84 * cosLat;

  const x1 = (lon1 - destLon) * mPerDegLon;
  const y1 = (lat1 - destLat) * mPerDegLat;
  const x2 = (lon2 - destLon) * mPerDegLon;
  const y2 = (lat2 - destLat) * mPerDegLat;

  const dx = x2 - x1;
  const dy = y2 - y1;
  const lenSq = dx * dx + dy * dy;

  if (lenSq === 0) {
    const d = Math.sqrt(x1 * x1 + y1 * y1);
    return { passed: d <= radiusMeters, minDistance: d, t: 0 };
  }

  const t = -(x1 * dx + y1 * dy) / lenSq;

  if (t > 0 && t < 1) {
    const projX = x1 + t * dx;
    const projY = y1 + t * dy;
    const minDistance = Math.sqrt(projX * projX + projY * projY);
    return { passed: minDistance <= radiusMeters, minDistance, t };
  }

  const d1 = Math.sqrt(x1 * x1 + y1 * y1);
  const d2 = Math.sqrt(x2 * x2 + y2 * y2);
  const minDistance = Math.min(d1, d2);
  return { passed: minDistance <= radiusMeters, minDistance, t: t <= 0 ? 0 : 1 };
}

export function useGpsTracker(
  currentStop: RouteStop | null,
  previousStop: RouteStop | null,
  nextStop: RouteStop | null,
  onAutoAdvance: () => void,
  arrivalRadiusMeters: number = DEFAULT_ARRIVAL_RADIUS_METERS,
  roadRemainingMeters?: number | null,
  routeCoordinates?: [number, number][]
): UseGpsTrackerReturn {
  const [location, setLocation] = useState<GpsLocation | null>(null);
  const [gpsStatus, setGpsStatus] = useState<'acquiring' | 'locked' | 'denied'>('acquiring');
  const [gpsErrorMsg, setGpsErrorMsg] = useState<string | null>(null);
  const [arrivalStateDesc, setArrivalStateDesc] = useState<string>('Monitoring GPS (500 ft Zone)');
  const [isPassedWithoutCompletion, setIsPassedWithoutCompletion] = useState<boolean>(false);

  // Simulation state for phone/desktop indoor testing
  const [isSimulatingGps, setIsSimulatingGps] = useState(false);
  const simIntervalRef = useRef<number | null>(null);

  // Safeguard & Tracking Refs
  const minDistanceSeenRef = useRef<number>(Infinity);
  const enteredArrivalZoneRef = useRef<boolean>(false);
  const consecutiveInsideCountRef = useRef<number>(0);
  const lastLocationRef = useRef<GpsLocation | null>(null);
  const locationHistoryRef = useRef<GpsLocation[]>([]);
  const lastAdvanceTimestampRef = useRef<number>(0);
  const lastAdvancedStopIdRef = useRef<string | null>(null);
  const isAdvancingRef = useRef<boolean>(false);
  const departurePendingRef = useRef<boolean>(false);
  const activeStopIdRef = useRef<string | null>(null);

  // Stable references to latest props
  const currentStopRef = useRef(currentStop);
  currentStopRef.current = currentStop;

  const previousStopRef = useRef(previousStop);
  previousStopRef.current = previousStop;

  const nextStopRef = useRef(nextStop);
  nextStopRef.current = nextStop;

  const onAutoAdvanceRef = useRef(onAutoAdvance);
  onAutoAdvanceRef.current = onAutoAdvance;

  const arrivalRadiusRef = useRef(arrivalRadiusMeters);
  arrivalRadiusRef.current = arrivalRadiusMeters;

  const roadRemainingMetersRef = useRef(roadRemainingMeters);
  roadRemainingMetersRef.current = roadRemainingMeters;

  const routeCoordinatesRef = useRef(routeCoordinates);
  routeCoordinatesRef.current = routeCoordinates;

  // Shared location check (within 20m of previous/next stop, e.g. same building)
  const isSharedLocationWithPrevious = Boolean(
    currentStop &&
    previousStop &&
    isValidCoordinate(currentStop.lat, currentStop.lon) &&
    isValidCoordinate(previousStop.lat, previousStop.lon) &&
    calculateDistanceMeters(currentStop.lat, currentStop.lon, previousStop.lat, previousStop.lon) < 20
  );

  const isSharedLocationWithNext = Boolean(
    currentStop &&
    nextStop &&
    isValidCoordinate(currentStop.lat, currentStop.lon) &&
    isValidCoordinate(nextStop.lat, nextStop.lon) &&
    calculateDistanceMeters(currentStop.lat, currentStop.lon, nextStop.lat, nextStop.lon) < 20
  );

  const isSharedLocationWithPreviousRef = useRef(isSharedLocationWithPrevious);
  isSharedLocationWithPreviousRef.current = isSharedLocationWithPrevious;

  // Reset tracking state whenever the active customer changes
  useEffect(() => {
    const newStopId = currentStop?.id || null;
    if (newStopId !== activeStopIdRef.current) {
      activeStopIdRef.current = newStopId;
      minDistanceSeenRef.current = Infinity;
      enteredArrivalZoneRef.current = false;
      consecutiveInsideCountRef.current = 0;
      isAdvancingRef.current = false;
      setIsPassedWithoutCompletion(false);
      locationHistoryRef.current = [];

      // If driver is currently inside arrival radius of the NEW stop at activation,
      // require departure/movement or dwell cooldown before allowing auto-advance.
      if (
        location &&
        currentStop &&
        isValidCoordinate(currentStop.lat, currentStop.lon)
      ) {
        const d = calculateDistanceMeters(location.lat, location.lon, currentStop.lat, currentStop.lon);
        if (d <= arrivalRadiusRef.current) {
          departurePendingRef.current = true;
        } else {
          departurePendingRef.current = false;
        }
      } else {
        departurePendingRef.current = false;
      }
    }
  }, [currentStop?.id]);

  /**
   * Core Arrival Decision Engine
   * Evaluates current GPS location against verified coordinates of active customer address.
   * - Configurable arrival radius (initial 500 ft / 152.4m)
   * - Accounts for GPS accuracy and successive location updates
   * - Segment interpolation detects passes even when GPS readings jump across boundary
   * - Distinguishes passing the destination from driving along a nearby or parallel road
   * - Prevents duplicate arrival events and accidental cascade through multiple customers
   */
  const processLocationUpdate = useCallback((currentLoc: GpsLocation) => {
    const activeStop = currentStopRef.current;
    if (!activeStop) {
      setArrivalStateDesc('No Active Route');
      return;
    }

    // 1. Verify Destination Coordinates
    if (!isValidCoordinate(activeStop.lat, activeStop.lon)) {
      setArrivalStateDesc('Invalid Destination Coordinates (Manual Skip)');
      return;
    }

    // 2. Filter out extreme GPS inaccurate jumps (> 65 meters / ~213 ft)
    if (currentLoc.accuracy > MAX_ACCURACY_THRESHOLD_METERS) {
      setArrivalStateDesc(`GPS Accuracy Low (±${Math.round(currentLoc.accuracy * 3.28084)} ft) · Waiting for fix...`);
      return;
    }

    // Account for GPS accuracy by slightly relaxing effective boundary (max +25m / ~80 ft)
    const baseRadius = arrivalRadiusRef.current;
    const accuracyAllowance = Math.min(Math.max(0, currentLoc.accuracy - 5) * 0.4, 25.0);
    const effectiveRadius = baseRadius + accuracyAllowance;

    const distToDestination = calculateDistanceMeters(
      currentLoc.lat,
      currentLoc.lon,
      activeStop.lat,
      activeStop.lon
    );

    const prevLoc = lastLocationRef.current;
    const now = Date.now();

    // Check segment passage: did the vehicle travel vector pass through the arrival zone between fixes?
    let segmentPassInfo = { passed: false, minDistance: distToDestination, t: 1 };
    if (prevLoc) {
      segmentPassInfo = checkSegmentPassesPoint(
        prevLoc.lat,
        prevLoc.lon,
        currentLoc.lat,
        currentLoc.lon,
        activeStop.lat,
        activeStop.lon,
        effectiveRadius
      );
    }

    // Track minimum distance seen for this active stop
    const currentMinDist = Math.min(distToDestination, segmentPassInfo.minDistance);
    if (currentMinDist < minDistanceSeenRef.current) {
      minDistanceSeenRef.current = currentMinDist;
    }

    // Maintain location history (last 5 fixes)
    locationHistoryRef.current = [...locationHistoryRef.current.slice(-4), currentLoc];

    // 3. Prevent duplicate arrival events / rapid multi-stop cascade
    if (isAdvancingRef.current) return;
    if (now - lastAdvanceTimestampRef.current < COOLDOWN_MS) return;
    if (lastAdvancedStopIdRef.current === activeStop.id) return;

    // 4. Shared Address Safeguard (multi-unit apartment or shared parking lot)
    if (isSharedLocationWithPreviousRef.current && lastAdvancedStopIdRef.current === previousStopRef.current?.id) {
      // If within 20m of previous stop, give driver time or wait until they move
      if (now - lastAdvanceTimestampRef.current < 12000 && distToDestination < 25) {
        setArrivalStateDesc('Shared Address with Previous Stop · Tap Skip when done');
        lastLocationRef.current = currentLoc;
        return;
      }
    }

    // 5. Departure Latch
    // If the active stop began with the driver already inside the arrival radius (from completing previous stop),
    // require the driver to either:
    // a) Move closer towards the customer's coordinates by at least 15m, or
    // b) Dwell at the new stop after cooldown, or
    // c) Depart and re-enter.
    if (departurePendingRef.current) {
      if (distToDestination > baseRadius * 1.05) {
        departurePendingRef.current = false;
      } else if (now - lastAdvanceTimestampRef.current > 10000) {
        departurePendingRef.current = false;
      } else {
        setArrivalStateDesc('En route from previous stop...');
        lastLocationRef.current = currentLoc;
        return;
      }
    }

    // 6. Parallel Road & Different Road Rejection:
    // Do not automatically complete a stop solely because the vehicle is within 500 feet
    // if the GPS or road routing context indicates the vehicle is on a different road!
    const roadDist = roadRemainingMetersRef.current;
    if (roadDist !== undefined && roadDist !== null && !isNaN(roadDist)) {
      // If straight-line is <= 500 ft (e.g. 130m), but road driving distance is > 350m
      // or > 2.4x the straight line distance, vehicle is on a parallel arterial, highway, or wrong street!
      if (distToDestination <= effectiveRadius && roadDist > Math.max(effectiveRadius * 2.3, 350)) {
        setArrivalStateDesc(`On Parallel Road (${Math.round(roadDist * 3.28084)} ft via road network)`);
        lastLocationRef.current = currentLoc;
        return;
      }
    }

    let isReliablyArrived = false;
    let arrivalReason = '';

    const isInsideRadius = distToDestination <= effectiveRadius || segmentPassInfo.passed;

    if (isInsideRadius) {
      enteredArrivalZoneRef.current = true;
      consecutiveInsideCountRef.current += 1;

      // Condition 1: Stopped or crawling (delivery driver pulled up to curbside or driveway)
      const isStoppedOrCrawling = currentLoc.speed !== null && currentLoc.speed <= 8.0;
      // Condition 2: Very close proximity (within 35 meters / ~115 ft)
      const isCurbsideProximity = distToDestination <= 35.0;
      // Condition 3: Successive updates inside zone (steady presence, at least 2 consecutive updates)
      const isDwellInZone = consecutiveInsideCountRef.current >= 2;

      // Condition 4: Passing the destination within the 500 ft zone
      // As the vehicle drives along the street past the address:
      // Minimum distance was within arrival zone, and distance is now expanding by >= 15m
      const isPassingPastDestination = Boolean(
        minDistanceSeenRef.current <= baseRadius &&
        distToDestination >= minDistanceSeenRef.current + PASSING_DISTANCE_INCREASE_METERS
      );

      if (isStoppedOrCrawling || isCurbsideProximity || isDwellInZone || isPassingPastDestination) {
        isReliablyArrived = true;
        const ft = Math.round(distToDestination * 3.28084);
        arrivalReason = isPassingPastDestination
          ? `Passed customer address (${ft} ft)`
          : `Reached customer address (${ft} ft)`;
      } else {
        setArrivalStateDesc(`In Arrival Zone (${Math.round(distToDestination * 3.28084)} ft)`);
      }
    } else {
      consecutiveInsideCountRef.current = 0;

      // If vehicle was previously inside the arrival zone (or segment passed through it)
      // and has now exited the zone on the same road, confirm completion rather than failing
      if (enteredArrivalZoneRef.current && minDistanceSeenRef.current <= baseRadius) {
        isReliablyArrived = true;
        arrivalReason = `Passed customer address (${Math.round(minDistanceSeenRef.current * 3.28084)} ft)`;
      }
    }

    // ========================================================
    // EXECUTE RELIABLY CONFIRMED ARRIVAL
    // ========================================================
    if (isReliablyArrived) {
      isAdvancingRef.current = true;
      lastAdvanceTimestampRef.current = now;
      lastAdvancedStopIdRef.current = activeStop.id;
      enteredArrivalZoneRef.current = false;
      consecutiveInsideCountRef.current = 0;
      minDistanceSeenRef.current = Infinity;
      setIsPassedWithoutCompletion(false);

      setArrivalStateDesc(`Arrived: ${arrivalReason}`);
      triggerHaptic('complete');
      onAutoAdvanceRef.current();
      return;
    }

    // Normal navigation progress tracking description
    if (!enteredArrivalZoneRef.current) {
      const feet = Math.round(distToDestination * 3.28084);
      const zoneFt = Math.round(baseRadius * 3.28084);
      setArrivalStateDesc(`${feet} ft to customer (Zone: ${zoneFt} ft)`);
    }

    lastLocationRef.current = currentLoc;
  }, []);

  // Mount native Android GPS watcher
  useEffect(() => {
    if (typeof window === 'undefined' || !('geolocation' in navigator)) {
      setGpsStatus('denied');
      setGpsErrorMsg('GPS hardware not supported by this browser.');
      return;
    }

    setGpsStatus('acquiring');

    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        if (isSimulatingGps) return;

        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;
        const accuracy = pos.coords.accuracy || 8;
        const speed = pos.coords.speed !== null && pos.coords.speed >= 0
          ? Math.round(pos.coords.speed * 2.23694)
          : null;
        const heading = pos.coords.heading !== null && !isNaN(pos.coords.heading)
          ? pos.coords.heading
          : null;

        const currentLoc: GpsLocation = {
          lat,
          lon,
          accuracy,
          speed,
          heading,
          timestamp: pos.timestamp || Date.now(),
        };

        setLocation(currentLoc);
        setGpsStatus('locked');
        setGpsErrorMsg(null);

        processLocationUpdate(currentLoc);
      },
      (err) => {
        if (isSimulatingGps) return;
        setGpsStatus('denied');
        setGpsErrorMsg(err.message || 'GPS hardware access denied.');
      },
      {
        enableHighAccuracy: true,
        maximumAge: 1000,
        timeout: 10000,
      }
    );

    return () => {
      try {
        navigator.geolocation.clearWatch(watchId);
      } catch (e) {}
    };
  }, [processLocationUpdate, isSimulatingGps]);

  // Clean up any running simulation on unmount
  useEffect(() => {
    return () => {
      if (simIntervalRef.current) {
        window.clearInterval(simIntervalRef.current);
      }
    };
  }, []);

  /**
   * Interactive Simulator 1: Approach from 800 ft, enter 500 ft zone, pull up to stop,
   * verify arrival detection, and cleanly advance to next customer.
   */
  const simulateApproachAndArrive = useCallback(() => {
    const activeStop = currentStopRef.current;
    if (!activeStop || !isValidCoordinate(activeStop.lat, activeStop.lon)) return;

    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    setIsSimulatingGps(true);
    setGpsStatus('locked');
    setGpsErrorMsg(null);
    setIsPassedWithoutCompletion(false);

    const latMeters = 111132.92;
    const destLat = activeStop.lat;
    const destLon = activeStop.lon;

    // Approaching: -240m (780 ft) -> -140m (450 ft, inside 500ft zone) -> -50m (160 ft) -> 0m (curb) -> stop
    const waypoints = [
      { offset: -240, speed: 28 }, // 780 ft away
      { offset: -140, speed: 22 }, // 450 ft away (enters 500 ft arrival zone)
      { offset: -60, speed: 15 },  // 195 ft away
      { offset: -10, speed: 5 },   // 32 ft away, pulling to curb
      { offset: 0, speed: 0 },     // Stopped at customer
    ];
    let step = 0;

    simIntervalRef.current = window.setInterval(() => {
      if (step >= waypoints.length) {
        if (simIntervalRef.current) {
          window.clearInterval(simIntervalRef.current);
          simIntervalRef.current = null;
        }
        setIsSimulatingGps(false);
        return;
      }

      const wp = waypoints[step];
      const simLat = destLat + (wp.offset / latMeters);
      const simLon = destLon;

      const simLoc: GpsLocation = {
        lat: simLat,
        lon: simLon,
        accuracy: 5,
        speed: wp.speed,
        heading: 0,
        timestamp: Date.now(),
      };

      setLocation(simLoc);
      processLocationUpdate(simLoc);

      step += 1;
    }, 1100);
  }, [processLocationUpdate]);

  /**
   * Interactive Simulator 2: Drive past address at 25 mph within 500 ft arrival zone.
   * Demonstrates the app detecting vehicle passing close enough even when moving at driving speed,
   * advancing the customer without falsely claiming a missed stop!
   */
  const simulateApproachAndPass = useCallback(() => {
    const activeStop = currentStopRef.current;
    if (!activeStop || !isValidCoordinate(activeStop.lat, activeStop.lon)) return;

    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    setIsSimulatingGps(true);
    setGpsStatus('locked');
    setGpsErrorMsg(null);

    const latMeters = 111132.92;
    const destLat = activeStop.lat;
    const destLon = activeStop.lon;

    // Passes from 600 ft south, passes house at 40 ft offset, continues north at 25 mph
    const waypoints = [
      { offset: -180, speed: 25 }, // 590 ft away
      { offset: -100, speed: 25 }, // 328 ft away (inside 500 ft zone)
      { offset: -15, speed: 25 },  // 50 ft closest point of approach
      { offset: 60, speed: 25 },   // 196 ft past customer
      { offset: 130, speed: 25 },  // 426 ft past customer
    ];
    let step = 0;

    simIntervalRef.current = window.setInterval(() => {
      if (step >= waypoints.length) {
        if (simIntervalRef.current) {
          window.clearInterval(simIntervalRef.current);
          simIntervalRef.current = null;
        }
        setIsSimulatingGps(false);
        return;
      }

      const wp = waypoints[step];
      const simLat = destLat + (wp.offset / latMeters);
      const simLon = destLon + (12 / (latMeters * Math.cos(destLat * Math.PI / 180)));

      const simLoc: GpsLocation = {
        lat: simLat,
        lon: simLon,
        accuracy: 6,
        speed: wp.speed,
        heading: 0,
        timestamp: Date.now(),
      };

      setLocation(simLoc);
      processLocationUpdate(simLoc);

      step += 1;
    }, 1100);
  }, [processLocationUpdate]);

  /**
   * Interactive Simulator 3: Parallel Road Rejection Test.
   * Simulates driving along a parallel road 400 ft away where road routing indicates
   * a significant detour around the block. Demonstrates that the app avoids premature
   * completion on adjacent roads!
   */
  const simulateParallelRoadTest = useCallback(() => {
    const activeStop = currentStopRef.current;
    if (!activeStop || !isValidCoordinate(activeStop.lat, activeStop.lon)) return;

    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    setIsSimulatingGps(true);
    setGpsStatus('locked');
    setGpsErrorMsg(null);

    const latMeters = 111132.92;
    const destLat = activeStop.lat;
    const destLon = activeStop.lon;
    // 120m (~390 ft) lateral offset on parallel street
    const lateralOffsetDeg = 120 / (latMeters * Math.cos(destLat * Math.PI / 180));

    const waypoints = [
      { offset: -150, speed: 30 },
      { offset: -50, speed: 30 },
      { offset: 20, speed: 30 },
      { offset: 100, speed: 30 },
    ];
    let step = 0;

    simIntervalRef.current = window.setInterval(() => {
      if (step >= waypoints.length) {
        if (simIntervalRef.current) {
          window.clearInterval(simIntervalRef.current);
          simIntervalRef.current = null;
        }
        setIsSimulatingGps(false);
        return;
      }

      const wp = waypoints[step];
      const simLat = destLat + (wp.offset / latMeters);
      const simLon = destLon + lateralOffsetDeg;

      const simLoc: GpsLocation = {
        lat: simLat,
        lon: simLon,
        accuracy: 5,
        speed: wp.speed,
        heading: 0,
        timestamp: Date.now(),
      };

      setLocation(simLoc);
      processLocationUpdate(simLoc);

      step += 1;
    }, 1200);
  }, [processLocationUpdate]);

  const stopGpsSimulation = useCallback(() => {
    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }
    setIsSimulatingGps(false);
  }, []);

  // Calculated reactive metrics for UI display
  let distanceToCurrentMeters: number | null = null;
  let distanceToCurrentFeet: number | null = null;
  let isWithinGeofence = false;

  if (location && currentStop && isValidCoordinate(currentStop.lat, currentStop.lon)) {
    distanceToCurrentMeters = calculateDistanceMeters(location.lat, location.lon, currentStop.lat, currentStop.lon);
    distanceToCurrentFeet = Math.round(distanceToCurrentMeters * 3.28084);
    isWithinGeofence = distanceToCurrentMeters <= arrivalRadiusMeters;
  }

  let finalArrivalStatus = arrivalStateDesc;
  if (gpsStatus === 'denied') {
    finalArrivalStatus = 'GPS Disabled';
  } else if (gpsStatus === 'acquiring') {
    finalArrivalStatus = 'Acquiring Satellites...';
  } else if (isPassedWithoutCompletion) {
    finalArrivalStatus = `Passed stop (${distanceToCurrentFeet} ft) · Recalculating...`;
  } else if (isSimulatingGps) {
    finalArrivalStatus = `Simulating GPS (${distanceToCurrentFeet} ft)`;
  } else if (isWithinGeofence) {
    finalArrivalStatus = isSharedLocationWithPrevious
      ? 'Shared Address · Tap Skip when done'
      : `In 500 ft Zone (${distanceToCurrentFeet} ft / ${Math.round(arrivalRadiusMeters * 3.28084)} ft)`;
  }

  return {
    location,
    gpsStatus,
    gpsErrorMsg,
    distanceToCurrentMeters,
    distanceToCurrentFeet,
    isWithinGeofence,
    isSharedLocationWithPrevious,
    isSharedLocationWithNext,
    autoArrivalStatus: finalArrivalStatus,
    arrivalRadiusMeters,
    isPassedWithoutCompletion,
    simulateApproachAndPass,
    simulateApproachAndArrive,
    simulateParallelRoadTest,
    isSimulatingGps,
    stopGpsSimulation,
  };
}
