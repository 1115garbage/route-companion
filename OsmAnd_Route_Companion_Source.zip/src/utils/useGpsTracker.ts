import { useState, useEffect, useRef, useCallback } from 'react';
import { RouteStop } from '../types/route';
import { calculateDistanceMeters, calculateBearing, calculateDistanceToPolylineMeters } from './navigationService';
import { triggerHaptic } from './voiceAndHaptics';

export interface GpsLocation {
  lat: number;
  lon: number;
  accuracy: number;
  speed: number | null; // mph
  heading: number | null;
  timestamp: number;
}

export interface UseGpsTrackerReturn {
  location: GpsLocation | null;
  gpsStatus: 'acquiring' | 'locked' | 'denied';
  gpsErrorMsg: string | null;
  distanceToCurrentMeters: number | null;
  distanceToCurrentFeet: number | null;
  isWithinGeofence: boolean;
  isWithinArrivalConfirmZone: boolean;
  isConfirmedArrival: boolean;
  isSharedLocationWithPrevious: boolean;
  isSharedLocationWithNext: boolean;
  autoArrivalStatus: string;
  arrivalRadiusMeters: number;
  arrivalConfirmFeet: number;
  arrivalConfirmMeters: number;
  isPassedWithoutCompletion: boolean;
  simulateApproachAndPass: () => void;
  simulateApproachAndArrive: () => void;
  simulateCurbsidePassThrough: () => void;
  isSimulatingGps: boolean;
  stopGpsSimulation: () => void;
}

// Configurable constants and safeguards
export const DEFAULT_ARRIVAL_RADIUS_METERS = 152.4; // 500 feet proximity evaluation window
export const DEFAULT_ARRIVAL_CONFIRM_METERS = 45.72; // 150 feet initial arrival confirmation threshold (~45.7m)
const MAX_ACCURACY_THRESHOLD_METERS = 28.0; // Filter out inaccurate GPS drift (> 90 ft)
const COOLDOWN_MS = 5000; // Minimum time between auto-advances (5 seconds)
const PASSING_DISTANCE_INCREASE_METERS = 18.0; // Distance must expand by 18m (~60ft) from closest point to confirm vehicle passed

/**
 * Validate latitude and longitude coordinates
 */
export function isValidCoordinate(lat: number, lon: number): boolean {
  return (
    !isNaN(lat) &&
    !isNaN(lon) &&
    lat >= -90 &&
    lat <= 90 &&
    lon >= -180 &&
    lon <= 180 &&
    !(lat === 0 && lon === 0)
  );
}

/**
 * Calculates whether the straight line path between two consecutive GPS fixes
 * passed within radiusMeters of destination coordinates.
 */
export function checkSegmentPassesPoint(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
  destLat: number,
  destLon: number,
  radiusMeters: number
): { passed: boolean; minDistance: number; t: number } {
  const latRad = (destLat * Math.PI) / 180;
  const cosLat = Math.cos(latRad);
  const mPerDegLat = 111132.92;
  const mPerDegLon = 111412.84 * cosLat;

  const x1 = (lon1 - destLon) * mPerDegLon;
  const y1 = (lat1 - destLat) * mPerDegLat;
  const x2 = (lon2 - destLon) * mPerDegLon;
  const y2 = (lat2 - destLat) * mPerDegLat;

  const dx = x2 - x1;
  const dy = y2 - y1;
  const lenSq = dx * dx + dy * dy;

  if (lenSq === 0) {
    const d = Math.sqrt(x1 * x1 + y1 * y1);
    return { passed: d <= radiusMeters, minDistance: d, t: 0 };
  }

  const t = -(x1 * dx + y1 * dy) / lenSq;

  if (t > 0 && t < 1) {
    const projX = x1 + t * dx;
    const projY = y1 + t * dy;
    const minDistance = Math.sqrt(projX * projX + projY * projY);
    return { passed: minDistance <= radiusMeters, minDistance, t };
  }

  const d1 = Math.sqrt(x1 * x1 + y1 * y1);
  const d2 = Math.sqrt(x2 * x2 + y2 * y2);
  const minDistance = Math.min(d1, d2);
  return { passed: minDistance <= radiusMeters, minDistance, t };
}

export function useGpsTracker(
  currentStop: RouteStop | null,
  previousStop: RouteStop | null,
  nextStop: RouteStop | null,
  onAutoAdvance: () => void,
  arrivalRadiusMeters: number = DEFAULT_ARRIVAL_RADIUS_METERS,
  arrivalConfirmMeters: number = DEFAULT_ARRIVAL_CONFIRM_METERS,
  roadRemainingMeters?: number | null,
  routeCoordinates?: [number, number][]
): UseGpsTrackerReturn {
  const [location, setLocation] = useState<GpsLocation | null>(null);
  const [gpsStatus, setGpsStatus] = useState<'acquiring' | 'locked' | 'denied'>('acquiring');
  const [gpsErrorMsg, setGpsErrorMsg] = useState<string | null>(null);
  const [arrivalStateDesc, setArrivalStateDesc] = useState<string>('Monitoring GPS');
  const [isPassedWithoutCompletion, setIsPassedWithoutCompletion] = useState<boolean>(false);

  const [isConfirmedArrival, setIsConfirmedArrival] = useState<boolean>(false);

  // Simulation state for phone/desktop indoor testing
  const [isSimulatingGps, setIsSimulatingGps] = useState(false);
  const simIntervalRef = useRef<number | null>(null);

  // Safeguard & Tracking Refs
  const minDistanceSeenRef = useRef<number>(Infinity);
  const enteredArrivalZoneRef = useRef<boolean>(false);
  const consecutiveInsideCountRef = useRef<number>(0);
  const consecutiveCloseCountRef = useRef<number>(0);
  const consecutivePassCountRef = useRef<number>(0);
  const consecutiveMissedCountRef = useRef<number>(0);
  const lastLocationRef = useRef<GpsLocation | null>(null);
  const lastDistanceRef = useRef<number | null>(null);
  const lastAdvanceTimestampRef = useRef<number>(0);
  const lastAdvancedStopIdRef = useRef<string | null>(null);
  const isAdvancingRef = useRef<boolean>(false);
  const departurePendingRef = useRef<boolean>(false);
  const activeStopIdRef = useRef<string | null>(null);

  // Keep stable refs to latest props to prevent watchPosition re-binding
  const currentStopRef = useRef(currentStop);
  currentStopRef.current = currentStop;

  const previousStopRef = useRef(previousStop);
  previousStopRef.current = previousStop;

  const nextStopRef = useRef(nextStop);
  nextStopRef.current = nextStop;

  const onAutoAdvanceRef = useRef(onAutoAdvance);
  onAutoAdvanceRef.current = onAutoAdvance;

  const arrivalRadiusRef = useRef(arrivalRadiusMeters);
  arrivalRadiusRef.current = arrivalRadiusMeters;

  const arrivalConfirmMetersRef = useRef(arrivalConfirmMeters);
  arrivalConfirmMetersRef.current = arrivalConfirmMeters;

  const roadRemainingMetersRef = useRef(roadRemainingMeters);
  roadRemainingMetersRef.current = roadRemainingMeters;

  const routeCoordinatesRef = useRef(routeCoordinates);
  routeCoordinatesRef.current = routeCoordinates;

  // Shared location check (within 18m of previous/next stop)
  const isSharedLocationWithPrevious = Boolean(
    currentStop &&
    previousStop &&
    isValidCoordinate(currentStop.lat, currentStop.lon) &&
    isValidCoordinate(previousStop.lat, previousStop.lon) &&
    calculateDistanceMeters(currentStop.lat, currentStop.lon, previousStop.lat, previousStop.lon) < 18
  );

  const isSharedLocationWithNext = Boolean(
    currentStop &&
    nextStop &&
    isValidCoordinate(currentStop.lat, currentStop.lon) &&
    isValidCoordinate(nextStop.lat, nextStop.lon) &&
    calculateDistanceMeters(currentStop.lat, currentStop.lon, nextStop.lat, nextStop.lon) < 18
  );

  const isSharedLocationWithPreviousRef = useRef(isSharedLocationWithPrevious);
  isSharedLocationWithPreviousRef.current = isSharedLocationWithPrevious;

  // Reset tracking state whenever the active customer changes
  useEffect(() => {
    const newStopId = currentStop?.id || null;
    if (newStopId !== activeStopIdRef.current) {
      activeStopIdRef.current = newStopId;
      minDistanceSeenRef.current = Infinity;
      enteredArrivalZoneRef.current = false;
      consecutiveInsideCountRef.current = 0;
      consecutiveCloseCountRef.current = 0;
      consecutivePassCountRef.current = 0;
      consecutiveMissedCountRef.current = 0;
      lastDistanceRef.current = null;
      isAdvancingRef.current = false;
      setIsConfirmedArrival(false);
      setIsPassedWithoutCompletion(false);

      // If driver is currently inside arrival radius of the NEW stop at activation,
      // require departure/movement or dwell cooldown before allowing auto-advance.
      if (
        location &&
        currentStop &&
        isValidCoordinate(currentStop.lat, currentStop.lon)
      ) {
        const d = calculateDistanceMeters(location.lat, location.lon, currentStop.lat, currentStop.lon);
        if (d <= arrivalRadiusRef.current) {
          departurePendingRef.current = true;
        } else {
          departurePendingRef.current = false;
        }
      } else {
        departurePendingRef.current = false;
      }
    }
  }, [currentStop?.id]);

  /**
   * Core Arrival & Missed Stop Decision Engine
   * Evaluates current GPS location against verified coordinates of currentStop.
   * Separates 500-foot proximity window from confirmed arrival at the customer address.
   */
  const processLocationUpdate = useCallback((currentLoc: GpsLocation) => {
    const activeStop = currentStopRef.current;
    if (!activeStop) {
      setArrivalStateDesc('No Active Route');
      return;
    }

    // 1. Verify Destination Coordinates
    if (!isValidCoordinate(activeStop.lat, activeStop.lon)) {
      setArrivalStateDesc('Invalid Destination Coordinates (Manual Skip)');
      return;
    }

    // 2. Reject stale updates (> 4.5s old)
    if (Date.now() - currentLoc.timestamp > 4500) {
      return;
    }

    // 3. Filter out inaccurate GPS readings (> 30m error)
    if (currentLoc.accuracy > MAX_ACCURACY_THRESHOLD_METERS) {
      setArrivalStateDesc(`GPS Accuracy ±${Math.round(currentLoc.accuracy * 3.28084)} ft (Refining...)`);
      return;
    }

    const proximityRadius = arrivalRadiusRef.current || DEFAULT_ARRIVAL_RADIUS_METERS; // 500 ft proximity window
    const confirmRadius = arrivalConfirmMetersRef.current || DEFAULT_ARRIVAL_CONFIRM_METERS; // 150 ft confirmation threshold
    const distToDestination = calculateDistanceMeters(
      currentLoc.lat,
      currentLoc.lon,
      activeStop.lat,
      activeStop.lon
    );
    const feetToDestination = Math.round(distToDestination * 3.28084);

    // Track minimum distance seen for this active stop
    if (distToDestination < minDistanceSeenRef.current) {
      minDistanceSeenRef.current = distToDestination;
    }

    const prevLoc = lastLocationRef.current;
    const prevDist = lastDistanceRef.current;
    const now = Date.now();

    // Check if path segment between prevLoc and currentLoc passed closer to verified customer coordinates
    if (prevLoc && isValidCoordinate(prevLoc.lat, prevLoc.lon)) {
      const segCheck = checkSegmentPassesPoint(
        prevLoc.lat,
        prevLoc.lon,
        currentLoc.lat,
        currentLoc.lon,
        activeStop.lat,
        activeStop.lon,
        confirmRadius
      );
      if (segCheck.passed && segCheck.minDistance < minDistanceSeenRef.current) {
        minDistanceSeenRef.current = segCheck.minDistance;
      }
    }

    // 4. Prevent immediate cascade / double advance
    if (isAdvancingRef.current) return;
    if (now - lastAdvanceTimestampRef.current < COOLDOWN_MS) return;
    if (lastAdvancedStopIdRef.current === activeStop.id) return;

    // 5. Shared Location Safeguard (Multi-unit building or shared entrance)
    if (isSharedLocationWithPreviousRef.current && lastAdvancedStopIdRef.current === previousStopRef.current?.id) {
      setArrivalStateDesc('Shared Address · Tap Skip when done');
      return;
    }

    // 6. Departure Latch (if activated while already near the stop)
    if (departurePendingRef.current) {
      if (distToDestination > proximityRadius * 1.1) {
        departurePendingRef.current = false;
      } else if (now - lastAdvanceTimestampRef.current > 8000 && !isSharedLocationWithPreviousRef.current) {
        departurePendingRef.current = false;
      } else {
        setArrivalStateDesc('Departing Previous Stop...');
        return;
      }
    }

    // 7. Parallel Road Rejection (Avoid triggering arrival when driving on a nearby or parallel road)
    const roadDist = roadRemainingMetersRef.current;
    if (roadDist !== undefined && roadDist !== null && roadDist > Math.max(proximityRadius * 2.0, 150)) {
      setArrivalStateDesc(`Parallel Road / Route Distance ${Math.round(roadDist * 3.28084)} ft`);
      return;
    }

    if (routeCoordinatesRef.current && routeCoordinatesRef.current.length > 1) {
      const distToPolyline = calculateDistanceToPolylineMeters(currentLoc.lat, currentLoc.lon, routeCoordinatesRef.current);
      // If vehicle has drifted > 38m (~125 ft) from delivery street polyline while distToDestination > 25m:
      if (distToPolyline > 38.0 && distToDestination > 25.0) {
        setArrivalStateDesc(`Parallel Road · ${feetToDestination} ft to customer`);
        return;
      }
    }

    // Calculate inter-fix displacement and effective speed (in mph)
    const displacementMeters = (prevLoc && isValidCoordinate(prevLoc.lat, prevLoc.lon))
      ? calculateDistanceMeters(prevLoc.lat, prevLoc.lon, currentLoc.lat, currentLoc.lon)
      : null;
    const timeDeltaSec = prevLoc ? Math.max(0.4, (currentLoc.timestamp - prevLoc.timestamp) / 1000) : 1.0;
    const computedSpeedMph = displacementMeters !== null ? (displacementMeters / timeDeltaSec) * 2.23694 : null;
    const effectiveSpeedMph = currentLoc.speed !== null ? currentLoc.speed : computedSpeedMph;

    // Dynamic Arrival Confirmation Threshold (accounts for GPS accuracy + house setback, default 150 ft)
    const effectiveConfirmZone = Math.max(confirmRadius, Math.min(confirmRadius + 15.0, currentLoc.accuracy * 1.4));
    const isInsideConfirmZone = distToDestination <= effectiveConfirmZone;
    
    // Actively closing distance at cruising road speed towards the house (> 18 mph):
    const isClosingDistanceAtSpeed = prevDist !== null
      && distToDestination < prevDist - 1.5
      && effectiveSpeedMph !== null
      && effectiveSpeedMph > 18.0;

    // Moving away from destination:
    const isMovingAway = prevDist !== null && distToDestination > prevDist + 1.2;

    let isReliablyArrived = false;
    let arrivalReason = '';

    // ========================================================
    // ARRIVAL DETECTION (Separated from 500-ft Proximity Window)
    // Does NOT require a complete stop (speed zero).
    // ========================================================

    // Case 1: Curbside / Address Presence (within 150-ft threshold)
    // Recognizes arrival whether vehicle stopped, crawling, or rolling past at normal delivery speed (<= 25 mph).
    if (isInsideConfirmZone) {
      if (isClosingDistanceAtSpeed && distToDestination > 18.0) {
        // Vehicle is still approaching at cruising speed towards the house: wait until closest approach
        consecutiveCloseCountRef.current = 0;
        setArrivalStateDesc(`Approaching customer: ${feetToDestination} ft`);
      } else {
        // Vehicle is at address: stopped, crawling, or rolling past at delivery speed (<= 25 mph)
        consecutiveCloseCountRef.current += 1;
        // Require 2 consecutive reliable GPS fixes within confirmation threshold (does not require complete stop)
        if (consecutiveCloseCountRef.current >= 2) {
          isReliablyArrived = true;
          arrivalReason = `At customer address (${feetToDestination} ft)`;
        } else {
          setArrivalStateDesc(`At address (${feetToDestination} ft, confirming...)`);
        }
      }
    } else {
      consecutiveCloseCountRef.current = 0;
    }

    // Case 2: Pass-Through Arrival (Rolled past address within 150-ft threshold at delivery pace)
    // Vehicle came within closest approach threshold (minDistanceSeen <= effectiveConfirmZone)
    // and is now moving past the customer
    if (!isReliablyArrived && minDistanceSeenRef.current <= effectiveConfirmZone) {
      const hasPassedMin = distToDestination >= minDistanceSeenRef.current + 3.0;
      const isDeliveryPace = effectiveSpeedMph === null || effectiveSpeedMph <= 25.0;

      // Heading or displacement check: destination is behind vehicle
      const bearingToDest = calculateBearing(currentLoc.lat, currentLoc.lon, activeStop.lat, activeStop.lon);
      let isBehindVehicle = true;
      if (currentLoc.heading !== null) {
        const diff = Math.abs(currentLoc.heading - bearingToDest);
        const normalizedDiff = diff > 180 ? 360 - diff : diff;
        isBehindVehicle = normalizedDiff > 65;
      } else if (prevDist !== null) {
        isBehindVehicle = distToDestination > prevDist;
      }

      if (hasPassedMin && isMovingAway && isBehindVehicle && isDeliveryPace) {
        consecutivePassCountRef.current += 1;
        if (consecutivePassCountRef.current >= 2) {
          isReliablyArrived = true;
          arrivalReason = `Passed customer address (${Math.round(minDistanceSeenRef.current * 3.28084)} ft min)`;
        }
      } else {
        consecutivePassCountRef.current = 0;
      }
    } else {
      consecutivePassCountRef.current = 0;
    }

    // Case 3: Still Approaching the House within the 500-ft Proximity Window
    // If vehicle is approaching outside the confirmation zone, keep tracking
    if (!isReliablyArrived && distToDestination <= proximityRadius && !isInsideConfirmZone) {
      setArrivalStateDesc(`Approaching customer: ${feetToDestination} ft`);
    }

    // Case 4: Genuinely Missed Destination
    // Strict multi-condition check to prevent false turnaround triggers:
    // 1) Vehicle is NOT inside confirmation zone
    // 2) Vehicle was within proximity window (minDistanceSeenRef.current <= proximityRadius)
    // 3) Vehicle is now well past and outside the confirmation zone (> 75m / 245+ ft away)
    // 4) Distance has expanded substantially from closest approach (> 35m / 115+ ft expansion)
    // 5) Direction of travel is moving away from the customer
    // 6) Inconclusive evidence -> continue tracking, NEVER declare missed prematurely!
    if (!isReliablyArrived && !isInsideConfirmZone && minDistanceSeenRef.current <= proximityRadius) {
      const isWellPastCustomer = distToDestination > Math.max(effectiveConfirmZone + 25.0, 75.0);
      const isExpandingSignificantly = distToDestination >= minDistanceSeenRef.current + 35.0;

      const bearingToDest = calculateBearing(currentLoc.lat, currentLoc.lon, activeStop.lat, activeStop.lon);
      let headingPointsAway = false;
      if (currentLoc.heading !== null) {
        const diff = Math.abs(currentLoc.heading - bearingToDest);
        const normalizedDiff = diff > 180 ? 360 - diff : diff;
        headingPointsAway = normalizedDiff > 75;
      } else if (prevDist !== null) {
        headingPointsAway = distToDestination > prevDist + 2.0;
      }

      if (isWellPastCustomer && isExpandingSignificantly && (isMovingAway || headingPointsAway)) {
        consecutiveMissedCountRef.current += 1;
        if (consecutiveMissedCountRef.current >= 3) {
          setIsPassedWithoutCompletion(true);
          setArrivalStateDesc(`Missed stop (${feetToDestination} ft) · Recalculating...`);
          lastLocationRef.current = currentLoc;
          lastDistanceRef.current = distToDestination;
          return;
        }
      } else {
        consecutiveMissedCountRef.current = 0;
      }
    } else {
      consecutiveMissedCountRef.current = 0;
    }

    // ========================================================
    // EXECUTE CONFIRMED ARRIVAL
    // ========================================================
    if (isReliablyArrived) {
      isAdvancingRef.current = true;
      lastAdvanceTimestampRef.current = now;
      lastAdvancedStopIdRef.current = activeStop.id;
      consecutiveCloseCountRef.current = 0;
      consecutivePassCountRef.current = 0;
      minDistanceSeenRef.current = Infinity;
      setIsPassedWithoutCompletion(false);
      setIsConfirmedArrival(true);

      setArrivalStateDesc(`Arrived: ${arrivalReason}`);
      triggerHaptic('complete');
      onAutoAdvanceRef.current();

      setTimeout(() => {
        setIsConfirmedArrival(false);
      }, 3000);
      return;
    }

    // General navigation tracking outside 500ft window
    if (distToDestination > proximityRadius) {
      setArrivalStateDesc(`${feetToDestination} ft to customer (Window: ${Math.round(proximityRadius * 3.28084)} ft)`);
    }

    lastLocationRef.current = currentLoc;
    lastDistanceRef.current = distToDestination;
  }, []);

  // Mount native Android GPS watcher
  useEffect(() => {
    if (typeof window === 'undefined' || !('geolocation' in navigator)) {
      setGpsStatus('denied');
      setGpsErrorMsg('GPS hardware not supported by this browser.');
      return;
    }

    setGpsStatus('acquiring');

    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        if (isSimulatingGps) return;

        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;
        const accuracy = pos.coords.accuracy || 8;
        const speed = pos.coords.speed !== null && pos.coords.speed >= 0
          ? Math.round(pos.coords.speed * 2.23694)
          : null;
        const heading = pos.coords.heading !== null && !isNaN(pos.coords.heading)
          ? pos.coords.heading
          : null;

        const currentLoc: GpsLocation = {
          lat,
          lon,
          accuracy,
          speed,
          heading,
          timestamp: pos.timestamp || Date.now(),
        };

        setLocation(currentLoc);
        setGpsStatus('locked');
        setGpsErrorMsg(null);

        processLocationUpdate(currentLoc);
      },
      (err) => {
        if (isSimulatingGps) return;
        setGpsStatus('denied');
        setGpsErrorMsg(err.message || 'GPS hardware access denied.');
      },
      {
        enableHighAccuracy: true,
        maximumAge: 1000,
        timeout: 10000,
      }
    );

    return () => {
      try {
        navigator.geolocation.clearWatch(watchId);
      } catch (e) {}
    };
  }, [processLocationUpdate, isSimulatingGps]);

  // Clean up any running simulation on unmount
  useEffect(() => {
    return () => {
      if (simIntervalRef.current) {
        window.clearInterval(simIntervalRef.current);
      }
    };
  }, []);

  /**
   * Interactive Simulator 1: Approach within 500ft proximity window, stop at address curbside, confirm arrival, and advance.
   */
  const simulateApproachAndArrive = useCallback(() => {
    const activeStop = currentStopRef.current;
    if (!activeStop || !isValidCoordinate(activeStop.lat, activeStop.lon)) return;

    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    setIsSimulatingGps(true);
    setGpsStatus('locked');
    setGpsErrorMsg(null);
    setIsPassedWithoutCompletion(false);
    setIsConfirmedArrival(false);

    const latMeters = 111132.92;
    const destLat = activeStop.lat;
    const destLon = activeStop.lon;

    // Approaching:
    // -130m (~425 ft): inside 500ft proximity window, NOT arrived
    // -75m (~245 ft): approaching customer, NOT arrived
    // -36m (~118 ft): inside 150ft confirmation threshold, but driving forward at 12 mph (NOT arrived yet)
    // -23m (~75 ft): pulled up to curb/driveway in front of house, slows to 2 mph (reading 1)
    // -23m (~75 ft): stopped at curb in front of house (reading 2 -> confirms arrival at 75 ft and advances)
    const waypoints = [
      { offset: -130, speed: 25 },
      { offset: -75, speed: 20 },
      { offset: -36, speed: 12 },
      { offset: -23, speed: 2 },
      { offset: -23, speed: 0 },
    ];
    let step = 0;

    simIntervalRef.current = window.setInterval(() => {
      if (step >= waypoints.length) {
        if (simIntervalRef.current) {
          window.clearInterval(simIntervalRef.current);
          simIntervalRef.current = null;
        }
        setIsSimulatingGps(false);
        return;
      }

      const wp = waypoints[step];
      const simLat = destLat + (wp.offset / latMeters);
      const simLon = destLon;

      const simLoc: GpsLocation = {
        lat: simLat,
        lon: simLon,
        accuracy: 3,
        speed: wp.speed,
        heading: 0,
        timestamp: Date.now(),
      };

      setLocation(simLoc);
      processLocationUpdate(simLoc);

      step += 1;
    }, 1100);
  }, [processLocationUpdate]);

  /**
   * Interactive Simulator 2: Curbside Pass-Through Delivery (rolls past at delivery speed ~8-10 mph).
   * Confirms pass-through arrival as GPS readings cross the address threshold.
   */
  const simulateCurbsidePassThrough = useCallback(() => {
    const activeStop = currentStopRef.current;
    if (!activeStop || !isValidCoordinate(activeStop.lat, activeStop.lon)) return;

    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    setIsSimulatingGps(true);
    setGpsStatus('locked');
    setGpsErrorMsg(null);
    setIsPassedWithoutCompletion(false);
    setIsConfirmedArrival(false);

    const latMeters = 111132.92;
    const destLat = activeStop.lat;
    const destLon = activeStop.lon;

    // Rolls past address within the 150-ft threshold at delivery pace (10 mph):
    // -55m (~180 ft) -> -28m (~92 ft) -> 0m (closest approach 22m / ~72 ft) -> +12m (crossed threshold 1) -> +24m (crossed threshold 2)
    const waypoints = [
      { offset: -55, speed: 18 },
      { offset: -28, speed: 14 },
      { offset: 0, speed: 10 },  // Closest curbside approach (lateral offset 22m / ~72 ft)
      { offset: 12, speed: 10 }, // 1st reading moving away past destination
      { offset: 24, speed: 10 }, // 2nd reading moving away past destination -> confirms pass-through arrival
    ];
    let step = 0;

    simIntervalRef.current = window.setInterval(() => {
      if (step >= waypoints.length) {
        if (simIntervalRef.current) {
          window.clearInterval(simIntervalRef.current);
          simIntervalRef.current = null;
        }
        setIsSimulatingGps(false);
        return;
      }

      const wp = waypoints[step];
      const simLat = destLat + (wp.offset / latMeters);
      const simLon = destLon + (22 / (latMeters * Math.cos(destLat * Math.PI / 180)));

      const simLoc: GpsLocation = {
        lat: simLat,
        lon: simLon,
        accuracy: 3,
        speed: wp.speed,
        heading: 0,
        timestamp: Date.now(),
      };

      setLocation(simLoc);
      processLocationUpdate(simLoc);

      step += 1;
    }, 1100);
  }, [processLocationUpdate]);

  /**
   * Interactive Simulator 3: Approach, DRIVE PAST at 28 mph without stopping,
   * triggers live OSRM route recalculation (Turn around as soon as possible)!
   */
  const simulateApproachAndPass = useCallback(() => {
    const activeStop = currentStopRef.current;
    if (!activeStop || !isValidCoordinate(activeStop.lat, activeStop.lon)) return;

    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    setIsSimulatingGps(true);
    setGpsStatus('locked');
    setGpsErrorMsg(null);

    const latMeters = 111132.92;
    const destLat = activeStop.lat;
    const destLon = activeStop.lon;

    // Passes from -100m south to +90m north at 28 mph without slowing down
    const waypoints = [
      { offset: -100, speed: 28 },
      { offset: -45, speed: 28 },
      { offset: 0, speed: 28 },  // Driven directly past at 28 mph
      { offset: 45, speed: 28 }, // Missed address, continuing down street
      { offset: 90, speed: 28 }, // Recalculation active
    ];
    let step = 0;

    simIntervalRef.current = window.setInterval(() => {
      if (step >= waypoints.length) {
        if (simIntervalRef.current) {
          window.clearInterval(simIntervalRef.current);
          simIntervalRef.current = null;
        }
        setIsSimulatingGps(false);
        return;
      }

      const wp = waypoints[step];
      const simLat = destLat + (wp.offset / latMeters);
      const simLon = destLon + (12 / (latMeters * Math.cos(destLat * Math.PI / 180)));

      const simLoc: GpsLocation = {
        lat: simLat,
        lon: simLon,
        accuracy: 4,
        speed: wp.speed,
        heading: 0, // Traveling North away from destination
        timestamp: Date.now(),
      };

      setLocation(simLoc);
      processLocationUpdate(simLoc);

      step += 1;
    }, 1200);
  }, [processLocationUpdate]);

  const stopGpsSimulation = useCallback(() => {
    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }
    setIsSimulatingGps(false);
  }, []);

  // Calculated reactive metrics for UI display
  let distanceToCurrentMeters: number | null = null;
  let distanceToCurrentFeet: number | null = null;
  let isWithinGeofence = false;
  let isWithinArrivalConfirmZone = false;

  const currentConfirmRadius = arrivalConfirmMetersRef.current || DEFAULT_ARRIVAL_CONFIRM_METERS;

  if (location && currentStop && isValidCoordinate(currentStop.lat, currentStop.lon)) {
    distanceToCurrentMeters = calculateDistanceMeters(location.lat, location.lon, currentStop.lat, currentStop.lon);
    distanceToCurrentFeet = Math.round(distanceToCurrentMeters * 3.28084);
    isWithinGeofence = distanceToCurrentMeters <= arrivalRadiusMeters;
    isWithinArrivalConfirmZone = distanceToCurrentMeters <= currentConfirmRadius;
  }

  let finalArrivalStatus = arrivalStateDesc;
  if (gpsStatus === 'denied') {
    finalArrivalStatus = 'GPS Disabled';
  } else if (gpsStatus === 'acquiring') {
    finalArrivalStatus = 'Acquiring Satellites...';
  } else if (isConfirmedArrival) {
    finalArrivalStatus = `Arrived at Stop (${distanceToCurrentFeet} ft)`;
  } else if (isPassedWithoutCompletion) {
    finalArrivalStatus = `Passed stop (${distanceToCurrentFeet} ft) · Recalculating...`;
  } else if (isSimulatingGps) {
    finalArrivalStatus = `Simulating Road Progress (${distanceToCurrentFeet} ft)`;
  } else if (isWithinArrivalConfirmZone) {
    finalArrivalStatus = `In delivery zone (${distanceToCurrentFeet} ft / ${Math.round(currentConfirmRadius * 3.28084)} ft)`;
  } else if (isWithinGeofence) {
    finalArrivalStatus = isSharedLocationWithPrevious
      ? 'Shared Address · Tap Skip when done'
      : `Customer nearby (${distanceToCurrentFeet} ft / ${Math.round(arrivalRadiusMeters * 3.28084)} ft window)`;
  }

  return {
    location,
    gpsStatus,
    gpsErrorMsg,
    distanceToCurrentMeters,
    distanceToCurrentFeet,
    isWithinGeofence,
    isWithinArrivalConfirmZone,
    isConfirmedArrival,
    isSharedLocationWithPrevious,
    isSharedLocationWithNext,
    autoArrivalStatus: finalArrivalStatus,
    arrivalRadiusMeters,
    arrivalConfirmFeet: Math.round(currentConfirmRadius * 3.28084),
    arrivalConfirmMeters: currentConfirmRadius,
    isPassedWithoutCompletion,
    simulateApproachAndPass,
    simulateApproachAndArrive,
    simulateCurbsidePassThrough,
    isSimulatingGps,
    stopGpsSimulation,
  };
}
