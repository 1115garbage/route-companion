import { useState, useEffect, useRef, useCallback } from 'react';
import { RouteStop } from '../types/route';
import { calculateDistanceMeters, calculateBearing } from './navigationService';
import { triggerHaptic } from './voiceAndHaptics';

export interface GpsLocation {
  lat: number;
  lon: number;
  accuracy: number;
  speed: number | null; // mph
  heading: number | null;
  timestamp: number;
}

export interface UseGpsTrackerReturn {
  location: GpsLocation | null;
  gpsStatus: 'acquiring' | 'locked' | 'denied';
  gpsErrorMsg: string | null;
  distanceToCurrentMeters: number | null;
  distanceToCurrentFeet: number | null;
  isWithinGeofence: boolean;
  isSharedLocationWithPrevious: boolean;
  isSharedLocationWithNext: boolean;
  autoArrivalStatus: string;
  arrivalRadiusMeters: number;
  simulateApproachAndPass: () => void;
  isSimulatingGps: boolean;
  stopGpsSimulation: () => void;
}

// Configurable constants and safeguards
export const DEFAULT_ARRIVAL_RADIUS_METERS = 50.0; // ~164 feet
const MAX_ACCURACY_THRESHOLD_METERS = 40.0; // Filter out inaccurate GPS drift
const COOLDOWN_MS = 5000; // Minimum time between auto-advances (5 seconds)
const PASSING_DISTANCE_INCREASE_METERS = 8.0; // Distance must expand by 8m from closest point to confirm passing

/**
 * Validate latitude and longitude coordinates
 */
export function isValidCoordinate(lat: number, lon: number): boolean {
  return (
    !isNaN(lat) &&
    !isNaN(lon) &&
    lat >= -90 &&
    lat <= 90 &&
    lon >= -180 &&
    lon <= 180 &&
    !(lat === 0 && lon === 0)
  );
}

/**
 * Calculates whether the straight line path between two consecutive GPS fixes
 * passed within radiusMeters of destination coordinates.
 * Handles the edge case where GPS jumps from before the house to past the house.
 */
export function checkSegmentPassesPoint(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
  destLat: number,
  destLon: number,
  radiusMeters: number
): { passed: boolean; minDistance: number; t: number } {
  const latRad = (destLat * Math.PI) / 180;
  const cosLat = Math.cos(latRad);
  const mPerDegLat = 111132.92;
  const mPerDegLon = 111412.84 * cosLat;

  const x1 = (lon1 - destLon) * mPerDegLon;
  const y1 = (lat1 - destLat) * mPerDegLat;
  const x2 = (lon2 - destLon) * mPerDegLon;
  const y2 = (lat2 - destLat) * mPerDegLat;

  const dx = x2 - x1;
  const dy = y2 - y1;
  const lenSq = dx * dx + dy * dy;

  if (lenSq === 0) {
    const d = Math.sqrt(x1 * x1 + y1 * y1);
    return { passed: d <= radiusMeters, minDistance: d, t: 0 };
  }

  // Parameter t of closest point on segment to origin (0, 0)
  const t = -(x1 * dx + y1 * dy) / lenSq;

  if (t > 0 && t < 1) {
    const projX = x1 + t * dx;
    const projY = y1 + t * dy;
    const minDistance = Math.sqrt(projX * projX + projY * projY);
    return { passed: minDistance <= radiusMeters, minDistance, t };
  }

  const d1 = Math.sqrt(x1 * x1 + y1 * y1);
  const d2 = Math.sqrt(x2 * x2 + y2 * y2);
  const minDistance = Math.min(d1, d2);
  return { passed: minDistance <= radiusMeters, minDistance, t };
}

export function useGpsTracker(
  currentStop: RouteStop | null,
  previousStop: RouteStop | null,
  nextStop: RouteStop | null,
  onAutoAdvance: () => void,
  arrivalRadiusMeters: number = DEFAULT_ARRIVAL_RADIUS_METERS,
  roadRemainingMeters?: number | null
): UseGpsTrackerReturn {
  const [location, setLocation] = useState<GpsLocation | null>(null);
  const [gpsStatus, setGpsStatus] = useState<'acquiring' | 'locked' | 'denied'>('acquiring');
  const [gpsErrorMsg, setGpsErrorMsg] = useState<string | null>(null);
  const [arrivalStateDesc, setArrivalStateDesc] = useState<string>('Monitoring GPS');

  // Simulation state for phone/desktop indoor testing
  const [isSimulatingGps, setIsSimulatingGps] = useState(false);
  const simIntervalRef = useRef<number | null>(null);

  // Safeguard & Tracking Refs
  const minDistanceSeenRef = useRef<number>(Infinity);
  const enteredArrivalZoneRef = useRef<boolean>(false);
  const consecutiveInsideCountRef = useRef<number>(0);
  const lastLocationRef = useRef<GpsLocation | null>(null);
  const lastAdvanceTimestampRef = useRef<number>(0);
  const lastAdvancedStopIdRef = useRef<string | null>(null);
  const isAdvancingRef = useRef<boolean>(false);
  const departurePendingRef = useRef<boolean>(false);
  const activeStopIdRef = useRef<string | null>(null);

  // Keep stable refs to latest props to prevent watchPosition re-binding
  const currentStopRef = useRef(currentStop);
  currentStopRef.current = currentStop;

  const previousStopRef = useRef(previousStop);
  previousStopRef.current = previousStop;

  const nextStopRef = useRef(nextStop);
  nextStopRef.current = nextStop;

  const onAutoAdvanceRef = useRef(onAutoAdvance);
  onAutoAdvanceRef.current = onAutoAdvance;

  const arrivalRadiusRef = useRef(arrivalRadiusMeters);
  arrivalRadiusRef.current = arrivalRadiusMeters;

  const roadRemainingMetersRef = useRef(roadRemainingMeters);
  roadRemainingMetersRef.current = roadRemainingMeters;

  // Shared location check (within 15m of previous/next stop)
  const isSharedLocationWithPrevious = Boolean(
    currentStop &&
    previousStop &&
    isValidCoordinate(currentStop.lat, currentStop.lon) &&
    isValidCoordinate(previousStop.lat, previousStop.lon) &&
    calculateDistanceMeters(currentStop.lat, currentStop.lon, previousStop.lat, previousStop.lon) < 18
  );

  const isSharedLocationWithNext = Boolean(
    currentStop &&
    nextStop &&
    isValidCoordinate(currentStop.lat, currentStop.lon) &&
    isValidCoordinate(nextStop.lat, nextStop.lon) &&
    calculateDistanceMeters(currentStop.lat, currentStop.lon, nextStop.lat, nextStop.lon) < 18
  );

  const isSharedLocationWithPreviousRef = useRef(isSharedLocationWithPrevious);
  isSharedLocationWithPreviousRef.current = isSharedLocationWithPrevious;

  // Reset tracking state whenever the active customer changes
  useEffect(() => {
    const newStopId = currentStop?.id || null;
    if (newStopId !== activeStopIdRef.current) {
      activeStopIdRef.current = newStopId;
      minDistanceSeenRef.current = Infinity;
      enteredArrivalZoneRef.current = false;
      consecutiveInsideCountRef.current = 0;
      isAdvancingRef.current = false;

      // If driver is currently inside arrival radius of the NEW stop at activation,
      // require departure/movement or dwell cooldown before allowing auto-advance.
      if (
        location &&
        currentStop &&
        isValidCoordinate(currentStop.lat, currentStop.lon)
      ) {
        const d = calculateDistanceMeters(location.lat, location.lon, currentStop.lat, currentStop.lon);
        if (d <= arrivalRadiusRef.current) {
          departurePendingRef.current = true;
        } else {
          departurePendingRef.current = false;
        }
      } else {
        departurePendingRef.current = false;
      }
    }
  }, [currentStop?.id]);

  /**
   * Core Arrival Decision Engine
   * Evaluates current GPS location against the verified coordinates of currentStop
   */
  const processLocationUpdate = useCallback((currentLoc: GpsLocation) => {
    const activeStop = currentStopRef.current;
    if (!activeStop) {
      setArrivalStateDesc('No Active Route');
      return;
    }

    // 1. Verify Destination Coordinates
    if (!isValidCoordinate(activeStop.lat, activeStop.lon)) {
      setArrivalStateDesc('Invalid Destination Coordinates (Manual Skip)');
      return;
    }

    // 2. Filter out poor accuracy readings (e.g. initial tower jump > 40m)
    if (currentLoc.accuracy > MAX_ACCURACY_THRESHOLD_METERS) {
      setArrivalStateDesc(`GPS Accuracy Low (±${Math.round(currentLoc.accuracy * 3.28084)} ft)`);
      return;
    }

    const radius = arrivalRadiusRef.current;
    const distToDestination = calculateDistanceMeters(
      currentLoc.lat,
      currentLoc.lon,
      activeStop.lat,
      activeStop.lon
    );

    // Track minimum distance seen for this active stop
    if (distToDestination < minDistanceSeenRef.current) {
      minDistanceSeenRef.current = distToDestination;
    }

    const prevLoc = lastLocationRef.current;
    const now = Date.now();

    // 3. Prevent immediate cascade / double advance
    if (isAdvancingRef.current) return;
    if (now - lastAdvanceTimestampRef.current < COOLDOWN_MS) return;
    if (lastAdvancedStopIdRef.current === activeStop.id) return;

    // 4. Shared Location Safeguard (Multi-unit building or shared entrance)
    if (isSharedLocationWithPreviousRef.current && lastAdvancedStopIdRef.current === previousStopRef.current?.id) {
      // Must wait for explicit driver departure or manual skip
      setArrivalStateDesc('Shared Address · Tap Skip when done');
      return;
    }

    // 5. Departure Latch
    if (departurePendingRef.current) {
      if (distToDestination > radius * 1.1) {
        // Vehicle has driven away from the previous stop arrival zone
        departurePendingRef.current = false;
      } else if (now - lastAdvanceTimestampRef.current > 8000 && !isSharedLocationWithPreviousRef.current) {
        // Vehicle remained parked/stopped at new customer address for > 8s
        departurePendingRef.current = false;
      } else {
        setArrivalStateDesc('Departing Previous Stop...');
        return;
      }
    }

    // 6. Parallel Road Rejection
    // If road navigation reports remaining road distance much greater than straight line,
    // the vehicle is on a parallel road with no direct street connection.
    const roadDist = roadRemainingMetersRef.current;
    if (roadDist !== undefined && roadDist !== null && roadDist > Math.max(radius * 2.2, 120)) {
      setArrivalStateDesc(`Parallel Road / Route Distance ${Math.round(roadDist * 3.28084)} ft`);
      return;
    }

    let shouldArrive = false;
    let arrivalReason = '';

    // ========================================================
    // TRIGGER LOGIC A: Direct Presence inside Arrival Radius
    // ========================================================
    if (distToDestination <= radius) {
      enteredArrivalZoneRef.current = true;
      consecutiveInsideCountRef.current += 1;

      // If vehicle slowed down (stopped, parked, or crawling < 4 mph)
      const isStoppedOrSlow = currentLoc.speed !== null && currentLoc.speed <= 4.0;
      if (isStoppedOrSlow || consecutiveInsideCountRef.current >= 2) {
        shouldArrive = true;
        arrivalReason = `Reached destination (${Math.round(distToDestination * 3.28084)} ft)`;
      } else {
        setArrivalStateDesc(`In Arrival Zone (${Math.round(distToDestination * 3.28084)} ft)`);
      }
    } else {
      consecutiveInsideCountRef.current = 0;
    }

    // ========================================================
    // TRIGGER LOGIC B: Passing Detection (Closest Approach Inflection)
    // Driver drove past the customer's property without stopping
    // ========================================================
    if (
      !shouldArrive &&
      enteredArrivalZoneRef.current &&
      minDistanceSeenRef.current <= radius
    ) {
      // Distance was inside arrival radius, and has now expanded by at least 8 meters
      const distanceExpanded = distToDestination >= minDistanceSeenRef.current + PASSING_DISTANCE_INCREASE_METERS;
      const isMovingAway = prevLoc ? distToDestination > calculateDistanceMeters(prevLoc.lat, prevLoc.lon, activeStop.lat, activeStop.lon) : false;

      // Check heading: points away from destination
      const bearingToDest = calculateBearing(currentLoc.lat, currentLoc.lon, activeStop.lat, activeStop.lon);
      let headingPointsAway = false;
      if (currentLoc.heading !== null) {
        const diff = Math.abs(currentLoc.heading - bearingToDest);
        const normalizedDiff = diff > 180 ? 360 - diff : diff;
        headingPointsAway = normalizedDiff > 80;
      }

      if (distanceExpanded && isMovingAway && (headingPointsAway || (currentLoc.speed && currentLoc.speed > 5))) {
        // Vehicle passed the customer within the arrival radius and is continuing down the road
        shouldArrive = true;
        arrivalReason = `Passed customer (Closest: ${Math.round(minDistanceSeenRef.current * 3.28084)} ft)`;
      }
    }

    // ========================================================
    // TRIGGER LOGIC C: Segment Gate Crossing (Jump between GPS ticks)
    // Handles fast driving where GPS ticks fall on opposite sides of the house
    // ========================================================
    if (!shouldArrive && prevLoc) {
      const prevDist = calculateDistanceMeters(prevLoc.lat, prevLoc.lon, activeStop.lat, activeStop.lon);
      if (prevDist <= radius * 1.8 && distToDestination <= radius * 1.8) {
        const segmentResult = checkSegmentPassesPoint(
          prevLoc.lat,
          prevLoc.lon,
          currentLoc.lat,
          currentLoc.lon,
          activeStop.lat,
          activeStop.lon,
          radius
        );

        if (segmentResult.passed && segmentResult.t > 0 && segmentResult.t < 1) {
          // Trajectory crossed through the arrival radius between the two GPS samples!
          shouldArrive = true;
          arrivalReason = `Crossed stop gate (${Math.round(segmentResult.minDistance * 3.28084)} ft CPA)`;
        }
      }
    }

    // ========================================================
    // EXECUTE CONFIRMED ARRIVAL
    // ========================================================
    if (shouldArrive) {
      isAdvancingRef.current = true;
      lastAdvanceTimestampRef.current = now;
      lastAdvancedStopIdRef.current = activeStop.id;
      enteredArrivalZoneRef.current = false;
      consecutiveInsideCountRef.current = 0;
      minDistanceSeenRef.current = Infinity;

      setArrivalStateDesc(`Arrived: ${arrivalReason}`);
      triggerHaptic('complete');
      onAutoAdvanceRef.current();
      return;
    }

    // Display real-time progress text if not arrived
    if (!enteredArrivalZoneRef.current) {
      const feet = Math.round(distToDestination * 3.28084);
      setArrivalStateDesc(`${feet} ft to customer (Zone: ${Math.round(radius * 3.28084)} ft)`);
    }

    lastLocationRef.current = currentLoc;
  }, []);

  // Mount native Android GPS watcher
  useEffect(() => {
    if (typeof window === 'undefined' || !('geolocation' in navigator)) {
      setGpsStatus('denied');
      setGpsErrorMsg('GPS hardware not supported by this browser.');
      return;
    }

    setGpsStatus('acquiring');

    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        if (isSimulatingGps) return; // Do not overwrite active simulation

        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;
        const accuracy = pos.coords.accuracy || 8;
        const speed = pos.coords.speed !== null && pos.coords.speed >= 0
          ? Math.round(pos.coords.speed * 2.23694)
          : null;
        const heading = pos.coords.heading !== null && !isNaN(pos.coords.heading)
          ? pos.coords.heading
          : null;

        const currentLoc: GpsLocation = {
          lat,
          lon,
          accuracy,
          speed,
          heading,
          timestamp: pos.timestamp || Date.now(),
        };

        setLocation(currentLoc);
        setGpsStatus('locked');
        setGpsErrorMsg(null);

        processLocationUpdate(currentLoc);
      },
      (err) => {
        if (isSimulatingGps) return;
        if (err.code === err.PERMISSION_DENIED) {
          setGpsStatus('denied');
          setGpsErrorMsg('Location permission denied. Enable GPS in Android Settings.');
        } else {
          setGpsStatus('acquiring');
          setGpsErrorMsg('Acquiring satellite lock...');
        }
      },
      {
        enableHighAccuracy: true,
        maximumAge: 1000,
        timeout: 10000,
      }
    );

    return () => {
      try {
        navigator.geolocation.clearWatch(watchId);
      } catch (e) {}
    };
  }, [processLocationUpdate, isSimulatingGps]);

  // Clean up any running simulation on unmount
  useEffect(() => {
    return () => {
      if (simIntervalRef.current) {
        window.clearInterval(simIntervalRef.current);
      }
    };
  }, []);

  /**
   * Interactive Simulator: Approaches customer, enters arrival radius,
   * passes the customer, and triggers auto-advance.
   * Enables immediate phone/desktop testing without needing to drive!
   */
  const simulateApproachAndPass = useCallback(() => {
    const activeStop = currentStopRef.current;
    if (!activeStop || !isValidCoordinate(activeStop.lat, activeStop.lon)) return;

    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    setIsSimulatingGps(true);
    setGpsStatus('locked');
    setGpsErrorMsg(null);

    // Generate path that approaches from 120m south to 60m north (passing right by the address)
    const latMeters = 111132.92;
    const destLat = activeStop.lat;
    const destLon = activeStop.lon;

    // Distances relative to stop in meters (-120m approaching, -70m, -30m in zone, -10m CPA, +25m passed, +60m away)
    const waypoints = [-130, -85, -45, -15, 25, 70];
    let step = 0;

    simIntervalRef.current = window.setInterval(() => {
      if (step >= waypoints.length) {
        if (simIntervalRef.current) {
          window.clearInterval(simIntervalRef.current);
          simIntervalRef.current = null;
        }
        setIsSimulatingGps(false);
        return;
      }

      const offsetMeters = waypoints[step];
      const simLat = destLat + (offsetMeters / latMeters);
      const simLon = destLon + (15 / (latMeters * Math.cos(destLat * Math.PI / 180))); // 15m street offset

      const simLoc: GpsLocation = {
        lat: simLat,
        lon: simLon,
        accuracy: 4,
        speed: 25, // 25 mph driving
        heading: 0, // Heading north
        timestamp: Date.now(),
      };

      setLocation(simLoc);
      processLocationUpdate(simLoc);

      step += 1;
    }, 1100);
  }, [processLocationUpdate]);

  const stopGpsSimulation = useCallback(() => {
    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }
    setIsSimulatingGps(false);
  }, []);

  // Calculated reactive metrics for UI display
  let distanceToCurrentMeters: number | null = null;
  let distanceToCurrentFeet: number | null = null;
  let isWithinGeofence = false;

  if (location && currentStop && isValidCoordinate(currentStop.lat, currentStop.lon)) {
    distanceToCurrentMeters = calculateDistanceMeters(location.lat, location.lon, currentStop.lat, currentStop.lon);
    distanceToCurrentFeet = Math.round(distanceToCurrentMeters * 3.28084);
    isWithinGeofence = distanceToCurrentMeters <= arrivalRadiusMeters;
  }

  let finalArrivalStatus = arrivalStateDesc;
  if (gpsStatus === 'denied') {
    finalArrivalStatus = 'GPS Disabled';
  } else if (gpsStatus === 'acquiring') {
    finalArrivalStatus = 'Acquiring Satellites...';
  } else if (isSimulatingGps) {
    finalArrivalStatus = `Simulating Approach & Pass (${distanceToCurrentFeet} ft)`;
  } else if (isWithinGeofence) {
    finalArrivalStatus = isSharedLocationWithPrevious
      ? 'Shared Address · Tap Skip when done'
      : `In Zone (${distanceToCurrentFeet} ft / ${Math.round(arrivalRadiusMeters * 3.28084)} ft)`;
  }

  return {
    location,
    gpsStatus,
    gpsErrorMsg,
    distanceToCurrentMeters,
    distanceToCurrentFeet,
    isWithinGeofence,
    isSharedLocationWithPrevious,
    isSharedLocationWithNext,
    autoArrivalStatus: finalArrivalStatus,
    arrivalRadiusMeters,
    simulateApproachAndPass,
    isSimulatingGps,
    stopGpsSimulation,
  };
}
