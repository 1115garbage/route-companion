/**
 * Tactile haptic feedback for Samsung Android devices and browsers
 */
export function triggerHaptic(type: 'tap' | 'skip' | 'next' | 'undo' | 'complete' = 'tap') {
  if (typeof window === 'undefined') return;

  // 1. Prefer native Android Bridge if running inside Android APK wrapper
  try {
    const androidBridge = (window as any).AndroidBridge;
    if (androidBridge && typeof androidBridge.vibrate === 'function') {
      androidBridge.vibrate(type);
      return;
    }
  } catch (err) {
    // Non-blocking
  }

  // 2. Web browser fallback with navigator.vibrate
  if (!('vibrate' in navigator)) return;

  try {
    switch (type) {
      case 'skip':
        navigator.vibrate([60, 40, 80]);
        break;
      case 'next':
        navigator.vibrate(45);
        break;
      case 'undo':
        navigator.vibrate([30, 30, 30]);
        break;
      case 'complete':
        navigator.vibrate([100, 50, 100, 50, 150]);
        break;
      case 'tap':
      default:
        navigator.vibrate(30);
        break;
    }
  } catch (err) {
    // Graceful fallback
  }
}

/**
 * Text-to-speech announcement for hands-free driving
 */
export function announceStop(customerName: string, houseNumber: string, streetName: string) {
  if (typeof window === 'undefined') return;

  let text = `Next customer: ${customerName}.`;
  if (houseNumber) {
    text += ` Number ${houseNumber}, ${streetName || ''}`;
  }

  // 1. Prefer native Android Bridge TTS (never blocks main thread)
  try {
    const androidBridge = (window as any).AndroidBridge;
    if (androidBridge && typeof androidBridge.speak === 'function') {
      androidBridge.speak(text);
      return;
    }
  } catch (err) {
    // Non-blocking
  }

  // 2. Web browser fallback with SpeechSynthesis (only when not inside Android wrapper)
  if (!('speechSynthesis' in window)) return;

  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.05;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;
    window.speechSynthesis.speak(utterance);
  } catch (err) {
    // Non-blocking
  }
}

/**
 * Screen WakeLock manager to prevent screen from dimming/sleeping on phone mount
 */
let wakeLockSentinel: any = null;

export async function requestWakeLock(): Promise<boolean> {
  if (typeof window === 'undefined') return false;

  // If in Android native app, FLAG_KEEP_SCREEN_ON is already set on the Window
  if ((window as any).AndroidBridge) {
    return true;
  }

  if (!('wakeLock' in navigator)) {
    return false;
  }
  try {
    wakeLockSentinel = await (navigator as any).wakeLock.request('screen');
    wakeLockSentinel.addEventListener('release', () => {
      wakeLockSentinel = null;
    });
    return true;
  } catch (err) {
    return false;
  }
}

export function releaseWakeLock() {
  if (wakeLockSentinel) {
    try {
      wakeLockSentinel.release();
    } catch (e) {
      // ignore
    }
    wakeLockSentinel = null;
  }
}

/**
 * Generate navigation URIs for OsmAnd and standard Android map handlers
 */
export function getNavigationLinks(lat: number, lon: number, label: string) {
  const encodedLabel = encodeURIComponent(label || 'Customer Stop');
  
  // Standard geo URI (will open OsmAnd or default Android map app)
  const geoUri = `geo:${lat},${lon}?q=${lat},${lon}(${encodedLabel})`;
  
  // OsmAnd direct intent URI
  const osmandUri = `osmand.navigation:q=${lat},${lon}`;
  
  // Google Maps fallback web link
  const gmapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lon}`;

  return { geoUri, osmandUri, gmapsUrl };
}
