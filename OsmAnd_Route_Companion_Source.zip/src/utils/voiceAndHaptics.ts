/**
 * Tactile haptic feedback for Samsung Android devices and browsers
 */
export function triggerHaptic(type: 'tap' | 'skip' | 'next' | 'undo' | 'complete' = 'tap') {
  if (typeof window === 'undefined') return;

  // 1. Prefer native Android Bridge if running inside Android APK wrapper
  try {
    const androidBridge = (window as any).AndroidBridge;
    if (androidBridge && typeof androidBridge.vibrate === 'function') {
      androidBridge.vibrate(type);
      return;
    }
  } catch (err) {
    // Non-blocking
  }

  // 2. Web browser fallback with navigator.vibrate
  if (!('vibrate' in navigator)) return;

  try {
    switch (type) {
      case 'skip':
        navigator.vibrate([60, 40, 80]);
        break;
      case 'next':
        navigator.vibrate(45);
        break;
      case 'undo':
        navigator.vibrate([30, 30, 30]);
        break;
      case 'complete':
        navigator.vibrate([100, 50, 100, 50, 150]);
        break;
      case 'tap':
      default:
        navigator.vibrate(30);
        break;
    }
  } catch (err) {
    // Graceful fallback
  }
}

import { NavManeuver } from './navigationService';

/**
 * Coordinated Speech Queue & Manager
 * Prevents overlapping speech, prevents turn warnings from cutting off
 * customer announcements, and drops obsolete instructions on reroute.
 */
interface SpeechItem {
  id: string;
  text: string;
  priority: 'high' | 'normal';
  createdAt: number;
  maxAgeMs: number;
}

class SpeechCoordinator {
  private queue: SpeechItem[] = [];
  private isSpeaking = false;
  private currentPriority: 'high' | 'normal' | null = null;
  private safetyTimer: any = null;
  private activeUtterance: SpeechSynthesisUtterance | null = null;
  private lastSpokenText = '';
  private lastSpokenTime = 0;

  public speak(item: SpeechItem) {
    const now = Date.now();

    // Prevent immediate duplicate speech within 6 seconds
    if (this.lastSpokenText === item.text && now - this.lastSpokenTime < 6000) {
      return;
    }

    if (item.priority === 'high') {
      // High priority (Customer arrival, next customer, turnaround)
      // Discard any queued lower-priority turn announcements so they don't delay customer info
      this.queue = this.queue.filter((q) => q.priority === 'high');

      // If currently speaking a normal priority turn, stop it immediately
      if (this.isSpeaking && this.currentPriority === 'normal') {
        this.stopCurrent();
      }

      // Add to front of queue
      this.queue.unshift(item);
    } else {
      // Normal priority (Upcoming turn warning)
      // Discard expired items
      this.queue = this.queue.filter((q) => now - q.createdAt < q.maxAgeMs);
      if (this.queue.length >= 2) {
        // Drop oldest normal priority item
        const normalIdx = this.queue.findIndex((q) => q.priority === 'normal');
        if (normalIdx >= 0) this.queue.splice(normalIdx, 1);
      }
      this.queue.push(item);
    }

    this.processQueue();
  }

  public cancelNormalPriority() {
    this.queue = this.queue.filter((item) => item.priority === 'high');
    if (this.isSpeaking && this.currentPriority === 'normal') {
      this.stopCurrent();
    }
  }

  private stopCurrent() {
    if (this.safetyTimer) {
      clearTimeout(this.safetyTimer);
      this.safetyTimer = null;
    }
    this.isSpeaking = false;
    this.currentPriority = null;
    this.activeUtterance = null;

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch (e) {}
    }
  }

  private processQueue() {
    if (this.isSpeaking) return;
    if (this.queue.length === 0) return;

    const now = Date.now();
    // Drop expired items
    while (this.queue.length > 0 && now - this.queue[0].createdAt > this.queue[0].maxAgeMs) {
      this.queue.shift();
    }
    if (this.queue.length === 0) return;

    const item = this.queue.shift()!;
    this.executeSpeak(item);
  }

  private executeSpeak(item: SpeechItem) {
    this.isSpeaking = true;
    this.currentPriority = item.priority;
    this.lastSpokenText = item.text;
    this.lastSpokenTime = Date.now();

    // 1. Android Bridge TTS (native wrapper)
    try {
      const androidBridge = (window as any).AndroidBridge;
      if (androidBridge && typeof androidBridge.speak === 'function') {
        androidBridge.speak(item.text);
        const wordCount = item.text.split(/\s+/).length;
        const estimatedDurationMs = Math.max(1200, wordCount * 360);
        this.safetyTimer = setTimeout(() => {
          this.isSpeaking = false;
          this.currentPriority = null;
          this.processQueue();
        }, estimatedDurationMs);
        return;
      }
    } catch (e) {
      // Fall through to Web Speech API
    }

    // 2. Web browser fallback with SpeechSynthesis
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      this.isSpeaking = false;
      this.currentPriority = null;
      return;
    }

    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(item.text);
      utterance.rate = 1.05;
      utterance.pitch = 1.0;
      utterance.volume = 1.0;

      const finish = () => {
        if (this.safetyTimer) {
          clearTimeout(this.safetyTimer);
          this.safetyTimer = null;
        }
        this.isSpeaking = false;
        this.currentPriority = null;
        this.activeUtterance = null;
        // Small 200ms pause between utterances
        setTimeout(() => {
          this.processQueue();
        }, 200);
      };

      utterance.onend = finish;
      utterance.onerror = finish;

      // Chrome safety timeout in case onend fails to fire
      const wordCount = item.text.split(/\s+/).length;
      const maxDurationMs = Math.max(2500, wordCount * 500);
      this.safetyTimer = setTimeout(finish, maxDurationMs);

      this.activeUtterance = utterance;
      window.speechSynthesis.speak(utterance);
    } catch (err) {
      this.isSpeaking = false;
      this.currentPriority = null;
      this.activeUtterance = null;
    }
  }
}

const speechCoordinator = new SpeechCoordinator();

/**
 * Format spoken text for upcoming maneuver and advance distance.
 * Examples:
 * - "Right turn in 500 feet."
 * - "Left turn in 300 feet."
 * - "Turn right onto Main Street in 200 feet."
 * - "Turn around as soon as possible."
 */
export function formatManeuverSpokenText(maneuver: NavManeuver, distanceFeet: number): string {
  if (!maneuver) return '';
  const mod = (maneuver.modifier || '').toLowerCase().trim();
  const type = (maneuver.type || '').toLowerCase().trim();
  const rawStreet = (maneuver.streetName || '').trim();
  const hasStreet = rawStreet.length > 0 && !rawStreet.toLowerCase().startsWith('unnamed');
  const street = hasStreet ? rawStreet : '';

  // Turnaround maneuver
  if (mod.includes('uturn') || mod.includes('turnaround') || type === 'turnaround') {
    return 'Turn around as soon as possible.';
  }

  // Roundabout / Rotary
  if (type === 'roundabout' || type === 'rotary') {
    return street
      ? `Enter the roundabout toward ${street} in ${distanceFeet} feet.`
      : `Enter the roundabout in ${distanceFeet} feet.`;
  }

  // Fork
  if (type === 'fork') {
    const side = mod.includes('left') ? 'left' : 'right';
    return street
      ? `Keep ${side} at the fork onto ${street} in ${distanceFeet} feet.`
      : `Keep ${side} at the fork in ${distanceFeet} feet.`;
  }

  // End of road
  if (type === 'end of road') {
    const side = mod.includes('left') ? 'left' : 'right';
    return street
      ? `Turn ${side} at the end of the road onto ${street} in ${distanceFeet} feet.`
      : `Turn ${side} at the end of the road in ${distanceFeet} feet.`;
  }

  // Ramp / Merge
  if (type === 'ramp' || type === 'on ramp' || type === 'off ramp') {
    return street
      ? `Take the ramp onto ${street} in ${distanceFeet} feet.`
      : `Take the ramp in ${distanceFeet} feet.`;
  }

  if (type === 'merge') {
    const side = mod.includes('left') ? 'left' : 'right';
    return street
      ? `Merge ${side} onto ${street} in ${distanceFeet} feet.`
      : `Merge ${side} in ${distanceFeet} feet.`;
  }

  // Standard turns
  switch (mod) {
    case 'right':
      return street
        ? `Turn right onto ${street} in ${distanceFeet} feet.`
        : `Right turn in ${distanceFeet} feet.`;
    case 'left':
      return street
        ? `Turn left onto ${street} in ${distanceFeet} feet.`
        : `Left turn in ${distanceFeet} feet.`;
    case 'slight right':
      return street
        ? `Bear slightly right onto ${street} in ${distanceFeet} feet.`
        : `Bear slightly right in ${distanceFeet} feet.`;
    case 'slight left':
      return street
        ? `Bear slightly left onto ${street} in ${distanceFeet} feet.`
        : `Bear slightly left in ${distanceFeet} feet.`;
    case 'sharp right':
      return street
        ? `Make a sharp right onto ${street} in ${distanceFeet} feet.`
        : `Sharp right in ${distanceFeet} feet.`;
    case 'sharp left':
      return street
        ? `Make a sharp left onto ${street} in ${distanceFeet} feet.`
        : `Sharp left in ${distanceFeet} feet.`;
    case 'straight':
      return street
        ? `Continue straight on ${street} in ${distanceFeet} feet.`
        : `Continue straight in ${distanceFeet} feet.`;
    default:
      if (type === 'turn') {
        return street
          ? `Turn onto ${street} in ${distanceFeet} feet.`
          : `Turn ahead in ${distanceFeet} feet.`;
      }
      return '';
  }
}

/**
 * Checks whether a NavManeuver is a spoken road turn
 */
export function isTurnManeuver(m: NavManeuver): boolean {
  if (!m) return false;
  const t = (m.type || '').toLowerCase();
  const mod = (m.modifier || '').toLowerCase();
  if (t === 'arrive' || t === 'depart') return false;
  if (mod.includes('left') || mod.includes('right') || mod.includes('uturn') || mod.includes('turnaround')) return true;
  if (t === 'turn' || t === 'fork' || t === 'roundabout' || t === 'rotary' || t === 'end of road' || t === 'merge' || t === 'ramp') return true;
  return false;
}

/**
 * Text-to-speech announcement for hands-free driving
 * Continuous customer arrival and customer stop announcement (HIGH priority)
 */
export function announceStop(customerName: string, houseNumber: string, streetName: string) {
  if (typeof window === 'undefined') return;

  let text = `Next customer: ${customerName}.`;
  if (houseNumber) {
    text += ` Number ${houseNumber}, ${streetName || ''}`;
  }

  speechCoordinator.speak({
    id: `stop_${Date.now()}`,
    text,
    priority: 'high',
    createdAt: Date.now(),
    maxAgeMs: 15000,
  });
}

/**
 * Voice guidance for missed stops and turnaround maneuvers (HIGH priority)
 * Preferred exact wording: "Turn around as soon as possible."
 */
let lastTurnaroundSpokenTime = 0;

export function announceTurnaround() {
  if (typeof window === 'undefined') return;

  const now = Date.now();
  // Prevent repeating more than once every 12 seconds
  if (now - lastTurnaroundSpokenTime < 12000) return;
  lastTurnaroundSpokenTime = now;

  const text = 'Turn around as soon as possible.';

  speechCoordinator.speak({
    id: `turnaround_${now}`,
    text,
    priority: 'high',
    createdAt: now,
    maxAgeMs: 8000,
  });
}

/**
 * Spoken voice announcement for upcoming driving maneuver at distance threshold (NORMAL priority)
 */
export function announceTurn(maneuver: NavManeuver, distanceFeet: number) {
  if (typeof window === 'undefined') return;

  const text = formatManeuverSpokenText(maneuver, distanceFeet);
  if (!text) return;

  speechCoordinator.speak({
    id: `turn_${distanceFeet}_${Date.now()}`,
    text,
    priority: 'normal',
    createdAt: Date.now(),
    maxAgeMs: 5000,
  });
}

/**
 * Cancel and flush upcoming turn announcements (e.g. on route recalculation or customer advance)
 */
export function cancelTurnAnnouncements() {
  speechCoordinator.cancelNormalPriority();
}

/**
 * Screen WakeLock manager to prevent screen from dimming/sleeping on phone mount
 */
let wakeLockSentinel: any = null;

export async function requestWakeLock(): Promise<boolean> {
  if (typeof window === 'undefined') return false;

  // If in Android native app, FLAG_KEEP_SCREEN_ON is already set on the Window
  if ((window as any).AndroidBridge) {
    return true;
  }

  if (!('wakeLock' in navigator)) {
    return false;
  }
  try {
    wakeLockSentinel = await (navigator as any).wakeLock.request('screen');
    wakeLockSentinel.addEventListener('release', () => {
      wakeLockSentinel = null;
    });
    return true;
  } catch (err) {
    return false;
  }
}

export function releaseWakeLock() {
  if (wakeLockSentinel) {
    try {
      wakeLockSentinel.release();
    } catch (e) {
      // ignore
    }
    wakeLockSentinel = null;
  }
}

/**
 * Generate navigation URIs for OsmAnd and standard Android map handlers
 */
export function getNavigationLinks(lat: number, lon: number, label: string) {
  const encodedLabel = encodeURIComponent(label || 'Customer Stop');
  
  // Standard geo URI (will open OsmAnd or default Android map app)
  const geoUri = `geo:${lat},${lon}?q=${lat},${lon}(${encodedLabel})`;
  
  // OsmAnd direct intent URI
  const osmandUri = `osmand.navigation:q=${lat},${lon}`;
  
  // Google Maps fallback web link
  const gmapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lon}`;

  return { geoUri, osmandUri, gmapsUrl };
}
