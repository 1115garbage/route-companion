import React, { useState } from 'react';
import { RouteStop, AppSettings } from '../types/route';
import { TurnByTurnPanel } from './TurnByTurnPanel';
import { RoadMapView } from './RoadMapView';
import { GpsLocation } from '../utils/useGpsTracker';
import { getStopHouseNumber } from '../utils/gpxParser';
import { 
  ChevronLeft, 
  SkipForward, 
  List,
  Map
} from 'lucide-react';

interface StopCardProps {
  stop: RouteStop;
  previousStop?: RouteStop;
  nextStop?: RouteStop;
  userLocation: GpsLocation | null;
  gpsStatus: 'acquiring' | 'locked' | 'denied';
  gpsErrorMsg: string | null;
  distanceToCurrentFeet: number | null;
  isWithinGeofence: boolean;
  isConfirmedArrival?: boolean;
  isSharedLocationWithPrevious: boolean;
  isSharedLocationWithNext: boolean;
  autoArrivalStatus: string;
  currentIndex: number;
  totalStops: number;
  completedCount: number;
  skippedCount: number;
  settings: AppSettings;
  onSkip: () => void;
  onPrevious: () => void;
  onJumpToStopList: () => void;
  arrivalRadiusMeters?: number;
  isPassedWithoutCompletion?: boolean;
  simulateApproachAndPass?: () => void;
  simulateApproachAndArrive?: () => void;
  isSimulatingGps?: boolean;
  stopGpsSimulation?: () => void;
}

export const StopCard: React.FC<StopCardProps> = ({
  stop,
  previousStop,
  nextStop,
  userLocation,
  gpsStatus,
  gpsErrorMsg,
  distanceToCurrentFeet,
  isWithinGeofence,
  isConfirmedArrival = false,
  autoArrivalStatus,
  currentIndex,
  totalStops,
  settings,
  onSkip,
  onPrevious,
  onJumpToStopList,
  arrivalRadiusMeters,
  isPassedWithoutCompletion,
  simulateApproachAndPass,
  simulateApproachAndArrive,
  isSimulatingGps,
  stopGpsSimulation,
}) => {
  const isDark = settings.theme === 'amoled-black';

  // Toggle map view on/off (defaults to map-free large-text navigation)
  const [isMapOpen, setIsMapOpen] = useState(false);
  const [routeCoordinates, setRouteCoordinates] = useState<[number, number][]>([]);

  // Extract true house number from the customer's delivery address data (never stop sequence e.g. "002")
  const displayHouseNumber = getStopHouseNumber(stop, currentIndex);

  return (
    <div className="flex flex-col h-full justify-between pb-safe select-none overflow-hidden">
      {/* 1. Turn-by-Turn Navigation Panel at the very top (compacted for S26 viewport) */}
      <div className="shrink-0">
        <TurnByTurnPanel
          currentStop={stop}
          previousStop={previousStop}
          nextStop={nextStop}
          userLocation={userLocation}
          gpsStatus={gpsStatus}
          gpsErrorMsg={gpsErrorMsg}
          distanceToCurrentFeet={distanceToCurrentFeet}
          isDark={isDark}
          arrivalRadiusMeters={arrivalRadiusMeters || settings.arrivalRadiusMeters || 152.4}
          isWithinGeofence={isWithinGeofence}
          isConfirmedArrival={isConfirmedArrival}
          autoArrivalStatus={autoArrivalStatus}
          isPassedWithoutCompletion={isPassedWithoutCompletion}
          simulateApproachAndPass={simulateApproachAndPass}
          simulateApproachAndArrive={simulateApproachAndArrive}
          isSimulatingGps={isSimulatingGps}
          stopGpsSimulation={stopGpsSimulation}
          onRouteCoordinatesUpdate={setRouteCoordinates}
          onSkipCustomer={onSkip}
          voiceAnnouncement={settings.voiceAnnouncement}
        />
      </div>

      {/* 2. Stop Number, Show Map / Hide Map Toggle, and Previous Button */}
      <div className="shrink-0 flex items-center justify-between px-1 py-0.5 mb-1 gap-2">
        <button
          onClick={onJumpToStopList}
          className="flex items-center gap-1.5 text-xs font-mono font-bold text-neutral-400 hover:text-white transition-colors"
          title="Open Stop List"
        >
          <span className="text-emerald-400">STOP {currentIndex + 1} OF {totalStops}</span>
          <List className="w-3.5 h-3.5 text-neutral-500" />
        </button>

        <div className="flex items-center gap-1.5">
          {/* Show Map / Hide Map toggle button located near the STOP 5 OF 175 area */}
          <button
            onClick={() => setIsMapOpen((prev) => !prev)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-black uppercase tracking-wider transition-all active:scale-95 border ${
              isMapOpen
                ? 'bg-amber-400 text-black border-amber-300 shadow-md shadow-amber-950/40'
                : 'bg-neutral-900 hover:bg-neutral-800 text-amber-400 border-neutral-700'
            }`}
            title={isMapOpen ? 'Hide road map' : 'Show road map'}
          >
            <Map className="w-3.5 h-3.5" />
            <span>{isMapOpen ? 'Hide Map' : 'Show Map'}</span>
          </button>

          {currentIndex > 0 && (
            <button
              onClick={onPrevious}
              className="flex items-center gap-1 text-[11px] font-semibold text-neutral-400 hover:text-white px-2 py-1 rounded-lg bg-neutral-900 border border-neutral-800 transition-colors active:scale-95"
              title="Return to previous customer"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Prev</span>
            </button>
          )}
        </div>
      </div>

      {/* 3 & 4. Main Display Area: Map Mode OR Customer Name & Large Yellow House-Number Block */}
      {isMapOpen ? (
        /* MAP MODE: Live interactive road map with compact customer header */
        <div className="flex-1 flex flex-col min-h-0 my-auto py-1 space-y-1.5">
          {/* Compact Customer & House Number Strip */}
          <div className="shrink-0 flex items-center justify-between bg-neutral-900/90 border border-neutral-800 rounded-xl px-3 py-1.5">
            <div className="min-w-0 flex-1 pr-2">
              <div className="text-sm font-black text-white truncate">{stop.name}</div>
              {stop.fullAddress && (
                <div className="text-[11px] font-semibold text-neutral-400 truncate">{stop.fullAddress}</div>
              )}
            </div>
            <div className="shrink-0 px-2.5 py-0.5 bg-amber-400 text-black font-black font-mono text-xl rounded-lg border border-amber-300 shadow">
              {displayHouseNumber}
            </div>
          </div>

          {/* Real OpenStreetMap Road Map */}
          <div className="flex-1 min-h-[160px] max-h-[250px] w-full">
            <RoadMapView
              userLocation={userLocation}
              destination={{
                lat: stop.lat,
                lon: stop.lon,
                name: stop.name,
                houseNumber: displayHouseNumber,
                address: stop.fullAddress,
              }}
              routeCoordinates={routeCoordinates}
              isDark={isDark}
            />
          </div>
        </div>
      ) : (
        /* DEFAULT MAP-FREE MODE: Large Customer Name + Large Yellow House-Number Block */
        <div className="flex-1 flex flex-col items-center justify-center my-auto py-1 text-center min-h-0">
          {/* Customer's Name in Large Text */}
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight leading-snug mb-2 px-2 max-w-md break-words line-clamp-2">
            {stop.name}
          </h1>

          {/* Yellow House-Number Block with Very Large Number */}
          <div 
            className="bg-amber-400 text-black border-2 border-amber-300 rounded-2xl px-6 py-2.5 sm:py-3 flex items-center justify-center shadow-xl min-w-[160px] max-w-[260px] transition-transform active:scale-95"
          >
            <span className="text-5xl sm:text-6xl font-black font-mono tracking-tighter leading-none">
              {displayHouseNumber}
            </span>
          </div>
        </div>
      )}

      {/* 5. Orange SKIP CUSTOMER Button at the Bottom (Tightened to fit S26 without scrolling) */}
      <div className="shrink-0 pt-1.5">
        <button
          onClick={onSkip}
          className="w-full h-12 sm:h-13 rounded-xl flex items-center justify-center gap-2 font-black text-base sm:text-lg tracking-wide uppercase bg-amber-500 hover:bg-amber-400 text-black border-2 border-amber-300 shadow-lg shadow-amber-950/40 transition-all active:scale-[0.98]"
        >
          <SkipForward className="w-5 h-5 stroke-[3]" />
          <span>Skip Customer</span>
        </button>
      </div>
    </div>
  );
};
