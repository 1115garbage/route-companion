import React, { useState } from 'react';
import { RouteStop, AppSettings } from '../types/route';
import { getNavigationLinks, triggerHaptic } from '../utils/voiceAndHaptics';
import { TurnByTurnPanel } from './TurnByTurnPanel';
import { MapView } from './MapView';
import { GpsLocation } from '../utils/useGpsTracker';
import { getStopHouseNumber } from '../utils/gpxParser';
import { 
  ChevronLeft, 
  SkipForward, 
  Compass,
  List,
  Map as MapIcon,
  EyeOff
} from 'lucide-react';

interface StopCardProps {
  stop: RouteStop;
  stops: RouteStop[];
  previousStop?: RouteStop;
  nextStop?: RouteStop;
  userLocation: GpsLocation | null;
  gpsStatus: 'acquiring' | 'locked' | 'denied';
  gpsErrorMsg: string | null;
  distanceToCurrentFeet: number | null;
  isWithinGeofence: boolean;
  isSharedLocationWithPrevious: boolean;
  isSharedLocationWithNext: boolean;
  autoArrivalStatus: string;
  currentIndex: number;
  totalStops: number;
  completedCount: number;
  skippedCount: number;
  settings: AppSettings;
  onSkip: () => void;
  onPrevious: () => void;
  onJumpToStopList: () => void;
  arrivalRadiusMeters?: number;
  isPassedWithoutCompletion?: boolean;
  simulateApproachAndPass?: () => void;
  simulateApproachAndArrive?: () => void;
  simulateParallelRoadTest?: () => void;
  isSimulatingGps?: boolean;
  stopGpsSimulation?: () => void;
  routeCoordinates?: [number, number][];
  onRouteCalculated?: (coords: [number, number][], distanceMeters: number) => void;
  isMapVisible: boolean;
  onToggleMap: () => void;
}

export const StopCard: React.FC<StopCardProps> = ({
  stop,
  stops,
  previousStop,
  userLocation,
  gpsStatus,
  gpsErrorMsg,
  distanceToCurrentFeet,
  isWithinGeofence,
  autoArrivalStatus,
  currentIndex,
  totalStops,
  settings,
  onSkip,
  onPrevious,
  onJumpToStopList,
  arrivalRadiusMeters,
  isPassedWithoutCompletion,
  simulateApproachAndPass,
  simulateApproachAndArrive,
  simulateParallelRoadTest,
  isSimulatingGps,
  stopGpsSimulation,
  routeCoordinates = [],
  onRouteCalculated,
  isMapVisible,
  onToggleMap,
}) => {
  const isDark = settings.theme === 'amoled-black';
  const { osmandUri } = getNavigationLinks(stop.lat, stop.lon, stop.name);

  // Extract true house number from the customer's delivery address data
  const displayHouseNumber = getStopHouseNumber(stop, currentIndex);

  const openOsmAnd = (e: React.MouseEvent) => {
    e.preventDefault();
    triggerHaptic('tap');

    if (!stop.lat || !stop.lon || (stop.lat === 0 && stop.lon === 0)) {
      return;
    }

    // 1. Native Android Bridge
    try {
      const bridge = (window as any).AndroidBridge;
      if (bridge && typeof bridge.openOsmAnd === 'function') {
        bridge.openOsmAnd(stop.lat, stop.lon);
        return;
      }
    } catch (err) {}

    // 2. Safe browser fallback
    try {
      window.location.href = osmandUri;
    } catch (err) {}
  };

  return (
    <div className="flex flex-col h-full justify-between pb-safe select-none">
      {/* 1. Turn-by-Turn Navigation Panel at the very top */}
      <div className="shrink-0">
        <TurnByTurnPanel
          currentStop={stop}
          previousStop={previousStop}
          userLocation={userLocation}
          gpsStatus={gpsStatus}
          gpsErrorMsg={gpsErrorMsg}
          distanceToCurrentFeet={distanceToCurrentFeet}
          isDark={isDark}
          onOpenOsmAnd={openOsmAnd}
          arrivalRadiusMeters={arrivalRadiusMeters || settings.arrivalRadiusMeters || 152.4}
          isWithinGeofence={isWithinGeofence}
          autoArrivalStatus={autoArrivalStatus}
          isPassedWithoutCompletion={isPassedWithoutCompletion}
          simulateApproachAndPass={simulateApproachAndPass}
          simulateApproachAndArrive={simulateApproachAndArrive}
          simulateParallelRoadTest={simulateParallelRoadTest}
          isSimulatingGps={isSimulatingGps}
          stopGpsSimulation={stopGpsSimulation}
          onRouteCalculated={onRouteCalculated}
          isMapVisible={isMapVisible}
          onToggleMap={onToggleMap}
        />
      </div>

      {/* 2. Stop Number, Total Stops & View Toggle Control */}
      <div className="shrink-0 flex items-center justify-between px-1 py-1 mb-1">
        <div className="flex items-center gap-2">
          <button
            onClick={onJumpToStopList}
            className="flex items-center gap-1.5 text-xs font-mono font-bold text-neutral-400 hover:text-white transition-colors"
            title="Open Stop List"
          >
            <span className="text-emerald-400">STOP {currentIndex + 1} OF {totalStops}</span>
            <List className="w-3.5 h-3.5 text-neutral-500" />
          </button>

          {/* Map view status indicator */}
          <button
            onClick={onToggleMap}
            className={`flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-mono font-bold border transition-colors ${
              isMapVisible
                ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
            }`}
            title="Toggle Map View"
          >
            <MapIcon className="w-3 h-3" />
            <span>{isMapVisible ? 'Map: ON' : 'Map: OFF'}</span>
          </button>
        </div>

        {currentIndex > 0 && (
          <button
            onClick={onPrevious}
            className="flex items-center gap-1 text-[11px] font-semibold text-neutral-400 hover:text-white px-2.5 py-1 rounded-xl bg-neutral-900 border border-neutral-800 transition-colors"
            title="Return to previous customer"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            <span>Prev</span>
          </button>
        )}
      </div>

      {/* 3. Main Central Content: Optional Map View OR Minimal Large House-Number Display */}
      {isMapVisible ? (
        /* MAP VIEW MODE: Real Road Map with Driver, Destination, 500ft Circle & Route */
        <div className="flex-1 flex flex-col min-h-[320px] mb-2 relative">
          <MapView
            currentStop={stop}
            stops={stops}
            currentIndex={currentIndex}
            userLocation={userLocation}
            routeCoordinates={routeCoordinates}
            arrivalRadiusMeters={arrivalRadiusMeters || 152.4}
            isDark={isDark}
            className="flex-1"
          />

          {/* Floating Customer Info Bar over map for Driver Glanceability */}
          <div className="mt-2 p-2.5 rounded-2xl bg-neutral-900/95 border border-neutral-800 flex items-center justify-between gap-3 shadow-xl backdrop-blur-md">
            <div className="min-w-0 flex-1">
              <h3 className="font-bold text-sm text-white truncate">{stop.name}</h3>
              <p className="text-[11px] text-neutral-400 truncate">{stop.fullAddress || stop.streetName}</p>
            </div>
            
            {/* House Number Badge */}
            <div className="bg-amber-400 text-black px-3 py-1 rounded-xl font-black font-mono text-base border border-amber-300 shadow shrink-0">
              {displayHouseNumber}
            </div>

            {/* OsmAnd Link */}
            <a
              href={osmandUri}
              onClick={openOsmAnd}
              className="p-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white text-xs shrink-0"
              title="Open in OsmAnd"
            >
              <Compass className="w-4 h-4 text-orange-400" />
            </a>
          </div>
        </div>
      ) : (
        /* MAP-FREE MODE (DEFAULT): Large Minimalist Typography + Very Large Yellow House-Number Block */
        <div className="flex-1 flex flex-col items-center justify-center my-auto py-4 text-center">
          {/* Customer's Name in Large Text */}
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight leading-tight mb-4 px-2 max-w-md break-words">
            {stop.name}
          </h1>

          {/* Yellow House-Number Block with Very Large Number */}
          <div 
            className="bg-amber-400 text-black border-2 border-amber-300 rounded-3xl px-8 py-5 flex items-center justify-center shadow-2xl min-w-[200px] max-w-[320px] transition-transform active:scale-95"
          >
            <span className="text-6xl sm:text-7xl font-black font-mono tracking-tighter leading-none">
              {displayHouseNumber}
            </span>
          </div>

          {/* Secondary Actions directly beneath the house number box with clean, compact spacing */}
          <div className="mt-3.5 flex items-center gap-2">
            <a
              href={osmandUri}
              onClick={openOsmAnd}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white text-xs font-medium transition-colors"
              title="Open in OsmAnd"
            >
              <Compass className="w-3.5 h-3.5 text-orange-400" />
              <span>Open in OsmAnd</span>
            </a>

            <button
              onClick={onToggleMap}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white text-xs font-medium transition-colors"
              title="Show Road Map"
            >
              <MapIcon className="w-3.5 h-3.5 text-emerald-400" />
              <span>Show Map</span>
            </button>
          </div>
        </div>
      )}

      {/* 4. Large Orange SKIP CUSTOMER Button at the Bottom */}
      <div className="shrink-0 pt-2">
        <button
          onClick={onSkip}
          className="w-full h-18 rounded-2xl flex items-center justify-center gap-3 font-black text-xl tracking-wide uppercase bg-amber-500 hover:bg-amber-400 text-black border-2 border-amber-300 shadow-xl shadow-amber-950/50 transition-all active:scale-[0.98]"
        >
          <SkipForward className="w-7 h-7 stroke-[3]" />
          <span>Skip Customer</span>
        </button>
      </div>
    </div>
  );
};
