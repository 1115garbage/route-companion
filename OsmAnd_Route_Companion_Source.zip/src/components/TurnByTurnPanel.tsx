import React, { useState, useEffect, useRef, useCallback } from 'react';
import { RouteStop } from '../types/route';
import { GpsLocation } from '../utils/useGpsTracker';
import { 
  NavManeuver, 
  fetchOsmRoute, 
  calculateDistanceMeters, 
  calculateDistanceToPolylineMeters, 
  formatDistance, 
  formatDuration 
} from '../utils/navigationService';
import { 
  Compass, 
  Play, 
  Square, 
  RotateCcw, 
  X, 
  Info, 
  CheckCircle2, 
  Sparkles,
  CornerUpRight, 
  CornerUpLeft, 
  ArrowUp, 
  ArrowUpRight, 
  ArrowUpLeft,
  CircleDot, 
  GitFork, 
  Flag,
  Map as MapIcon,
  ShieldAlert,
  FastForward
} from 'lucide-react';

function isValidCoordinate(lat: number, lon: number): boolean {
  return (
    !isNaN(lat) &&
    !isNaN(lon) &&
    lat >= -90 &&
    lat <= 90 &&
    lon >= -180 &&
    lon <= 180 &&
    !(lat === 0 && lon === 0)
  );
}

// ==========================================
// 1. Maneuver Icon Component with Prominent U-Turn
// ==========================================
export const ManeuverIconComponent: React.FC<{ type?: string; modifier?: string; className?: string }> = ({ 
  type = 'turn', 
  modifier = 'straight',
  className = 'w-10 h-10' 
}) => {
  const mod = (modifier || '').toLowerCase();
  const t = (type || '').toLowerCase();

  if (t === 'arrive') return <Flag className={className} />;
  if (t === 'roundabout' || t === 'rotary') return <CircleDot className={className} />;
  if (t === 'fork') return <GitFork className={className} />;
  
  // Prominent driver-grade U-turn symbol
  if (mod.includes('uturn') || mod === 'uturn') {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M9 19V9a5 5 0 0 1 10 0v7" />
        <polyline points="6 16 9 19 12 16" />
      </svg>
    );
  }
  
  if (mod === 'sharp right') {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M12 21V11a4 4 0 0 1 4-4h5" />
        <polyline points="18 4 21 7 18 10" />
      </svg>
    );
  }
  if (mod === 'sharp left') {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M12 21V11a4 4 0 0 0-4-4H3" />
        <polyline points="6 4 3 7 6 10" />
      </svg>
    );
  }
  if (mod === 'slight right') return <ArrowUpRight className={className} strokeWidth={2.75} />;
  if (mod === 'slight left') return <ArrowUpLeft className={className} strokeWidth={2.75} />;
  if (mod === 'right') return <CornerUpRight className={className} strokeWidth={2.75} />;
  if (mod === 'left') return <CornerUpLeft className={className} strokeWidth={2.75} />;
  if (mod === 'straight' || t === 'continue' || t === 'depart') {
    return <ArrowUp className={className} strokeWidth={2.75} />;
  }
  return <Compass className={className} strokeWidth={2.5} />;
};

// ==========================================
// 2. Complete Turn-by-Turn Panel Component
// ==========================================
export interface TurnByTurnPanelProps {
  currentStop: RouteStop;
  previousStop?: RouteStop;
  userLocation: GpsLocation | null;
  gpsStatus: 'acquiring' | 'locked' | 'denied';
  gpsErrorMsg: string | null;
  distanceToCurrentFeet: number | null;
  isDark: boolean;
  onOpenOsmAnd: (e: React.MouseEvent) => void;
  arrivalRadiusMeters?: number;
  isWithinGeofence?: boolean;
  autoArrivalStatus?: string;
  isPassedWithoutCompletion?: boolean;
  simulateApproachAndPass?: () => void;
  simulateApproachAndArrive?: () => void;
  simulateParallelRoadTest?: () => void;
  isSimulatingGps?: boolean;
  stopGpsSimulation?: () => void;
  onRouteCalculated?: (coords: [number, number][], distanceMeters: number) => void;
  isMapVisible?: boolean;
  onToggleMap?: () => void;
}

export const TurnByTurnPanel: React.FC<TurnByTurnPanelProps> = ({
  currentStop,
  previousStop,
  userLocation,
  distanceToCurrentFeet,
  isDark,
  arrivalRadiusMeters = 152.4,
  isWithinGeofence = false,
  autoArrivalStatus,
  isPassedWithoutCompletion = false,
  simulateApproachAndPass,
  simulateApproachAndArrive,
  simulateParallelRoadTest,
  isSimulatingGps = false,
  stopGpsSimulation,
  onRouteCalculated,
  isMapVisible = false,
  onToggleMap,
}) => {
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [showTestMenu, setShowTestMenu] = useState(false);

  // Live OsmAnd AIDL feed state (from Android Kotlin wrapper)
  const [aidlUpdate, setAidlUpdate] = useState<{
    maneuver: string;
    street: string;
    distanceMeters: number;
    lastReceived: number;
  } | null>(null);

  useEffect(() => {
    (window as any).onOsmAndNavUpdate = (maneuver: string, street: string, distMeters: number) => {
      setAidlUpdate({
        maneuver: maneuver || 'straight',
        street: street || '',
        distanceMeters: typeof distMeters === 'number' ? distMeters : 0,
        lastReceived: Date.now(),
      });
    };
    return () => {
      delete (window as any).onOsmAndNavUpdate;
    };
  }, []);

  const isAidlActive = Boolean(aidlUpdate && Date.now() - aidlUpdate.lastReceived < 20000);

  // Road navigation state
  const [maneuvers, setManeuvers] = useState<NavManeuver[]>([]);
  const [routeCoordinates, setRouteCoordinates] = useState<[number, number][]>([]);
  const [currentManeuverIndex, setCurrentManeuverIndex] = useState(0);
  const [distanceToTurnMeters, setDistanceToTurnMeters] = useState(0);
  const [totalDistanceMeters, setTotalDistanceMeters] = useState(0);
  const [totalDurationSeconds, setTotalDurationSeconds] = useState(0);
  const [isRouting, setIsRouting] = useState(false);
  const [routingError, setRoutingError] = useState<string | null>(null);
  const [rerouteBadge, setRerouteBadge] = useState<string | null>(null);

  // Tracking and Debounce Refs for recalculations
  const lastRerouteTimeRef = useRef<number>(0);
  const lastReroutePosRef = useRef<{ lat: number; lon: number } | null>(null);
  const minDistanceToDestRef = useRef<number>(Infinity);
  const currentStopIdRef = useRef<string | null>(null);

  // Determine starting point: live GPS if valid, else previous stop, else realistic approach offset
  const getStartPoint = useCallback((): { lat: number; lon: number; heading: number | null } | null => {
    if (userLocation && isValidCoordinate(userLocation.lat, userLocation.lon)) {
      return { 
        lat: userLocation.lat, 
        lon: userLocation.lon, 
        heading: userLocation.heading ?? null 
      };
    }
    if (previousStop && isValidCoordinate(previousStop.lat, previousStop.lon)) {
      return { 
        lat: previousStop.lat, 
        lon: previousStop.lon, 
        heading: null 
      };
    }
    if (currentStop && isValidCoordinate(currentStop.lat, currentStop.lon)) {
      // 0.005 deg offset (~500m) approach vector
      return { 
        lat: currentStop.lat - 0.005, 
        lon: currentStop.lon - 0.004, 
        heading: 35 
      };
    }
    return null;
  }, [userLocation, previousStop, currentStop]);

  // Primary Road Route Fetcher
  const fetchRoute = useCallback(async (customStart?: { lat: number; lon: number; heading?: number | null }, reasonTag?: string) => {
    if (!currentStop || !isValidCoordinate(currentStop.lat, currentStop.lon)) {
      setManeuvers([]);
      setRouteCoordinates([]);
      return;
    }

    const start = customStart || getStartPoint();
    if (!start) return;

    setIsRouting(true);
    setRoutingError(null);

    try {
      const route = await fetchOsmRoute(
        start.lat,
        start.lon,
        currentStop.lat,
        currentStop.lon,
        currentStop.name,
        start.heading
      );

      if (route.maneuvers.length > 0) {
        setManeuvers(route.maneuvers);
        setRouteCoordinates(route.coordinates);
        setCurrentManeuverIndex(0);
        setTotalDistanceMeters(route.totalDistance);
        setTotalDurationSeconds(route.totalDuration);
        setDistanceToTurnMeters(route.maneuvers[0]?.distanceMeters || 0);

        lastRerouteTimeRef.current = Date.now();
        lastReroutePosRef.current = { lat: start.lat, lon: start.lon };

        // Expose coordinates and road distance to parent App / MapView / useGpsTracker
        if (onRouteCalculated) {
          onRouteCalculated(route.coordinates, route.totalDistance);
        }

        if (reasonTag) {
          setRerouteBadge(reasonTag);
          setTimeout(() => setRerouteBadge(null), 5000);
        } else if (route.hasUturn) {
          setRerouteBadge('Legal U-Turn Active');
          setTimeout(() => setRerouteBadge(null), 5000);
        }
      }
    } catch (err: any) {
      console.warn('Road routing error:', err);
      setRoutingError(err.message || 'Routing unavailable');
    } finally {
      setIsRouting(false);
    }
  }, [currentStop, getStartPoint, onRouteCalculated]);

  // Initial Route Fetch on active customer change
  useEffect(() => {
    const stopId = currentStop?.id || null;
    if (stopId !== currentStopIdRef.current) {
      currentStopIdRef.current = stopId;
      setCurrentManeuverIndex(0);
      minDistanceToDestRef.current = Infinity;
      lastReroutePosRef.current = null;
      lastRerouteTimeRef.current = 0;
      setRerouteBadge(null);
      fetchRoute();
    }
  }, [currentStop?.id, currentStop?.lat, currentStop?.lon, fetchRoute]);

  // Real-time Vehicle Progress & Intelligent Recalculation Engine
  useEffect(() => {
    if (!userLocation || !isValidCoordinate(userLocation.lat, userLocation.lon)) return;
    if (!currentStop || !isValidCoordinate(currentStop.lat, currentStop.lon)) return;

    const now = Date.now();
    const distToDest = calculateDistanceMeters(userLocation.lat, userLocation.lon, currentStop.lat, currentStop.lon);

    if (distToDest < minDistanceToDestRef.current) {
      minDistanceToDestRef.current = distToDest;
    }

    // Recalculation Trigger:
    // Only if vehicle has deviated significantly off planned route polyline (> 55m)
    const timeSinceLastReroute = now - lastRerouteTimeRef.current;
    const distFromLastReroute = lastReroutePosRef.current
      ? calculateDistanceMeters(userLocation.lat, userLocation.lon, lastReroutePosRef.current.lat, lastReroutePosRef.current.lon)
      : Infinity;

    let isOffRoute = false;
    if (routeCoordinates.length > 1) {
      const distToPolyline = calculateDistanceToPolylineMeters(userLocation.lat, userLocation.lon, routeCoordinates);
      isOffRoute = distToPolyline > 55 && distToDest > 40;
    }

    if (isOffRoute && timeSinceLastReroute > 4000 && distFromLastReroute > 20 && !isRouting) {
      minDistanceToDestRef.current = distToDest;
      fetchRoute(
        { lat: userLocation.lat, lon: userLocation.lon, heading: userLocation.heading },
        'Off-Route · Recalculating'
      );
      return;
    }

    // Maneuver Progression along active route
    if (maneuvers.length > 0 && currentManeuverIndex < maneuvers.length) {
      const currentM = maneuvers[currentManeuverIndex];
      if (currentM) {
        const [turnLon, turnLat] = currentM.location;
        const distToWaypoint = calculateDistanceMeters(userLocation.lat, userLocation.lon, turnLat, turnLon);

        if (distToWaypoint < 28 && currentManeuverIndex < maneuvers.length - 1) {
          setCurrentManeuverIndex((idx) => idx + 1);
          const nextM = maneuvers[currentManeuverIndex + 1];
          setDistanceToTurnMeters(nextM ? nextM.distanceMeters : 0);
        } else {
          setDistanceToTurnMeters(Math.max(0, Math.round(distToWaypoint)));
        }
      }
    }
  }, [userLocation, currentStop, maneuvers, currentManeuverIndex, routeCoordinates, isRouting, fetchRoute]);

  const currentManeuver = maneuvers[currentManeuverIndex] || null;
  const nextManeuver = maneuvers[currentManeuverIndex + 1] || null;

  const activeManeuverType = isAidlActive && aidlUpdate
    ? (aidlUpdate.maneuver.includes('roundabout') ? 'roundabout' : 'turn')
    : currentManeuver?.type || 'turn';

  const activeManeuverModifier = isAidlActive && aidlUpdate
    ? aidlUpdate.maneuver
    : currentManeuver?.modifier || 'straight';

  const activeInstructionText = isAidlActive && aidlUpdate
    ? (aidlUpdate.street ? `Turn onto ${aidlUpdate.street}` : aidlUpdate.maneuver)
    : currentManeuver?.instruction || (currentStop.streetName ? `Proceed along route to ${currentStop.streetName}` : 'Proceed toward customer destination');

  const activeStreetName = isAidlActive && aidlUpdate
    ? aidlUpdate.street
    : currentManeuver?.streetName || currentStop.streetName || currentStop.fullAddress || '';

  const activeDistanceToNextTurn = isAidlActive && aidlUpdate
    ? formatDistance(aidlUpdate.distanceMeters)
    : formatDistance(distanceToTurnMeters) || '0 ft';

  const hasValidCoords = isValidCoordinate(currentStop.lat, currentStop.lon);
  const distanceToStopFormatted = distanceToCurrentFeet !== null && hasValidCoords
    ? formatDistance(distanceToCurrentFeet / 3.28084)
    : formatDistance(totalDistanceMeters) || null;

  const arrivalZoneFeet = Math.round((arrivalRadiusMeters || 152.4) * 3.28084);
  const isArrived = Boolean(
    isWithinGeofence ||
    (distanceToCurrentFeet !== null && distanceToCurrentFeet <= arrivalZoneFeet)
  );

  return (
    <>
      <div 
        className={`w-full rounded-3xl border-2 transition-all shadow-2xl relative mb-3 flex flex-col ${
          isArrived
            ? 'bg-emerald-950/95 border-emerald-400 text-white shadow-emerald-950/90'
            : isDark 
              ? 'bg-neutral-950 border-neutral-800 text-white shadow-neutral-950/95' 
              : 'bg-neutral-900 border-neutral-700 text-white shadow-neutral-500/40'
        }`}
      >
        {/* Amber accent top bar */}
        <div className="w-full h-1.5 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-400 rounded-t-3xl" />

        {/* 1. Header Bar: Engine Source, Show/Hide Map Toggle, & In-Phone Simulation Controls */}
        <div className="px-3.5 py-2 flex items-center justify-between border-b border-neutral-800/90 gap-2 flex-wrap">
          {/* Active Status Badge */}
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5 shrink-0">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                isAidlActive ? 'bg-emerald-400' : isSimulatingGps ? 'bg-amber-400' : 'bg-orange-400'
              }`} />
              <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${
                isAidlActive ? 'bg-emerald-400' : isSimulatingGps ? 'bg-amber-400' : 'bg-orange-500'
              }`} />
            </span>
            <span className="font-mono font-black uppercase tracking-wider text-[11px] text-neutral-300">
              {rerouteBadge
                ? rerouteBadge
                : isAidlActive 
                  ? 'OsmAnd Native AIDL' 
                  : isSimulatingGps
                    ? 'Test Simulation Active'
                    : isRouting 
                      ? 'Recalculating...' 
                      : 'OpenStreetMap Route'}
            </span>
          </div>

          {/* Map Toggle & Test Controls */}
          <div className="flex items-center gap-1.5 relative">
            {/* Show Map / Hide Map Button */}
            {onToggleMap && (
              <button
                onClick={onToggleMap}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-[11px] font-black uppercase tracking-wider border transition-all active:scale-95 ${
                  isMapVisible
                    ? 'bg-emerald-500 text-black border-emerald-400 shadow-md shadow-emerald-950/50'
                    : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-200 border-neutral-700'
                }`}
                title={isMapVisible ? 'Hide Map (Switch to Map-Free Mode)' : 'Show Live Road Map'}
              >
                <MapIcon className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>{isMapVisible ? 'Hide Map' : 'Show Map'}</span>
              </button>
            )}

            {/* In-Phone Testing Controls */}
            {isSimulatingGps ? (
              <button
                onClick={() => {
                  if (stopGpsSimulation) stopGpsSimulation();
                }}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-[11px] font-black uppercase tracking-wider bg-amber-400 text-black shadow-lg shadow-amber-950/60 animate-pulse transition-all active:scale-95"
                title="Pause active simulation"
              >
                <Square className="w-3 h-3 fill-current" />
                <span>Stop Test</span>
              </button>
            ) : (
              <div className="relative">
                <button
                  onClick={() => setShowTestMenu((v) => !v)}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-black uppercase tracking-wider bg-neutral-900 hover:bg-neutral-800 text-amber-400 border border-neutral-700 transition-all active:scale-95"
                  title="Test GPS arrival scenarios on phone"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>Test</span>
                </button>

                {/* Test Scenarios Dropdown */}
                {showTestMenu && (
                  <div className="absolute right-0 top-full mt-2 w-64 bg-neutral-900 border border-neutral-700 rounded-2xl shadow-2xl p-2 z-40 space-y-1 animate-in fade-in zoom-in-95 duration-150">
                    <button
                      onClick={() => {
                        setShowTestMenu(false);
                        simulateApproachAndArrive?.();
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-white hover:bg-neutral-800 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>Approach & Stop</span>
                      </div>
                      <span className="text-[10px] text-neutral-400 font-mono">500ft Zone</span>
                    </button>

                    <button
                      onClick={() => {
                        setShowTestMenu(false);
                        simulateApproachAndPass?.();
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-white hover:bg-neutral-800 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <FastForward className="w-4 h-4 text-sky-400 shrink-0" />
                        <span>Drive Past Customer</span>
                      </div>
                      <span className="text-[10px] text-sky-400 font-mono">Auto-Advance</span>
                    </button>

                    <button
                      onClick={() => {
                        setShowTestMenu(false);
                        simulateParallelRoadTest?.();
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-white hover:bg-neutral-800 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                        <span>Parallel Road Test</span>
                      </div>
                      <span className="text-[10px] text-amber-400 font-mono">Reject False</span>
                    </button>
                  </div>
                )}
              </div>
            )}

            <button
              onClick={() => setShowStatusModal(true)}
              className="p-1 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
              title="Navigation details & instructions"
            >
              <Info className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 2. Primary Turn Section: Maneuver Arrow + Distance to Next Turn */}
        <div className={`flex items-center justify-between gap-3 border-b border-neutral-800/60 ${isMapVisible ? 'p-3' : 'p-4 sm:p-5'}`}>
          {/* Prominent Maneuver Arrow */}
          <div 
            className={`rounded-2xl flex items-center justify-center shrink-0 border-2 shadow-xl transition-all ${
              isMapVisible ? 'w-14 h-14' : 'w-18 h-18 sm:w-22 sm:h-22'
            } ${
              isArrived
                ? 'bg-emerald-500 border-emerald-300 text-black shadow-emerald-500/50'
                : isAidlActive
                  ? 'bg-emerald-500/25 border-emerald-400 text-emerald-400'
                  : 'bg-amber-400 border-amber-300 text-black shadow-amber-400/20'
            }`}
          >
            {isArrived ? (
              <CheckCircle2 className={`${isMapVisible ? 'w-8 h-8' : 'w-11 h-11 sm:w-13 sm:h-13'} stroke-[3] text-black`} />
            ) : (
              <ManeuverIconComponent 
                type={activeManeuverType}
                modifier={activeManeuverModifier}
                className={`${isMapVisible ? 'w-8 h-8' : 'w-11 h-11 sm:w-13 sm:h-13'} stroke-[3]`} 
              />
            )}
          </div>

          {/* Distance to NEXT TURN */}
          <div className="flex-1 text-right min-w-0">
            <div className="text-[10px] font-black uppercase tracking-widest text-amber-400 font-mono mb-0.5">
              DISTANCE TO NEXT TURN
            </div>
            <div className={`font-black font-mono text-white tracking-tight leading-none drop-shadow ${
              isMapVisible ? 'text-3xl' : 'text-4xl sm:text-5xl'
            }`}>
              {activeDistanceToNextTurn}
            </div>

            {/* Total Remaining Distance to the Customer */}
            {distanceToStopFormatted && (
              <div className="text-xs font-semibold text-neutral-300 mt-1 font-mono">
                Customer: <span className="font-bold text-white">{distanceToStopFormatted}</span>
                {totalDurationSeconds > 0 ? ` • ~${formatDuration(totalDurationSeconds)}` : ''}
              </div>
            )}

            {/* Live Auto-Arrival Status (500 ft zone) */}
            {autoArrivalStatus && (
              <div className="text-[11px] font-mono font-medium text-amber-300/90 mt-0.5 truncate">
                {autoArrivalStatus}
              </div>
            )}
          </div>
        </div>

        {/* 3. Driving Instruction Text (Multi-Line Wrapping) */}
        <div className={`space-y-1.5 ${isMapVisible ? 'p-3' : 'p-4 sm:p-5'}`}>
          <h2 className={`font-black text-amber-300 tracking-tight leading-tight whitespace-normal break-words ${
            isMapVisible ? 'text-lg sm:text-xl' : 'text-2xl sm:text-3xl'
          }`}>
            {activeInstructionText}
          </h2>

          {activeStreetName && (
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-neutral-900 border border-neutral-700/80 text-white font-bold text-xs max-w-full whitespace-normal break-words">
              <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
              <span className="break-words">Road: {activeStreetName}</span>
            </div>
          )}
        </div>

        {/* 4. Upcoming Next Turn Preview Strip ("THEN" Maneuver) */}
        {nextManeuver && !isArrived && !isMapVisible && (
          <div className="px-4 py-2.5 bg-neutral-900/95 border-t border-neutral-800 rounded-b-3xl flex items-start gap-3 text-xs sm:text-sm font-semibold text-neutral-300 whitespace-normal break-words">
            <span className="text-[10px] font-black uppercase tracking-wider text-black bg-amber-400 px-2 py-0.5 rounded-md shrink-0 mt-0.5">
              THEN
            </span>
            <div className="w-5 h-5 flex items-center justify-center shrink-0 text-amber-400 mt-0.5">
              <ManeuverIconComponent 
                type={nextManeuver.type}
                modifier={nextManeuver.modifier}
                className="w-4 h-4 stroke-[2.75]" 
              />
            </div>
            <div className="flex-1 min-w-0 whitespace-normal break-words text-neutral-200">
              <span className="font-mono text-amber-400 font-bold">In {formatDistance(nextManeuver.distanceMeters)}:</span>{' '}
              <span>{nextManeuver.instruction}</span>
            </div>
          </div>
        )}

        {/* 5. Geofence Arrival Banner */}
        {isArrived && (
          <div className="p-2.5 bg-emerald-500 text-black font-black text-xs sm:text-sm text-center tracking-wide uppercase rounded-b-3xl flex items-center justify-center gap-2">
            <CheckCircle2 className="w-4 h-4 stroke-[3]" />
            <span>ARRIVED WITHIN {arrivalZoneFeet} FT GEOFENCE</span>
          </div>
        )}

        {/* Routing Error Notice */}
        {routingError && (
          <div className="px-4 py-2 bg-red-950/80 border-t border-red-900 text-xs text-red-300 flex items-center justify-between">
            <span>Routing server: {routingError}</span>
            <button
              onClick={() => fetchRoute()}
              className="underline text-red-200 flex items-center gap-1 font-bold"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Retry
            </button>
          </div>
        )}
      </div>

      {/* Navigation Info Modal */}
      {showStatusModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-3xl border border-neutral-700 bg-neutral-900 text-white shadow-2xl p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-orange-600 flex items-center justify-center text-white shrink-0">
                  <Compass className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-black text-base">GPS & Map Navigation</h3>
                  <p className="text-xs text-neutral-400">Reliable 500 ft Arrival & Real Map</p>
                </div>
              </div>
              <button
                onClick={() => setShowStatusModal(false)}
                className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs text-neutral-300">
              <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="font-bold text-amber-400 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" />
                  <span>500 ft Arrival Geofence</span>
                </div>
                <p>
                  Configured with an initial 500 ft (~152.4m) radius. Automatically detects arrivals when you pull up or drive past the customer at delivery speed.
                </p>
                <ul className="list-disc pl-4 space-y-1 text-neutral-400">
                  <li><strong>Segment Interpolation:</strong> Detects arrivals even when GPS readings jump across the boundary between updates.</li>
                  <li><strong>Parallel Road Guard:</strong> Does not falsely complete if you are traveling along an adjacent highway or parallel street.</li>
                  <li><strong>Cascade Protection:</strong> Prevents multiple stops from skipping at once.</li>
                </ul>
              </div>

              <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="font-bold text-emerald-400 flex items-center gap-1.5">
                  <MapIcon className="w-4 h-4" />
                  <span>Optional Real Road Map</span>
                </div>
                <p>
                  Toggle between the default distraction-free card view and a full interactive road map powered by OpenStreetMap with your vehicle location and route polyline.
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowStatusModal(false)}
              className="w-full mt-5 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-sm transition-all"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
};
