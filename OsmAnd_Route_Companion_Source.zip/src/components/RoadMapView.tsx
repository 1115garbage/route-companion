import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { GpsLocation } from '../utils/useGpsTracker';
import { Crosshair, Navigation } from 'lucide-react';

interface RoadMapViewProps {
  userLocation: GpsLocation | null;
  destination: {
    lat: number;
    lon: number;
    name: string;
    houseNumber?: string;
    address?: string;
  };
  routeCoordinates?: [number, number][]; // [lat, lon][]
  isDark?: boolean;
}

export const RoadMapView: React.FC<RoadMapViewProps> = ({
  userLocation,
  destination,
  routeCoordinates = [],
  isDark = true,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);
  const destMarkerRef = useRef<L.Marker | null>(null);
  const routePolylineRef = useRef<L.Polyline | null>(null);

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    const initialLat = userLocation?.lat || destination.lat;
    const initialLon = userLocation?.lon || destination.lon;

    const map = L.map(mapContainerRef.current, {
      center: [initialLat, initialLon],
      zoom: 16,
      zoomControl: false,
      attributionControl: false,
    });

    // High performance OpenStreetMap standard tiles
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      className: isDark ? 'dark-map-tiles' : '',
    }).addTo(map);

    mapInstanceRef.current = map;

    // Invalidate size to ensure crisp rendering on mobile screens
    setTimeout(() => {
      map.invalidateSize();
    }, 150);

    return () => {
      map.remove();
      mapInstanceRef.current = null;
      userMarkerRef.current = null;
      destMarkerRef.current = null;
      routePolylineRef.current = null;
    };
  }, []);

  // Update Route Polyline
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (routePolylineRef.current) {
      map.removeLayer(routePolylineRef.current);
      routePolylineRef.current = null;
    }

    if (routeCoordinates && routeCoordinates.length > 1) {
      const polyline = L.polyline(routeCoordinates, {
        color: '#f59e0b', // Amber road route
        weight: 5,
        opacity: 0.9,
        lineCap: 'round',
        lineJoin: 'round',
      }).addTo(map);

      routePolylineRef.current = polyline;

      // Fit bounds to route
      try {
        map.fitBounds(polyline.getBounds(), { padding: [25, 25], maxZoom: 17 });
      } catch (e) {
        // ignore bounds calculation error if identical points
      }
    }
  }, [routeCoordinates]);

  // Update Destination Marker
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !destination || isNaN(destination.lat) || isNaN(destination.lon)) return;

    if (destMarkerRef.current) {
      destMarkerRef.current.setLatLng([destination.lat, destination.lon]);
    } else {
      const destHtml = `
        <div style="display:flex; flex-direction:column; align-items:center; transform: translate(-50%, -100%);">
          <div style="background:#fbbf24; color:#000; font-weight:900; font-family:monospace; font-size:12px; padding:3px 7px; border-radius:8px; border:2px solid #000; box-shadow:0 4px 8px rgba(0,0,0,0.5); white-space:nowrap;">
            ${destination.houseNumber || 'STOP'}
          </div>
          <div style="width:0; height:0; border-left:6px solid transparent; border-right:6px solid transparent; border-top:8px solid #fbbf24;"></div>
        </div>
      `;

      const destIcon = L.divIcon({
        html: destHtml,
        className: 'custom-dest-pin',
        iconSize: [40, 40],
        iconAnchor: [20, 36],
      });

      destMarkerRef.current = L.marker([destination.lat, destination.lon], { icon: destIcon }).addTo(map);
    }
  }, [destination.lat, destination.lon, destination.houseNumber]);

  // Update Driver / User Location Marker
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (userLocation && !isNaN(userLocation.lat) && !isNaN(userLocation.lon)) {
      const userLatLng: L.LatLngExpression = [userLocation.lat, userLocation.lon];

      if (userMarkerRef.current) {
        userMarkerRef.current.setLatLng(userLatLng);
      } else {
        const userHtml = `
          <div style="position:relative; width:22px; height:22px; display:flex; align-items:center; justify-content:center;">
            <div style="position:absolute; width:100%; height:100%; border-radius:50%; background:#38bdf8; opacity:0.4; animation:ping 1.5s cubic-bezier(0,0,0.2,1) infinite;"></div>
            <div style="width:14px; height:14px; border-radius:50%; background:#0284c7; border:2.5px solid #ffffff; box-shadow:0 0 8px rgba(2,132,199,0.9);"></div>
          </div>
        `;

        const userIcon = L.divIcon({
          html: userHtml,
          className: 'custom-user-dot',
          iconSize: [22, 22],
          iconAnchor: [11, 11],
        });

        userMarkerRef.current = L.marker(userLatLng, { icon: userIcon, zIndexOffset: 1000 }).addTo(map);
      }
    } else if (userMarkerRef.current) {
      map.removeLayer(userMarkerRef.current);
      userMarkerRef.current = null;
    }
  }, [userLocation?.lat, userLocation?.lon]);

  // Recenter handler
  const handleRecenter = () => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (userLocation && !isNaN(userLocation.lat) && !isNaN(userLocation.lon)) {
      map.setView([userLocation.lat, userLocation.lon], 17, { animate: true });
    } else if (destination && !isNaN(destination.lat) && !isNaN(destination.lon)) {
      map.setView([destination.lat, destination.lon], 17, { animate: true });
    }
  };

  const handleFitRoute = () => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (routePolylineRef.current) {
      map.fitBounds(routePolylineRef.current.getBounds(), { padding: [25, 25], maxZoom: 17 });
    } else if (userLocation && destination) {
      const bounds = L.latLngBounds(
        [userLocation.lat, userLocation.lon],
        [destination.lat, destination.lon]
      );
      map.fitBounds(bounds, { padding: [30, 30], maxZoom: 17 });
    }
  };

  return (
    <div className="relative w-full h-full min-h-[170px] max-h-[260px] rounded-2xl overflow-hidden border border-neutral-800 bg-neutral-950 shadow-inner">
      <div ref={mapContainerRef} className="w-full h-full" />

      {/* Map Action Buttons */}
      <div className="absolute bottom-2.5 right-2.5 z-[1000] flex flex-col gap-1.5">
        <button
          onClick={handleRecenter}
          className="p-2 bg-neutral-900/90 hover:bg-neutral-800 text-amber-400 rounded-xl border border-neutral-700 shadow-lg backdrop-blur-sm transition-transform active:scale-90"
          title="Center on current location"
        >
          <Navigation className="w-4 h-4" />
        </button>
        <button
          onClick={handleFitRoute}
          className="p-2 bg-neutral-900/90 hover:bg-neutral-800 text-neutral-300 rounded-xl border border-neutral-700 shadow-lg backdrop-blur-sm transition-transform active:scale-90"
          title="Fit full route to customer"
        >
          <Crosshair className="w-4 h-4" />
        </button>
      </div>

      {/* Attribution overlay badge */}
      <div className="absolute bottom-1 left-2 z-[1000] pointer-events-none text-[9px] font-mono text-neutral-400/80 bg-black/60 px-1.5 py-0.5 rounded">
        © OpenStreetMap
      </div>
    </div>
  );
};
