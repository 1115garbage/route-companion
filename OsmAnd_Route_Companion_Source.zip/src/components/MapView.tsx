import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { RouteStop } from '../types/route';
import { GpsLocation } from '../utils/useGpsTracker';
import { getStopHouseNumber } from '../utils/gpxParser';
import { Crosshair, Maximize2, Layers } from 'lucide-react';

interface MapViewProps {
  currentStop: RouteStop;
  stops: RouteStop[];
  currentIndex: number;
  userLocation: GpsLocation | null;
  routeCoordinates: [number, number][]; // [lon, lat] from OSRM
  arrivalRadiusMeters: number;
  isDark: boolean;
  className?: string;
}

export const MapView: React.FC<MapViewProps> = ({
  currentStop,
  stops,
  currentIndex,
  userLocation,
  routeCoordinates,
  arrivalRadiusMeters,
  isDark,
  className = '',
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);

  // Layer references for clean updates without flickering
  const routePolylineRef = useRef<L.Polyline | null>(null);
  const geofenceCircleRef = useRef<L.Circle | null>(null);
  const driverMarkerRef = useRef<L.Marker | null>(null);
  const driverAccuracyRef = useRef<L.Circle | null>(null);
  const destMarkerRef = useRef<L.Marker | null>(null);
  const otherStopsLayerRef = useRef<L.LayerGroup | null>(null);

  const [hasUserInteracted, setHasUserInteracted] = useState(false);

  // Initialize Leaflet map
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return;

    const initialLat = userLocation?.lat || currentStop.lat || 37.7749;
    const initialLon = userLocation?.lon || currentStop.lon || -122.4194;

    const map = L.map(mapContainerRef.current, {
      center: [initialLat, initialLon],
      zoom: 16,
      zoomControl: false,
      attributionControl: false,
    });

    // Add minimal custom zoom control in bottom right
    L.control.zoom({ position: 'bottomright' }).addTo(map);

    // Initial tile layer (CARTO Dark Matter for AMOLED, OSM Standard for daylight)
    const tileUrl = isDark
      ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
      : 'https://tile.openstreetmap.org/{z}/{x}.png';

    const attribution = isDark
      ? '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>'
      : '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

    const tiles = L.tileLayer(tileUrl, {
      maxZoom: 19,
      subdomains: 'abcd',
      attribution,
    }).addTo(map);

    tileLayerRef.current = tiles;

    // Layer group for secondary route waypoints
    const otherStopsGroup = L.layerGroup().addTo(map);
    otherStopsLayerRef.current = otherStopsGroup;

    mapInstanceRef.current = map;

    // Mark user interaction if driver manually pans/drags map
    map.on('dragstart', () => {
      setHasUserInteracted(true);
    });

    // Invalidate size after container settles
    const timer = setTimeout(() => {
      map.invalidateSize();
    }, 250);

    return () => {
      clearTimeout(timer);
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Sync theme changes with tile layer
  useEffect(() => {
    if (!mapInstanceRef.current || !tileLayerRef.current) return;

    const tileUrl = isDark
      ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
      : 'https://tile.openstreetmap.org/{z}/{x}.png';

    tileLayerRef.current.setUrl(tileUrl);
  }, [isDark]);

  // Update calculated road route polyline
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Convert GeoJSON [lon, lat] coordinates to Leaflet [lat, lon]
    const leafletCoords = routeCoordinates.map(([lon, lat]) => [lat, lon] as [number, number]);

    if (routePolylineRef.current) {
      routePolylineRef.current.setLatLngs(leafletCoords);
    } else if (leafletCoords.length > 0) {
      routePolylineRef.current = L.polyline(leafletCoords, {
        color: '#f59e0b', // High-contrast amber road polyline
        weight: 6,
        opacity: 0.92,
        lineCap: 'round',
        lineJoin: 'round',
      }).addTo(map);
    }
  }, [routeCoordinates]);

  // Update Active Destination Marker and Arrival Geofence Circle
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !currentStop.lat || !currentStop.lon) return;

    const destLat = currentStop.lat;
    const destLon = currentStop.lon;
    const houseNumber = getStopHouseNumber(currentStop, currentIndex);

    // 1. Arrival Geofence Circle (500 ft / 152.4m)
    if (geofenceCircleRef.current) {
      geofenceCircleRef.current.setLatLng([destLat, destLon]);
      geofenceCircleRef.current.setRadius(arrivalRadiusMeters);
    } else {
      geofenceCircleRef.current = L.circle([destLat, destLon], {
        radius: arrivalRadiusMeters,
        color: '#10b981', // Emerald green
        fillColor: '#10b981',
        fillOpacity: 0.14,
        weight: 2,
        dashArray: '6, 6',
      }).addTo(map);
    }

    // 2. Active Customer Destination Marker
    const destHtml = `
      <div class="flex flex-col items-center transform -translate-x-1/2 -translate-y-full cursor-pointer pointer-events-auto">
        <div class="bg-amber-400 text-black font-black font-mono text-xs px-2.5 py-1 rounded-xl border-2 border-amber-300 shadow-xl flex items-center gap-1">
          <span class="text-[10px]">🏠</span>
          <span>${houseNumber !== '—' ? houseNumber : '#' + (currentIndex + 1)}</span>
        </div>
        <div class="w-2.5 h-2.5 bg-amber-400 rotate-45 transform -translate-y-1 shadow"></div>
        <div class="w-3 h-1.5 bg-black/40 rounded-full blur-[1px]"></div>
      </div>
    `;

    const destIcon = L.divIcon({
      html: destHtml,
      className: 'dest-custom-marker',
      iconSize: [0, 0],
      iconAnchor: [0, 0],
    });

    if (destMarkerRef.current) {
      destMarkerRef.current.setLatLng([destLat, destLon]);
      destMarkerRef.current.setIcon(destIcon);
    } else {
      destMarkerRef.current = L.marker([destLat, destLon], { icon: destIcon }).addTo(map);
    }
  }, [currentStop, currentIndex, arrivalRadiusMeters]);

  // Update other upcoming route stops on the map
  useEffect(() => {
    const map = mapInstanceRef.current;
    const group = otherStopsLayerRef.current;
    if (!map || !group) return;

    group.clearLayers();

    // Show upcoming 6 stops as small numbered dots
    const upcomingStops = stops.slice(currentIndex + 1, currentIndex + 7);
    upcomingStops.forEach((stop, idx) => {
      if (!stop.lat || !stop.lon) return;
      const stopIdx = currentIndex + 2 + idx;
      const markerHtml = `
        <div class="w-6 h-6 rounded-full bg-neutral-900/90 text-white border border-neutral-700 font-mono font-bold text-[10px] flex items-center justify-center shadow-lg transform -translate-x-1/2 -translate-y-1/2">
          ${stopIdx}
        </div>
      `;
      const icon = L.divIcon({
        html: markerHtml,
        className: 'sub-stop-marker',
        iconSize: [0, 0],
        iconAnchor: [0, 0],
      });
      L.marker([stop.lat, stop.lon], { icon }).addTo(group);
    });
  }, [stops, currentIndex]);

  // Update Driver Current GPS Location Marker
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !userLocation) return;

    const userLat = userLocation.lat;
    const userLon = userLocation.lon;
    const heading = userLocation.heading;

    // Driver Marker Icon: Pulse Beacon with Directional Arrow
    const headingTransform = typeof heading === 'number' ? `rotate(${heading}deg)` : 'rotate(0deg)';
    const driverHtml = `
      <div class="relative flex items-center justify-center transform -translate-x-1/2 -translate-y-1/2">
        <div class="absolute w-8 h-8 rounded-full bg-sky-500/30 animate-ping"></div>
        <div class="w-7 h-7 rounded-full bg-sky-500 border-2 border-white shadow-xl flex items-center justify-center text-white" style="transform: ${headingTransform}">
          ${
            typeof heading === 'number'
              ? `<svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71z"/></svg>`
              : `<div class="w-2.5 h-2.5 bg-white rounded-full"></div>`
          }
        </div>
      </div>
    `;

    const driverIcon = L.divIcon({
      html: driverHtml,
      className: 'driver-gps-marker',
      iconSize: [0, 0],
      iconAnchor: [0, 0],
    });

    if (driverMarkerRef.current) {
      driverMarkerRef.current.setLatLng([userLat, userLon]);
      driverMarkerRef.current.setIcon(driverIcon);
    } else {
      driverMarkerRef.current = L.marker([userLat, userLon], { icon: driverIcon, zIndexOffset: 1000 }).addTo(map);
    }

    // Driver Accuracy Circle
    const accuracyRadius = Math.max(8, Math.min(userLocation.accuracy, 40));
    if (driverAccuracyRef.current) {
      driverAccuracyRef.current.setLatLng([userLat, userLon]);
      driverAccuracyRef.current.setRadius(accuracyRadius);
    } else {
      driverAccuracyRef.current = L.circle([userLat, userLon], {
        radius: accuracyRadius,
        color: '#38bdf8',
        fillColor: '#38bdf8',
        fillOpacity: 0.1,
        weight: 1,
      }).addTo(map);
    }

    // Auto-center map if user hasn't manually panned away
    if (!hasUserInteracted) {
      map.panTo([userLat, userLon], { animate: true, duration: 0.6 });
    }
  }, [userLocation, hasUserInteracted]);

  // Center on Vehicle action
  const handleCenterOnVehicle = () => {
    const map = mapInstanceRef.current;
    if (!map) return;
    setHasUserInteracted(false);

    if (userLocation) {
      map.setView([userLocation.lat, userLocation.lon], 17, { animate: true });
    } else if (currentStop.lat && currentStop.lon) {
      map.setView([currentStop.lat, currentStop.lon], 16, { animate: true });
    }
  };

  // Fit Route (bounds containing both driver and destination)
  const handleFitRoute = () => {
    const map = mapInstanceRef.current;
    if (!map) return;
    setHasUserInteracted(true);

    const points: [number, number][] = [];
    if (userLocation) points.push([userLocation.lat, userLocation.lon]);
    if (currentStop.lat && currentStop.lon) points.push([currentStop.lat, currentStop.lon]);
    if (routeCoordinates.length > 0) {
      // Sample a few route coordinates for accurate bounds
      const midIdx = Math.floor(routeCoordinates.length / 2);
      const [midLon, midLat] = routeCoordinates[midIdx];
      points.push([midLat, midLon]);
    }

    if (points.length > 0) {
      const bounds = L.latLngBounds(points);
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 18, animate: true });
    }
  };

  return (
    <div className={`relative w-full h-full min-h-[300px] flex flex-col ${className}`}>
      {/* Map DOM Element */}
      <div 
        ref={mapContainerRef} 
        className="w-full h-full flex-1 rounded-3xl overflow-hidden border-2 border-neutral-800 bg-neutral-950 z-0" 
      />

      {/* Floating Map Controls */}
      <div className="absolute top-3 right-3 z-10 flex flex-col gap-2">
        {/* Recenter on Me Button */}
        <button
          onClick={handleCenterOnVehicle}
          className="p-2.5 rounded-2xl bg-neutral-900/90 hover:bg-neutral-800 text-sky-400 border border-neutral-700/80 shadow-xl backdrop-blur-md transition-all active:scale-95"
          title="Center on My Location"
        >
          <Crosshair className="w-5 h-5" />
        </button>

        {/* Fit Full Route Bounds Button */}
        <button
          onClick={handleFitRoute}
          className="p-2.5 rounded-2xl bg-neutral-900/90 hover:bg-neutral-800 text-amber-400 border border-neutral-700/80 shadow-xl backdrop-blur-md transition-all active:scale-95"
          title="Fit Route to Screen"
        >
          <Maximize2 className="w-5 h-5" />
        </button>
      </div>

      {/* Map Legend Overlay at Bottom Left */}
      <div className="absolute bottom-3 left-3 z-10 pointer-events-none flex items-center gap-2 bg-neutral-950/80 backdrop-blur-md px-2.5 py-1.5 rounded-xl border border-neutral-800 text-[10px] text-neutral-300 font-mono">
        <span className="flex items-center gap-1">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block border border-white/50"></span>
          <span>500 ft Arrival Zone</span>
        </span>
        <span className="text-neutral-600">|</span>
        <span className="flex items-center gap-1">
          <span className="w-2.5 h-1 bg-amber-400 inline-block rounded"></span>
          <span>Road Route</span>
        </span>
      </div>
    </div>
  );
};
