# OsmAnd Route Companion (Android APK Source)

This package contains the complete source code and native Android wrapper for **OsmAnd Route Companion**.

## How to Build the APK on your Samsung Galaxy S26:

1. In your GitHub repository (`route-companion`), ensure `.github/workflows/build.yml` is present.
2. The GitHub Action will automatically run and compile the APK in ~2 minutes!
3. Go to the **Actions** tab on your GitHub repository.
4. Tap the workflow run, scroll down to **Artifacts**, and download **OsmAnd-Route-Companion-APK**.
5. In Samsung **My Files > Downloads**, tap `app-debug.apk` to install.
