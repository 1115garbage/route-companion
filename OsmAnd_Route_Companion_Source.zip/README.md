# OsmAnd Route Companion (Android APK Source)

This package contains the complete source code and native Android wrapper for **OsmAnd Route Companion**.

## How to Build the APK on your Samsung Galaxy S26 (Free):

1. Go to https://github.com on your phone.
2. Create a new repository named `route-companion`.
3. Tap **Upload files** and upload the contents of this ZIP file.
4. Go to the **Actions** tab on your GitHub repository.
5. In ~2 minutes, GitHub will finish compiling your APK!
6. Tap the completed run, scroll to **Artifacts**, and tap **OsmAnd-Route-Companion-APK**.
7. In Samsung **My Files > Downloads**, tap `app-debug.apk` to install.
