package com.routecompanion.app

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.os.IBinder
import android.util.Log
import net.osmand.aidl.IOsmAndAidlInterface

/**
 * Communicates with OsmAnd through both native AIDL Service and Broadcast Intents
 */
class OsmAndNavigationBridge(
    private val context: Context,
    private val onUpdate: (maneuver: String, street: String, distanceMeters: Int) -> Unit
) {
    private var osmandAidlService: IOsmAndAidlInterface? = null
    private var isBound = false

    // Fallback broadcast receiver for OsmAnd NAVIGATION_INFO intents
    private val navBroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent?.action == "net.osmand.NAVIGATION_INFO") {
                val maneuver = intent.getStringExtra("NEXT_MANEUVER_TYPE") ?: "straight"
                val street = intent.getStringExtra("NEXT_STREET_NAME") ?: ""
                val dist = intent.getIntExtra("DISTANCE_TO_NEXT", 0)
                onUpdate(maneuver, street, dist)
            }
        }
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            Log.d("OsmAndBridge", "Connected to OsmAnd AIDL Service")
            osmandAidlService = IOsmAndAidlInterface.Stub.asInterface(service)
            isBound = true

            try {
                // Subscribe to live turn-by-turn navigation updates from OsmAnd
                osmandAidlService?.registerForNavigationUpdates(true)
            } catch (e: Exception) {
                Log.e("OsmAndBridge", "Failed to register for updates", e)
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            Log.d("OsmAndBridge", "Disconnected from OsmAnd AIDL Service")
            osmandAidlService = null
            isBound = false
        }
    }

    fun start() {
        // 1. Register broadcast receiver
        val filter = IntentFilter("net.osmand.NAVIGATION_INFO")
        try {
            context.registerReceiver(navBroadcastReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } catch (e: Exception) {
            try {
                context.registerReceiver(navBroadcastReceiver, filter)
            } catch (err: Exception) {
                Log.w("OsmAndBridge", "Could not register receiver", err)
            }
        }

        // 2. Bind to OsmAnd AIDL service (checking both standard and plus packages)
        val packages = listOf("net.osmand", "net.osmand.plus")
        for (pkg in packages) {
            val intent = Intent("net.osmand.aidl.OsmandAidlService")
            intent.`package` = pkg
            val bound = context.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
            if (bound) {
                Log.d("OsmAndBridge", "Binding initiated to package: $pkg")
                break
            }
        }
    }

    fun stop() {
        try {
            context.unregisterReceiver(navBroadcastReceiver)
        } catch (e: Exception) {}

        if (isBound) {
            try {
                osmandAidlService?.registerForNavigationUpdates(false)
                context.unbindService(serviceConnection)
            } catch (e: Exception) {}
            isBound = false
        }
    }
}
