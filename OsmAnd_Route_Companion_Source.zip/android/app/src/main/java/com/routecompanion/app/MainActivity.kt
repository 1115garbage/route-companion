package com.routecompanion.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.WindowManager
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var osmandBridge: OsmAndNavigationBridge

    companion object {
        private const val LOCATION_PERMISSION_REQUEST = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep screen on while navigating on phone dashboard mount
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                setGeolocationEnabled(true)
                cacheMode = WebSettings.LOAD_DEFAULT
                allowFileAccess = true
                allowContentAccess = true
            }

            webChromeClient = object : WebChromeClient() {
                override fun onGeolocationPermissionsShowPrompt(
                    origin: String?,
                    callback: GeolocationPermissions.Callback?
                ) {
                    callback?.invoke(origin, true, false)
                }
            }

            webViewClient = WebViewClient()
        }

        setContentView(webView)

        // Request location permissions if not already granted
        checkLocationPermission()

        // Initialize OsmAnd AIDL bridge
        osmandBridge = OsmAndNavigationBridge(this) { maneuver, street, distanceMeters ->
            runOnUiThread {
                val safeManeuver = maneuver.replace("'", "\\'")
                val safeStreet = street.replace("'", "\\'")
                val js = "window.onOsmAndNavUpdate && window.onOsmAndNavUpdate('$safeManeuver', '$safeStreet', $distanceMeters);"
                webView.evaluateJavascript(js, null)
            }
        }
        osmandBridge.start()

        // Load bundled web application from local assets
        webView.loadUrl("file:///android_asset/dist/index.html")
    }

    private fun checkLocationPermission() {
        val permissions = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        val needed = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), LOCATION_PERMISSION_REQUEST)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        osmandBridge.stop()
    }
}
