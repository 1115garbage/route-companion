package net.osmand.aidl;

interface IOsmAndAidlInterface {
    boolean registerForNavigationUpdates(in boolean subscribeToUpdates);
    boolean navigate(in String destination, in double lat, in double lon, in String profile);
    boolean stopNavigation();
}
