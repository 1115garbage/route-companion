var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t,t.exports),e=null),t.exports),s=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(var c=r(i),l=0,u=c.length,d;l<u;l++)d=c[l],!a.call(e,d)&&d!==o&&t(e,d,{get:(e=>i[e]).bind(null,d),enumerable:!(s=n(i,d))||s.enumerable});return e},c=(n,r,o)=>(o=n==null?{}:e(i(n)),s(r||!n||!n.__esModule||!a.call(n,`default`)?t(o,`default`,{value:n,enumerable:!0}):o,n)),l=(e=>typeof require<`u`?require:typeof Proxy<`u`?new Proxy(e,{get:(e,t)=>(typeof require<`u`?require:e)[t]}):e)(function(e){if(typeof require<`u`)return require.apply(this,arguments);throw Error('Calling `require` for "'+e+"\" in an environment that doesn't expose the `require` function. See https://rolldown.rs/in-depth/bundling-cjs#require-external-modules for more details.")});(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var u=o((e=>{function t(e,t){var n=e.length;e.push(t);a:for(;0<n;){var r=n-1>>>1,a=e[r];if(0<i(a,t))e[r]=t,e[n]=a,n=r;else break a}}function n(e){return e.length===0?null:e[0]}function r(e){if(e.length===0)return null;var t=e[0],n=e.pop();if(n!==t){e[0]=n;a:for(var r=0,a=e.length,o=a>>>1;r<o;){var s=2*(r+1)-1,c=e[s],l=s+1,u=e[l];if(0>i(c,n))l<a&&0>i(u,c)?(e[r]=u,e[l]=n,r=l):(e[r]=c,e[s]=n,r=s);else if(l<a&&0>i(u,n))e[r]=u,e[l]=n,r=l;else break a}}return t}function i(e,t){var n=e.sortIndex-t.sortIndex;return n===0?e.id-t.id:n}if(e.unstable_now=void 0,typeof performance==`object`&&typeof performance.now==`function`){var a=performance;e.unstable_now=function(){return a.now()}}else{var o=Date,s=o.now();e.unstable_now=function(){return o.now()-s}}var c=[],l=[],u=1,d=null,f=3,p=!1,m=!1,h=!1,g=!1,_=typeof setTimeout==`function`?setTimeout:null,v=typeof clearTimeout==`function`?clearTimeout:null,y=typeof setImmediate<`u`?setImmediate:null;function b(e){for(var i=n(l);i!==null;){if(i.callback===null)r(l);else if(i.startTime<=e)r(l),i.sortIndex=i.expirationTime,t(c,i);else break;i=n(l)}}function x(e){if(h=!1,b(e),!m){if(n(c)!==null)m=!0,S||(S=!0,O());else{var t=n(l);t!==null&&j(x,t.startTime-e)}}}var S=!1,C=-1,w=5,T=-1;function E(){return g?!0:!(e.unstable_now()-T<w)}function D(){if(g=!1,S){var t=e.unstable_now();T=t;var i=!0;try{a:{m=!1,h&&(h=!1,v(C),C=-1),p=!0;var a=f;try{b:{for(b(t),d=n(c);d!==null&&!(d.expirationTime>t&&E());){var o=d.callback;if(typeof o==`function`){d.callback=null,f=d.priorityLevel;var s=o(d.expirationTime<=t);if(t=e.unstable_now(),typeof s==`function`){d.callback=s,b(t),i=!0;break b}d===n(c)&&r(c),b(t)}else r(c);d=n(c)}if(d!==null)i=!0;else{var u=n(l);u!==null&&j(x,u.startTime-t),i=!1}}break a}finally{d=null,f=a,p=!1}i=void 0}}finally{i?O():S=!1}}}var O;if(typeof y==`function`)O=function(){y(D)};else if(typeof MessageChannel<`u`){var k=new MessageChannel,A=k.port2;k.port1.onmessage=D,O=function(){A.postMessage(null)}}else O=function(){_(D,0)};function j(t,n){C=_(function(){t(e.unstable_now())},n)}e.unstable_IdlePriority=5,e.unstable_ImmediatePriority=1,e.unstable_LowPriority=4,e.unstable_NormalPriority=3,e.unstable_Profiling=null,e.unstable_UserBlockingPriority=2,e.unstable_cancelCallback=function(e){e.callback=null},e.unstable_forceFrameRate=function(e){0>e||125<e?console.error(`forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported`):w=0<e?Math.floor(1e3/e):5},e.unstable_getCurrentPriorityLevel=function(){return f},e.unstable_next=function(e){switch(f){case 1:case 2:case 3:var t=3;break;default:t=f}var n=f;f=t;try{return e()}finally{f=n}},e.unstable_requestPaint=function(){g=!0},e.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=f;f=e;try{return t()}finally{f=n}},e.unstable_scheduleCallback=function(r,i,a){var o=e.unstable_now();switch(typeof a==`object`&&a?(a=a.delay,a=typeof a==`number`&&0<a?o+a:o):a=o,r){case 1:var s=-1;break;case 2:s=250;break;case 5:s=1073741823;break;case 4:s=1e4;break;default:s=5e3}return s=a+s,r={id:u++,callback:i,priorityLevel:r,startTime:a,expirationTime:s,sortIndex:-1},a>o?(r.sortIndex=a,t(l,r),n(c)===null&&r===n(l)&&(h?(v(C),C=-1):h=!0,j(x,a-o))):(r.sortIndex=s,t(c,r),m||p||(m=!0,S||(S=!0,O()))),r},e.unstable_shouldYield=E,e.unstable_wrapCallback=function(e){var t=f;return function(){var n=f;f=t;try{return e.apply(this,arguments)}finally{f=n}}}})),d=o(((e,t)=>{t.exports=u()})),f=o((e=>{var t=Symbol.for(`react.transitional.element`),n=Symbol.for(`react.portal`),r=Symbol.for(`react.fragment`),i=Symbol.for(`react.strict_mode`),a=Symbol.for(`react.profiler`),o=Symbol.for(`react.consumer`),s=Symbol.for(`react.context`),c=Symbol.for(`react.forward_ref`),l=Symbol.for(`react.suspense`),u=Symbol.for(`react.memo`),d=Symbol.for(`react.lazy`),f=Symbol.for(`react.activity`),p=Symbol.for(`react.view_transition`),m=Symbol.iterator;function h(e){return typeof e!=`object`||!e?null:(e=m&&e[m]||e[`@@iterator`],typeof e==`function`?e:null)}var g={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},_=Object.assign,v={};function y(e,t,n){this.props=e,this.context=t,this.refs=v,this.updater=n||g}y.prototype.isReactComponent={},y.prototype.setState=function(e,t){if(typeof e!=`object`&&typeof e!=`function`&&e!=null)throw Error(`takes an object of state variables to update or a function which returns an object of state variables.`);this.updater.enqueueSetState(this,e,t,`setState`)},y.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,`forceUpdate`)};function b(){}b.prototype=y.prototype;function x(e,t,n){this.props=e,this.context=t,this.refs=v,this.updater=n||g}var S=x.prototype=new b;S.constructor=x,_(S,y.prototype),S.isPureReactComponent=!0;var C=Array.isArray;function w(){}var T={H:null,A:null,T:null,S:null},E=Object.prototype.hasOwnProperty;function D(e,n,r){var i=r.ref;return{$$typeof:t,type:e,key:n,ref:i===void 0?null:i,props:r}}function O(e,t){return D(e.type,t,e.props)}function k(e){return typeof e==`object`&&!!e&&e.$$typeof===t}function A(e){var t={"=":`=0`,":":`=2`};return`$`+e.replace(/[=:]/g,function(e){return t[e]})}var j=/\/+/g;function M(e,t){return typeof e==`object`&&e&&e.key!=null?A(``+e.key):t.toString(36)}function ee(e){switch(e.status){case`fulfilled`:return e.value;case`rejected`:throw e.reason;default:switch(typeof e.status==`string`?e.then(w,w):(e.status=`pending`,e.then(function(t){e.status===`pending`&&(e.status=`fulfilled`,e.value=t)},function(t){e.status===`pending`&&(e.status=`rejected`,e.reason=t)})),e.status){case`fulfilled`:return e.value;case`rejected`:throw e.reason}}throw e}function N(e,r,i,a,o){var s=typeof e;(s===`undefined`||s===`boolean`)&&(e=null);var c=!1;if(e===null)c=!0;else switch(s){case`bigint`:case`string`:case`number`:c=!0;break;case`object`:switch(e.$$typeof){case t:case n:c=!0;break;case d:return c=e._init,N(c(e._payload),r,i,a,o)}}if(c)return o=o(e),c=a===``?`.`+M(e,0):a,C(o)?(i=``,c!=null&&(i=c.replace(j,`$&/`)+`/`),N(o,r,i,``,function(e){return e})):o!=null&&(k(o)&&(o=O(o,i+(o.key==null||e&&e.key===o.key?``:(``+o.key).replace(j,`$&/`)+`/`)+c)),r.push(o)),1;c=0;var l=a===``?`.`:a+`:`;if(C(e))for(var u=0;u<e.length;u++)a=e[u],s=l+M(a,u),c+=N(a,r,i,s,o);else if(u=h(e),typeof u==`function`)for(e=u.call(e),u=0;!(a=e.next()).done;)a=a.value,s=l+M(a,u++),c+=N(a,r,i,s,o);else if(s===`object`){if(typeof e.then==`function`)return N(ee(e),r,i,a,o);throw r=String(e),Error(`Objects are not valid as a React child (found: `+(r===`[object Object]`?`object with keys {`+Object.keys(e).join(`, `)+`}`:r)+`). If you meant to render a collection of children, use an array instead.`)}return c}function P(e,t,n){if(e==null)return e;var r=[],i=0;return N(e,r,``,``,function(e){return t.call(n,e,i++)}),r}function F(e){if(e._status===-1){var t=e._result,n=t();n.then(function(t){(e._status===0||e._status===-1)&&(e._status=1,e._result=t,n.status===void 0&&(n.status=`fulfilled`,n.value=t))},function(t){(e._status===0||e._status===-1)&&(e._status=2,e._result=t,n.status===void 0&&(n.status=`rejected`,n.reason=t))}),e._status===-1&&(e._status=0,e._result=n)}if(e._status===1)return e._result.default;throw e._result}var I=typeof reportError==`function`?reportError:function(e){if(typeof window==`object`&&typeof window.ErrorEvent==`function`){var t=new window.ErrorEvent(`error`,{bubbles:!0,cancelable:!0,message:typeof e==`object`&&e&&typeof e.message==`string`?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process==`object`&&typeof process.emit==`function`){process.emit(`uncaughtException`,e);return}console.error(e)};function R(e){var t=T.T,n={};n.types=t===null?null:t.types,T.T=n;try{var r=e(),i=T.S;i!==null&&i(n,r),typeof r==`object`&&r&&typeof r.then==`function`&&r.then(w,I)}catch(e){I(e)}finally{t!==null&&n.types!==null&&(t.types=n.types),T.T=t}}function z(e){var t=T.T;if(t!==null){var n=t.types;n===null?t.types=[e]:n.indexOf(e)===-1&&n.push(e)}else R(z.bind(null,e))}var B={map:P,forEach:function(e,t,n){P(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return P(e,function(){t++}),t},toArray:function(e){return P(e,function(e){return e})||[]},only:function(e){if(!k(e))throw Error(`React.Children.only expected to receive a single React element child.`);return e}};e.Activity=f,e.Children=B,e.Component=y,e.Fragment=r,e.Profiler=a,e.PureComponent=x,e.StrictMode=i,e.Suspense=l,e.ViewTransition=p,e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=T,e.__COMPILER_RUNTIME={__proto__:null,c:function(e){return T.H.useMemoCache(e)}},e.addTransitionType=z,e.cache=function(e){return function(){return e.apply(null,arguments)}},e.cacheSignal=function(){return null},e.cloneElement=function(e,t,n){if(e==null)throw Error(`The argument must be a React element, but you passed `+e+`.`);var r=_({},e.props),i=e.key;if(t!=null)for(a in t.key!==void 0&&(i=``+t.key),t)!E.call(t,a)||a===`key`||a===`__self`||a===`__source`||a===`ref`&&t.ref===void 0||(r[a]=t[a]);var a=arguments.length-2;if(a===1)r.children=n;else if(1<a){for(var o=Array(a),s=0;s<a;s++)o[s]=arguments[s+2];r.children=o}return D(e.type,i,r)},e.createContext=function(e){return e={$$typeof:s,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null},e.Provider=e,e.Consumer={$$typeof:o,_context:e},e},e.createElement=function(e,t,n){var r,i={},a=null;if(t!=null)for(r in t.key!==void 0&&(a=``+t.key),t)E.call(t,r)&&r!==`key`&&r!==`__self`&&r!==`__source`&&(i[r]=t[r]);var o=arguments.length-2;if(o===1)i.children=n;else if(1<o){for(var s=Array(o),c=0;c<o;c++)s[c]=arguments[c+2];i.children=s}if(e&&e.defaultProps)for(r in o=e.defaultProps,o)i[r]===void 0&&(i[r]=o[r]);return D(e,a,i)},e.createRef=function(){return{current:null}},e.forwardRef=function(e){return{$$typeof:c,render:e}},e.isValidElement=k,e.lazy=function(e){return{$$typeof:d,_payload:{_status:-1,_result:e},_init:F}},e.memo=function(e,t){return{$$typeof:u,type:e,compare:t===void 0?null:t}},e.startTransition=R,e.unstable_useCacheRefresh=function(){return T.H.useCacheRefresh()},e.use=function(e){return T.H.use(e)},e.useActionState=function(e,t,n){return T.H.useActionState(e,t,n)},e.useCallback=function(e,t){return T.H.useCallback(e,t)},e.useContext=function(e){return T.H.useContext(e)},e.useDebugValue=function(){},e.useDeferredValue=function(e,t){return T.H.useDeferredValue(e,t)},e.useEffect=function(e,t){return T.H.useEffect(e,t)},e.useEffectEvent=function(e){return T.H.useEffectEvent(e)},e.useId=function(){return T.H.useId()},e.useImperativeHandle=function(e,t,n){return T.H.useImperativeHandle(e,t,n)},e.useInsertionEffect=function(e,t){return T.H.useInsertionEffect(e,t)},e.useLayoutEffect=function(e,t){return T.H.useLayoutEffect(e,t)},e.useMemo=function(e,t){return T.H.useMemo(e,t)},e.useOptimistic=function(e,t){return T.H.useOptimistic(e,t)},e.useReducer=function(e,t,n){return T.H.useReducer(e,t,n)},e.useRef=function(e){return T.H.useRef(e)},e.useState=function(e){return T.H.useState(e)},e.useSyncExternalStore=function(e,t,n){return T.H.useSyncExternalStore(e,t,n)},e.useTransition=function(){return T.H.useTransition()},e.version=`19.3.1`})),p=o(((e,t)=>{t.exports=f()})),m=o((e=>{var t=p();function n(e){var t=`https://react.dev/errors/`+e;if(1<arguments.length){t+=`?args[]=`+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+=`&args[]=`+encodeURIComponent(arguments[n])}return`Minified React error #`+e+`; visit `+t+` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`}function r(){}var i={d:{f:r,r:function(){throw Error(n(522))},D:r,C:r,L:r,m:r,X:r,S:r,M:r},p:0,findDOMNode:null},a=Symbol.for(`react.portal`),o=Symbol.for(`react.recoverable`),s=Symbol.for(`react.optimistic_key`);function c(e,t,n){var r=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:a,key:r==null?null:r===s?s:``+r,children:e,containerInfo:t,implementation:n}}var l=t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function u(e,t){if(e===`font`)return``;if(typeof t==`string`)return t===`use-credentials`?t:``}e.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=i,e.browser=function(e){return{$$typeof:o,_reason:e}},e.createPortal=function(e,t){var r=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)throw Error(n(299));return c(e,t,null,r)},e.flushSync=function(e){var t=l.T,n=i.p;try{if(l.T=null,i.p=2,e)return e()}finally{l.T=t,i.p=n,i.d.f()}},e.preconnect=function(e,t){typeof e==`string`&&(t?(t=t.crossOrigin,t=typeof t==`string`?t===`use-credentials`?t:``:void 0):t=null,i.d.C(e,t))},e.prefetchDNS=function(e){typeof e==`string`&&i.d.D(e)},e.preinit=function(e,t){if(typeof e==`string`&&t&&typeof t.as==`string`){var n=t.as,r=u(n,t.crossOrigin),a=typeof t.integrity==`string`?t.integrity:void 0,o=typeof t.fetchPriority==`string`?t.fetchPriority:void 0;n===`style`?i.d.S(e,typeof t.precedence==`string`?t.precedence:void 0,{crossOrigin:r,integrity:a,fetchPriority:o}):n===`script`&&i.d.X(e,{crossOrigin:r,integrity:a,fetchPriority:o,nonce:typeof t.nonce==`string`?t.nonce:void 0})}},e.preinitModule=function(e,t){if(typeof e==`string`){if(typeof t==`object`&&t){if(t.as==null||t.as===`script`){var n=u(t.as,t.crossOrigin);i.d.M(e,{crossOrigin:n,integrity:typeof t.integrity==`string`?t.integrity:void 0,nonce:typeof t.nonce==`string`?t.nonce:void 0,fetchPriority:typeof t.fetchPriority==`string`?t.fetchPriority:void 0})}}else t??i.d.M(e)}},e.preload=function(e,t){if(typeof e==`string`&&typeof t==`object`&&t&&typeof t.as==`string`){var n=t.as,r=u(n,t.crossOrigin);i.d.L(e,n,{crossOrigin:r,integrity:typeof t.integrity==`string`?t.integrity:void 0,nonce:typeof t.nonce==`string`?t.nonce:void 0,type:typeof t.type==`string`?t.type:void 0,fetchPriority:typeof t.fetchPriority==`string`?t.fetchPriority:void 0,referrerPolicy:typeof t.referrerPolicy==`string`?t.referrerPolicy:void 0,imageSrcSet:typeof t.imageSrcSet==`string`?t.imageSrcSet:void 0,imageSizes:typeof t.imageSizes==`string`?t.imageSizes:void 0,media:typeof t.media==`string`?t.media:void 0})}},e.preloadModule=function(e,t){if(typeof e==`string`){if(t){var n=u(t.as,t.crossOrigin);i.d.m(e,{as:typeof t.as==`string`&&t.as!==`script`?t.as:void 0,crossOrigin:n,integrity:typeof t.integrity==`string`?t.integrity:void 0,nonce:typeof t.nonce==`string`?t.nonce:void 0,fetchPriority:typeof t.fetchPriority==`string`?t.fetchPriority:void 0})}else i.d.m(e)}},e.requestFormReset=function(e){i.d.r(e)},e.unstable_batchedUpdates=function(e,t){return e(t)},e.useFormState=function(e,t,n){return l.H.useFormState(e,t,n)},e.useFormStatus=function(){return l.H.useHostTransitionStatus()},e.version=`19.3.1`})),h=o(((e,t)=>{function n(){if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE==`function`)try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)}catch(e){console.error(e)}}n(),t.exports=m()})),g=o((e=>{var t=d(),n=p(),r=h();function i(e){var t=`https://react.dev/errors/`+e;if(1<arguments.length){t+=`?args[]=`+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+=`&args[]=`+encodeURIComponent(arguments[n])}return`Minified React error #`+e+`; visit `+t+` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`}function a(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function o(e){for(var t=e,n=t;n&&!n.alternate;)t=n,t.flags&4098&&(e=t.return),n=t.return;for(;t.return;)t=t.return;return t.tag===3?e:null}function s(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function c(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function l(e){if(o(e)!==e)throw Error(i(188))}function u(e){var t=e.alternate;if(!t){if(t=o(e),t===null)throw Error(i(188));return t===e?e:null}for(var n=e,r=t;;){var a=n.return;if(a===null)break;var s=a.alternate;if(s===null){if(r=a.return,r!==null){n=r;continue}break}if(a.child===s.child){for(s=a.child;s;){if(s===n)return l(a),e;if(s===r)return l(a),t;s=s.sibling}throw Error(i(188))}if(n.return!==r.return)n=a,r=s;else{for(var c=!1,u=a.child;u;){if(u===n){c=!0,n=a,r=s;break}if(u===r){c=!0,r=a,n=s;break}u=u.sibling}if(!c){for(u=s.child;u;){if(u===n){c=!0,n=s,r=a;break}if(u===r){c=!0,r=s,n=a;break}u=u.sibling}if(!c)throw Error(i(189))}}if(n.alternate!==r)throw Error(i(190))}if(n.tag!==3)throw Error(i(188));return n.stateNode.current===n?e:t}function f(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=f(e),t!==null)return t;e=e.sibling}return null}function m(e,t,n,r,i,a){for(;e!==null;){if((e.tag===5||e.tag===27||e.tag===6)&&n(e,r,i,a)||(e.tag!==22||e.memoizedState===null)&&(t||e.tag!==5&&e.tag!==27)&&m(e.child,t,n,r,i,a))return!0;e=e.sibling}return!1}function g(e){for(e=e.return;e!==null;){if(e.tag===3||e.tag===5||e.tag===27)return e;e=e.return}return null}function _(e){var t=!1;for(e=e.return;e!==null&&(e.tag===4&&(t=!0),e.tag!==3&&e.tag!==5&&e.tag!==27);)e=e.return;return t}function v(e){var t=[null,null],n=g(e);return n===null||y(t,e,n.child,{foundSelf:!1}),t}function y(e,t,n,r){for(;n!==null;){if(n===t)r.foundSelf=!0;else if(n.tag===5||n.tag===27||n.tag===6){if(r.foundSelf)return e[1]=n,!0;e[0]=n}else if((n.tag!==22||n.memoizedState===null)&&y(e,t,n.child,r))return!0;n=n.sibling}return!1}function b(e){switch(e.tag){case 5:case 27:case 6:return e.stateNode;case 3:return e.stateNode.containerInfo;default:throw Error(i(559))}}var x=null,S=null;function C(e,t,n){return e===n||e===t&&(x=e,!0)}function w(e,t,n){return e===n?(S=e,!1):e===t&&(S!==null&&(x=e),!0)}function T(e){if(e===null)return null;do e=e===null?null:e.return;while(e&&e.tag!==5&&e.tag!==27&&e.tag!==3);return e||null}function E(e,t,n){for(var r=0,i=e;i;i=n(i))r++;i=0;for(var a=t;a;a=n(a))i++;for(;0<r-i;)e=n(e),r--;for(;0<i-r;)t=n(t),i--;for(;r--;){if(e===t||t!==null&&e===t.alternate)return e;e=n(e),t=n(t)}return null}var D=Object.assign,O=Symbol.for(`react.element`),k=Symbol.for(`react.transitional.element`),A=Symbol.for(`react.portal`),j=Symbol.for(`react.fragment`),M=Symbol.for(`react.strict_mode`),ee=Symbol.for(`react.profiler`),N=Symbol.for(`react.consumer`),P=Symbol.for(`react.context`),F=Symbol.for(`react.forward_ref`),I=Symbol.for(`react.suspense`),R=Symbol.for(`react.suspense_list`),z=Symbol.for(`react.memo`),B=Symbol.for(`react.lazy`),te=Symbol.for(`react.activity`),ne=Symbol.for(`react.legacy_hidden`),re=Symbol.for(`react.memo_cache_sentinel`),ie=Symbol.for(`react.view_transition`),ae=Symbol.for(`react.recoverable`),oe=Symbol.iterator;function se(e){return typeof e!=`object`||!e?null:(e=oe&&e[oe]||e[`@@iterator`],typeof e==`function`?e:null)}var ce=Symbol.for(`react.client.reference`);function le(e){if(e==null)return null;if(typeof e==`function`)return e.$$typeof===ce?null:e.displayName||e.name||null;if(typeof e==`string`)return e;switch(e){case j:return`Fragment`;case ee:return`Profiler`;case M:return`StrictMode`;case I:return`Suspense`;case R:return`SuspenseList`;case te:return`Activity`;case ie:return`ViewTransition`}if(typeof e==`object`)switch(e.$$typeof){case A:return`Portal`;case P:return e.displayName||`Context`;case N:return(e._context.displayName||`Context`)+`.Consumer`;case F:var t=e.render;return e=e.displayName,e||=(e=t.displayName||t.name||``,e===``?`ForwardRef`:`ForwardRef(`+e+`)`),e;case z:return t=e.displayName||null,t===null?le(e.type)||`Memo`:t;case B:t=e._payload,e=e._init;try{return le(e(t))}catch{}}return null}var V=Array.isArray,H=n.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,U=r.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,ue={pending:!1,data:null,method:null,action:null},de=[],fe=-1;function pe(e){return{current:e}}function me(e){0>fe||(e.current=de[fe],de[fe]=null,fe--)}function he(e,t){fe++,de[fe]=e.current,e.current=t}var ge=pe(null),_e=pe(null),ve=pe(null),ye=pe(null);function be(e,t){switch(he(ve,t),he(_e,e),he(ge,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?dp(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=dp(t),e=fp(t,e);else switch(e){case`svg`:e=1;break;case`math`:e=2;break;default:e=0}}me(ge),he(ge,e)}function xe(){me(ge),me(_e),me(ve)}function Se(e){var t=e.memoizedState;t!==null&&(ch._currentValue=t.memoizedState,he(ye,e)),t=ge.current;var n=fp(t,e.type);t!==n&&(he(_e,e),he(ge,n))}function Ce(e){_e.current===e&&(me(ge),me(_e)),ye.current===e&&(me(ye),ch._currentValue=ue)}var we,Te;function Ee(e){if(we===void 0)try{throw Error()}catch(e){var t=e.stack.trim().match(/\n( *(at )?)/);we=t&&t[1]||``,Te=-1<e.stack.indexOf(`
    at`)?` (<anonymous>)`:-1<e.stack.indexOf(`@`)?`@unknown:0:0`:``}return`
`+we+e+Te}var De=!1;function Oe(e,t){if(!e||De)return``;De=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var r={DetermineComponentFrameRoot:function(){try{if(t){var n=function(){throw Error()};if(Object.defineProperty(n.prototype,"props",{set:function(){throw Error()}}),typeof Reflect==`object`&&Reflect.construct){try{Reflect.construct(n,[])}catch(e){var r=e}Reflect.construct(e,[],n)}else{try{n.call()}catch(e){r=e}n=!1;try{var i=Object.getOwnPropertyDescriptor(e.prototype,`props`);Object.defineProperty(e.prototype,"props",{configurable:!0,set:function(){throw Error()}}),n=!0,new e}finally{n&&(i===void 0?delete e.prototype.props:Object.defineProperty(e.prototype,"props",i))}}}else{try{throw Error()}catch(e){r=e}(n=e())&&typeof n.catch==`function`&&n.catch(function(){})}}catch(e){if(e&&r&&typeof e.stack==`string`)return[e.stack,r.stack]}return[null,null]}};r.DetermineComponentFrameRoot.displayName=`DetermineComponentFrameRoot`;var i=Object.getOwnPropertyDescriptor(r.DetermineComponentFrameRoot,`name`);i&&i.configurable&&Object.defineProperty(r.DetermineComponentFrameRoot,"name",{value:`DetermineComponentFrameRoot`});var a=r.DetermineComponentFrameRoot(),o=a[0],s=a[1];if(o&&s){var c=o.split(`
`),l=s.split(`
`);for(i=r=0;r<c.length&&!c[r].includes(`DetermineComponentFrameRoot`);)r++;for(;i<l.length&&!l[i].includes(`DetermineComponentFrameRoot`);)i++;if(r===c.length||i===l.length)for(r=c.length-1,i=l.length-1;1<=r&&0<=i&&c[r]!==l[i];)i--;for(;1<=r&&0<=i;r--,i--)if(c[r]!==l[i]){if(r!==1||i!==1)do if(r--,i--,0>i||c[r]!==l[i]){var u=`
`+c[r].replace(` at new `,` at `);return e.displayName&&u.includes(`<anonymous>`)&&(u=u.replace(`<anonymous>`,e.displayName)),u}while(1<=r&&0<=i);break}}}finally{De=!1,Error.prepareStackTrace=n}return(n=e?e.displayName||e.name:``)?Ee(n):``}function ke(e,t){switch(e.tag){case 26:case 27:case 5:return Ee(e.type);case 16:return Ee(`Lazy`);case 13:return e.child!==t&&t!==null?Ee(`Suspense Fallback`):Ee(`Suspense`);case 19:return Ee(`SuspenseList`);case 0:case 15:return Oe(e.type,!1);case 11:return Oe(e.type.render,!1);case 1:return Oe(e.type,!0);case 31:return Ee(`Activity`);case 30:return Ee(`ViewTransition`);default:return``}}function Ae(e){try{var t=``,n=null;do t+=ke(e,n),n=e,e=e.return;while(e);return t}catch(e){return`
Error generating stack: `+e.message+`
`+e.stack}}var je=Object.prototype.hasOwnProperty,Me=t.unstable_scheduleCallback,Ne=t.unstable_cancelCallback,Pe=t.unstable_shouldYield,Fe=t.unstable_requestPaint,Ie=t.unstable_now,Le=t.unstable_getCurrentPriorityLevel,Re=t.unstable_ImmediatePriority,ze=t.unstable_UserBlockingPriority,Be=t.unstable_NormalPriority,Ve=t.unstable_LowPriority,He=t.unstable_IdlePriority,Ue=t.log,We=t.unstable_setDisableYieldValue,Ge=null,W=null;function Ke(e){if(typeof Ue==`function`&&We(e),W&&typeof W.setStrictMode==`function`)try{W.setStrictMode(Ge,e)}catch{}}var qe=Math.clz32?Math.clz32:Ye,Je=Math.log,G=Math.LN2;function Ye(e){return e>>>=0,e===0?32:31-(Je(e)/G|0)|0}var Xe=256,Ze=262144,Qe=4194304;function $e(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&-e;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function et(e,t,n){var r=e.pendingLanes;if(r===0)return 0;var i=0,a=e.suspendedLanes,o=e.pingedLanes;e=e.warmLanes;var s=r&134217727;return s===0?(s=r&~a,s===0?o===0?n||(n=r&~e,n!==0&&(i=$e(n))):i=$e(o):i=$e(s)):(r=s&~a,r===0?(o&=s,o===0?n||(n=s&~e,n!==0&&(i=$e(n))):i=$e(o)):i=$e(r)),i===0?0:t!==0&&t!==i&&(t&a)===0&&(a=i&-i,n=t&-t,a>=n||a===32&&n&4194048)?t:i}function tt(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function nt(e,t){t&8&&(t|=t&32);var n=e.entangledLanes;if(n!==0)for(e=e.entanglements,n&=t;0<n;){var r=31-qe(n),i=1<<r;t|=e[r],n&=~i}return t}function rt(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function it(){var e=Qe;return Qe<<=1,!(Qe&62914560)&&(Qe=4194304),e}function at(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function ot(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function st(e,t,n,r,i,a){var o=e.pendingLanes;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=n,e.entangledLanes&=n,e.errorRecoveryDisabledLanes&=n,e.shellSuspendCounter=0;var s=e.entanglements,c=e.expirationTimes,l=e.hiddenUpdates;for(n=o&~n;0<n;){var u=31-qe(n),d=1<<u;s[u]=0,c[u]=-1;var f=l[u];if(f!==null)for(l[u]=null,u=0;u<f.length;u++){var p=f[u];p!==null&&(p.lane&=-536870913)}n&=~d}r!==0&&ct(e,r,0),a!==0&&i===0&&e.tag!==0&&(e.suspendedLanes|=a&~(o&~t))}function ct(e,t,n){e.pendingLanes|=t,e.suspendedLanes&=~t;var r=31-qe(t);e.entangledLanes|=t,e.entanglements[r]=e.entanglements[r]|1073741824|n&261930}function lt(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var r=31-qe(n),i=1<<r;i&t|e[r]&t&&(e[r]|=t),n&=~i}}function ut(e,t){var n=t&-t;return n=n&42?1:dt(n),(n&(e.suspendedLanes|t))===0?n:0}function dt(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function ft(e){return e&=-e,2<e?8<e?e&134217727?32:268435456:8:2}function pt(){var e=U.p;return e===0?(e=window.event,e===void 0?32:wh(e.type)):e}function mt(e,t){var n=U.p;try{return U.p=e,t()}finally{U.p=n}}var ht=Math.random().toString(36).slice(2),K=`__reactFiber$`+ht,q=`__reactProps$`+ht,gt=`__reactContainer$`+ht,_t=`__reactEvents$`+ht,vt=`__reactListeners$`+ht,yt=`__reactHandles$`+ht,J=`__reactResources$`+ht,bt=`__reactMarker$`+ht,xt=`__reactLoad$`+ht;function St(e){delete e[K],delete e[q],delete e[vt],delete e[yt]}function Ct(e){var t;if(t=e[K])return t;for(var n=e.parentNode;n;){if(t=n[gt]||n[K]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=pm(e);e!==null;){if(n=e[K])return n;e=pm(e)}return t}e=n,n=e.parentNode}return null}function wt(e){if(e=e[K]||e[gt]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function Tt(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(i(33))}function Et(e){var t=e[J];return t||=e[J]={hoistableStyles:new Map,hoistableScripts:new Map},t}function Y(e){e[bt]=!0}function Dt(e){e[xt]=void 0}var Ot=new Set,kt={};function At(e,t){jt(e,t),jt(e+`Capture`,t)}function jt(e,t){for(kt[e]=t,e=0;e<t.length;e++)Ot.add(t[e])}var Mt=RegExp(`^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$`),Nt={},Pt={};function Ft(e){return je.call(Pt,e)?!0:je.call(Nt,e)?!1:Mt.test(e)?Pt[e]=!0:(Nt[e]=!0,!1)}var It=!1;function Lt(){var e=It;return It=!1,e}function Rt(e,t,n){if(Ft(t)){if(n===null)e.removeAttribute(t);else{switch(typeof n){case`undefined`:case`function`:case`symbol`:e.removeAttribute(t);return;case`boolean`:var r=t.toLowerCase().slice(0,5);if(r!==`data-`&&r!==`aria-`){e.removeAttribute(t);return}}e.setAttribute(t,n)}}}function zt(e,t,n){if(n===null)e.removeAttribute(t);else{switch(typeof n){case`undefined`:case`function`:case`symbol`:case`boolean`:e.removeAttribute(t);return}e.setAttribute(t,n)}}function Bt(e,t,n,r){if(r===null)e.removeAttribute(n);else{switch(typeof r){case`undefined`:case`function`:case`symbol`:case`boolean`:e.removeAttribute(n);return}e.setAttributeNS(t,n,r)}}function X(e){switch(typeof e){case`bigint`:case`boolean`:case`number`:case`string`:case`undefined`:return e;case`object`:return e;default:return``}}function Vt(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()===`input`&&(t===`checkbox`||t===`radio`)}function Ht(e,t,n){var r=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&r!==void 0&&typeof r.get==`function`&&typeof r.set==`function`){var i=r.get,a=r.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return i.call(this)},set:function(e){n=``+e,a.call(this,e)}}),Object.defineProperty(e,t,{enumerable:r.enumerable}),{getValue:function(){return n},setValue:function(e){n=``+e},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function Ut(e){if(!e._valueTracker){var t=Vt(e)?`checked`:`value`;e._valueTracker=Ht(e,t,``+e[t])}}function Wt(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),r=``;return e&&(r=Vt(e)?e.checked?`true`:`false`:e.value),e=r,e!==n&&(t.setValue(e),!0)}var Gt=/[\n"\\]/g;function Kt(e){return e.replace(Gt,function(e){return`\\`+e.charCodeAt(0).toString(16)+` `})}function qt(e,t,n,r,i,a,o,s){e.name=``,o!=null&&typeof o!=`function`&&typeof o!=`symbol`&&typeof o!=`boolean`?e.type=o:e.removeAttribute(`type`),t==null?o!==`submit`&&o!==`reset`||e.removeAttribute(`value`):o===`number`?(t===0&&e.value===``||e.value!=t)&&(e.value=``+X(t)):e.value!==``+X(t)&&(e.value=``+X(t)),t==null?n==null?r!=null&&e.removeAttribute(`value`):Yt(e,X(n)):o===`number`&&e.value==t?Yt(e,X(e.value)):Yt(e,X(t)),i==null&&a!=null&&(e.defaultChecked=!!a),i!=null&&(e.checked=i&&typeof i!=`function`&&typeof i!=`symbol`),s!=null&&typeof s!=`function`&&typeof s!=`symbol`&&typeof s!=`boolean`?e.name=``+X(s):e.removeAttribute(`name`)}function Jt(e,t,n,r,i,a,o,s){if(a!=null&&typeof a!=`function`&&typeof a!=`symbol`&&typeof a!=`boolean`&&(e.type=a),t!=null||n!=null){if(!(a!==`submit`&&a!==`reset`||t!=null)){Ut(e);return}n=n==null?``:``+X(n),t=t==null?n:``+X(t),s||t===e.value||(e.value=t),e.defaultValue=t}r??=i,r=typeof r!=`function`&&typeof r!=`symbol`&&!!r,e.checked=s?e.checked:!!r,e.defaultChecked=!!r,o!=null&&typeof o!=`function`&&typeof o!=`symbol`&&typeof o!=`boolean`&&(e.name=o),Ut(e)}function Yt(e,t){e.defaultValue!==``+t&&(e.defaultValue=``+t)}function Xt(e,t,n,r){if(e=e.options,t){t={};for(var i=0;i<n.length;i++)t[`$`+n[i]]=!0;for(n=0;n<e.length;n++)i=t.hasOwnProperty(`$`+e[n].value),e[n].selected!==i&&(e[n].selected=i),i&&r&&(e[n].defaultSelected=!0)}else{for(n=``+X(n),t=null,i=0;i<e.length;i++){if(e[i].value===n){e[i].selected=!0,r&&(e[i].defaultSelected=!0);return}t!==null||e[i].disabled||(t=e[i])}t!==null&&(t.selected=!0)}}function Zt(e,t,n){t!=null&&(t=``+X(t),t!==e.value&&(e.value=t),n==null)?e.defaultValue!==t&&(e.defaultValue=t):e.defaultValue=n==null?``:``+X(n)}function Qt(e,t,n,r){if(t==null){if(r!=null){if(n!=null)throw Error(i(92));if(V(r)){if(1<r.length)throw Error(i(93));r=r[0]}n=r}n??=``,t=n}n=X(t),e.defaultValue=n,r=e.textContent,r===n&&r!==``&&r!==null&&(e.value=r),Ut(e)}function $t(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var en=new Set(`animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp`.split(` `));function tn(e,t,n){var r=t.indexOf(`--`)===0;n==null||typeof n==`boolean`||n===``?r?e.setProperty(t,``):t===`float`?e.cssFloat=``:e[t]=``:r?e.setProperty(t,n):typeof n!=`number`||n===0||en.has(t)?t===`float`?e.cssFloat=n:e[t]=(``+n).trim():e[t]=n+`px`}function nn(e,t,n){if(t!=null&&typeof t!=`object`)throw Error(i(62));if(e=e.style,n!=null){for(var r in n)!n.hasOwnProperty(r)||t!=null&&t.hasOwnProperty(r)||(r.indexOf(`--`)===0?e.setProperty(r,``):r===`float`?e.cssFloat=``:e[r]=``,It=!0);for(var a in t)r=t[a],t.hasOwnProperty(a)&&n[a]!==r&&(tn(e,a,r),It=!0)}else for(var o in t)t.hasOwnProperty(o)&&tn(e,o,t[o])}function rn(e){if(e.indexOf(`-`)===-1)return!1;switch(e){case`annotation-xml`:case`color-profile`:case`font-face`:case`font-face-src`:case`font-face-uri`:case`font-face-format`:case`font-face-name`:case`missing-glyph`:return!1;default:return!0}}var an=new Map([[`acceptCharset`,`accept-charset`],[`htmlFor`,`for`],[`httpEquiv`,`http-equiv`],[`crossOrigin`,`crossorigin`],[`accentHeight`,`accent-height`],[`alignmentBaseline`,`alignment-baseline`],[`arabicForm`,`arabic-form`],[`baselineShift`,`baseline-shift`],[`capHeight`,`cap-height`],[`clipPath`,`clip-path`],[`clipRule`,`clip-rule`],[`colorInterpolation`,`color-interpolation`],[`colorInterpolationFilters`,`color-interpolation-filters`],[`colorProfile`,`color-profile`],[`colorRendering`,`color-rendering`],[`dominantBaseline`,`dominant-baseline`],[`enableBackground`,`enable-background`],[`fillOpacity`,`fill-opacity`],[`fillRule`,`fill-rule`],[`floodColor`,`flood-color`],[`floodOpacity`,`flood-opacity`],[`fontFamily`,`font-family`],[`fontSize`,`font-size`],[`fontSizeAdjust`,`font-size-adjust`],[`fontStretch`,`font-stretch`],[`fontStyle`,`font-style`],[`fontVariant`,`font-variant`],[`fontWeight`,`font-weight`],[`glyphName`,`glyph-name`],[`glyphOrientationHorizontal`,`glyph-orientation-horizontal`],[`glyphOrientationVertical`,`glyph-orientation-vertical`],[`horizAdvX`,`horiz-adv-x`],[`horizOriginX`,`horiz-origin-x`],[`imageRendering`,`image-rendering`],[`letterSpacing`,`letter-spacing`],[`lightingColor`,`lighting-color`],[`markerEnd`,`marker-end`],[`markerMid`,`marker-mid`],[`markerStart`,`marker-start`],[`maskType`,`mask-type`],[`overlinePosition`,`overline-position`],[`overlineThickness`,`overline-thickness`],[`paintOrder`,`paint-order`],[`panose-1`,`panose-1`],[`pointerEvents`,`pointer-events`],[`renderingIntent`,`rendering-intent`],[`shapeRendering`,`shape-rendering`],[`stopColor`,`stop-color`],[`stopOpacity`,`stop-opacity`],[`strikethroughPosition`,`strikethrough-position`],[`strikethroughThickness`,`strikethrough-thickness`],[`strokeDasharray`,`stroke-dasharray`],[`strokeDashoffset`,`stroke-dashoffset`],[`strokeLinecap`,`stroke-linecap`],[`strokeLinejoin`,`stroke-linejoin`],[`strokeMiterlimit`,`stroke-miterlimit`],[`strokeOpacity`,`stroke-opacity`],[`strokeWidth`,`stroke-width`],[`textAnchor`,`text-anchor`],[`textDecoration`,`text-decoration`],[`textRendering`,`text-rendering`],[`transformOrigin`,`transform-origin`],[`underlinePosition`,`underline-position`],[`underlineThickness`,`underline-thickness`],[`unicodeBidi`,`unicode-bidi`],[`unicodeRange`,`unicode-range`],[`unitsPerEm`,`units-per-em`],[`vAlphabetic`,`v-alphabetic`],[`vHanging`,`v-hanging`],[`vIdeographic`,`v-ideographic`],[`vMathematical`,`v-mathematical`],[`vectorEffect`,`vector-effect`],[`vertAdvY`,`vert-adv-y`],[`vertOriginX`,`vert-origin-x`],[`vertOriginY`,`vert-origin-y`],[`wordSpacing`,`word-spacing`],[`writingMode`,`writing-mode`],[`xmlnsXlink`,`xmlns:xlink`],[`xHeight`,`x-height`]]),on=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function sn(e){return on.test(``+e)?`javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')`:e}function cn(){}var ln=null;function un(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var dn=null,fn=null;function pn(e){var t=wt(e);if(t&&(e=t.stateNode)){var n=e[q]||null;a:switch(e=t.stateNode,t.type){case`input`:if(qt(e,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name),t=n.name,n.type===`radio`&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll(`input[name="`+Kt(``+t)+`"][type="radio"]`),t=0;t<n.length;t++){var r=n[t];if(r!==e&&r.form===e.form){var a=r[q]||null;if(!a)throw Error(i(90));qt(r,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name)}}for(t=0;t<n.length;t++)r=n[t],r.form===e.form&&Wt(r)}break a;case`textarea`:Zt(e,n.value,n.defaultValue);break a;case`select`:t=n.value,t!=null&&Xt(e,!!n.multiple,t,!1)}}}var mn=!1;function hn(e,t,n){if(mn)return e(t,n);mn=!0;try{return e(t)}finally{if(mn=!1,(dn!==null||fn!==null)&&(Ld(),dn&&(t=dn,e=fn,fn=dn=null,pn(t),e)))for(t=0;t<e.length;t++)pn(e[t])}}function gn(e,t){var n=e.stateNode;if(n===null)return null;var r=n[q]||null;if(r===null)return null;n=r[t];a:switch(t){case`onClick`:case`onClickCapture`:case`onDoubleClick`:case`onDoubleClickCapture`:case`onMouseDown`:case`onMouseDownCapture`:case`onMouseMove`:case`onMouseMoveCapture`:case`onMouseUp`:case`onMouseUpCapture`:case`onMouseEnter`:(r=!r.disabled)||(e=e.type,r=e!==`button`&&e!==`input`&&e!==`select`&&e!==`textarea`),e=!r;break a;default:e=!1}if(e)return null;if(n&&typeof n!=`function`)throw Error(i(231,t,typeof n));return n}var _n=typeof window<`u`&&window.document!==void 0&&window.document.createElement!==void 0,vn=!1;if(_n)try{var yn={};Object.defineProperty(yn,"passive",{get:function(){vn=!0}}),window.addEventListener(`test`,yn,yn),window.removeEventListener(`test`,yn,yn)}catch{vn=!1}var bn=null,xn=null,Sn=null;function Cn(){if(Sn)return Sn;var e,t=xn,n=t.length,r,i=`value`in bn?bn.value:bn.textContent,a=i.length;for(e=0;e<n&&t[e]===i[e];e++);var o=n-e;for(r=1;r<=o&&t[n-r]===i[a-r];r++);return Sn=i.slice(e,1<r?1-r:void 0)}function wn(e){var t=e.keyCode;return`charCode`in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function Tn(){return!0}function En(){return!1}function Dn(e){function t(t,n,r,i,a){for(var o in this._reactName=t,this._targetInst=r,this.type=n,this.nativeEvent=i,this.target=a,this.currentTarget=null,e)e.hasOwnProperty(o)&&(t=e[o],this[o]=t?t(i):i[o]);return this.isDefaultPrevented=(i.defaultPrevented==null?!1===i.returnValue:i.defaultPrevented)?Tn:En,this.isPropagationStopped=En,this}return D(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var e=this.nativeEvent;e&&(e.preventDefault?e.preventDefault():typeof e.returnValue!=`unknown`&&(e.returnValue=!1),this.isDefaultPrevented=Tn)},stopPropagation:function(){var e=this.nativeEvent;e&&(e.stopPropagation?e.stopPropagation():typeof e.cancelBubble!=`unknown`&&(e.cancelBubble=!0),this.isPropagationStopped=Tn)},persist:function(){},isPersistent:Tn}),t}var On={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},kn=Dn(On),An=D({},On,{view:0,detail:0}),jn=Dn(An),Mn,Nn,Pn,Fn=D({},An,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Kn,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return`movementX`in e?e.movementX:(e!==Pn&&(Pn&&e.type===`mousemove`?(Mn=e.screenX-Pn.screenX,Nn=e.screenY-Pn.screenY):Nn=Mn=0,Pn=e),Mn)},movementY:function(e){return`movementY`in e?e.movementY:Nn}}),In=Dn(Fn),Ln=Dn(D({},Fn,{dataTransfer:0})),Rn=Dn(D({},An,{relatedTarget:0})),zn=Dn(D({},On,{animationName:0,elapsedTime:0,pseudoElement:0})),Bn=Dn(D({},On,{clipboardData:function(e){return`clipboardData`in e?e.clipboardData:window.clipboardData}})),Vn=Dn(D({},On,{data:0})),Hn={Esc:`Escape`,Spacebar:` `,Left:`ArrowLeft`,Up:`ArrowUp`,Right:`ArrowRight`,Down:`ArrowDown`,Del:`Delete`,Win:`OS`,Menu:`ContextMenu`,Apps:`ContextMenu`,Scroll:`ScrollLock`,MozPrintableKey:`Unidentified`},Un={8:`Backspace`,9:`Tab`,12:`Clear`,13:`Enter`,16:`Shift`,17:`Control`,18:`Alt`,19:`Pause`,20:`CapsLock`,27:`Escape`,32:` `,33:`PageUp`,34:`PageDown`,35:`End`,36:`Home`,37:`ArrowLeft`,38:`ArrowUp`,39:`ArrowRight`,40:`ArrowDown`,45:`Insert`,46:`Delete`,112:`F1`,113:`F2`,114:`F3`,115:`F4`,116:`F5`,117:`F6`,118:`F7`,119:`F8`,120:`F9`,121:`F10`,122:`F11`,123:`F12`,144:`NumLock`,145:`ScrollLock`,224:`Meta`},Wn={Alt:`altKey`,Control:`ctrlKey`,Meta:`metaKey`,Shift:`shiftKey`};function Gn(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=Wn[e])?!!t[e]:!1}function Kn(){return Gn}var qn=Dn(D({},An,{key:function(e){if(e.key){var t=Hn[e.key]||e.key;if(t!==`Unidentified`)return t}return e.type===`keypress`?(e=wn(e),e===13?`Enter`:String.fromCharCode(e)):e.type===`keydown`||e.type===`keyup`?Un[e.keyCode]||`Unidentified`:``},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Kn,charCode:function(e){return e.type===`keypress`?wn(e):0},keyCode:function(e){return e.type===`keydown`||e.type===`keyup`?e.keyCode:0},which:function(e){return e.type===`keypress`?wn(e):e.type===`keydown`||e.type===`keyup`?e.keyCode:0}})),Jn=Dn(D({},Fn,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0})),Yn=Dn(D({},On,{submitter:0})),Xn=Dn(D({},An,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Kn})),Zn=Dn(D({},On,{propertyName:0,elapsedTime:0,pseudoElement:0})),Qn=Dn(D({},Fn,{deltaX:function(e){return`deltaX`in e?e.deltaX:`wheelDeltaX`in e?-e.wheelDeltaX:0},deltaY:function(e){return`deltaY`in e?e.deltaY:`wheelDeltaY`in e?-e.wheelDeltaY:`wheelDelta`in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0})),$n=Dn(D({},On,{newState:0,oldState:0,source:0})),er=[9,13,27,32],tr=_n&&`CompositionEvent`in window,nr=null;_n&&`documentMode`in document&&(nr=document.documentMode);var rr=_n&&`TextEvent`in window&&!nr,ir=_n&&(!tr||nr&&8<nr&&11>=nr),ar=` `,or=!1;function sr(e,t){switch(e){case`keyup`:return er.indexOf(t.keyCode)!==-1;case`keydown`:return t.keyCode!==229;case`keypress`:case`mousedown`:case`focusout`:return!0;default:return!1}}function cr(e){return e=e.detail,typeof e==`object`&&`data`in e?e.data:null}var lr=!1;function ur(e,t){switch(e){case`compositionend`:return cr(t);case`keypress`:return t.which===32?(or=!0,ar):null;case`textInput`:return e=t.data,e===ar&&or?null:e;default:return null}}function dr(e,t){if(lr)return e===`compositionend`||!tr&&sr(e,t)?(e=Cn(),Sn=xn=bn=null,lr=!1,e):null;switch(e){case`paste`:return null;case`keypress`:if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case`compositionend`:return ir&&t.locale!==`ko`?null:t.data;default:return null}}var fr={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function pr(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t===`input`?!!fr[e.type]:t===`textarea`}function mr(e,t,n,r){dn?fn?fn.push(r):fn=[r]:dn=r,t=Jf(t,`onChange`),0<t.length&&(n=new kn(`onChange`,`change`,null,n,r),e.push({event:n,listeners:t}))}var hr=null,gr=null;function _r(e){Bf(e,0)}function vr(e){if(Wt(Tt(e)))return e}function yr(e,t){if(e===`change`)return t}var br=!1;if(_n){var xr;if(_n){var Sr=`oninput`in document;if(!Sr){var Cr=document.createElement(`div`);Cr.setAttribute(`oninput`,`return;`),Sr=typeof Cr.oninput==`function`}xr=Sr}else xr=!1;br=xr&&(!document.documentMode||9<document.documentMode)}function wr(){hr&&(hr.detachEvent(`onpropertychange`,Tr),gr=hr=null)}function Tr(e){if(e.propertyName===`value`&&vr(gr)){var t=[];mr(t,gr,e,un(e)),hn(_r,t)}}function Er(e,t,n){e===`focusin`?(wr(),hr=t,gr=n,hr.attachEvent(`onpropertychange`,Tr)):e===`focusout`&&wr()}function Dr(e){if(e===`selectionchange`||e===`keyup`||e===`keydown`)return vr(gr)}function Or(e,t){if(e===`click`)return vr(t)}function kr(e,t){if(e===`input`||e===`change`)return vr(t)}function Ar(e,t){return e===t&&(e!==0||1/e==1/t)||e!==e&&t!==t}var jr=typeof Object.is==`function`?Object.is:Ar;function Mr(e,t){if(jr(e,t))return!0;if(typeof e!=`object`||!e||typeof t!=`object`||!t)return!1;var n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var i=n[r];if(!je.call(t,i)||!jr(e[i],t[i]))return!1}return!0}function Nr(e){if(e||=typeof document<`u`?document:void 0,e===void 0)return null;try{return e.activeElement||e.body}catch{return e.body}}function Pr(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Fr(e,t){var n=Pr(e);e=0;for(var r;n;){if(n.nodeType===3){if(r=e+n.textContent.length,e<=t&&r>=t)return{node:n,offset:t-e};e=r}a:{for(;n;){if(n.nextSibling){n=n.nextSibling;break a}n=n.parentNode}n=void 0}n=Pr(n)}}function Ir(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?Ir(e,t.parentNode):`contains`in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function Lr(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=Nr(e.document);t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href==`string`}catch{n=!1}if(n)e=t.contentWindow;else break;t=Nr(e.document)}return t}function Rr(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t===`input`&&(e.type===`text`||e.type===`search`||e.type===`tel`||e.type===`url`||e.type===`password`)||t===`textarea`||e.contentEditable===`true`)}var zr=_n&&`documentMode`in document&&11>=document.documentMode,Br=null,Vr=null,Hr=null,Ur=!1;function Wr(e,t,n){var r=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;Ur||Br==null||Br!==Nr(r)||(r=Br,`selectionStart`in r&&Rr(r)?r={start:r.selectionStart,end:r.selectionEnd}:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection(),r={anchorNode:r.anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset}),Hr&&Mr(Hr,r)||(Hr=r,r=Jf(Vr,`onSelect`),0<r.length&&(t=new kn(`onSelect`,`select`,null,t,n),e.push({event:t,listeners:r}),t.target=Br)))}function Gr(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n[`Webkit`+e]=`webkit`+t,n[`Moz`+e]=`moz`+t,n}var Kr={animationend:Gr(`Animation`,`AnimationEnd`),animationiteration:Gr(`Animation`,`AnimationIteration`),animationstart:Gr(`Animation`,`AnimationStart`),transitionrun:Gr(`Transition`,`TransitionRun`),transitionstart:Gr(`Transition`,`TransitionStart`),transitioncancel:Gr(`Transition`,`TransitionCancel`),transitionend:Gr(`Transition`,`TransitionEnd`)},qr={},Jr={};_n&&(Jr=document.createElement(`div`).style,`AnimationEvent`in window||(delete Kr.animationend.animation,delete Kr.animationiteration.animation,delete Kr.animationstart.animation),`TransitionEvent`in window||delete Kr.transitionend.transition);function Yr(e){if(qr[e])return qr[e];if(!Kr[e])return e;var t=Kr[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in Jr)return qr[e]=t[n];return e}var Xr=Yr(`animationend`),Zr=Yr(`animationiteration`),Qr=Yr(`animationstart`),$r=Yr(`transitionrun`),ei=Yr(`transitionstart`),ti=Yr(`transitioncancel`),ni=Yr(`transitionend`),ri=new Map,ii=`abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel`.split(` `);ii.push(`scrollEnd`);function ai(e,t){ri.set(e,t),At(t,[e])}var oi=0;function si(e,t){if(e.name!=null&&e.name!==`auto`)return e.name;if(t.autoName!==null)return t.autoName;e=vd.identifierPrefix;var n=oi++;return e=`_`+e+`t_`+n.toString(32)+`_`,t.autoName=e}function ci(e){if(e==null||typeof e==`string`)return e;var t=null,n=Ed;if(n!==null)for(var r=0;r<n.length;r++){var i=e[n[r]];if(i!=null){if(i===`none`)return`none`;t=t==null?i:t+(` `+i)}}return t??e.default}function li(e,t){return e=ci(e),t=ci(t),t==null?e===`auto`?null:e:t===`auto`?null:t}var ui=typeof reportError==`function`?reportError:function(e){if(typeof window==`object`&&typeof window.ErrorEvent==`function`){var t=new window.ErrorEvent(`error`,{bubbles:!0,cancelable:!0,message:typeof e==`object`&&e&&typeof e.message==`string`?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process==`object`&&typeof process.emit==`function`){process.emit(`uncaughtException`,e);return}console.error(e)},di=[],fi=0,pi=0;function mi(){for(var e=fi,t=pi=fi=0;t<e;){var n=di[t];di[t++]=null;var r=di[t];di[t++]=null;var i=di[t];di[t++]=null;var a=di[t];if(di[t++]=null,r!==null&&i!==null){var o=r.pending;o===null?i.next=i:(i.next=o.next,o.next=i),r.pending=i}a!==0&&vi(n,i,a)}}function hi(e,t,n,r){di[fi++]=e,di[fi++]=t,di[fi++]=n,di[fi++]=r,pi|=r,e.lanes|=r,e=e.alternate,e!==null&&(e.lanes|=r)}function gi(e,t,n,r){return hi(e,t,n,r),yi(e)}function _i(e,t){return hi(e,null,null,t),yi(e)}function vi(e,t,n){e.lanes|=n;var r=e.alternate;r!==null&&(r.lanes|=n);for(var i=!1,a=e.return;a!==null;)a.childLanes|=n,r=a.alternate,r!==null&&(r.childLanes|=n),a.tag===22&&(e=a.stateNode,e===null||e._visibility&1||(i=!0)),e=a,a=a.return;return e.tag===3?(a=e.stateNode,i&&t!==null&&(i=31-qe(n),e=a.hiddenUpdates,r=e[i],r===null?e[i]=[t]:r.push(t),t.lane=n|536870912),a):null}function yi(e){if(50<Dd)throw Dd=0,Od=null,Error(i(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var bi={};function xi(e,t,n,r){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Si(e,t,n,r){return new xi(e,t,n,r)}function Ci(e){return e=e.prototype,!(!e||!e.isReactComponent)}function wi(e,t){var n=e.alternate;return n===null?(n=Si(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&1206910976,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n.refCleanup=e.refCleanup,n}function Ti(e,t){e.flags&=1206910978;var n=e.alternate;return n===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=n.childLanes,e.lanes=n.lanes,e.child=n.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=n.memoizedProps,e.memoizedState=n.memoizedState,e.updateQueue=n.updateQueue,e.type=n.type,t=n.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function Ei(e,t,n,r,a,o){var s=0;if(r=e,typeof r==`function`)Ci(r)&&(s=1);else if(typeof r==`string`)s=Jm(e,n,ge.current)?26:e===`html`||e===`head`||e===`body`?27:5;else a:switch(r){case te:return e=Si(31,n,t,a),e.elementType=te,e.lanes=o,e;case j:return Di(n.children,a,o,t);case M:s=8,a|=24;break;case ee:return e=Si(12,n,t,a|2),e.elementType=ee,e.lanes=o,e;case I:return e=Si(13,n,t,a),e.elementType=I,e.lanes=o,e;case R:return e=Si(19,n,t,a),e.elementType=R,e.lanes=o,e;case ne:case ie:return e=a|32,e=Si(30,n,t,e),e.elementType=ie,e.lanes=o,e.stateNode={autoName:null,paired:null,clones:null,ref:null},e;default:if(typeof r==`object`&&r)switch(r.$$typeof){case P:s=10;break a;case N:s=9;break a;case F:s=11;break a;case z:s=14;break a;case B:s=16,r=null;break a}s=29,n=Error(i(130,e===null?`null`:typeof e,``)),r=null}return t=Si(s,n,t,a),t.elementType=e,t.type=r,t.lanes=o,t}function Di(e,t,n,r){return e=Si(7,e,r,t),e.lanes=n,e}function Oi(e,t,n){return e=Si(6,e,null,t),e.lanes=n,e}function ki(e){var t=Si(18,null,null,0);return t.stateNode=e,t}function Ai(e,t,n){return t=Si(4,e.children===null?[]:e.children,e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var ji=new WeakMap;function Mi(e,t){if(typeof e==`object`&&e){var n=ji.get(e);return n===void 0?(t={value:e,source:t,stack:Ae(t)},ji.set(e,t),t):n}return{value:e,source:t,stack:Ae(t)}}var Ni=[],Pi=0,Fi=null,Ii=0,Li=[],Ri=0,zi=null,Bi=1,Vi=``;function Hi(e,t){Ni[Pi++]=Ii,Ni[Pi++]=Fi,Fi=e,Ii=t}function Ui(e,t,n){Li[Ri++]=Bi,Li[Ri++]=Vi,Li[Ri++]=zi,zi=e;var r=Bi;e=Vi;var i=32-qe(r)-1;r&=~(1<<i),n+=1;var a=32-qe(t)+i;if(30<a){var o=i-i%5;a=(r&(1<<o)-1).toString(32),r>>=o,i-=o,Bi=1<<32-qe(t)+i|n<<i|r,Vi=a+e}else Bi=1<<a|n<<i|r,Vi=e}function Wi(e){e.return!==null&&(Hi(e,1),Ui(e,1,0))}function Gi(e){for(;e===Fi;)Fi=Ni[--Pi],Ni[Pi]=null,Ii=Ni[--Pi],Ni[Pi]=null;for(;e===zi;)zi=Li[--Ri],Li[Ri]=null,Vi=Li[--Ri],Li[Ri]=null,Bi=Li[--Ri],Li[Ri]=null}function Ki(e,t){Li[Ri++]=Bi,Li[Ri++]=Vi,Li[Ri++]=zi,Bi=t.id,Vi=t.overflow,zi=e}var qi=null,Ji=null,Z=!1,Yi=null,Xi=!1,Zi=Error(i(519));function Qi(e){throw ia(Mi(Error(i(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?`text`:`HTML`,``)),e)),Zi}function $i(e){var t=e.stateNode,n=e.type,r=e.memoizedProps;switch(t[K]=e,t[q]=r,n){case`dialog`:Vf(`cancel`,t),Vf(`close`,t);break;case`iframe`:case`object`:case`embed`:Vf(`load`,t);break;case`video`:case`audio`:for(n=0;n<Rf.length;n++)Vf(Rf[n],t);break;case`source`:Vf(`error`,t);break;case`img`:case`image`:case`link`:Vf(`error`,t),Vf(`load`,t);break;case`details`:Vf(`toggle`,t);break;case`input`:Vf(`invalid`,t),Jt(t,r.value,r.defaultValue,r.checked,r.defaultChecked,r.type,r.name,!0);break;case`select`:Vf(`invalid`,t);break;case`textarea`:Vf(`invalid`,t),Qt(t,r.value,r.defaultValue,r.children)}n=r.children,typeof n!=`string`&&typeof n!=`number`&&typeof n!=`bigint`||t.textContent===``+n||!0===r.suppressHydrationWarning||ep(t.textContent,n)?(r.popover!=null&&(Vf(`beforetoggle`,t),Vf(`toggle`,t)),r.onScroll!=null&&Vf(`scroll`,t),r.onScrollEnd!=null&&Vf(`scrollend`,t),r.onClick!=null&&(t.onclick=cn),t=!0):t=!1,t||Qi(e,!0)}function ea(e){for(qi=e.return;qi;)switch(qi.tag){case 5:case 31:case 13:Xi=!1;return;case 27:case 3:Xi=!0;return;default:qi=qi.return}}function ta(e){if(e!==qi)return!1;if(!Z)return ea(e),Z=!0,!1;var t=e.tag,n;if((n=t!==3&&t!==27)&&((n=t===5)&&(n=e.type,n=n===`form`||n===`button`||mp(e.type,e.memoizedProps)),n=!n),n&&Ji&&Qi(e),ea(e),t===13){if(e=e.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(i(317));Ji=fm(e)}else if(t===31){if(e=e.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(i(317));Ji=fm(e)}else t===27?(t=Ji,Cp(e.type)?(e=dm,dm=null,Ji=e):Ji=t):Ji=qi?um(e.stateNode.nextSibling):null;return!0}function na(){Ji=qi=null,Z=!1}function ra(){var e=Yi;return e!==null&&(ud===null?ud=e:ud.push.apply(ud,e),Yi=null),e}function ia(e){Yi===null?Yi=[e]:Yi.push(e)}var aa=pe(null),oa=null,sa=null;function ca(e,t,n){he(aa,t._currentValue),t._currentValue=n}function la(e){e._currentValue=aa.current,me(aa)}function ua(e,t,n){for(;e!==null;){var r=e.alternate;if((e.childLanes&t)===t?r!==null&&(r.childLanes&t)!==t&&(r.childLanes|=t):(e.childLanes|=t,r!==null&&(r.childLanes|=t)),e===n)break;e=e.return}}function da(e,t,n,r){var a=e.child;for(a!==null&&(a.return=e);a!==null;){var o=a.dependencies;if(o!==null){var s=a.child;o=o.firstContext;a:for(;o!==null;){var c=o;o=a;for(var l=0;l<t.length;l++)if(c.context===t[l]){o.lanes|=n,c=o.alternate,c!==null&&(c.lanes|=n),ua(o.return,n,e),r||(s=null);break a}o=c.next}}else if(a.tag===18){if(s=a.return,s===null)throw Error(i(341));s.lanes|=n,o=s.alternate,o!==null&&(o.lanes|=n),ua(s,n,e),s=null}else a.tag===13&&a.memoizedState!==null&&a.memoizedState.dehydrated===null?(a.lanes|=n,s=a.alternate,s!==null&&(s.lanes|=n),ua(a.return,n,e),s=a.child,s=s===null?null:s.sibling):s=a.child;if(s!==null)s.return=a;else for(s=a;s!==null;){if(s===e){s=null;break}if(a=s.sibling,a!==null){a.return=s.return,s=a;break}s=s.return}a=s}}function fa(e,t,n,r){e=null;for(var a=t,o=!1;a!==null;){if(!o){if(a.flags&524288)o=!0;else if(a.flags&262144)break}if(a.tag===10){var s=a.alternate;if(s===null)throw Error(i(387));if(s=s.memoizedProps,s!==null){var c=a.type;jr(a.pendingProps.value,s.value)||(e===null?e=[c]:e.push(c))}}else if(a===ye.current){if(s=a.alternate,s===null)throw Error(i(387));s.memoizedState.memoizedState!==a.memoizedState.memoizedState&&(e===null?e=[ch]:e.push(ch))}a=a.return}return e!==null&&da(t,e,n,r),t.flags|=262144,e!==null}function pa(e){for(e=e.firstContext;e!==null;){if(!jr(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function ma(e){oa=e,sa=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function ha(e){return _a(oa,e)}function ga(e,t){return oa===null&&ma(e),_a(e,t)}function _a(e,t){var n=t._currentValue;if(t={context:t,memoizedValue:n,next:null},sa===null){if(e===null)throw Error(i(308));sa=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else sa=sa.next=t;return n}var va=typeof AbortController<`u`?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(t,n){e.push(n)}};this.abort=function(){t.aborted=!0,e.forEach(function(e){return e()})}},ya=t.unstable_scheduleCallback,ba=t.unstable_NormalPriority,xa={$$typeof:P,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function Sa(){return{controller:new va,data:new Map,refCount:0}}function Ca(e){e.refCount--,e.refCount===0&&ya(ba,function(){e.controller.abort()})}function wa(e,t){if(e.pendingLanes&4194048){var n=e.transitionTypes;for(n===null&&(n=e.transitionTypes=[]),e=0;e<t.length;e++){var r=t[e];n.indexOf(r)===-1&&n.push(r)}}}var Ta=null;function Ea(e){var t=e.transitionTypes;return e.transitionTypes=null,t}var Da=null,Oa=0,ka=0,Aa=null;function ja(e,t){if(Da===null){var n=Da=[];Oa=0,ka=Nf(),Aa={status:`pending`,value:void 0,then:function(e){n.push(e)}}}return Oa++,t.then(Ma,Ma),t}function Ma(){if(--Oa===0&&(Ta=null,Da!==null)){Aa!==null&&(Aa.status=`fulfilled`);var e=Da;Da=null,ka=0,Aa=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function Na(e,t){var n=[],r={status:`pending`,value:null,reason:null,then:function(e){n.push(e)}};return e.then(function(){r.status=`fulfilled`,r.value=t;for(var e=0;e<n.length;e++)(0,n[e])(t)},function(e){for(r.status=`rejected`,r.reason=e,e=0;e<n.length;e++)(0,n[e])(void 0)}),r}var Pa=H.S;H.S=function(e,t){if(pd=Ie(),typeof t==`object`&&t&&typeof t.then==`function`&&ja(e,t),Ta!==null)for(var n=yf;n!==null;)wa(n,Ta),n=n.next;if(n=e.types,n!==null){for(var r=yf;r!==null;)wa(r,n),r=r.next;if(ka!==0){r=Ta,r===null&&(r=Ta=[]);for(var i=0;i<n.length;i++){var a=n[i];r.indexOf(a)===-1&&r.push(a)}}}Pa!==null&&Pa(e,t)};var Fa=pe(null);function Ia(){var e=Fa.current;return e===null?Yu.pooledCache:e}function La(e,t){t===null?he(Fa,Fa.current):he(Fa,t.pool)}function Ra(){var e=Ia();return e===null?null:{parent:xa._currentValue,pool:e}}var za=Error(i(460)),Ba=Error(i(474)),Va=Error(i(542)),Ha={then:function(){}};function Ua(e){return e=e.status,e===`fulfilled`||e===`rejected`}function Wa(e,t,n){switch(n=e[n],n===void 0?e.push(t):n!==t&&(t.then(cn,cn),t=n),t.status){case`fulfilled`:return t.value;case`rejected`:throw e=t.reason,Ja(e),e===void 0&&!(`reason`in t)?Error(i(600)):e;default:if(typeof t.status==`string`)t.then(cn,cn);else{if(e=Yu,e!==null&&100<e.shellSuspendCounter)throw Error(i(482));e=t,e.status=`pending`,e.then(function(e){if(t.status===`pending`){var n=t;n.status=`fulfilled`,n.value=e}},function(e){if(t.status===`pending`){var n=t;n.status=`rejected`,n.reason=e}})}switch(t.status){case`fulfilled`:return t.value;case`rejected`:throw e=t.reason,Ja(e),e}throw Ka=t,za}}function Ga(e){try{var t=e._init;return t(e._payload)}catch(e){throw typeof e==`object`&&e&&typeof e.then==`function`?(Ka=e,za):e}}var Ka=null;function qa(){if(Ka===null)throw Error(i(459));var e=Ka;return Ka=null,e}function Ja(e){if(e===za||e===Va)throw Error(i(483))}var Ya=null,Xa=0;function Za(e){var t=Xa;return Xa+=1,Ya===null&&(Ya=[]),Wa(Ya,e,t)}function Qa(e,t){t=t.props.ref,e.ref=t===void 0?null:t}function $a(e,t){throw t.$$typeof===O?Error(i(525)):(e=Object.prototype.toString.call(t),Error(i(31,e===`[object Object]`?`object with keys {`+Object.keys(t).join(`, `)+`}`:e)))}function eo(e){function t(t,n){if(e){var r=t.deletions;r===null?(t.deletions=[n],t.flags|=16):r.push(n)}}function n(n,r){if(!e)return null;for(;r!==null;)t(n,r),r=r.sibling;return null}function r(e){for(var t=new Map;e!==null;)e.key===null?t.set(e.index,e):t.set(e.key,e),e=e.sibling;return t}function a(e,t){return e=wi(e,t),e.index=0,e.sibling=null,e}function o(t,n,r){return t.index=r,e?(r=t.alternate,r===null?(t.flags|=134217730,n):(r=r.index,r<n?(t.flags|=2,n):r)):(t.flags|=1048576,n)}function s(t){return e&&t.alternate===null&&(t.flags|=134217730),t}function c(e,t,n,r){return t===null||t.tag!==6?(t=Oi(n,e.mode,r),t.return=e,t):(t=a(t,n),t.return=e,t)}function l(e,t,n,r){var i=n.type;return i===j?(e=d(e,t,n.props.children,r,n.key),Qa(e,n),e):t!==null&&(t.elementType===i||typeof i==`object`&&i&&i.$$typeof===B&&Ga(i)===t.type)?(t=a(t,n.props),Qa(t,n),t.return=e,t):(t=Ei(n.type,n.key,n.props,null,e.mode,r),Qa(t,n),t.return=e,t)}function u(e,t,n,r){return t===null||t.tag!==4||t.stateNode.containerInfo!==n.containerInfo||t.stateNode.implementation!==n.implementation?(t=Ai(n,e.mode,r),t.return=e,t):(t=a(t,n.children||[]),t.return=e,t)}function d(e,t,n,r,i){return t===null||t.tag!==7?(t=Di(n,e.mode,r,i),t.return=e,t):(t=a(t,n),t.return=e,t)}function f(e,t,n){if(typeof t==`string`&&t!==``||typeof t==`number`||typeof t==`bigint`)return t=Oi(``+t,e.mode,n),t.return=e,t;if(typeof t==`object`&&t){switch(t.$$typeof){case k:return n=Ei(t.type,t.key,t.props,null,e.mode,n),Qa(n,t),n.return=e,n;case A:return t=Ai(t,e.mode,n),t.return=e,t;case B:return t=Ga(t),f(e,t,n)}if(V(t)||se(t))return t=Di(t,e.mode,n,null),t.return=e,t;if(typeof t.then==`function`)return f(e,Za(t),n);if(t.$$typeof===P)return f(e,ga(e,t),n);$a(e,t)}return null}function p(e,t,n,r){var i=t===null?null:t.key;if(typeof n==`string`&&n!==``||typeof n==`number`||typeof n==`bigint`)return i===null?c(e,t,``+n,r):null;if(typeof n==`object`&&n){switch(n.$$typeof){case k:return n.key===i?l(e,t,n,r):null;case A:return n.key===i?u(e,t,n,r):null;case B:return n=Ga(n),p(e,t,n,r)}if(V(n)||se(n))return i===null?d(e,t,n,r,null):null;if(typeof n.then==`function`)return p(e,t,Za(n),r);if(n.$$typeof===P)return p(e,t,ga(e,n),r);$a(e,n)}return null}function m(e,t,n,r,i){if(typeof r==`string`&&r!==``||typeof r==`number`||typeof r==`bigint`)return e=e.get(n)||null,c(t,e,``+r,i);if(typeof r==`object`&&r){switch(r.$$typeof){case k:return e=e.get(r.key===null?n:r.key)||null,l(t,e,r,i);case A:return e=e.get(r.key===null?n:r.key)||null,u(t,e,r,i);case B:return r=Ga(r),m(e,t,n,r,i)}if(V(r)||se(r))return e=e.get(n)||null,d(t,e,r,i,null);if(typeof r.then==`function`)return m(e,t,n,Za(r),i);if(r.$$typeof===P)return m(e,t,n,ga(t,r),i);$a(t,r)}return null}function h(i,a,s,c){for(var l=null,u=null,d=a,h=a=0,g=null;d!==null&&h<s.length;h++){d.index>h?(g=d,d=null):g=d.sibling;var _=p(i,d,s[h],c);if(_===null){d===null&&(d=g);break}e&&d&&_.alternate===null&&t(i,d),a=o(_,a,h),u===null?l=_:u.sibling=_,u=_,d=g}if(h===s.length)return n(i,d),Z&&Hi(i,h),l;if(d===null){for(;h<s.length;h++)d=f(i,s[h],c),d!==null&&(a=o(d,a,h),u===null?l=d:u.sibling=d,u=d);return Z&&Hi(i,h),l}for(d=r(d);h<s.length;h++)g=m(d,i,h,s[h],c),g!==null&&(e&&(_=g.alternate,_!==null&&d.delete(_.key===null?h:_.key)),a=o(g,a,h),u===null?l=g:u.sibling=g,u=g);return e&&d.forEach(function(e){return t(i,e)}),Z&&Hi(i,h),l}function g(a,s,c,l){if(c==null)throw Error(i(151));for(var u=null,d=null,h=s,g=s=0,_=null,v=c.next();h!==null&&!v.done;g++,v=c.next()){h.index>g?(_=h,h=null):_=h.sibling;var y=p(a,h,v.value,l);if(y===null){h===null&&(h=_);break}e&&h&&y.alternate===null&&t(a,h),s=o(y,s,g),d===null?u=y:d.sibling=y,d=y,h=_}if(v.done)return n(a,h),Z&&Hi(a,g),u;if(h===null){for(;!v.done;g++,v=c.next())v=f(a,v.value,l),v!==null&&(s=o(v,s,g),d===null?u=v:d.sibling=v,d=v);return Z&&Hi(a,g),u}for(h=r(h);!v.done;g++,v=c.next())v=m(h,a,g,v.value,l),v!==null&&(e&&(_=v.alternate,_!==null&&h.delete(_.key===null?g:_.key)),s=o(v,s,g),d===null?u=v:d.sibling=v,d=v);return e&&h.forEach(function(e){return t(a,e)}),Z&&Hi(a,g),u}function _(e,r,o,c){if(typeof o==`object`&&o&&o.type===j&&o.key===null&&o.props.ref===void 0&&(o=o.props.children),typeof o==`object`&&o){switch(o.$$typeof){case k:a:{for(var l=o.key;r!==null;){if(r.key===l){if(l=o.type,l===j){if(r.tag===7){n(e,r.sibling),c=a(r,o.props.children),Qa(c,o),c.return=e,e=c;break a}}else if(r.elementType===l||typeof l==`object`&&l&&l.$$typeof===B&&Ga(l)===r.type){n(e,r.sibling),c=a(r,o.props),Qa(c,o),c.return=e,e=c;break a}n(e,r);break}t(e,r),r=r.sibling}o.type===j?(c=Di(o.props.children,e.mode,c,o.key),Qa(c,o),c.return=e,e=c):(c=Ei(o.type,o.key,o.props,null,e.mode,c),Qa(c,o),c.return=e,e=c)}return s(e);case A:a:{for(l=o.key;r!==null;){if(r.key===l){if(r.tag===4&&r.stateNode.containerInfo===o.containerInfo&&r.stateNode.implementation===o.implementation){n(e,r.sibling),c=a(r,o.children||[]),c.return=e,e=c;break a}n(e,r);break}t(e,r),r=r.sibling}c=Ai(o,e.mode,c),c.return=e,e=c}return s(e);case B:return o=Ga(o),_(e,r,o,c)}if(V(o))return h(e,r,o,c);if(se(o)){if(l=se(o),typeof l!=`function`)throw Error(i(150));return o=l.call(o),g(e,r,o,c)}if(typeof o.then==`function`)return _(e,r,Za(o),c);if(o.$$typeof===P)return _(e,r,ga(e,o),c);$a(e,o)}return typeof o==`string`&&o!==``||typeof o==`number`||typeof o==`bigint`?(o=``+o,r!==null&&r.tag===6?(n(e,r.sibling),c=a(r,o),c.return=e,e=c):(n(e,r),c=Oi(o,e.mode,c),c.return=e,e=c),s(e)):n(e,r)}return function(e,t,n,r){try{Xa=0;var i=_(e,t,n,r);return Ya=null,i}catch(t){if(t===za||t===Va)throw t;var a=Si(29,t,null,e.mode);return a.lanes=r,a.return=e,a}}}var to=eo(!0),no=eo(!1),ro=!1;function io(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function ao(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function oo(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function so(e,t,n){var r=e.updateQueue;if(r===null)return null;if(r=r.shared,Ju&2){var i=r.pending;return i===null?t.next=t:(t.next=i.next,i.next=t),r.pending=t,t=yi(e),vi(e,null,n),t}return hi(e,r,t,n),yi(e)}function co(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,n&4194048)){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,lt(e,n)}}function lo(e,t){var n=e.updateQueue,r=e.alternate;if(r!==null&&(r=r.updateQueue,n===r)){var i=null,a=null;if(n=n.firstBaseUpdate,n!==null){do{var o={lane:n.lane,tag:n.tag,payload:n.payload,callback:null,next:null};a===null?i=a=o:a=a.next=o,n=n.next}while(n!==null);a===null?i=a=t:a=a.next=t}else i=a=t;n={baseState:r.baseState,firstBaseUpdate:i,lastBaseUpdate:a,shared:r.shared,callbacks:r.callbacks},e.updateQueue=n}else e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}var uo=!1;function fo(){if(uo){var e=Aa;if(e!==null)throw e}}function po(e,t,n,r){uo=!1;var i=e.updateQueue;ro=!1;var a=i.firstBaseUpdate,o=i.lastBaseUpdate,s=i.shared.pending;if(s!==null){i.shared.pending=null;var c=s,l=c.next;c.next=null,o===null?a=l:o.next=l,o=c;var u=e.alternate;u!==null&&(u=u.updateQueue,s=u.lastBaseUpdate,s!==o&&(s===null?u.firstBaseUpdate=l:s.next=l,u.lastBaseUpdate=c))}if(a!==null){var d=i.baseState;o=0,u=l=c=null,s=a;do{var f=s.lane&-536870913,p=f!==s.lane;if(p?(Xu&f)===f:(r&f)===f){f!==0&&f===ka&&(uo=!0),u!==null&&(u=u.next={lane:0,tag:s.tag,payload:s.payload,callback:null,next:null});a:{var m=e,h=s;f=t;var g=n;switch(h.tag){case 1:if(m=h.payload,typeof m==`function`){d=m.call(g,d,f);break a}d=m;break a;case 3:m.flags=m.flags&-65537|128;case 0:if(m=h.payload,f=typeof m==`function`?m.call(g,d,f):m,f==null)break a;d=D({},d,f);break a;case 2:ro=!0}}f=s.callback,f!==null&&(e.flags|=64,p&&(e.flags|=8192),p=i.callbacks,p===null?i.callbacks=[f]:p.push(f))}else p={lane:f,tag:s.tag,payload:s.payload,callback:s.callback,next:null},u===null?(l=u=p,c=d):u=u.next=p,o|=f;if(s=s.next,s===null){if(s=i.shared.pending,s===null)break;p=s,s=p.next,p.next=null,i.lastBaseUpdate=p,i.shared.pending=null}}while(1);u===null&&(c=d),i.baseState=c,i.firstBaseUpdate=l,i.lastBaseUpdate=u,a===null&&(i.shared.lanes=0),id|=o,e.lanes=o,e.memoizedState=d}}function mo(e,t){if(typeof e!=`function`)throw Error(i(191,e));e.call(t)}function ho(e,t){var n=e.callbacks;if(n!==null)for(e.callbacks=null,e=0;e<n.length;e++)mo(n[e],t)}var go=pe(null),_o=pe(0);function vo(e,t){e=nd,he(_o,e),he(go,t),nd=e|t.baseLanes}function yo(){he(_o,nd),he(go,go.current)}function bo(){nd=_o.current,me(go),me(_o)}var xo=pe(null),So=null;function Co(e){var t=e.alternate;he(Oo,Oo.current&1),he(xo,e),So===null&&(t===null||go.current!==null||t.memoizedState!==null)&&(So=e)}function wo(e){he(Oo,Oo.current),he(xo,e),So===null&&(So=e)}function To(e){e.tag===22?(he(Oo,Oo.current),he(xo,e),So===null&&(So=e)):Eo()}function Eo(){he(Oo,Oo.current),he(xo,xo.current)}function Do(e){me(xo),So===e&&(So=null),me(Oo)}var Oo=pe(0);function ko(e,t){he(xo,xo.current),he(Oo,t)}function Ao(e){me(Oo),me(xo),So===e&&(So=null)}function jo(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||sm(n)||cm(n)))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!==`independent`){if(t.flags&128)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var Mo=0,Q=null,No=null,Po=null,Fo=!1,Io=!1,Lo=!1,Ro=0,zo=0,Bo=null,Vo=0;function Ho(){throw Error(i(321))}function Uo(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!jr(e[n],t[n]))return!1;return!0}function Wo(e,t,n,r,i,a){return Mo=a,Q=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,H.H=e===null||e.memoizedState===null?sc:cc,Lo=!1,a=n(r,i),Lo=!1,Io&&(a=Ko(t,n,r,i)),Go(e),a}function Go(e){H.H=oc;var t=No!==null&&No.next!==null;if(Mo=0,Po=No=Q=null,Fo=!1,zo=0,Bo=null,t)throw Error(i(300));e===null||Tc||(e=e.dependencies,e!==null&&pa(e)&&(Tc=!0))}function Ko(e,t,n,r){Q=e;var a=0;do{if(Io&&(Bo=null),zo=0,Io=!1,25<=a)throw Error(i(301));if(a+=1,Po=No=null,e.updateQueue!=null){var o=e.updateQueue;o.lastEffect=null,o.events=null,o.stores=null,o.memoCache!=null&&(o.memoCache.index=0)}H.H=lc,o=t(n,r)}while(Io);return o}function qo(){var e=H.H,t=e.useState()[0];return t=typeof t.then==`function`?es(t):t,e=e.useState()[0],(No===null?null:No.memoizedState)!==e&&(Q.flags|=1024),t}function Jo(){var e=Ro!==0;return Ro=0,e}function Yo(e,t,n){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~n}function Xo(e){if(Fo){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}Fo=!1}Mo=0,Po=No=Q=null,Io=!1,zo=Ro=0,Bo=null}function Zo(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Po===null?Q.memoizedState=Po=e:Po=Po.next=e,Po}function Qo(){if(No===null){var e=Q.alternate;e=e===null?null:e.memoizedState}else e=No.next;var t=Po===null?Q.memoizedState:Po.next;if(t!==null)Po=t,No=e;else{if(e===null)throw Q.alternate===null?Error(i(467)):Error(i(310));No=e,e={memoizedState:No.memoizedState,baseState:No.baseState,baseQueue:No.baseQueue,queue:No.queue,next:null},Po===null?Q.memoizedState=Po=e:Po=Po.next=e}return Po}function $o(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function es(e){var t=zo;return zo+=1,Bo===null&&(Bo=[]),e=Wa(Bo,e,t),t=Q,(Po===null?t.memoizedState:Po.next)===null&&(t=t.alternate,H.H=t===null||t.memoizedState===null?sc:cc),e}function ts(e){if(typeof e==`object`&&e){if(typeof e.then==`function`)return es(e);if(e.$$typeof===ae)return;if(e.$$typeof===P)return ha(e)}throw Error(i(438,String(e)))}function ns(e){var t=null,n=Q.updateQueue;if(n!==null&&(t=n.memoCache),t==null){var r=Q.alternate;r!==null&&(r=r.updateQueue,r!==null&&(r=r.memoCache,r!=null&&(t={data:r.data.map(function(e){return e.slice()}),index:0})))}if(t??={data:[],index:0},n===null&&(n=$o(),Q.updateQueue=n),n.memoCache=t,n=t.data[t.index],n===void 0)for(n=t.data[t.index]=Array(e),r=0;r<e;r++)n[r]=re;return t.index++,n}function rs(e,t){return typeof t==`function`?t(e):t}function is(e){return as(Qo(),No,e)}function as(e,t,n){var r=e.queue;if(r===null)throw Error(i(311));r.lastRenderedReducer=n;var a=e.baseQueue,o=r.pending;if(o!==null){if(a!==null){var s=a.next;a.next=o.next,o.next=s}t.baseQueue=a=o,r.pending=null}if(o=e.baseState,a===null)e.memoizedState=o;else{t=a.next;var c=s=null,l=null,u=t,d=!1;do{var f=u.lane&-536870913;if(f===u.lane?(Mo&f)===f:(Xu&f)===f){var p=u.revertLane;if(p===0)l!==null&&(l=l.next={lane:0,revertLane:0,gesture:null,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null}),f===ka&&(d=!0);else if((Mo&p)===p){u=u.next,p===ka&&(d=!0);continue}else f={lane:0,revertLane:u.revertLane,gesture:null,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},l===null?(c=l=f,s=o):l=l.next=f,Q.lanes|=p,id|=p;f=u.action,Lo&&n(o,f),o=u.hasEagerState?u.eagerState:n(o,f)}else p={lane:f,revertLane:u.revertLane,gesture:u.gesture,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},l===null?(c=l=p,s=o):l=l.next=p,Q.lanes|=f,id|=f;u=u.next}while(u!==null&&u!==t);if(l===null?s=o:l.next=c,!jr(o,e.memoizedState)&&(Tc=!0,d&&(n=Aa,n!==null)))throw n;e.memoizedState=o,e.baseState=s,e.baseQueue=l,r.lastRenderedState=o}return a===null&&(r.lanes=0),[e.memoizedState,r.dispatch]}function os(e){var t=Qo(),n=t.queue;if(n===null)throw Error(i(311));n.lastRenderedReducer=e;var r=n.dispatch,a=n.pending,o=t.memoizedState;if(a!==null){n.pending=null;var s=a=a.next;do o=e(o,s.action),s=s.next;while(s!==a);jr(o,t.memoizedState)||(Tc=!0),t.memoizedState=o,t.baseQueue===null&&(t.baseState=o),n.lastRenderedState=o}return[o,r]}function ss(e,t,n){var r=Q,a=Qo(),o=Z;if(o){if(n===void 0)throw Error(i(407));n=n()}else n=t();var s=!jr((No||a).memoizedState,n);if(s&&(a.memoizedState=n,Tc=!0),a=a.queue,Ms(us.bind(null,r,a,e),[e]),e=a.getSnapshot!==t||s||Po!==null&&!!(Po.memoizedState.tag&1),Ds(e?9:8,{destroy:void 0},ls.bind(null,r,a,n,t),null),e){if(r.flags|=2048,Yu===null)throw Error(i(349));o||Mo&127||cs(r,t,n)}return n}function cs(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=Q.updateQueue,t===null?(t=$o(),Q.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function ls(e,t,n,r){t.value=n,t.getSnapshot=r,ds(t)&&fs(e)}function us(e,t,n){return n(function(){ds(t)&&fs(e)})}function ds(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!jr(e,n)}catch{return!0}}function fs(e){var t=_i(e,2);t!==null&&Md(t,e,2)}function ps(e){var t=Zo();if(typeof e==`function`){var n=e;if(e=n(),Lo){Ke(!0);try{n()}finally{Ke(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:rs,lastRenderedState:e},t}function ms(e,t,n,r){return e.baseState=n,as(e,No,typeof r==`function`?r:rs)}function hs(e,t,n,r,a){if(rc(e))throw Error(i(485));if(e=t.action,e!==null){var o={payload:a,action:e,next:null,isTransition:!0,status:`pending`,value:null,reason:null,listeners:[],then:function(e){o.listeners.push(e)}};H.T===null?o.isTransition=!1:n(!0),r(o),n=t.pending,n===null?(o.next=t.pending=o,gs(t,o)):(o.next=n.next,t.pending=n.next=o)}}function gs(e,t){var n=t.action,r=t.payload,i=e.state;if(t.isTransition){var a=H.T,o={};o.types=a===null?null:a.types,H.T=o;try{var s=n(i,r),c=H.S;c!==null&&c(o,s),_s(e,t,s)}catch(n){ys(e,t,n)}finally{a!==null&&o.types!==null&&(a.types=o.types),H.T=a}}else try{a=n(i,r),_s(e,t,a)}catch(n){ys(e,t,n)}}function _s(e,t,n){typeof n==`object`&&n&&typeof n.then==`function`?n.then(function(n){vs(e,t,n)},function(n){return ys(e,t,n)}):vs(e,t,n)}function vs(e,t,n){t.status=`fulfilled`,t.value=n,bs(t),e.state=n,t=e.pending,t!==null&&(n=t.next,n===t?e.pending=null:(n=n.next,t.next=n,gs(e,n)))}function ys(e,t,n){var r=e.pending;if(e.pending=null,r!==null){r=r.next;do t.status=`rejected`,t.reason=n,bs(t),t=t.next;while(t!==r)}e.action=null}function bs(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function xs(e,t){return t}function Ss(e,t){if(Z){var n=Yu.formState;if(n!==null){a:{var r=Q;if(Z){if(Ji){b:{for(var i=Ji,a=Xi;i.nodeType!==8;)if(!a||(i=um(i.nextSibling),i===null)){i=null;break b}a=i.data,i=a===`F!`||a===`F`?i:null}if(i){Ji=um(i.nextSibling),r=i.data===`F!`;break a}}Qi(r)}r=!1}r&&(t=n[0])}}return n=Zo(),n.memoizedState=n.baseState=t,r={pending:null,lanes:0,dispatch:null,lastRenderedReducer:xs,lastRenderedState:t},n.queue=r,n=ec.bind(null,Q,r),r.dispatch=n,r=ps(!1),a=nc.bind(null,Q,!1,r.queue),r=Zo(),i={state:t,dispatch:null,action:e,pending:null},r.queue=i,n=hs.bind(null,Q,i,a,n),i.dispatch=n,r.memoizedState=e,[t,n,!1]}function Cs(e){return ws(Qo(),No,e)}function ws(e,t,n){if(t=as(e,t,xs)[0],e=is(rs)[0],typeof t==`object`&&t&&typeof t.then==`function`)try{var r=es(t)}catch(e){throw e===za?Va:e}else r=t;t=Qo();var i=t.queue,a=i.dispatch;return n!==t.memoizedState&&(Q.flags|=2048,Ds(9,{destroy:void 0},Ts.bind(null,i,n),null)),[r,a,e]}function Ts(e,t){e.action=t}function Es(e){var t=Qo(),n=No;if(n!==null)return ws(t,n,e);Qo(),t=t.memoizedState,n=Qo();var r=n.queue.dispatch;return n.memoizedState=e,[t,r,!1]}function Ds(e,t,n,r){return e={tag:e,create:n,deps:r,inst:t,next:null},t=Q.updateQueue,t===null&&(t=$o(),Q.updateQueue=t),n=t.lastEffect,n===null?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e),e}function Os(){return Qo().memoizedState}function ks(e,t,n,r){var i=Zo();Q.flags|=e,i.memoizedState=Ds(1|t,{destroy:void 0},n,r===void 0?null:r)}function As(e,t,n,r){var i=Qo();r=r===void 0?null:r;var a=i.memoizedState.inst;No!==null&&r!==null&&Uo(r,No.memoizedState.deps)?i.memoizedState=Ds(t,a,n,r):(Q.flags|=e,i.memoizedState=Ds(1|t,a,n,r))}function js(e,t){ks(8390656,8,e,t)}function Ms(e,t){As(2048,8,e,t)}function Ns(e){Q.flags|=4;var t=Q.updateQueue;if(t===null)t=$o(),Q.updateQueue=t,t.events=[e];else{var n=t.events;n===null?t.events=[e]:n.push(e)}}function Ps(e){var t=Qo().memoizedState;return Ns({ref:t,nextImpl:e}),function(){if(Ju&2)throw Error(i(440));return t.impl.apply(void 0,arguments)}}function Fs(e,t){return As(4,2,e,t)}function Is(e,t){return As(4,4,e,t)}function Ls(e,t){if(typeof t==`function`){e=e();var n=t(e);return function(){typeof n==`function`?n():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function Rs(e,t,n){n=n==null?null:n.concat([e]),As(4,4,Ls.bind(null,t,e),n)}function zs(){}function Bs(e,t){var n=Qo();t=t===void 0?null:t;var r=n.memoizedState;return t!==null&&Uo(t,r[1])?r[0]:(n.memoizedState=[e,t],e)}function Vs(e,t){var n=Qo();t=t===void 0?null:t;var r=n.memoizedState;if(t!==null&&Uo(t,r[1]))return r[0];if(r=e(),Lo){Ke(!0);try{e()}finally{Ke(!1)}}return n.memoizedState=[r,t],r}function Hs(e,t,n){return n===void 0||Mo&1073741824&&!(Xu&261930)?e.memoizedState=t:(e.memoizedState=n,e=Ad(),Q.lanes|=e,id|=e,n)}function Us(e,t,n,r){return jr(n,t)?n:go.current===null?!(Mo&106)||Mo&1073741824&&!(Xu&261930)?(Tc=!0,e.memoizedState=n):(e=Ad(),Q.lanes|=e,id|=e,t):(e=Hs(e,n,r),jr(e,t)||(Tc=!0),e)}function Ws(e,t,n,r,i){var a=U.p;U.p=a!==0&&8>a?a:8;var o=H.T,s={};s.types=o===null?null:o.types,H.T=s,nc(e,!1,t,n);try{var c=i(),l=H.S;l!==null&&l(s,c),typeof c==`object`&&c&&typeof c.then==`function`?tc(e,t,Na(c,r),kd(e)):tc(e,t,r,kd(e))}catch(n){tc(e,t,{then:function(){},status:`rejected`,reason:n},kd())}finally{U.p=a,o!==null&&s.types!==null&&(o.types=s.types),H.T=o}}function Gs(){}function Ks(e,t,n,r){if(e.tag!==5)throw Error(i(476));var a=qs(e).queue;Ws(e,a,t,ue,n===null?Gs:function(){return Js(e),n(r)})}function qs(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:ue,baseState:ue,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:rs,lastRenderedState:ue},next:null};var n={};return t.next={memoizedState:n,baseState:n,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:rs,lastRenderedState:n},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function Js(e){var t=qs(e);t.next===null&&(t=e.alternate.memoizedState),tc(e,t.next.queue,{},kd())}function Ys(){return ha(ch)}function Xs(){return Qo().memoizedState}function Zs(){return Qo().memoizedState}function Qs(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var n=kd();e=oo(n);var r=so(t,e,n);r!==null&&(Md(r,t,n),co(r,t,n)),t={cache:Sa()},e.payload=t;return}t=t.return}}function $s(e,t,n){var r=kd();n={lane:r,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},rc(e)?ic(t,n):(n=gi(e,t,n,r),n!==null&&(Md(n,e,r),ac(n,t,r)))}function ec(e,t,n){tc(e,t,n,kd())}function tc(e,t,n,r){var i={lane:r,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null};if(rc(e))ic(t,i);else{var a=e.alternate;if(e.lanes===0&&(a===null||a.lanes===0)&&(a=t.lastRenderedReducer,a!==null))try{var o=t.lastRenderedState,s=a(o,n);if(i.hasEagerState=!0,i.eagerState=s,jr(s,o))return hi(e,t,i,0),Yu===null&&mi(),!1}catch{}if(n=gi(e,t,i,r),n!==null)return Md(n,e,r),ac(n,t,r),!0}return!1}function nc(e,t,n,r){if(r={lane:2,revertLane:Nf(),gesture:null,action:r,hasEagerState:!1,eagerState:null,next:null},rc(e)){if(t)throw Error(i(479))}else t=gi(e,n,r,2),t!==null&&Md(t,e,2)}function rc(e){var t=e.alternate;return e===Q||t!==null&&t===Q}function ic(e,t){Io=Fo=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function ac(e,t,n){if(n&4194048){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,lt(e,n)}}var oc={readContext:ha,use:ts,useCallback:Ho,useContext:Ho,useEffect:Ho,useImperativeHandle:Ho,useLayoutEffect:Ho,useInsertionEffect:Ho,useMemo:Ho,useReducer:Ho,useRef:Ho,useState:Ho,useDebugValue:Ho,useDeferredValue:Ho,useTransition:Ho,useSyncExternalStore:Ho,useId:Ho,useHostTransitionStatus:Ho,useFormState:Ho,useActionState:Ho,useOptimistic:Ho,useMemoCache:Ho,useCacheRefresh:Ho,useEffectEvent:Ho},sc={readContext:ha,use:ts,useCallback:function(e,t){return Zo().memoizedState=[e,t===void 0?null:t],e},useContext:ha,useEffect:js,useImperativeHandle:function(e,t,n){n=n==null?null:n.concat([e]),ks(4194308,4,Ls.bind(null,t,e),n)},useLayoutEffect:function(e,t){return ks(4194308,4,e,t)},useInsertionEffect:function(e,t){ks(4,2,e,t)},useMemo:function(e,t){var n=Zo();t=t===void 0?null:t;var r=e();if(Lo){Ke(!0);try{e()}finally{Ke(!1)}}return n.memoizedState=[r,t],r},useReducer:function(e,t,n){var r=Zo();if(n!==void 0){var i=n(t);if(Lo){Ke(!0);try{n(t)}finally{Ke(!1)}}}else i=t;return r.memoizedState=r.baseState=i,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:i},r.queue=e,e=e.dispatch=$s.bind(null,Q,e),[r.memoizedState,e]},useRef:function(e){var t=Zo();return e={current:e},t.memoizedState=e},useState:function(e){e=ps(e);var t=e.queue,n=ec.bind(null,Q,t);return t.dispatch=n,[e.memoizedState,n]},useDebugValue:zs,useDeferredValue:function(e,t){return Hs(Zo(),e,t)},useTransition:function(){var e=ps(!1);return e=Ws.bind(null,Q,e.queue,!0,!1),Zo().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,n){var r=Q,a=Zo();if(Z){if(n===void 0)throw Error(i(407));n=n()}else{if(n=t(),Yu===null)throw Error(i(349));Xu&127||cs(r,t,n)}a.memoizedState=n;var o={value:n,getSnapshot:t};return a.queue=o,js(us.bind(null,r,o,e),[e]),r.flags|=2048,Ds(9,{destroy:void 0},ls.bind(null,r,o,n,t),null),n},useId:function(){var e=Zo(),t=Yu.identifierPrefix;if(Z){var n=Vi,r=Bi;n=(r&~(1<<32-qe(r)-1)).toString(32)+n,t=`_`+t+`R_`+n,n=Ro++,0<n&&(t+=`H`+n.toString(32)),t+=`_`}else n=Vo++,t=`_`+t+`r_`+n.toString(32)+`_`;return e.memoizedState=t},useHostTransitionStatus:Ys,useFormState:Ss,useActionState:Ss,useOptimistic:function(e){var t=Zo();t.memoizedState=t.baseState=e;var n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=n,t=nc.bind(null,Q,!0,n),n.dispatch=t,[e,t]},useMemoCache:ns,useCacheRefresh:function(){return Zo().memoizedState=Qs.bind(null,Q)},useEffectEvent:function(e){var t=Zo(),n={impl:e};return t.memoizedState=n,function(){if(Ju&2)throw Error(i(440));return n.impl.apply(void 0,arguments)}}},cc={readContext:ha,use:ts,useCallback:Bs,useContext:ha,useEffect:Ms,useImperativeHandle:Rs,useInsertionEffect:Fs,useLayoutEffect:Is,useMemo:Vs,useReducer:is,useRef:Os,useState:function(){return is(rs)},useDebugValue:zs,useDeferredValue:function(e,t){return Us(Qo(),No.memoizedState,e,t)},useTransition:function(){var e=is(rs)[0],t=Qo().memoizedState;return[typeof e==`boolean`?e:es(e),t]},useSyncExternalStore:ss,useId:Xs,useHostTransitionStatus:Ys,useFormState:Cs,useActionState:Cs,useOptimistic:function(e,t){return ms(Qo(),No,e,t)},useMemoCache:ns,useCacheRefresh:Zs,useEffectEvent:Ps},lc={readContext:ha,use:ts,useCallback:Bs,useContext:ha,useEffect:Ms,useImperativeHandle:Rs,useInsertionEffect:Fs,useLayoutEffect:Is,useMemo:Vs,useReducer:os,useRef:Os,useState:function(){return os(rs)},useDebugValue:zs,useDeferredValue:function(e,t){var n=Qo();return No===null?Hs(n,e,t):Us(n,No.memoizedState,e,t)},useTransition:function(){var e=os(rs)[0],t=Qo().memoizedState;return[typeof e==`boolean`?e:es(e),t]},useSyncExternalStore:ss,useId:Xs,useHostTransitionStatus:Ys,useFormState:Es,useActionState:Es,useOptimistic:function(e,t){var n=Qo();return No===null?(n.baseState=e,[e,n.queue.dispatch]):ms(n,No,e,t)},useMemoCache:ns,useCacheRefresh:Zs,useEffectEvent:Ps};function uc(e,t,n,r){t=e.memoizedState,n=n(r,t),n=n==null?t:D({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var dc={enqueueSetState:function(e,t,n){e=e._reactInternals;var r=kd(),i=oo(r);i.payload=t,n!=null&&(i.callback=n),t=so(e,i,r),t!==null&&(Md(t,e,r),co(t,e,r))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var r=kd(),i=oo(r);i.tag=1,i.payload=t,n!=null&&(i.callback=n),t=so(e,i,r),t!==null&&(Md(t,e,r),co(t,e,r))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=kd(),r=oo(n);r.tag=2,t!=null&&(r.callback=t),t=so(e,r,n),t!==null&&(Md(t,e,n),co(t,e,n))}};function fc(e,t,n,r,i,a,o){return e=e.stateNode,typeof e.shouldComponentUpdate==`function`?e.shouldComponentUpdate(r,a,o):t.prototype&&t.prototype.isPureReactComponent?!Mr(n,r)||!Mr(i,a):!0}function pc(e,t,n,r){e=t.state,typeof t.componentWillReceiveProps==`function`&&t.componentWillReceiveProps(n,r),typeof t.UNSAFE_componentWillReceiveProps==`function`&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==e&&dc.enqueueReplaceState(t,t.state,null)}function mc(e,t){var n=t;if(`ref`in t)for(var r in n={},t)r!==`ref`&&(n[r]=t[r]);if(e=e.defaultProps)for(var i in n===t&&(n=D({},n)),e)n[i]===void 0&&(n[i]=e[i]);return n}function hc(e){ui(e)}function gc(e){console.error(e)}function _c(e){ui(e)}function vc(e,t){try{var n=e.onUncaughtError;n(t.value,{componentStack:t.stack})}catch(e){setTimeout(function(){throw e})}}function yc(e,t,n){try{var r=e.onCaughtError;r(n.value,{componentStack:n.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(e){setTimeout(function(){throw e})}}function bc(e,t,n){return n=oo(n),n.tag=3,n.payload={element:null},n.callback=function(){vc(e,t)},n}function xc(e){return e=oo(e),e.tag=3,e}function Sc(e,t,n,r){var i=n.type.getDerivedStateFromError;if(typeof i==`function`){var a=r.value;e.payload=function(){return i(a)},e.callback=function(){yc(t,n,r)}}var o=n.stateNode;o!==null&&typeof o.componentDidCatch==`function`&&(e.callback=function(){yc(t,n,r),typeof i!=`function`&&(gd===null?gd=new Set([this]):gd.add(this));var e=r.stack;this.componentDidCatch(r.value,{componentStack:e===null?``:e})})}function Cc(e,t,n,r,a){if(n.flags|=32768,typeof r==`object`&&r&&typeof r.then==`function`){if(t=n.alternate,t!==null&&fa(t,n,a,!0),n=xo.current,n!==null){switch(n.tag){case 31:case 13:case 19:return So===null?Wd():n.alternate===null&&rd===0&&(rd=3),n.flags&=-257,n.flags|=65536,n.lanes=a,r===Ha?n.flags|=16384:(t=n.updateQueue,t===null?n.updateQueue=new Set([r]):t.add(r),pf(e,r,a)),!1;case 22:return n.flags|=65536,r===Ha?n.flags|=16384:(t=n.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([r])},n.updateQueue=t):(n=t.retryQueue,n===null?t.retryQueue=new Set([r]):n.add(r)),pf(e,r,a)),!1}throw Error(i(435,n.tag))}return pf(e,r,a),Wd(),!1}if(Z)return t=xo.current,t===null?(r!==Zi&&(t=Error(i(423),{cause:r}),ia(Mi(t,n))),e=e.current.alternate,e.flags|=65536,a&=-a,e.lanes|=a,r=Mi(r,n),a=bc(e.stateNode,r,a),lo(e,a),rd!==4&&(rd=2)):(!(t.flags&65536)&&(t.flags|=256),t.flags|=65536,t.lanes=a,r!==Zi&&(e=Error(i(422),{cause:r}),ia(Mi(e,n)))),!1;var o=Error(i(520),{cause:r});if(o=Mi(o,n),ld===null?ld=[o]:ld.push(o),rd!==4&&(rd=2),t===null)return!0;r=Mi(r,n),n=t;do{switch(n.tag){case 3:return n.flags|=65536,e=a&-a,n.lanes|=e,e=bc(n.stateNode,r,e),lo(n,e),!1;case 1:if(t=n.type,o=n.stateNode,!(n.flags&128)&&(typeof t.getDerivedStateFromError==`function`||o!==null&&typeof o.componentDidCatch==`function`&&(gd===null||!gd.has(o))))return n.flags|=65536,a&=-a,n.lanes|=a,a=xc(a),Sc(a,e,n,r),lo(n,a),!1;break;case 22:if(n.memoizedState!==null)return n.flags|=65536,!1}n=n.return}while(n!==null);return!1}var wc=Error(i(461)),Tc=!1;function Ec(e,t,n,r){t.child=e===null?no(t,null,n,r):to(t,e.child,n,r)}function Dc(e,t,n,r,i){n=n.render;var a=t.ref;if(`ref`in r){var o={};for(var s in r)s!==`ref`&&(o[s]=r[s])}else o=r;return ma(t),r=Wo(e,t,n,o,a,i),s=Jo(),e!==null&&!Tc?(Yo(e,t,i),tl(e,t,i)):(Z&&s&&Wi(t),t.flags|=1,Ec(e,t,r,i),t.child)}function Oc(e,t,n,r,i){if(e===null){var a=n.type;return typeof a==`function`&&!Ci(a)&&a.defaultProps===void 0&&n.compare===null?(t.tag=15,t.type=a,kc(e,t,a,r,i)):(e=Ei(n.type,null,r,t,t.mode,i),e.ref=t.ref,e.return=t,t.child=e)}if(a=e.child,!nl(e,i)){var o=a.memoizedProps;if(n=n.compare,n=n===null?Mr:n,n(o,r)&&e.ref===t.ref)return tl(e,t,i)}return t.flags|=1,e=wi(a,r),e.ref=t.ref,e.return=t,t.child=e}function kc(e,t,n,r,i){if(e!==null){var a=e.memoizedProps;if(Mr(a,r)&&e.ref===t.ref){if(Tc=!1,t.pendingProps=r=a,nl(e,i))e.flags&131072&&(Tc=!0);else return t.lanes=e.lanes,tl(e,t,i)}}return Lc(e,t,n,r,i)}function Ac(e,t,n,r){var i=r.children,a=e===null?null:e.memoizedState;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),r.mode===`hidden`){if(t.flags&128){if(a=a===null?n:a.baseLanes|n,e!==null){for(r=t.child=e.child,i=0;r!==null;)i=i|r.lanes|r.childLanes,r=r.sibling;r=i&~a}else r=0,t.child=null;return Mc(e,t,a,n,r)}if(n&536870912)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&La(t,a===null?null:a.cachePool),a===null?yo():vo(t,a),To(t);else return r=t.lanes=536870912,Mc(e,t,a===null?n:a.baseLanes|n,n,r)}else a===null?(e!==null&&La(t,null),yo(),Eo()):(La(t,a.cachePool),vo(t,a),Eo(),t.memoizedState=null);return Ec(e,t,i,n),t.child}function jc(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function Mc(e,t,n,r,i){var a=Ia();return a=a===null?null:{parent:xa._currentValue,pool:a},t.memoizedState={baseLanes:n,cachePool:a},e!==null&&La(t,null),yo(),To(t),e!==null&&fa(e,t,r,!0),t.childLanes=i,null}function Nc(e,t){return t=Kc({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function Pc(e,t,n){return to(t,e.child,null,n),e=Nc(t,t.pendingProps),e.flags|=2,Do(t),t.memoizedState=null,e}function Fc(e,t,n){var r=t.pendingProps,a=!!(t.flags&128);if(t.flags&=-129,e===null){if(Z){if(r.mode===`hidden`)return e=Nc(t,r),t.lanes=536870912,e.memoizedState={baseLanes:0,cachePool:null},jc(null,e);if(wo(t),(e=Ji)?(e=om(e,Xi),e=e!==null&&e.data===`&`?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:zi===null?null:{id:Bi,overflow:Vi},retryLane:536870912,hydrationErrors:null},n=ki(e),n.return=t,t.child=n,qi=t,Ji=null)):e=null,e===null)throw Qi(t);return t.lanes=536870912,null}return Nc(t,r)}var o=e.memoizedState;if(o!==null){var s=o.dehydrated;if(wo(t),a){if(t.flags&256)t.flags&=-257,t=Pc(e,t,n);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(i(558))}else if(Tc||fa(e,t,n,!1),a=(n&e.childLanes)!==0,Tc||a){if(go.current===null){if(r=Yu,r!==null&&(s=ut(r,n),s!==0&&s!==o.retryLane))throw o.retryLane=s,_i(e,s),Md(r,e,s),wc;Wd()}t=Pc(e,t,n)}else e=o.treeContext,Ji=um(s.nextSibling),qi=t,Z=!0,Yi=null,Xi=!1,e!==null&&Ki(t,e),t=Nc(t,r),t.flags|=134221824;return t}return e=wi(e.child,{mode:r.mode,children:r.children}),e.ref=t.ref,t.child=e,e.return=t,e}function Ic(e,t){var n=t.ref;if(n===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof n!=`function`&&typeof n!=`object`)throw Error(i(284));(e===null||e.ref!==n)&&(t.flags|=4194816)}}function Lc(e,t,n,r,i){return ma(t),n=Wo(e,t,n,r,void 0,i),r=Jo(),e!==null&&!Tc?(Yo(e,t,i),tl(e,t,i)):(Z&&r&&Wi(t),t.flags|=1,Ec(e,t,n,i),t.child)}function Rc(e,t,n,r,i,a){return ma(t),t.updateQueue=null,n=Ko(t,r,n,i),Go(e),r=Jo(),e!==null&&!Tc?(Yo(e,t,a),tl(e,t,a)):(Z&&r&&Wi(t),t.flags|=1,Ec(e,t,n,a),t.child)}function zc(e,t,n,r,i){if(ma(t),t.stateNode===null){var a=bi,o=n.contextType;typeof o==`object`&&o&&(a=ha(o)),a=new n(r,a),t.memoizedState=a.state!==null&&a.state!==void 0?a.state:null,a.updater=dc,t.stateNode=a,a._reactInternals=t,a=t.stateNode,a.props=r,a.state=t.memoizedState,a.refs={},io(t),o=n.contextType,a.context=typeof o==`object`&&o?ha(o):bi,a.state=t.memoizedState,o=n.getDerivedStateFromProps,typeof o==`function`&&(uc(t,n,o,r),a.state=t.memoizedState),typeof n.getDerivedStateFromProps==`function`||typeof a.getSnapshotBeforeUpdate==`function`||typeof a.UNSAFE_componentWillMount!=`function`&&typeof a.componentWillMount!=`function`||(o=a.state,typeof a.componentWillMount==`function`&&a.componentWillMount(),typeof a.UNSAFE_componentWillMount==`function`&&a.UNSAFE_componentWillMount(),o!==a.state&&dc.enqueueReplaceState(a,a.state,null),po(t,r,a,i),fo(),a.state=t.memoizedState),typeof a.componentDidMount==`function`&&(t.flags|=4194308),r=!0}else if(e===null){a=t.stateNode;var s=t.memoizedProps,c=mc(n,s);a.props=c;var l=a.context,u=n.contextType;o=bi,typeof u==`object`&&u&&(o=ha(u));var d=n.getDerivedStateFromProps;u=typeof d==`function`||typeof a.getSnapshotBeforeUpdate==`function`,s=t.pendingProps!==s,u||typeof a.UNSAFE_componentWillReceiveProps!=`function`&&typeof a.componentWillReceiveProps!=`function`||(s||l!==o)&&pc(t,a,r,o),ro=!1;var f=t.memoizedState;a.state=f,po(t,r,a,i),fo(),l=t.memoizedState,s||f!==l||ro?(typeof d==`function`&&(uc(t,n,d,r),l=t.memoizedState),(c=ro||fc(t,n,c,r,f,l,o))?(u||typeof a.UNSAFE_componentWillMount!=`function`&&typeof a.componentWillMount!=`function`||(typeof a.componentWillMount==`function`&&a.componentWillMount(),typeof a.UNSAFE_componentWillMount==`function`&&a.UNSAFE_componentWillMount()),typeof a.componentDidMount==`function`&&(t.flags|=4194308)):(typeof a.componentDidMount==`function`&&(t.flags|=4194308),t.memoizedProps=r,t.memoizedState=l),a.props=r,a.state=l,a.context=o,r=c):(typeof a.componentDidMount==`function`&&(t.flags|=4194308),r=!1)}else{a=t.stateNode,ao(e,t),o=t.memoizedProps,u=mc(n,o),a.props=u,d=t.pendingProps,f=a.context,l=n.contextType,c=bi,typeof l==`object`&&l&&(c=ha(l)),s=n.getDerivedStateFromProps,(l=typeof s==`function`||typeof a.getSnapshotBeforeUpdate==`function`)||typeof a.UNSAFE_componentWillReceiveProps!=`function`&&typeof a.componentWillReceiveProps!=`function`||(o!==d||f!==c)&&pc(t,a,r,c),ro=!1,f=t.memoizedState,a.state=f,po(t,r,a,i),fo();var p=t.memoizedState;o!==d||f!==p||ro||e!==null&&e.dependencies!==null&&pa(e.dependencies)?(typeof s==`function`&&(uc(t,n,s,r),p=t.memoizedState),(u=ro||fc(t,n,u,r,f,p,c)||e!==null&&e.dependencies!==null&&pa(e.dependencies))?(l||typeof a.UNSAFE_componentWillUpdate!=`function`&&typeof a.componentWillUpdate!=`function`||(typeof a.componentWillUpdate==`function`&&a.componentWillUpdate(r,p,c),typeof a.UNSAFE_componentWillUpdate==`function`&&a.UNSAFE_componentWillUpdate(r,p,c)),typeof a.componentDidUpdate==`function`&&(t.flags|=4),typeof a.getSnapshotBeforeUpdate==`function`&&(t.flags|=1024)):(typeof a.componentDidUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),typeof a.getSnapshotBeforeUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),t.memoizedProps=r,t.memoizedState=p),a.props=r,a.state=p,a.context=c,r=u):(typeof a.componentDidUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),typeof a.getSnapshotBeforeUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),r=!1)}return a=r,Ic(e,t),r=!!(t.flags&128),a||r?(a=t.stateNode,n=r&&typeof n.getDerivedStateFromError!=`function`?null:a.render(),t.flags|=1,e!==null&&r?(t.child=to(t,e.child,null,i),t.child=to(t,null,n,i)):Ec(e,t,n,i),t.memoizedState=a.state,e=t.child):e=tl(e,t,i),e}function Bc(e,t,n,r){return na(),t.flags|=256,Ec(e,t,n,r),t.child}var Vc={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Hc(e){return{baseLanes:e,cachePool:Ra()}}function Uc(e,t,n){return e=e===null?0:e.childLanes&~n,t&&(e|=sd),e}function Wc(e,t,n){var r=t.pendingProps,i=!1,a=!!(t.flags&128),o;if((o=a)||(o=e!==null&&e.memoizedState===null?!1:!!(Oo.current&2)),o&&(i=!0,t.flags&=-129),o=!!(t.flags&32),t.flags&=-33,e===null){if(Z){if(i?Co(t):Eo(),(e=Ji)?(e=om(e,Xi),e=e!==null&&e.data!==`&`?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:zi===null?null:{id:Bi,overflow:Vi},retryLane:536870912,hydrationErrors:null},n=ki(e),n.return=t,t.child=n,qi=t,Ji=null)):e=null,e===null)throw Qi(t);return t.lanes=cm(e)?32:536870912,null}return a=r.children,r=r.fallback,i?(Eo(),i=t.mode,a=Kc({mode:`hidden`,children:a},i),r=Di(r,i,n,null),a.return=t,r.return=t,a.sibling=r,t.child=a,r=t.child,r.memoizedState=Hc(n),r.childLanes=Uc(e,o,n),t.memoizedState=Vc,jc(null,r)):(Co(t),Gc(t,a))}var s=e.memoizedState;if(s!==null){var c=s.dehydrated;if(c!==null)return Jc(e,t,a,o,r,c,s,n)}return i?(Eo(),i=r.fallback,a=t.mode,s=e.child,c=s.sibling,r=wi(s,{mode:`hidden`,children:r.children}),r.subtreeFlags=s.subtreeFlags&1206910976,c===null?(i=Di(i,a,n,null),i.flags|=2):i=wi(c,i),i.return=t,r.return=t,r.sibling=i,t.child=r,jc(null,r),r=t.child,i=e.child.memoizedState,i===null?i=Hc(n):(a=i.cachePool,a===null?a=Ra():(s=xa._currentValue,a=a.parent===s?a:{parent:s,pool:s}),i={baseLanes:i.baseLanes|n,cachePool:a}),r.memoizedState=i,r.childLanes=Uc(e,o,n),t.memoizedState=Vc,jc(e.child,r)):(Co(t),n=e.child,e=n.sibling,n=wi(n,{mode:`visible`,children:r.children}),n.return=t,n.sibling=null,e!==null&&(o=t.deletions,o===null?(t.deletions=[e],t.flags|=16):o.push(e)),t.child=n,t.memoizedState=null,n)}function Gc(e,t){return t=Kc({mode:`visible`,children:t},e.mode),t.return=e,e.child=t}function Kc(e,t){return e=Si(22,e,null,t),e.lanes=0,e}function qc(e,t,n){return to(t,e.child,null,n),e=Gc(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function Jc(e,t,n,r,a,o,s,c){if(n)return t.flags&256?(Co(t),t.flags&=-257,qc(e,t,c)):t.memoizedState===null?(Eo(),o=a.fallback,s=t.mode,a=Kc({mode:`visible`,children:a.children},s),o=Di(o,s,c,null),o.flags|=2,a.return=t,o.return=t,a.sibling=o,t.child=a,to(t,e.child,null,c),a=t.child,a.memoizedState=Hc(c),a.childLanes=Uc(e,r,c),t.memoizedState=Vc,jc(null,a)):(Eo(),t.child=e.child,t.flags|=128,null);if(Co(t),cm(o)){if(r=o.nextSibling&&o.nextSibling.dataset,r)var l=r.dgst;return r=l,r!==``&&(a=Error(i(419)),a.stack=``,a.digest=r,ia({value:a,source:null,stack:null})),qc(e,t,c)}if(Tc||fa(e,t,c,!1),r=(c&e.childLanes)!==0,Tc||r){if(go.current!==null)return qc(e,t,c);if(r=Yu,r!==null&&(a=ut(r,c),a!==0&&a!==s.retryLane))throw s.retryLane=a,_i(e,a),Md(r,e,a),wc;return sm(o)||Wd(),qc(e,t,c)}return sm(o)?(t.flags|=192,t.child=e.child,null):(e=s.treeContext,Ji=um(o.nextSibling),qi=t,Z=!0,Yi=null,Xi=!1,e!==null&&Ki(t,e),t=Gc(t,a.children),t.flags|=134221824,t)}function Yc(e,t,n){e.lanes|=t;var r=e.alternate;r!==null&&(r.lanes|=t),ua(e.return,t,n)}function Xc(e){for(var t=null;e!==null;){var n=e.alternate;n!==null&&jo(n)===null&&(t=e),e=e.sibling}return t}function Zc(e,t,n,r,i,a){var o=e.memoizedState;o===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:i,treeForkCount:a}:(o.isBackwards=t,o.rendering=null,o.renderingStartTime=0,o.last=r,o.tail=n,o.tailMode=i,o.treeForkCount=a)}function Qc(e){var t=e.child;for(e.child=null;t!==null;){var n=t.sibling;t.sibling=e.child,e.child=t,t=n}}function $c(e,t,n){var r=t.pendingProps,i=r.revealOrder,a=r.tail;r=r.children;var o=Oo.current;if(t.flags&128)return ko(t,o),null;var s=!!(o&2);if(s?(o=o&1|2,t.flags|=128):o&=1,ko(t,o),i===`backwards`&&e!==null?(Qc(e),Ec(e,t,r,n),Qc(e)):Ec(e,t,r,n),r=Z?Ii:0,!s&&e!==null&&e.flags&128)a:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Yc(e,n,t);else if(e.tag===19)Yc(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break a;for(;e.sibling===null;){if(e.return===null||e.return===t)break a;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(i){case`backwards`:n=Xc(t.child),n===null?(i=t.child,t.child=null):(i=n.sibling,n.sibling=null,Qc(t)),Zc(t,!0,i,null,a,r);break;case`unstable_legacy-backwards`:for(n=null,i=t.child,t.child=null;i!==null;){if(e=i.alternate,e!==null&&jo(e)===null){t.child=i;break}e=i.sibling,i.sibling=n,n=i,i=e}Zc(t,!0,n,null,a,r);break;case`together`:Zc(t,!1,null,null,void 0,r);break;case`independent`:t.memoizedState=null;break;default:n=Xc(t.child),n===null?(i=t.child,t.child=null):(i=n.sibling,n.sibling=null),Zc(t,!1,i,n,a,r)}return t.child}function el(e,t,n){var r=t.pendingProps;return ca(t,t.type,r.value),Ec(e,t,r.children,n),t.child}function tl(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),id|=t.lanes,(n&t.childLanes)===0){if(e!==null){if(fa(e,t,n,!1),(n&t.childLanes)===0)return null}else return null}if(e!==null&&t.child!==e.child)throw Error(i(153));if(t.child!==null){for(e=t.child,n=wi(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=wi(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function nl(e,t){return(e.lanes&t)!==0||(e=e.dependencies,!!(e!==null&&pa(e)))}function rl(e,t,n){switch(t.tag){case 3:be(t,t.stateNode.containerInfo),ca(t,xa,e.memoizedState.cache),na();break;case 27:case 5:Se(t);break;case 4:be(t,t.stateNode.containerInfo);break;case 10:ca(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,wo(t),null;break;case 13:var r=t.memoizedState;if(r!==null){if(r.dehydrated!==null)return Co(t),t.flags|=128,null;r=fa(e,t,n,!1);var i=t.child.childLanes;return r||(n&i)!==0?Wc(e,t,n):(Co(t),e=tl(e,t,n),e===null?null:e.sibling)}Co(t);break;case 19:if(t.flags&128)return $c(e,t,n);if(i=!!(e.flags&128),r=(n&t.childLanes)!==0,r||=(fa(e,t,n,!1),(n&t.childLanes)!==0),i){if(r)return $c(e,t,n);t.flags|=128}if(i=t.memoizedState,i!==null&&(i.rendering=null,i.tail=null,i.lastEffect=null),ko(t,Oo.current),r)break;return null;case 22:return t.lanes=0,Ac(e,t,n,t.pendingProps);case 24:ca(t,xa,e.memoizedState.cache)}return tl(e,t,n)}function il(e,t,n){if(e!==null){if(e.memoizedProps!==t.pendingProps)Tc=!0;else{if(!nl(e,n)&&!(t.flags&128))return Tc=!1,rl(e,t,n);Tc=!!(e.flags&131072)}}else Tc=!1,Z&&t.flags&1048576&&Ui(t,Ii,t.index);switch(t.lanes=0,t.tag){case 16:a:{var r=t.pendingProps;if(e=Ga(t.elementType),t.type=e,typeof e==`function`)Ci(e)?(r=mc(e,r),t.tag=1,t=zc(null,t,e,r,n)):(t.tag=0,t=Lc(null,t,e,r,n));else{if(e!=null){var a=e.$$typeof;if(a===F){t.tag=11,t=Dc(null,t,e,r,n);break a}if(a===z){t.tag=14,t=Oc(null,t,e,r,n);break a}if(a===P){t.tag=10,t.type=e,t=el(null,t,n);break a}}throw t=le(e)||e,Error(i(306,t,``))}}return t;case 0:return Lc(e,t,t.type,t.pendingProps,n);case 1:return r=t.type,a=mc(r,t.pendingProps),zc(e,t,r,a,n);case 3:a:{if(be(t,t.stateNode.containerInfo),e===null)throw Error(i(387));r=t.pendingProps;var o=t.memoizedState;a=o.element,ao(e,t),po(t,r,null,n);var s=t.memoizedState;if(r=s.cache,ca(t,xa,r),r!==o.cache&&da(t,[xa],n,!0),fo(),r=s.element,o.isDehydrated){if(o={element:r,isDehydrated:!1,cache:s.cache},t.updateQueue.baseState=o,t.memoizedState=o,t.flags&256){t=Bc(e,t,r,n);break a}if(r!==a){a=Mi(Error(i(424)),t),ia(a),t=Bc(e,t,r,n);break a}switch(e=t.stateNode.containerInfo,e.nodeType){case 9:e=e.body;break;default:e=e.nodeName===`HTML`?e.ownerDocument.body:e}for(Ji=um(e.firstChild),qi=t,Z=!0,Yi=null,Xi=!0,n=no(t,null,r,n),t.child=n;n;)n.flags=n.flags&-3|134221824,n=n.sibling}else{if(na(),r===a){t=tl(e,t,n);break a}Ec(e,t,r,n)}t=t.child}return t;case 26:return Ic(e,t),e===null?(n=Pm(t.type,null,t.pendingProps,null))?t.memoizedState=n:Z||(t.stateNode=pp(t.type,t.pendingProps,ve.current,t)):t.memoizedState=Pm(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return Se(t),e===null&&Z&&(r=t.stateNode=gm(t.type,t.pendingProps,ve.current),qi=t,Xi=!0,a=Ji,Cp(t.type)?(dm=a,Ji=um(r.firstChild)):Ji=a),Ec(e,t,t.pendingProps.children,n),Ic(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&Z&&((a=r=Ji)&&(r=im(r,t.type,t.pendingProps,Xi),r===null?a=!1:(t.stateNode=r,qi=t,Ji=um(r.firstChild),Xi=!1,a=!0)),a||Qi(t)),Se(t),a=t.type,o=t.pendingProps,s=e===null?null:e.memoizedProps,r=o.children,mp(a,o)?r=null:s!==null&&mp(a,s)&&(t.flags|=32),t.memoizedState!==null&&(a=Wo(e,t,qo,null,null,n),ch._currentValue=a),Ic(e,t),Ec(e,t,r,n),t.child;case 6:return e===null&&Z&&((e=n=Ji)&&(n=am(n,t.pendingProps,Xi),n===null?e=!1:(t.stateNode=n,qi=t,Ji=null,e=!0)),e||Qi(t)),null;case 13:return Wc(e,t,n);case 4:return be(t,t.stateNode.containerInfo),r=t.pendingProps,e===null?t.child=to(t,null,r,n):Ec(e,t,r,n),t.child;case 11:return Dc(e,t,t.type,t.pendingProps,n);case 7:return r=t.pendingProps,Ic(e,t),Ec(e,t,r,n),t.child;case 8:return Ec(e,t,t.pendingProps.children,n),t.child;case 12:return Ec(e,t,t.pendingProps.children,n),t.child;case 10:return el(e,t,n);case 9:return a=t.type._context,r=t.pendingProps.children,ma(t),a=ha(a),r=r(a),t.flags|=1,Ec(e,t,r,n),t.child;case 14:return Oc(e,t,t.type,t.pendingProps,n);case 15:return kc(e,t,t.type,t.pendingProps,n);case 19:return $c(e,t,n);case 31:return Fc(e,t,n);case 22:return Ac(e,t,n,t.pendingProps);case 24:return ma(t),r=ha(xa),e===null?(a=Ia(),a===null&&(a=Yu,o=Sa(),a.pooledCache=o,o.refCount++,o!==null&&(a.pooledCacheLanes|=n),a=o),t.memoizedState={parent:r,cache:a},io(t),ca(t,xa,a)):((e.lanes&n)!==0&&(ao(e,t),po(t,null,null,n),fo()),a=e.memoizedState,o=t.memoizedState,a.parent===r?(r=o.cache,ca(t,xa,r),r!==a.cache&&da(t,[xa],n,!0)):(a={parent:r,cache:r},t.memoizedState=a,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=a),ca(t,xa,r))),Ec(e,t,t.pendingProps.children,n),t.child;case 30:return t.stateNode===null&&(t.stateNode={autoName:null,paired:null,clones:null,ref:null}),r=t.pendingProps,r.name!=null&&r.name!==`auto`?t.flags|=e===null?18882560:18874368:Z&&Wi(t),e!==null&&e.memoizedProps.name!==r.name?t.flags|=4194816:Ic(e,t),Ec(e,t,r.children,n),t.child;case 29:throw t.pendingProps}throw Error(i(156,t.tag))}function al(e){e.flags|=4}function ol(e,t,n,r,i){var a;if((a=!!(e.mode&32))&&(a=n===null?Ym(t,r):Ym(t,r)&&(r.src!==n.src||r.srcSet!==n.srcSet)),a){if(e.flags|=16777216,(i&335544128)===i){if(e.stateNode.complete)e.flags|=8192;else if(Vd())e.flags|=8192;else throw Ka=Ha,Ba}}else e.flags&=-16777217}function sl(e,t){if(t.type!==`stylesheet`||t.state.loading&4)e.flags&=-16777217;else if(e.flags|=16777216,!Xm(t)){if(Vd())e.flags|=8192;else throw Ka=Ha,Ba}}function cl(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag===22?536870912:it(),e.lanes|=t,cd|=t)}function ll(e,t){if(!Z)switch(e.tailMode){case`visible`:break;case`collapsed`:for(var n=e.tail,r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:r.sibling=null;break;default:for(t=e.tail,n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null}}function ul(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,r=0;if(t)for(var i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags&1206910976,r|=i.flags&1206910976,i.return=e,i=i.sibling;else for(i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags,r|=i.flags,i.return=e,i=i.sibling;return e.subtreeFlags|=r,e.childLanes=n,t}function dl(e,t,n){var r=t.pendingProps;switch(Gi(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return ul(t),null;case 1:return ul(t),null;case 3:return n=t.stateNode,r=null,e!==null&&(r=e.memoizedState.cache),t.memoizedState.cache!==r&&(t.flags|=2048),la(xa),xe(),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),(e===null||e.child===null)&&(ta(t)?al(t):e===null||e.memoizedState.isDehydrated&&!(t.flags&256)||(t.flags|=1024,ra())),ul(t),null;case 26:var a=t.type,o=t.memoizedState;return e===null?(al(t),o===null?(ul(t),ol(t,a,null,r,n)):(ul(t),sl(t,o))):o?o===e.memoizedState?(ul(t),t.flags&=-16777217):(al(t),ul(t),sl(t,o)):(e=e.memoizedProps,e!==r&&al(t),ul(t),ol(t,a,e,r,n)),null;case 27:if(Ce(t),n=ve.current,a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==r&&al(t);else{if(!r){if(t.stateNode===null)throw Error(i(166));return ul(t),t.subtreeFlags&=-33554433,null}e=ge.current,ta(t)?$i(t,e):(e=gm(a,r,n),t.stateNode=e,al(t))}return ul(t),t.subtreeFlags&=-33554433,null;case 5:if(Ce(t),a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==r&&al(t);else{if(!r){if(t.stateNode===null)throw Error(i(166));return ul(t),t.subtreeFlags&=-33554433,null}if(o=ge.current,ta(t))$i(t,o);else{var s=up(ve.current);switch(o){case 1:o=s.createElementNS(`http://www.w3.org/2000/svg`,a);break;case 2:o=s.createElementNS(`http://www.w3.org/1998/Math/MathML`,a);break;default:switch(a){case`svg`:o=s.createElementNS(`http://www.w3.org/2000/svg`,a);break;case`math`:o=s.createElementNS(`http://www.w3.org/1998/Math/MathML`,a);break;case`script`:o=s.createElement(`div`),o.innerHTML=`<script><\/script>`,o=o.removeChild(o.firstChild);break;case`select`:o=typeof r.is==`string`?s.createElement(`select`,{is:r.is}):s.createElement(`select`),r.multiple?o.multiple=!0:r.size&&(o.size=r.size);break;default:o=typeof r.is==`string`?s.createElement(a,{is:r.is}):s.createElement(a)}}o[K]=t,o[q]=r;a:for(s=t.child;s!==null;){if(s.tag===5||s.tag===6)o.appendChild(s.stateNode);else if(s.tag!==4&&s.tag!==27&&s.child!==null){s.child.return=s,s=s.child;continue}if(s===t)break a;for(;s.sibling===null;){if(s.return===null||s.return===t)break a;s=s.return}s.sibling.return=s.return,s=s.sibling}t.stateNode=o;a:switch(rp(o,a,r),a){case`button`:case`input`:case`select`:case`textarea`:r=!!r.autoFocus;break a;case`img`:r=!0;break a;default:r=!1}r&&al(t)}}return ul(t),t.subtreeFlags&=-33554433,ol(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,n),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==r&&al(t);else{if(typeof r!=`string`&&t.stateNode===null)throw Error(i(166));if(e=ve.current,ta(t)){if(e=t.stateNode,n=t.memoizedProps,r=null,a=qi,a!==null)switch(a.tag){case 27:case 5:r=a.memoizedProps}e[K]=t,e=!!(e.nodeValue===n||r!==null&&!0===r.suppressHydrationWarning||ep(e.nodeValue,n)),e||Qi(t,!0)}else e=up(e).createTextNode(r),e[K]=t,t.stateNode=e}return ul(t),null;case 31:if(n=t.memoizedState,e===null||e.memoizedState!==null){if(r=ta(t),n!==null){if(e===null){if(!r)throw Error(i(318));if(e=t.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(i(557));e[K]=t}else na(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;ul(t),e=!1}else n=ra(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=n),e=!0;if(!e)return t.flags&256?(Do(t),t):(Do(t),null);if(t.flags&128)throw Error(i(558))}return ul(t),null;case 13:if(r=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(a=ta(t),r!==null&&r.dehydrated!==null){if(e===null){if(!a)throw Error(i(318));if(a=t.memoizedState,a=a===null?null:a.dehydrated,!a)throw Error(i(317));a[K]=t}else na(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;ul(t),a=!1}else a=ra(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=a),a=!0;if(!a)return t.flags&256?(Do(t),t):(Do(t),null)}return Do(t),t.flags&128?(t.lanes=n,t):(n=r!==null,e=e!==null&&e.memoizedState!==null,n&&(r=t.child,a=null,r.alternate!==null&&r.alternate.memoizedState!==null&&r.alternate.memoizedState.cachePool!==null&&(a=r.alternate.memoizedState.cachePool.pool),o=null,r.memoizedState!==null&&r.memoizedState.cachePool!==null&&(o=r.memoizedState.cachePool.pool),o!==a&&(r.flags|=2048)),n!==e&&n&&(t.child.flags|=8192),cl(t,t.updateQueue),ul(t),null);case 4:return xe(),e===null&&Wf(t.stateNode.containerInfo),t.flags|=67108864,ul(t),null;case 10:return la(t.type),ul(t),null;case 19:if(Ao(t),r=t.memoizedState,r===null)return ul(t),null;if(a=!!(t.flags&128),o=r.rendering,o===null){if(a)ll(r,!1);else{if(rd!==0||e!==null&&e.flags&128)for(e=t.child;e!==null;){if(o=jo(e),o!==null){for(t.flags|=128,ll(r,!1),e=o.updateQueue,t.updateQueue=e,cl(t,e),t.subtreeFlags=0,e=n,n=t.child;n!==null;)Ti(n,e),n=n.sibling;return ko(t,Oo.current&1|2),Z&&Hi(t,r.treeForkCount),t.child}e=e.sibling}r.tail!==null&&Ie()>md&&(t.flags|=128,a=!0,ll(r,!1),t.lanes=4194304)}}else{if(!a){if(e=jo(o),e!==null){if(t.flags|=128,a=!0,e=e.updateQueue,t.updateQueue=e,cl(t,e),ll(r,!0),r.tail===null&&r.tailMode!==`collapsed`&&r.tailMode!==`visible`&&!o.alternate&&!Z)return ul(t),null}else 2*Ie()-r.renderingStartTime>md&&n!==536870912&&(t.flags|=128,a=!0,ll(r,!1),t.lanes=4194304)}r.isBackwards?(o.sibling=t.child,t.child=o):(e=r.last,e===null?t.child=o:e.sibling=o,r.last=o)}if(r.tail!==null){e=r.tail;a:{for(n=e;n!==null;){if(n.alternate!==null){n=!1;break a}n=n.sibling}n=!0}return r.rendering=e,r.tail=e.sibling,r.renderingStartTime=Ie(),e.sibling=null,o=Oo.current,o=a?o&1|2:o&1,r.tailMode===`visible`||r.tailMode===`collapsed`||!n||Z?ko(t,o):(n=o,he(xo,t),he(Oo,n),So===null&&(So=t)),Z&&Hi(t,r.treeForkCount),e}return ul(t),null;case 22:case 23:return Do(t),bo(),r=t.memoizedState!==null,e===null?r&&(t.flags|=8192):e.memoizedState!==null!==r&&(t.flags|=8192),r?n&536870912&&!(t.flags&128)&&(ul(t),t.subtreeFlags&6&&(t.flags|=8192)):ul(t),n=t.updateQueue,n!==null&&cl(t,n.retryQueue),n=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),r=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(r=t.memoizedState.cachePool.pool),r!==n&&(t.flags|=2048),e!==null&&me(Fa),null;case 24:return n=null,e!==null&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),la(xa),ul(t),null;case 25:return null;case 30:return t.flags|=33554432,ul(t),null}throw Error(i(156,t.tag))}function fl(e,t){switch(Gi(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return la(xa),xe(),e=t.flags,e&65536&&!(e&128)?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return Ce(t),null;case 31:if(t.memoizedState!==null){if(Do(t),t.alternate===null)throw Error(i(340));na()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(Do(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(i(340));na()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return Ao(t),e=t.flags,e&65536?(t.flags=e&-65537|128,e=t.memoizedState,e!==null&&(e.rendering=null,e.tail=null),t.flags|=4,t):null;case 4:return xe(),null;case 10:return la(t.type),null;case 22:case 23:return Do(t),bo(),e!==null&&me(Fa),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return la(xa),null;case 25:return null;default:return null}}function pl(e,t){switch(Gi(t),t.tag){case 3:la(xa),xe();break;case 26:case 27:case 5:Ce(t);break;case 4:xe();break;case 31:t.memoizedState!==null&&Do(t);break;case 13:Do(t);break;case 19:Ao(t);break;case 10:la(t.type);break;case 22:case 23:Do(t),bo(),e!==null&&me(Fa);break;case 24:la(xa)}}function ml(e,t){try{var n=t.updateQueue,r=n===null?null:n.lastEffect;if(r!==null){var i=r.next;n=i;do{if((n.tag&e)===e){r=void 0;var a=n.create,o=n.inst;r=a(),o.destroy=r}n=n.next}while(n!==i)}}catch(e){ff(t,t.return,e)}}function hl(e,t,n){try{var r=t.updateQueue,i=r===null?null:r.lastEffect;if(i!==null){var a=i.next;r=a;do{if((r.tag&e)===e){var o=r.inst,s=o.destroy;if(s!==void 0){o.destroy=void 0,i=t;var c=n,l=s;try{l()}catch(e){ff(i,c,e)}}}r=r.next}while(r!==a)}}catch(e){ff(t,t.return,e)}}function gl(e){var t=e.updateQueue;if(t!==null){var n=e.stateNode;try{ho(t,n)}catch(t){ff(e,e.return,t)}}}function _l(e,t,n){n.props=mc(e.type,e.memoizedProps),n.state=e.memoizedState;try{n.componentWillUnmount()}catch(n){ff(e,t,n)}}function vl(e,t){try{var n=e.ref;if(n!==null){switch(e.tag){case 26:case 27:case 5:var r=e.stateNode;break;case 30:var i=e.stateNode,a=si(e.memoizedProps,i);(i.ref===null||i.ref.name!==a)&&(i.ref=Fp(a)),r=i.ref;break;case 7:if(e.stateNode===null){var o=new Ip(e);m(e.child,!1,$p,o,void 0,void 0),e.stateNode=o}r=e.stateNode;break;default:r=e.stateNode}typeof n==`function`?e.refCleanup=n(r):n.current=r}}catch(n){ff(e,t,n)}}function yl(e,t){var n=e.ref,r=e.refCleanup;if(n!==null){if(typeof r==`function`)try{r()}catch(n){ff(e,t,n)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof n==`function`)try{n(null)}catch(n){ff(e,t,n)}else n.current=null}}function bl(e,t){if((e.tag===5||e.tag===27||e.tag===6)&&e.alternate===null&&t!==null)for(var n=0;n<t.length;n++)tm(e.stateNode,t[n])}function xl(e){for(var t=e.return;t!==null&&(wl(t)&&tm(e.stateNode,t.stateNode),!Cl(t));)t=t.return}function Sl(e){for(var t=e.return;t!==null&&(wl(t)&&nm(e.stateNode,t.stateNode),!Cl(t));)t=t.return}function Cl(e){return e.tag===5||e.tag===3||e.tag===27}function wl(e){return e&&e.tag===7&&e.stateNode!==null}function Tl(e){var t=e.type,n=e.memoizedProps,r=e.stateNode;try{a:switch(t){case`button`:case`input`:case`select`:case`textarea`:n.autoFocus&&r.focus();break a;case`img`:n.src?r.src=n.src:n.srcSet&&(r.srcset=n.srcSet)}}catch(t){ff(e,e.return,t)}}function El(e,t,n){try{var r=e.stateNode;ap(r,e.type,n,t),r[q]=t}catch(t){ff(e,e.return,t)}}function Dl(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&Cp(e.type)||e.tag===4}function Ol(e){a:for(;;){for(;e.sibling===null;){if(e.return===null||Dl(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&Cp(e.type)||e.flags&2||e.child===null||e.tag===4)continue a;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function kl(e,t,n,r){var i=e.tag;if(i===5||i===6)i=e.stateNode,t?(n.nodeType===9?n.body:n.nodeName===`HTML`?n.ownerDocument.body:n).insertBefore(i,t):(t=n.nodeType===9?n.body:n.nodeName===`HTML`?n.ownerDocument.body:n,t.appendChild(i),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=cn)),bl(e,r),It=!0;else if(i!==4&&(i===27&&(bl(e,r),r=null,Cp(e.type)&&(n=e.stateNode,t=null)),e=e.child,e!==null))for(kl(e,t,n,r),e=e.sibling;e!==null;)kl(e,t,n,r),e=e.sibling}function Al(e,t,n,r){var i=e.tag;if(i===5||i===6)i=e.stateNode,t?n.insertBefore(i,t):n.appendChild(i),bl(e,r),It=!0;else if(i!==4&&(i===27&&(bl(e,r),r=null,Cp(e.type)&&(n=e.stateNode)),e=e.child,e!==null))for(Al(e,t,n,r),e=e.sibling;e!==null;)Al(e,t,n,r),e=e.sibling}function jl(e){var t=e.stateNode,n=e.memoizedProps;try{for(var r=e.type,i=t.attributes;i.length;)t.removeAttributeNode(i[0]);rp(t,r,n),t[K]=e,t[q]=n}catch(t){ff(e,e.return,t)}}var Ml=!1,Nl=null;function Pl(e){(e.tag===30||e.subtreeFlags&33554432)&&(Ml=!0)}var Fl=null;function Il(){var e=Fl;return Fl=null,e}var Ll=0;function Rl(e,t,n,r,i){return Ll=0,zl(e.child,t,n,r,i)}function zl(e,t,n,r,i){for(var a=!1;e!==null;){if(e.tag===5){var o=e.stateNode;if(r!==null){var s=kp(o);r.push(s),s.view&&(a=!0)}else a||kp(o).view&&(a=!0);Ml=!0,Ep(o,Ll===0?t:t+`_`+Ll,n),Ll++}else(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&i||zl(e.child,t,n,r,i)&&(a=!0));e=e.sibling}return a}function Bl(e,t){for(;e!==null;)e.tag===5?Dp(e.stateNode,e.memoizedProps):(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&t||Bl(e.child,t)),e=e.sibling}function Vl(e){if(e.subtreeFlags&18874368)for(e=e.child;e!==null;){if((e.tag!==22||e.memoizedState===null)&&(Vl(e),e.tag===30&&e.flags&18874368&&e.stateNode.paired)){var t=e.memoizedProps;if(t.name==null||t.name===`auto`)throw Error(i(544));var n=t.name;t=li(t.default,t.share),t!==`none`&&(Rl(e,n,t,null,!1)||Bl(e.child,!1))}e=e.sibling}}function Hl(e,t){if(e.tag===30){var n=e.stateNode,r=e.memoizedProps,i=si(r,n),a=li(r.default,n.paired?r.share:r.enter);a===`none`?Vl(e):Rl(e,i,a,null,!1)?(Vl(e),n.paired||t||jd(e,r.onEnter)):Bl(e.child,!1)}else if(e.subtreeFlags&33554432)for(e=e.child;e!==null;)Hl(e,t),e=e.sibling;else Vl(e)}function Ul(e){if(Nl!==null&&Nl.size!==0){var t=Nl;if(e.subtreeFlags&18874368)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&e.flags&18874368){var n=e.memoizedProps,r=n.name;if(r!=null&&r!==`auto`){var i=t.get(r);if(i!==void 0){var a=li(n.default,n.share);if(a!==`none`&&(Rl(e,r,a,null,!1)?(a=e.stateNode,i.paired=a,a.paired=i,jd(e,n.onShare)):Bl(e.child,!1)),t.delete(r),t.size===0)break}}}Ul(e)}e=e.sibling}}}function Wl(e){if(e.tag===30){var t=e.memoizedProps,n=si(t,e.stateNode),r=Nl===null?void 0:Nl.get(n),i=li(t.default,r===void 0?t.exit:t.share);i!==`none`&&(Rl(e,n,i,null,!1)?r===void 0?jd(e,t.onExit):(i=e.stateNode,r.paired=i,i.paired=r,Nl.delete(n),jd(e,t.onShare)):Bl(e.child,!1)),Nl!==null&&Ul(e)}else if(e.subtreeFlags&33554432)for(e=e.child;e!==null;)Wl(e),e=e.sibling;else Nl!==null&&Ul(e)}function Gl(e){for(e=e.child;e!==null;){if(e.tag===30){var t=e.memoizedProps,n=si(t,e.stateNode);t=li(t.default,t.update),e.flags&=-5,t!==`none`&&Rl(e,n,t,e.memoizedState=[],!1)}else e.subtreeFlags&33554432&&Gl(e);e=e.sibling}}function Kl(e){if(e.subtreeFlags&18874368)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&e.flags&18874368){var t=e.stateNode;t.paired!==null&&(t.paired=null,Bl(e.child,!1))}Kl(e)}e=e.sibling}}function ql(e){if(e.tag===30)e.stateNode.paired=null,Bl(e.child,!1),Kl(e);else if(e.subtreeFlags&33554432)for(e=e.child;e!==null;)ql(e),e=e.sibling;else Kl(e)}function Jl(e){for(e=e.child;e!==null;)e.tag===30?Bl(e.child,!1):e.subtreeFlags&33554432&&Jl(e),e=e.sibling}function Yl(e,t,n,r,i,a,o){for(var s=!1;t!==null;){if(t.tag===5){var c=t.stateNode;if(a!==null&&Ll<a.length){var l=a[Ll],u=kp(c);(l.view||u.view)&&(s=!0);var d;if(d=!(e.flags&4)){if(u.clip)d=!0;else{d=l.rect;var f=u.rect;d=d.y!==f.y||d.x!==f.x||d.height!==f.height||d.width!==f.width}}d&&(e.flags|=4),u.abs?u=!l.abs:(l=l.rect,u=u.rect,u=l.height!==u.height||l.width!==u.width),u&&(e.flags|=32)}else e.flags|=32;e.flags&4&&Ep(c,Ll===0?n:n+`_`+Ll,i),s&&e.flags&4||(Fl===null&&(Fl=[]),Fl.push(c,Ll===0?r:r+`_`+Ll,t.memoizedProps)),Ll++}else(t.tag!==22||t.memoizedState===null)&&(t.tag===30&&o?e.flags|=t.flags&32:Yl(e,t.child,n,r,i,a,o)&&(s=!0));t=t.sibling}return s}function Xl(e,t){for(e=e.child;e!==null;){if(e.tag===30){var n=e.memoizedProps,r=e.stateNode,i=si(n,r),a=li(n.default,n.update);if(t){r=r.clones;var o=r===null?null:r.map(Ap)}else o=e.memoizedState,e.memoizedState=null;r=e;var s=e.child;Ll=0,i=Yl(r,s,i,i,a,o,!1),e.flags&4&&i&&(t||jd(e,n.onUpdate))}else e.subtreeFlags&33554432&&Xl(e,t);e=e.sibling}}var Zl=!1,Ql=!1,$l=!1,eu=!1,tu=typeof WeakSet==`function`?WeakSet:Set,nu=null,ru=!1,iu=!1,au=!1,ou=!1;function su(e,t,n){if(e=e.containerInfo,cp=_h,e=Lr(e),Rr(e)){if(`selectionStart`in e)var r={start:e.selectionStart,end:e.selectionEnd};else a:{r=(r=e.ownerDocument)&&r.defaultView||window;var i=r.getSelection&&r.getSelection();if(i&&i.rangeCount!==0){r=i.anchorNode;var a=i.anchorOffset,o=i.focusNode;i=i.focusOffset;try{r.nodeType,o.nodeType}catch{r=null;break a}var s=0,c=-1,l=-1,u=0,d=0,f=e,p=null;b:for(;;){for(var m;f!==r||a!==0&&f.nodeType!==3||(c=s+a),f!==o||i!==0&&f.nodeType!==3||(l=s+i),f.nodeType===3&&(s+=f.nodeValue.length),(m=f.firstChild)!==null;)p=f,f=m;for(;;){if(f===e)break b;if(p===r&&++u===a&&(c=s),p===o&&++d===i&&(l=s),(m=f.nextSibling)!==null)break;f=p,p=f.parentNode}f=m}r=c===-1||l===-1?null:{start:c,end:l}}else r=null}r||={start:0,end:0}}else r=null;for(lp={focusedElem:e,selectionRange:r},_h=!1,n=(n&335544064)===n,nu=t,t=n?9270:1024;nu!==null;){if(e=nu,n&&(r=e.deletions,r!==null))for(a=0;a<r.length;a++)n&&Wl(r[a]);if(e.alternate===null&&e.flags&2)n&&Pl(e),cu(n);else{if(e.tag===22){if(r=e.alternate,e.memoizedState!==null){r!==null&&r.memoizedState===null&&n&&Wl(r),cu(n);continue}if(r!==null&&r.memoizedState!==null){n&&Pl(e),cu(n);continue}}r=e.child,(e.subtreeFlags&t)!==0&&r!==null?(r.return=e,nu=r):(n&&Gl(e),cu(n))}}Nl=null}function cu(e){for(;nu!==null;){var t=nu,n=e,r=t.alternate,a=t.flags;switch(t.tag){case 0:case 11:case 15:break;case 1:if(a&1024&&r!==null){n=void 0,a=r.memoizedProps,r=r.memoizedState;var o=t.stateNode;try{var s=mc(t.type,a);n=o.getSnapshotBeforeUpdate(s,r),o.__reactInternalSnapshotBeforeUpdate=n}catch(e){ff(t,t.return,e)}}break;case 3:if(a&1024){if(r=t.stateNode.containerInfo,n=r.nodeType,n===9)rm(r);else if(n===1)switch(r.nodeName){case`HEAD`:case`HTML`:case`BODY`:rm(r);break;default:r.textContent=``}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;case 30:n&&r!==null&&(n=si(r.memoizedProps,r.stateNode),a=t.memoizedProps,a=li(a.default,a.update),a!==`none`&&Rl(r,n,a,r.memoizedState=[],!0));break;default:if(a&1024)throw Error(i(163))}if(r=t.sibling,r!==null){r.return=t.return,nu=r;break}nu=t.return}}function lu(e,t,n){var r=n.flags;switch(n.tag){case 0:case 11:case 15:ku(e,n),r&4&&ml(5,n);break;case 1:if(ku(e,n),r&4){if(e=n.stateNode,t===null)try{e.componentDidMount()}catch(e){ff(n,n.return,e)}else{var i=mc(n.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(i,t,e.__reactInternalSnapshotBeforeUpdate)}catch(e){ff(n,n.return,e)}}}r&64&&gl(n),r&512&&vl(n,n.return);break;case 3:if(ku(e,n),r&64&&(e=n.updateQueue,e!==null)){if(t=null,n.child!==null)switch(n.child.tag){case 27:case 5:t=n.child.stateNode;break;case 1:t=n.child.stateNode}try{ho(e,t)}catch(e){ff(n,n.return,e)}}break;case 27:t===null&&r&4&&jl(n);case 26:case 5:ku(e,n),t===null&&r&4&&Tl(n),r&512&&vl(n,n.return);break;case 12:ku(e,n);break;case 31:ku(e,n),r&4&&vu(e,n);break;case 13:ku(e,n),r&4&&yu(e,n),r&64&&(e=n.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(n=gf.bind(null,n),lm(e,n))));break;case 22:if(r=n.memoizedState!==null||Zl,!r){var a=t!==null&&t.memoizedState!==null||Ql;t=Zl,i=Ql,Zl=r,(Ql=a)&&!i?(r=2,n.subtreeFlags&8772&&(r|=1),ju(e,n,r)):ku(e,n),Zl=t,Ql=i}break;case 30:ku(e,n),r&512&&vl(n,n.return);break;case 7:r&512&&vl(n,n.return);default:ku(e,n)}}function uu(e,t){for(e=e.child;e!==null;)du(e,t),e=e.sibling}function du(e,t){switch(e.tag){case 5:case 26:try{var n=e.stateNode;if(t){var r=n.style;typeof r.setProperty==`function`?r.setProperty(`display`,`none`,`important`):r.display=`none`}else{var i=e.stateNode,a=e.memoizedProps.style,o=a!=null&&a.hasOwnProperty(`display`)?a.display:null;i.style.display=o==null||typeof o==`boolean`?``:(``+o).trim()}}catch(t){ff(e,e.return,t)}fu(e,t);break;case 6:try{e.stateNode.nodeValue=t?``:e.memoizedProps,It=!0}catch(t){ff(e,e.return,t)}break;case 18:try{var s=e.stateNode;t?Tp(s,!0):Tp(e.stateNode,!1)}catch(t){ff(e,e.return,t)}break;case 22:case 23:e.memoizedState===null&&uu(e,t);break;default:uu(e,t)}}function fu(e,t){if(e.subtreeFlags&67108864)for(e=e.child;e!==null;){a:{var n=e,r=t;switch(n.tag){case 4:du(n,r);break a;case 22:n.memoizedState===null&&fu(n,r);break a;default:fu(n,r)}}e=e.sibling}}function pu(e){var t=e.alternate;t!==null&&(e.alternate=null,pu(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&St(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var mu=null,hu=!1;function gu(e,t,n){for(n=n.child;n!==null;)_u(e,t,n),n=n.sibling}function _u(e,t,n){if(W&&typeof W.onCommitFiberUnmount==`function`)try{W.onCommitFiberUnmount(Ge,n)}catch{}switch(n.tag){case 26:Ql||yl(n,t),gu(e,t,n),n.memoizedState?n.memoizedState.count--:n.stateNode&&!Ql&&(n=n.stateNode,n.parentNode.removeChild(n));break;case 27:Ql||yl(n,t),Sl(n);var r=mu,i=hu;Cp(n.type)&&(mu=n.stateNode,hu=!1),gu(e,t,n),_m(n.stateNode,n.type,n.memoizedProps),mu=r,hu=i;break;case 5:Ql||yl(n,t),Sl(n);case 6:if(n.tag===6&&Sl(n),r=mu,i=hu,mu=null,gu(e,t,n),mu=r,hu=i,mu!==null){if(hu)try{(mu.nodeType===9?mu.body:mu.nodeName===`HTML`?mu.ownerDocument.body:mu).removeChild(n.stateNode),It=!0}catch(e){ff(n,t,e)}else try{mu.removeChild(n.stateNode),It=!0}catch(e){ff(n,t,e)}}break;case 18:mu!==null&&(hu?(e=mu,wp(e.nodeType===9?e.body:e.nodeName===`HTML`?e.ownerDocument.body:e,n.stateNode),Uh(e)):wp(mu,n.stateNode));break;case 4:r=mu,i=hu,mu=n.stateNode.containerInfo,hu=!0,gu(e,t,n),mu=r,hu=i;break;case 0:case 11:case 14:case 15:hl(2,n,t),Ql||hl(4,n,t),gu(e,t,n);break;case 1:Ql||(yl(n,t),r=n.stateNode,typeof r.componentWillUnmount==`function`&&_l(n,t,r)),gu(e,t,n);break;case 21:gu(e,t,n);break;case 22:Ql=(r=Ql)||n.memoizedState!==null,gu(e,t,n),Ql=r;break;case 30:yl(n,t),gu(e,t,n);break;case 7:Ql||yl(n,t),gu(e,t,n);break;default:gu(e,t,n)}}function vu(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{Uh(e)}catch(e){ff(t,t.return,e)}}}function yu(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{Uh(e)}catch(e){ff(t,t.return,e)}}function bu(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new tu),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new tu),t;default:throw Error(i(435,e.tag))}}function xu(e,t){var n=bu(e);t.forEach(function(t){if(!n.has(t)){n.add(t);var r=_f.bind(null,e,t);t.then(r,r)}})}function Su(e,t,n){var r=t.deletions;if(r!==null)for(var a=0;a<r.length;a++){var o=r[a],s=e,c=t,l=c;a:for(;l!==null;){switch(l.tag){case 27:if(Cp(l.type)){mu=l.stateNode,hu=!1;break a}break;case 5:mu=l.stateNode,hu=!1;break a;case 3:case 4:mu=l.stateNode.containerInfo,hu=!0;break a}l=l.return}if(mu===null)throw Error(i(160));_u(s,c,o),mu=null,hu=!1,s=o.alternate,s!==null&&(s.return=null),o.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)wu(t,e,n),t=t.sibling}var Cu=null;function wu(e,t,n){var r=e.alternate,a=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(a&4&&(r=e.updateQueue,r=r===null?null:r.events,r!==null))for(var o=0;o<r.length;o++){var s=r[o];s.ref.impl=s.nextImpl}Su(t,e,n),Tu(e),a&4&&(hl(3,e,e.return),ml(3,e),hl(5,e,e.return));break;case 1:Su(t,e,n),Tu(e),a&512&&(Ql||r===null||yl(r,r.return)),a&64&&Zl&&(e=e.updateQueue,e!==null&&(t=e.callbacks,t!==null&&(n=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=n===null?t:n.concat(t))));break;case 26:if(o=Cu,Su(t,e,n),Tu(e),a&512&&(Ql||r===null||yl(r,r.return)),a&4){if(a=r===null?null:r.memoizedState,n=e.memoizedState,r===null){if(n===null){if(e.stateNode===null){if(Zl)e.stateNode=pp(e.type,e.memoizedProps,t.containerInfo,e);else{a:{t=e.type,n=e.memoizedProps,a=o.ownerDocument||o;b:switch(t){case`title`:r=a.getElementsByTagName(`title`)[0],(!r||r[bt]||r[K]||r.namespaceURI===`http://www.w3.org/2000/svg`||r.hasAttribute(`itemprop`))&&(r=a.createElement(t),a.head.insertBefore(r,a.querySelector(`head > title`))),rp(r,t,n),r[K]=e,Y(r),t=r;break a;case`link`:if(o=Km(`link`,`href`,a).get(t+(n.href||``))){for(s=0;s<o.length;s++)if(r=o[s],r.getAttribute(`href`)===(n.href==null||n.href===``?null:n.href)&&r.getAttribute(`rel`)===(n.rel==null?null:n.rel)&&r.getAttribute(`title`)===(n.title==null?null:n.title)&&r.getAttribute(`crossorigin`)===(n.crossOrigin==null?null:n.crossOrigin)){o.splice(s,1);break b}}r=a.createElement(t),rp(r,t,n),a.head.appendChild(r);break;case`meta`:if(o=Km(`meta`,`content`,a).get(t+(n.content||``))){for(s=0;s<o.length;s++)if(r=o[s],r.getAttribute(`content`)===(n.content==null?null:``+n.content)&&r.getAttribute(`name`)===(n.name==null?null:n.name)&&r.getAttribute(`property`)===(n.property==null?null:n.property)&&r.getAttribute(`http-equiv`)===(n.httpEquiv==null?null:n.httpEquiv)&&r.getAttribute(`charset`)===(n.charSet==null?null:n.charSet)){o.splice(s,1);break b}}r=a.createElement(t),rp(r,t,n),a.head.appendChild(r);break;default:throw Error(i(468,t))}r[K]=e,Y(r),t=r}e.stateNode=t}}else Zl||qm(o,e.type,e.stateNode)}else e.stateNode=Vm(o,n,e.memoizedProps)}else a===n?n===null&&e.stateNode!==null&&El(e,e.memoizedProps,r.memoizedProps):(a===null?(t=r.stateNode,t===null||Ql||t.parentNode.removeChild(t)):a.count--,n===null?Zl||qm(o,e.type,e.stateNode):Vm(o,n,e.memoizedProps))}break;case 27:Su(t,e,n),Tu(e),a&512&&(Ql||r===null||yl(r,r.return)),r!==null&&a&4&&El(e,e.memoizedProps,r.memoizedProps);break;case 5:if(o=$l,$l=!1,Su(t,e,n),$l=o,Tu(e),a&512&&(Ql||r===null||yl(r,r.return)),e.flags&32){t=e.stateNode;try{$t(t,``),It=!0}catch(t){ff(e,e.return,t)}}a&4&&e.stateNode!=null&&(t=e.memoizedProps,El(e,t,r===null?t:r.memoizedProps)),a&1024&&(eu=!0);break;case 6:if(Su(t,e,n),Tu(e),a&4){if(e.stateNode===null)throw Error(i(162));t=e.memoizedProps,n=e.stateNode;try{n.nodeValue=t,It=!0}catch(t){ff(e,e.return,t)}}break;case 3:if(It=!1,Gm=null,o=Cu,Cu=xm(t.containerInfo),Su(t,e,n),Cu=o,Tu(e),a&4&&r!==null&&r.memoizedState.isDehydrated)try{Uh(t.containerInfo)}catch(t){ff(e,e.return,t)}eu&&(eu=!1,Eu(e)),It=!1;break;case 4:a=$l,$l=Zl,r=Lt(),o=Cu,Cu=xm(e.stateNode.containerInfo),Su(t,e,n),Tu(e),Cu=o,It&&iu&&(au=!0),It=r,$l=a;break;case 12:Su(t,e,n),Tu(e);break;case 31:Su(t,e,n),Tu(e),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,xu(e,t)));break;case 13:Su(t,e,n),Tu(e),e.child.flags&8192&&e.memoizedState!==null!=(r!==null&&r.memoizedState!==null)&&(fd=Ie()),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,xu(e,t)));break;case 22:o=e.memoizedState!==null,s=r!==null&&r.memoizedState!==null;var c=Zl,l=Ql,u=$l;Zl=c||o,$l=u||o,Ql=l||s,Su(t,e,n),Ql=l,$l=u,Zl=c,Tu(e),a&8192&&(t=e.stateNode,t._visibility=o?t._visibility&-2:t._visibility|1,!o||r===null||s||Zl||Ql||(t=s||Ql,n=Zl,r=Ql,Zl=o||Zl,Ql=t,Au(e,2),Zl=n,Ql=r),!o&&$l||uu(e,o)),a&4&&(t=e.updateQueue,t!==null&&(n=t.retryQueue,n!==null&&(t.retryQueue=null,xu(e,n))));break;case 19:Su(t,e,n),Tu(e),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,xu(e,t)));break;case 30:a&512&&(Ql||r===null||yl(r,r.return)),a=Lt(),o=iu,s=(n&335544064)===n,c=e.memoizedProps,iu=s&&li(c.default,c.update)!==`none`,Su(t,e,n),Tu(e),s&&r!==null&&It&&(e.flags|=4),iu=o,It=a;break;case 21:break;case 7:a&512&&(Ql||r===null||yl(r,r.return)),r&&r.stateNode!==null&&(r.stateNode._fragmentFiber=e);default:Su(t,e,n),Tu(e)}}function Tu(e){var t=e.flags;if(t&2){try{for(var n,r=e.return;r!==null;){if(Dl(r)){n=r;break}r=r.return}r=null;for(var a=e.return;a!==null;){if(wl(a)){var o=a.stateNode;r===null?r=[o]:r.push(o)}if(Cl(a))break;a=a.return}var s=r;if(n==null)throw Error(i(160));switch(n.tag){case 27:var c=n.stateNode;Al(e,Ol(e),c,s);break;case 5:var l=n.stateNode;n.flags&32&&($t(l,``),n.flags&=-33),Al(e,Ol(e),l,s);break;case 3:case 4:var u=n.stateNode.containerInfo;kl(e,Ol(e),u,s);break;default:throw Error(i(161))}}catch(t){ff(e,e.return,t)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function Eu(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;Eu(t),t.tag===5&&t.flags&1024&&(t=t.stateNode,_h=!0,t.reset(),_h=!1),e=e.sibling}}function Du(e,t){if(t.subtreeFlags&9270)for(t=t.child;t!==null;)Ou(t,e),t=t.sibling;else Xl(t,!1)}function Ou(e,t){var n=e.alternate;if(n===null)Hl(e,!1);else switch(e.tag){case 3:if(ou=ru=!1,Il(),Du(t,e),!ru&&!au){if(e=Fl,e!==null)for(var r=0;r<e.length;r+=3){n=e[r];var i=e[r+1];Dp(n,e[r+2]),n=n.ownerDocument.documentElement,n!==null&&n.animate({opacity:[0,0],pointerEvents:[`none`,`none`]},{duration:0,fill:`forwards`,pseudoElement:`::view-transition-group(`+i+`)`})}e=t.containerInfo,e=e.nodeType===9?e.documentElement:e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName===``&&(e.style.viewTransitionName=`none`,e.animate({opacity:[0,0],pointerEvents:[`none`,`none`]},{duration:0,fill:`forwards`,pseudoElement:`::view-transition-group(root)`}),e.animate({width:[0,0],height:[0,0]},{duration:0,fill:`forwards`,pseudoElement:`::view-transition`})),ou=!0}Fl=null;break;case 5:Du(t,e);break;case 4:r=ru,ru=!1,Du(t,e),ru&&(au=!0),ru=r;break;case 22:e.memoizedState===null&&(n.memoizedState===null?Du(t,e):Hl(e,!1));break;case 30:r=ru,i=Il(),ru=!1,Du(t,e),ru&&(e.flags|=4);var a=e.memoizedProps,o=e.stateNode;t=si(a,o),o=si(n.memoizedProps,o);var s=li(a.default,a.update);s===`none`?t=!1:(a=n.memoizedState,n.memoizedState=null,n=e.child,Ll=0,t=Yl(e,n,t,o,s,a,!0),Ll!==(a===null?0:a.length)&&(e.flags|=32)),e.flags&4&&t?(jd(e,e.memoizedProps.onUpdate),Fl=i):i!==null&&(i.push.apply(i,Fl),Fl=i),ru=e.flags&32?!0:r;break;default:Du(t,e)}}function ku(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)lu(e,t.alternate,t),t=t.sibling}function Au(e,t){for(e=e.child;e!==null;){var n=e,r=t;switch(n.tag){case 0:case 11:case 14:case 15:hl(4,n,n.return),Au(n,r);break;case 1:yl(n,n.return);var i=n.stateNode;typeof i.componentWillUnmount==`function`&&_l(n,n.return,i),Au(n,r);break;case 27:r&2&&_m(n.stateNode,n.type,n.memoizedProps);case 5:yl(n,n.return),n.tag!==5&&n.tag!==27||Sl(n),Au(n,r);break;case 6:Sl(n);break;case 26:yl(n,n.return),i=n.stateNode,n.memoizedState!==null||i===null||Ql||i.parentNode.removeChild(i),Au(n,r);break;case 22:n.memoizedState===null&&Au(n,r);break;case 30:yl(n,n.return),Au(n,r);break;case 7:yl(n,n.return);default:Au(n,r)}e=e.sibling}}function ju(e,t,n){for(n=t.subtreeFlags&8772?n:n&-2,t=t.child;t!==null;){var r=t.alternate,i=e,a=t,o=a.flags,s=!!(n&1);switch(a.tag){case 0:case 11:case 15:ju(i,a,n),ml(4,a);break;case 1:if(ju(i,a,n),r=a,i=r.stateNode,typeof i.componentDidMount==`function`)try{i.componentDidMount()}catch(e){ff(r,r.return,e)}if(r=a,i=r.updateQueue,i!==null){var c=r.stateNode;try{var l=i.shared.hiddenCallbacks;if(l!==null)for(i.shared.hiddenCallbacks=null,i=0;i<l.length;i++)mo(l[i],c)}catch(e){ff(r,r.return,e)}}s&&o&64&&gl(a),vl(a,a.return);break;case 27:n&2&&jl(a);case 5:a.tag!==5&&a.tag!==27||xl(a),ju(i,a,n),s&&r===null&&o&4&&Tl(a),vl(a,a.return);break;case 6:xl(a);break;case 26:c=a.stateNode,a.memoizedState!==null||c===null||Zl||qm(xm(c.ownerDocument),a.type,c),ju(i,a,n),s&&r===null&&o&4&&Tl(a),vl(a,a.return);break;case 12:ju(i,a,n);break;case 31:ju(i,a,n),s&&o&4&&vu(i,a);break;case 13:ju(i,a,n),s&&o&4&&yu(i,a);break;case 22:a.memoizedState===null&&ju(i,a,n),vl(a,a.return);break;case 30:ju(i,a,n),vl(a,a.return);break;case 7:vl(a,a.return);default:ju(i,a,n)}t=t.sibling}}function Mu(e,t){var n=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==n&&(e!=null&&e.refCount++,n!=null&&Ca(n))}function Nu(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&Ca(e))}function Pu(e,t,n,r){var i=(n&335544064)===n;if(t.subtreeFlags&(i?10262:10256))for(t=t.child;t!==null;)Fu(e,t,n,r),t=t.sibling;else i&&Jl(t)}function Fu(e,t,n,r){var i=(n&335544064)===n;i&&t.alternate===null&&t.return!==null&&t.return.alternate!==null&&ql(t);var a=t.flags;switch(t.tag){case 0:case 11:case 15:Pu(e,t,n,r),a&2048&&ml(9,t);break;case 1:Pu(e,t,n,r);break;case 3:Pu(e,t,n,r),i&&ou&&(e=e.containerInfo,e=e.nodeType===9?e.body:e.nodeName===`HTML`?e.ownerDocument.body:e,e.style.viewTransitionName===`root`&&(e.style.viewTransitionName=``),e=e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName===`none`&&(e.style.viewTransitionName=``)),a&2048&&(a=null,t.alternate!==null&&(a=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==a&&(t.refCount++,a!=null&&Ca(a)));break;case 12:if(a&2048){Pu(e,t,n,r),a=t.stateNode;try{var o=t.memoizedProps,s=o.id,c=o.onPostCommit;typeof c==`function`&&c(s,t.alternate===null?`mount`:`update`,a.passiveEffectDuration,-0)}catch(e){ff(t,t.return,e)}}else Pu(e,t,n,r);break;case 31:Pu(e,t,n,r);break;case 13:Pu(e,t,n,r);break;case 23:break;case 22:o=t.stateNode,s=t.alternate,t.memoizedState===null?(i&&s!==null&&s.memoizedState!==null&&ql(t),o._visibility&2?Pu(e,t,n,r):(o._visibility|=2,Iu(e,t,n,r,!!(t.subtreeFlags&10256)||!1))):(i&&s!==null&&s.memoizedState===null&&ql(s),o._visibility&2?Pu(e,t,n,r):Lu(e,t)),a&2048&&Mu(s,t);break;case 24:Pu(e,t,n,r),a&2048&&Nu(t.alternate,t);break;case 30:i&&(a=t.alternate,a!==null&&(Bl(a.child,!0),Bl(t.child,!0))),Pu(e,t,n,r);break;default:Pu(e,t,n,r)}}function Iu(e,t,n,r,i){for(i&&=!!(t.subtreeFlags&10256)||!1,t=t.child;t!==null;){var a=e,o=t,s=n,c=r,l=o.flags;switch(o.tag){case 0:case 11:case 15:Iu(a,o,s,c,i),ml(8,o);break;case 23:break;case 22:var u=o.stateNode;o.memoizedState===null?(u._visibility|=2,Iu(a,o,s,c,i)):u._visibility&2?Iu(a,o,s,c,i):Lu(a,o),i&&l&2048&&Mu(o.alternate,o);break;case 24:Iu(a,o,s,c,i),i&&l&2048&&Nu(o.alternate,o);break;default:Iu(a,o,s,c,i)}t=t.sibling}}function Lu(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var n=e,r=t,i=r.flags;switch(r.tag){case 22:Lu(n,r),i&2048&&Mu(r.alternate,r);break;case 24:Lu(n,r),i&2048&&Nu(r.alternate,r);break;default:Lu(n,r)}t=t.sibling}}var Ru=8192;function zu(e,t,n){if(e.subtreeFlags&Ru)for(e=e.child;e!==null;)Bu(e,t,n),e=e.sibling}function Bu(e,t,n){switch(e.tag){case 26:zu(e,t,n),e.flags&Ru&&(e.memoizedState===null?(e=e.stateNode,(t&335544128)===t&&Qm(n,e)):$m(n,Cu,e.memoizedState,e.memoizedProps));break;case 5:zu(e,t,n),e.flags&Ru&&(e=e.stateNode,(t&335544128)===t&&Qm(n,e));break;case 3:case 4:var r=Cu;Cu=xm(e.stateNode.containerInfo),zu(e,t,n),Cu=r;break;case 22:e.memoizedState===null&&(r=e.alternate,r!==null&&r.memoizedState!==null?(r=Ru,Ru=16777216,zu(e,t,n),Ru=r):zu(e,t,n));break;case 30:if((e.flags&Ru)!==0&&(r=e.memoizedProps.name,r!=null&&r!==`auto`)){var i=e.stateNode;i.paired=null,Nl===null&&(Nl=new Map),Nl.set(r,i)}zu(e,t,n);break;default:zu(e,t,n)}}function Vu(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function Hu(e){var t=e.deletions;if(e.flags&16){if(t!==null)for(var n=0;n<t.length;n++){var r=t[n];nu=r,Gu(r,e)}Vu(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)Uu(e),e=e.sibling}function Uu(e){switch(e.tag){case 0:case 11:case 15:Hu(e),e.flags&2048&&hl(9,e,e.return);break;case 3:Hu(e);break;case 12:Hu(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,Wu(e)):Hu(e);break;default:Hu(e)}}function Wu(e){var t=e.deletions;if(e.flags&16){if(t!==null)for(var n=0;n<t.length;n++){var r=t[n];nu=r,Gu(r,e)}Vu(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:hl(8,t,t.return),Wu(t);break;case 22:n=t.stateNode,n._visibility&2&&(n._visibility&=-3,Wu(t));break;default:Wu(t)}e=e.sibling}}function Gu(e,t){for(;nu!==null;){var n=nu;switch(n.tag){case 0:case 11:case 15:hl(8,n,t);break;case 23:case 22:if(n.memoizedState!==null&&n.memoizedState.cachePool!==null){var r=n.memoizedState.cachePool.pool;r!=null&&r.refCount++}break;case 24:Ca(n.memoizedState.cache)}if(r=n.child,r!==null)r.return=n,nu=r;else a:for(n=e;nu!==null;){r=nu;var i=r.sibling,a=r.return;if(pu(r),r===n){nu=null;break a}if(i!==null){i.return=a,nu=i;break a}nu=a}}}var Ku={getCacheForType:function(e){var t=ha(xa),n=t.data.get(e);return n===void 0&&(n=e(),t.data.set(e,n)),n},cacheSignal:function(){return ha(xa).controller.signal}},qu=typeof WeakMap==`function`?WeakMap:Map,Ju=0,Yu=null,$=null,Xu=0,Zu=0,Qu=null,$u=!1,ed=!1,td=!1,nd=0,rd=0,id=0,ad=0,od=0,sd=0,cd=0,ld=null,ud=null,dd=!1,fd=0,pd=0,md=1/0,hd=null,gd=null,_d=0,vd=null,yd=null,bd=0,xd=0,Sd=null,Cd=null,wd=null,Td=null,Ed=null,Dd=0,Od=null;function kd(){return Ju&2&&Xu!==0?Xu&-Xu:H.T===null?pt():Nf()}function Ad(){if(sd===0){if(!(Xu&536870912)||Z){var e=Ze;Ze<<=1,!(Ze&3932160)&&(Ze=262144),sd=e}else sd=536870912}return e=xo.current,e!==null&&(e.flags|=32),sd}function jd(e,t){if(t!=null){var n=e.stateNode,r=n.ref;r===null&&(r=n.ref=Fp(si(e.memoizedProps,n))),Td===null&&(Td=[]),Td.push(t.bind(null,r))}}function Md(e,t,n){(e===Yu&&(Zu===2||Zu===9)||e.cancelPendingCommit!==null)&&(zd(e,0),Id(e,Xu,sd,!1)),ot(e,n),(!(Ju&2)||e!==Yu)&&(e===Yu&&(!(Ju&2)&&(ad|=n),rd===4&&Id(e,Xu,sd,!1)),Tf(e))}function Nd(e,t,n){if(Ju&6)throw Error(i(327));var r=!n&&!(t&127)&&(t&e.expiredLanes)===0||tt(e,t),a=r?qd(e,t):Gd(e,t,!0),o=r;do{if(a===0){ed&&!r&&Id(e,t,0,!1);break}if(n=e.current.alternate,o&&!Fd(n))a=Gd(e,t,!1),o=!1;else{if(a===2){if(o=t,e.errorRecoveryDisabledLanes&o)var s=0;else s=e.pendingLanes&-536870913,s=s===0?s&536870912?536870912:0:s;if(s!==0){t=s;a:{var c=e;a=ld;var l=c.current.memoizedState.isDehydrated;if(l&&(zd(c,s).flags|=256),s=Gd(c,s,!1),s!==2&&s!==6){if(td&&!l){c.errorRecoveryDisabledLanes|=o,ad|=o,a=4;break a}o=ud,ud=a,o!==null&&(ud===null?ud=o:ud.push.apply(ud,o))}a=s}if(o=!1,a!==2)continue}}if(a===1){zd(e,0),Id(e,t,0,!0);break}a:{switch(r=e,o=a,o){case 0:case 1:throw Error(i(345));case 4:if((t&4194048)!==t&&(t&62914560)!==t)break;case 6:Id(r,t,sd,!$u);break a;case 2:ud=null;break;case 3:case 5:break;default:throw Error(i(329))}if((t&62914560)===t&&(a=fd+300-Ie(),10<a)){if(Id(r,t,sd,!$u),et(r,0,!0)!==0)break a;bd=t,r.timeoutHandle=_p(Pd.bind(null,r,n,ud,hd,dd,t,sd,ad,cd,$u,o,`Throttled`,-0,0),a);break a}Pd(r,n,ud,hd,dd,t,sd,ad,cd,$u,o,null,-0,0)}break}}while(1);Tf(e)}function Pd(e,t,n,r,i,a,o,s,c,l,u,d,f,p){e.timeoutHandle=-1;var m=t.subtreeFlags,h=(a&335544064)===a;d=null,(h||m&8192||(m&16785408)==16785408)&&(d={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:cn},Nl=null,Bu(t,a,d),h&&(m=d,h=e.containerInfo,h=(h.nodeType===9?h:h.ownerDocument).__reactViewTransition,h!=null&&(m.count++,m.waitingForViewTransition=!0,m=rh.bind(m),h.finished.then(m,m))),m=(a&62914560)===a?fd-Ie():(a&4194048)===a?pd-Ie():0,m=th(d,m),m!==null)?(bd=a,e.cancelPendingCommit=m(ef.bind(null,e,t,a,n,r,i,o,s,c,l,u,d,null,f,p)),Id(e,a,o,!l)):ef(e,t,a,n,r,i,o,s,c,l,u,d)}function Fd(e){for(var t=e;;){var n=t.tag;if((n===0||n===11||n===15)&&t.flags&16384&&(n=t.updateQueue,n!==null&&(n=n.stores,n!==null)))for(var r=0;r<n.length;r++){var i=n[r],a=i.getSnapshot;i=i.value;try{if(!jr(a(),i))return!1}catch{return!1}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function Id(e,t,n,r){t=nt(e,t),t&=~od,t&=~ad,e.suspendedLanes|=t,e.pingedLanes&=~t,r&&(e.warmLanes|=t),r=e.expirationTimes;for(var i=t;0<i;){var a=31-qe(i),o=1<<a;r[a]=-1,i&=~o}n!==0&&ct(e,n,t)}function Ld(){return Ju&6?!0:(Ef(0,!1),!1)}function Rd(){if($!==null){if(Zu===0)var e=$.return;else e=$,sa=oa=null,Xo(e),Ya=null,Xa=0,e=$;for(;e!==null;)pl(e.alternate,e),e=e.return;$=null}}function zd(e,t){var n=e.timeoutHandle;return n!==-1&&(e.timeoutHandle=-1,vp(n)),n=e.cancelPendingCommit,n!==null&&(e.cancelPendingCommit=null,n()),bd=0,Rd(),Yu=e,$=n=wi(e.current,null),Xu=t,Zu=0,Qu=null,$u=!1,ed=tt(e,t),td=!1,cd=sd=od=ad=id=rd=0,ud=ld=null,dd=!1,nd=nt(e,t),mi(),n}function Bd(e,t){Q=null,H.H=oc,t===za||t===Va?(t=qa(),Zu=3):t===Ba?(t=qa(),Zu=4):Zu=t===wc?8:typeof t==`object`&&t&&typeof t.then==`function`?6:1,Qu=t,$===null&&(rd=1,vc(e,Mi(t,e.current)))}function Vd(){var e=xo.current;return e===null?!0:(Xu&4194048)===Xu?So===null:(Xu&62914560)===Xu||Xu&536870912?e===So:!1}function Hd(){var e=H.H;return H.H=oc,e===null?oc:e}function Ud(){var e=H.A;return H.A=Ku,e}function Wd(){rd=4,$u||(Xu&4194048)!==Xu&&xo.current!==null||(ed=!0),!(id&134217727)&&!(ad&134217727)||Yu===null||Id(Yu,Xu,sd,!1)}function Gd(e,t,n){var r=Ju;Ju|=2;var i=Hd(),a=Ud();(Yu!==e||Xu!==t)&&(hd=null,zd(e,t)),t=!1;var o=rd;a:do try{if(Zu!==0&&$!==null){var s=$,c=Qu;switch(Zu){case 8:Rd(),o=6;break a;case 3:case 2:case 9:case 6:xo.current===null&&(t=!0);var l=Zu;if(Zu=0,Qu=null,Zd(e,s,c,l),n&&ed){o=0;break a}break;default:l=Zu,Zu=0,Qu=null,Zd(e,s,c,l)}}Kd(),o=rd;break}catch(t){Bd(e,t)}while(1);return t&&e.shellSuspendCounter++,sa=oa=null,Ju=r,H.H=i,H.A=a,$===null&&(Yu=null,Xu=0,mi()),o}function Kd(){for(;$!==null;)Yd($)}function qd(e,t){var n=Ju;Ju|=2;var r=Hd(),a=Ud();Yu!==e||Xu!==t?(hd=null,md=Ie()+500,zd(e,t)):ed=tt(e,t);a:do try{if(Zu!==0&&$!==null){t=$;var o=Qu;b:switch(Zu){case 1:Zu=0,Qu=null,Zd(e,t,o,1);break;case 2:case 9:if(Ua(o)){Zu=0,Qu=null,Xd(t);break}t=function(){Zu!==2&&Zu!==9||Yu!==e||(Zu=7),Tf(e)},o.then(t,t);break a;case 3:Zu=7;break a;case 4:Zu=5;break a;case 7:Ua(o)?(Zu=0,Qu=null,Xd(t)):(Zu=0,Qu=null,Zd(e,t,o,7));break;case 5:var s=null;switch($.tag){case 26:s=$.memoizedState;case 5:case 27:var c=$;if(s?Xm(s):c.stateNode.complete){Zu=0,Qu=null;var l=c.sibling;if(l!==null)$=l;else{var u=c.return;u===null?$=null:($=u,Qd(u))}break b}}Zu=0,Qu=null,Zd(e,t,o,5);break;case 6:Zu=0,Qu=null,Zd(e,t,o,6);break;case 8:Rd(),rd=6;break a;default:throw Error(i(462))}}Jd();break}catch(t){Bd(e,t)}while(1);return sa=oa=null,H.H=r,H.A=a,Ju=n,$===null?(Yu=null,Xu=0,mi(),rd):0}function Jd(){for(;$!==null&&!Pe();)Yd($)}function Yd(e){var t=il(e.alternate,e,nd);e.memoizedProps=e.pendingProps,t===null?Qd(e):$=t}function Xd(e){var t=e,n=t.alternate;switch(t.tag){case 15:case 0:t=Rc(n,t,t.pendingProps,t.type,void 0,Xu);break;case 11:t=Rc(n,t,t.pendingProps,t.type.render,t.ref,Xu);break;case 5:Xo(t);var r=t;r===qi&&(Z?(ea(r),r.tag===5&&r.stateNode!=null&&(Ji=r.stateNode)):(ea(r),Z=!0));default:pl(n,t),t=$=Ti(t,nd),t=il(n,t,nd)}e.memoizedProps=e.pendingProps,t===null?Qd(e):$=t}function Zd(e,t,n,r){sa=oa=null,Xo(t),Ya=null,Xa=0;var i=t.return;try{if(Cc(e,i,t,n,Xu)){rd=1,vc(e,Mi(n,e.current)),$=null;return}}catch(t){if(i!==null)throw $=i,t;rd=1,vc(e,Mi(n,e.current)),$=null;return}t.flags&32768?(Z||r===1?e=!0:ed||Xu&536870912?e=!1:($u=e=!0,(r===2||r===9||r===3||r===6)&&(r=xo.current,r!==null&&r.tag===13&&(r.flags|=16384))),$d(t,e)):Qd(t)}function Qd(e){var t=e;do{if(t.flags&32768){$d(t,$u);return}e=t.return;var n=dl(t.alternate,t,nd);if(n!==null){$=n;return}if(t=t.sibling,t!==null){$=t;return}$=t=e}while(t!==null);rd===0&&(rd=5)}function $d(e,t){do{var n=fl(e.alternate,e);if(n!==null){n.flags&=32767,$=n;return}if(n=e.return,n!==null&&(n.flags|=32768,n.subtreeFlags=0,n.deletions=null),!t&&(e=e.sibling,e!==null)){$=e;return}$=e=n}while(e!==null);rd=6,$=null}function ef(e,t,n,r,a,o,s,c,l,u,d,f){e.cancelPendingCommit=null;do lf();while(_d!==0);if(Ju&6)throw Error(i(327));if(t!==null){if(t===e.current)throw Error(i(177));e===Yu&&($=Yu=null,Xu=0),yd=t,vd=e,bd=n,Sd=a,Cd=r,tf(e,t,n,s,c,l,f)}}function tf(e,t,n,r,i,a,o){var s=t.lanes|t.childLanes;if(xd=s,s|=pi,st(e,n,s,r,i,a),Td=null,(n&335544064)===n?(Ed=Ea(e),r=10262):(Ed=null,r=10256),(t.subtreeFlags&r)!==0||(t.flags&r)!==0?(e.callbackNode=null,e.callbackPriority=0,vf(Be,function(){return uf(),null})):(e.callbackNode=null,e.callbackPriority=0),Ml=!1,r=!!(t.flags&13878),t.subtreeFlags&13878||r){r=H.T,H.T=null,i=U.p,U.p=2,a=Ju,Ju|=4;try{su(e,t,n)}finally{Ju=a,U.p=i,H.T=r}}_d=1,Ml?wd=Np(o,e.containerInfo,Ed,af,of,rf,sf,uf,nf,null,null):(af(),of(),sf())}function nf(e){if(_d!==0){var t=vd.onRecoverableError;t(e,{componentStack:null})}}function rf(){_d===3&&(_d=0,Ou(yd,vd),_d=4)}function af(){if(_d===1){_d=0;var e=vd,t=yd,n=bd,r=!!(t.flags&13878);if(t.subtreeFlags&13878||r){r=H.T,H.T=null;var i=U.p;U.p=2;var a=Ju;Ju|=4;try{iu=au=!1,wu(t,e,n),n=lp;var o=Lr(e.containerInfo),s=n.focusedElem,c=n.selectionRange;if(o!==s&&s&&s.ownerDocument&&Ir(s.ownerDocument.documentElement,s)){if(c!==null&&Rr(s)){var l=c.start,u=c.end;if(u===void 0&&(u=l),`selectionStart`in s)s.selectionStart=l,s.selectionEnd=Math.min(u,s.value.length);else{var d=s.ownerDocument||document,f=d&&d.defaultView||window;if(f.getSelection){var p=f.getSelection(),m=s.textContent.length,h=Math.min(c.start,m),g=c.end===void 0?h:Math.min(c.end,m);!p.extend&&h>g&&(o=g,g=h,h=o);var _=Fr(s,h),v=Fr(s,g);if(_&&v&&(p.rangeCount!==1||p.anchorNode!==_.node||p.anchorOffset!==_.offset||p.focusNode!==v.node||p.focusOffset!==v.offset)){var y=d.createRange();y.setStart(_.node,_.offset),p.removeAllRanges(),h>g?(p.addRange(y),p.extend(v.node,v.offset)):(y.setEnd(v.node,v.offset),p.addRange(y))}}}}for(d=[],p=s;p=p.parentNode;)p.nodeType===1&&d.push({element:p,left:p.scrollLeft,top:p.scrollTop});for(typeof s.focus==`function`&&s.focus(),s=0;s<d.length;s++){var b=d[s];b.element.scrollLeft=b.left,b.element.scrollTop=b.top}}_h=!!cp,lp=cp=null}finally{Ju=a,U.p=i,H.T=r}}e.current=t,_d=2}}function of(){if(_d===2){_d=0;var e=vd,t=yd,n=!!(t.flags&8772);if(t.subtreeFlags&8772||n){n=H.T,H.T=null;var r=U.p;U.p=2;var i=Ju;Ju|=4;try{lu(e,t.alternate,t)}finally{Ju=i,U.p=r,H.T=n}}_d=3}}function sf(){if(_d===4||_d===3){_d=0;var e=wd;wd=null,Fe();var t=vd,n=yd,r=bd,i=Cd,a=(r&335544064)===r?10262:10256;if((n.subtreeFlags&a)!==0||(n.flags&a)!==0?_d=5:(_d=0,yd=vd=null,cf(t,t.pendingLanes)),a=t.pendingLanes,a===0&&(gd=null),ft(r),n=n.stateNode,W&&typeof W.onCommitFiberRoot==`function`)try{W.onCommitFiberRoot(Ge,n,void 0,(n.current.flags&128)==128)}catch{}if(i!==null){n=H.T,a=U.p,U.p=2,H.T=null;try{for(var o=t.onRecoverableError,s=0;s<i.length;s++){var c=i[s];o(c.value,{componentStack:c.stack})}}finally{H.T=n,U.p=a}}if(i=Td,o=Ed,Ed=null,i!==null&&(Td=null,o===null&&(o=[]),e!==null))for(c=0;c<i.length;c++)n=(0,i[c])(o),n!==void 0&&e.finished.finally(n);bd&3&&lf(),Tf(t),a=t.pendingLanes,r&261930&&a&42?t===Od?Dd++:(Dd=0,Od=t):(Dd=0,Od=null),Ef(0,!1)}}function cf(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,Ca(t)))}function lf(){return wd!==null&&(wd.skipTransition(),wd=null),af(),of(),sf(),uf()}function uf(){if(_d!==5)return!1;var e=vd,t=xd;xd=0;var n=ft(bd),r=H.T,a=U.p;try{U.p=32>n?32:n,H.T=null,n=Sd,Sd=null;var o=vd,s=bd;if(_d=0,yd=vd=null,bd=0,Ju&6)throw Error(i(331));var c=Ju;if(Ju|=4,Uu(o.current),Fu(o,o.current,s,n),Ju=c,Ef(0,!1),W&&typeof W.onPostCommitFiberRoot==`function`)try{W.onPostCommitFiberRoot(Ge,o)}catch{}return!0}finally{U.p=a,H.T=r,cf(e,t)}}function df(e,t,n){t=Mi(n,t),t=bc(e.stateNode,t,2),e=so(e,t,2),e!==null&&(ot(e,2),Tf(e))}function ff(e,t,n){if(e.tag===3)df(e,e,n);else for(;t!==null;){if(t.tag===3){df(t,e,n);break}if(t.tag===1){var r=t.stateNode;if(typeof t.type.getDerivedStateFromError==`function`||typeof r.componentDidCatch==`function`&&(gd===null||!gd.has(r))){e=Mi(n,e),n=xc(2),r=so(t,n,2),r!==null&&(Sc(n,r,t,e),ot(r,2),Tf(r));break}}t=t.return}}function pf(e,t,n){var r=e.pingCache;if(r===null){r=e.pingCache=new qu;var i=new Set;r.set(t,i)}else i=r.get(t),i===void 0&&(i=new Set,r.set(t,i));i.has(n)||(td=!0,i.add(n),e=mf.bind(null,e,t,n),t.then(e,e))}function mf(e,t,n){var r=e.pingCache;r!==null&&r.delete(t),e.pingedLanes|=e.suspendedLanes&n,e.warmLanes&=~n,Yu===e&&(Xu&n)===n&&(rd===4||rd===3&&(Xu&62914560)===Xu&&300>Ie()-fd?Ju&2?od|=n:zd(e,0):od|=n,cd===Xu&&(cd=0)),Tf(e)}function hf(e,t){t===0&&(t=it()),e=_i(e,t),e!==null&&(ot(e,t),Tf(e))}function gf(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),hf(e,n)}function _f(e,t){var n=0;switch(e.tag){case 31:case 13:var r=e.stateNode,a=e.memoizedState;a!==null&&(n=a.retryLane);break;case 19:r=e.stateNode;break;case 22:r=e.stateNode._retryCache;break;default:throw Error(i(314))}r!==null&&r.delete(t),hf(e,n)}function vf(e,t){return Me(e,t)}var yf=null,bf=null,xf=!1,Sf=!1,Cf=!1,wf=0;function Tf(e){e!==bf&&e.next===null&&(bf===null?yf=bf=e:bf=bf.next=e),Sf=!0,xf||(xf=!0,Mf())}function Ef(e,t){if(!Cf&&Sf){Cf=!0;do for(var n=!1,r=yf;r!==null;){if(!t){if(e!==0){var i=r.pendingLanes;if(i===0)var a=0;else{var o=r.suspendedLanes,s=r.pingedLanes;a=(1<<31-qe(42|e)+1)-1,a&=i&~(o&~s),a=a&201326741?a&201326741|1:a?a|2:0}a!==0&&(n=!0,jf(r,a))}else a=Xu,a=et(r,r===Yu?a:0,r.cancelPendingCommit!==null||r.timeoutHandle!==-1),!(a&3)||tt(r,a)||(n=!0,jf(r,a))}r=r.next}while(n);Cf=!1}}function Df(){Of()}function Of(){Sf=xf=!1;var e=0;wf!==0&&gp()&&(e=wf);for(var t=Ie(),n=null,r=yf;r!==null;){var i=r.next,a=kf(r,t);a===0?(r.next=null,n===null?yf=i:n.next=i,i===null&&(bf=n)):(n=r,(e!==0||a&3)&&(Sf=!0)),r=i}_d!==0&&_d!==5||Ef(e,!1),wf!==0&&(wf=0)}function kf(e,t){for(var n=e.suspendedLanes,r=e.pingedLanes,i=e.expirationTimes,a=e.pendingLanes&-62914561;0<a;){var o=31-qe(a),s=1<<o,c=i[o];c===-1?((s&n)===0||(s&r)!==0)&&(i[o]=rt(s,t)):c<=t&&(e.expiredLanes|=s),a&=~s}if(t=Yu,n=Xu,n=et(e,e===t?n:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),r=e.callbackNode,n===0||e===t&&(Zu===2||Zu===9)||e.cancelPendingCommit!==null)return r!==null&&r!==null&&Ne(r),e.callbackNode=null,e.callbackPriority=0;if(!(n&3)||tt(e,n)){if(t=n&-n,t===e.callbackPriority)return t;switch(r!==null&&Ne(r),ft(n)){case 2:case 8:n=ze;break;case 32:n=Be;break;case 268435456:n=He;break;default:n=Be}return r=Af.bind(null,e),n=Me(n,r),e.callbackPriority=t,e.callbackNode=n,t}return r!==null&&r!==null&&Ne(r),e.callbackPriority=2,e.callbackNode=null,2}function Af(e,t){if(_d!==0&&_d!==5)return e.callbackNode=null,e.callbackPriority=0,null;var n=e.callbackNode;if(lf()&&e.callbackNode!==n)return null;var r=Xu;return r=et(e,e===Yu?r:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),r===0?null:(Nd(e,r,t),kf(e,Ie()),e.callbackNode!=null&&e.callbackNode===n?Af.bind(null,e):null)}function jf(e,t){if(lf())return null;Nd(e,t,!0)}function Mf(){xp(function(){Ju&6?Me(Re,Df):Of()})}function Nf(){if(wf===0){var e=ka;e===0&&(e=Xe,Xe<<=1,!(Xe&261888)&&(Xe=256)),wf=e}return wf}function Pf(e){return e==null||typeof e==`symbol`||typeof e==`boolean`?null:typeof e==`function`?e:sn(e)}function Ff(e,t,n,r,i){if(t===`submit`&&n&&n.stateNode===i){var a=Pf((i[q]||null).action),o=r.submitter;o&&(t=(t=o[q]||null)?Pf(t.formAction):o.getAttribute(`formAction`),t!==null&&(a=t,o=null));var s=new kn(`action`,`action`,null,r,i);e.push({event:s,listeners:[{instance:null,listener:function(){if(r.defaultPrevented){if(wf!==0){var e=new FormData(i,o);Ks(n,{pending:!0,data:e,method:i.method,action:a},null,e)}}else typeof a==`function`&&(s.preventDefault(),e=new FormData(i,o),Ks(n,{pending:!0,data:e,method:i.method,action:a},a,e))},currentTarget:i}]})}}for(var If=0;If<ii.length;If++){var Lf=ii[If];ai(Lf.toLowerCase(),`on`+(Lf[0].toUpperCase()+Lf.slice(1)))}ai(Xr,`onAnimationEnd`),ai(Zr,`onAnimationIteration`),ai(Qr,`onAnimationStart`),ai(`dblclick`,`onDoubleClick`),ai(`focusin`,`onFocus`),ai(`focusout`,`onBlur`),ai($r,`onTransitionRun`),ai(ei,`onTransitionStart`),ai(ti,`onTransitionCancel`),ai(ni,`onTransitionEnd`),jt(`onMouseEnter`,[`mouseout`,`mouseover`]),jt(`onMouseLeave`,[`mouseout`,`mouseover`]),jt(`onPointerEnter`,[`pointerout`,`pointerover`]),jt(`onPointerLeave`,[`pointerout`,`pointerover`]),At(`onChange`,`change click focusin focusout input keydown keyup selectionchange`.split(` `)),At(`onSelect`,`focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange`.split(` `)),At(`onBeforeInput`,[`compositionend`,`keypress`,`textInput`,`paste`]),At(`onCompositionEnd`,`compositionend focusout keydown keypress keyup mousedown`.split(` `)),At(`onCompositionStart`,`compositionstart focusout keydown keypress keyup mousedown`.split(` `)),At(`onCompositionUpdate`,`compositionupdate focusout keydown keypress keyup mousedown`.split(` `));var Rf=`abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting`.split(` `),zf=new Set(`beforetoggle cancel close invalid load scroll scrollend toggle`.split(` `).concat(Rf));function Bf(e,t){t=!!(t&4);for(var n=0;n<e.length;n++){var r=e[n],i=r.event;r=r.listeners;a:{var a=void 0;if(t)for(var o=r.length-1;0<=o;o--){var s=r[o],c=s.instance,l=s.currentTarget;if(s=s.listener,c!==a&&i.isPropagationStopped())break a;a=s,i.currentTarget=l;try{a(i)}catch(e){ui(e)}i.currentTarget=null,a=c}else for(o=0;o<r.length;o++){if(s=r[o],c=s.instance,l=s.currentTarget,s=s.listener,c!==a&&i.isPropagationStopped())break a;a=s,i.currentTarget=l;try{a(i)}catch(e){ui(e)}i.currentTarget=null,a=c}}}}function Vf(e,t){var n=t[_t];n===void 0&&(n=t[_t]=new Set);var r=e+`__bubble`;n.has(r)||(Gf(t,e,2,!1),n.add(r))}function Hf(e,t,n){var r=0;t&&(r|=4),Gf(n,e,r,t)}var Uf=`_reactListening`+Math.random().toString(36).slice(2);function Wf(e){if(!e[Uf]){e[Uf]=!0,Ot.forEach(function(t){t!==`selectionchange`&&(zf.has(t)||Hf(t,!1,e),Hf(t,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[Uf]||(t[Uf]=!0,Hf(`selectionchange`,!1,t))}}function Gf(e,t,n,r){switch(wh(t)){case 2:var i=vh;break;case 8:i=yh;break;default:i=bh}n=i.bind(null,t,n,e),i=void 0,!vn||t!==`touchstart`&&t!==`touchmove`&&t!==`wheel`||(i=!0),r?i===void 0?e.addEventListener(t,n,!0):e.addEventListener(t,n,{capture:!0,passive:i}):i===void 0?e.addEventListener(t,n,!1):e.addEventListener(t,n,{passive:i})}function Kf(e,t,n,r,i){var a=r;if(!(t&1)&&!(t&2)&&r!==null)a:for(;;){if(r===null)return;var s=r.tag;if(s===3||s===4){var c=r.stateNode.containerInfo;if(c===i)break;if(s===4)for(s=r.return;s!==null;){var l=s.tag;if((l===3||l===4)&&s.stateNode.containerInfo===i)return;s=s.return}for(;c!==null;){if(s=Ct(c),s===null)return;if(l=s.tag,l===5||l===6||l===26||l===27){r=a=s;continue a}c=c.parentNode}}r=r.return}hn(function(){var r=a,i=un(n),s=[];a:{var c=ri.get(e);if(c!==void 0){var l=kn,u=e;switch(e){case`keypress`:if(wn(n)===0)break a;case`keydown`:case`keyup`:l=qn;break;case`focusin`:u=`focus`,l=Rn;break;case`focusout`:u=`blur`,l=Rn;break;case`beforeblur`:case`afterblur`:l=Rn;break;case`click`:if(n.button===2)break a;case`auxclick`:case`dblclick`:case`mousedown`:case`mousemove`:case`mouseup`:case`mouseout`:case`mouseover`:case`contextmenu`:l=In;break;case`drag`:case`dragend`:case`dragenter`:case`dragexit`:case`dragleave`:case`dragover`:case`dragstart`:case`drop`:l=Ln;break;case`touchcancel`:case`touchend`:case`touchmove`:case`touchstart`:l=Xn;break;case Xr:case Zr:case Qr:l=zn;break;case ni:l=Zn;break;case`scroll`:case`scrollend`:l=jn;break;case`wheel`:l=Qn;break;case`copy`:case`cut`:case`paste`:l=Bn;break;case`gotpointercapture`:case`lostpointercapture`:case`pointercancel`:case`pointerdown`:case`pointermove`:case`pointerout`:case`pointerover`:case`pointerup`:l=Jn;break;case`submit`:l=Yn;break;case`toggle`:case`beforetoggle`:l=$n}var d=!!(t&4),f=!d&&(e===`scroll`||e===`scrollend`),p=d?c===null?null:c+`Capture`:c;d=[];for(var m=r,h;m!==null;){var g=m;if(h=g.stateNode,g=g.tag,g!==5&&g!==26&&g!==27||h===null||p===null||(g=gn(m,p),g!=null&&d.push(qf(m,g,h))),f)break;m=m.return}0<d.length&&(c=new l(c,u,null,n,i),s.push({event:c,listeners:d}))}}if(!(t&7)){a:{if(l=e===`mouseover`||e===`pointerover`,c=e===`mouseout`||e===`pointerout`,l&&n!==ln&&(u=n.relatedTarget||n.fromElement)&&(Ct(u)||u[gt]))break a;(c||l)&&(u=i.window===i?i:(l=i.ownerDocument)?l.defaultView||l.parentWindow:window,c?(l=n.relatedTarget||n.toElement,c=r,l=l?Ct(l):null,l!==null&&(f=o(l),d=l.tag,l!==f||d!==5&&d!==27&&d!==6)&&(l=null)):(c=null,l=r),c!==l&&(d=In,g=`onMouseLeave`,p=`onMouseEnter`,m=`mouse`,(e===`pointerout`||e===`pointerover`)&&(d=Jn,g=`onPointerLeave`,p=`onPointerEnter`,m=`pointer`),f=c==null?u:Tt(c),h=l==null?u:Tt(l),u=new d(g,m+`leave`,c,n,i),u.target=f,u.relatedTarget=h,g=null,Ct(i)===r&&(d=new d(p,m+`enter`,l,n,i),d.target=h,d.relatedTarget=f,g=d),f=g,d=c&&l?E(c,l,Yf):null,c!==null&&Xf(s,u,c,d,!1),l!==null&&f!==null&&Xf(s,f,l,d,!0)))}a:{if(c=r?Tt(r):window,l=c.nodeName&&c.nodeName.toLowerCase(),l===`select`||l===`input`&&c.type===`file`)var _=yr;else if(pr(c)){if(br)_=kr;else{_=Dr;var v=Er}}else l=c.nodeName,!l||l.toLowerCase()!==`input`||c.type!==`checkbox`&&c.type!==`radio`?r&&rn(r.elementType)&&(_=yr):_=Or;if(_&&=_(e,r)){mr(s,_,n,i);break a}v&&v(e,c,r)}switch(v=r?Tt(r):window,e){case`focusin`:(pr(v)||v.contentEditable===`true`)&&(Br=v,Vr=r,Hr=null);break;case`focusout`:Hr=Vr=Br=null;break;case`mousedown`:Ur=!0;break;case`contextmenu`:case`mouseup`:case`dragend`:Ur=!1,Wr(s,n,i);break;case`selectionchange`:if(zr)break;case`keydown`:case`keyup`:Wr(s,n,i)}var y;if(tr)b:{switch(e){case`compositionstart`:var b=`onCompositionStart`;break b;case`compositionend`:b=`onCompositionEnd`;break b;case`compositionupdate`:b=`onCompositionUpdate`;break b}b=void 0}else lr?sr(e,n)&&(b=`onCompositionEnd`):e===`keydown`&&n.keyCode===229&&(b=`onCompositionStart`);b&&(ir&&n.locale!==`ko`&&(lr||b!==`onCompositionStart`?b===`onCompositionEnd`&&lr&&(y=Cn()):(bn=i,xn=`value`in bn?bn.value:bn.textContent,lr=!0)),v=Jf(r,b),0<v.length&&(b=new Vn(b,e,null,n,i),s.push({event:b,listeners:v}),y?b.data=y:(y=cr(n),y!==null&&(b.data=y)))),(y=rr?ur(e,n):dr(e,n))&&(b=Jf(r,`onBeforeInput`),0<b.length&&(v=new Vn(`onBeforeInput`,`beforeinput`,null,n,i),s.push({event:v,listeners:b}),v.data=y)),Ff(s,e,r,n,i)}Bf(s,t)})}function qf(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Jf(e,t){for(var n=t+`Capture`,r=[];e!==null;){var i=e,a=i.stateNode;if(i=i.tag,i!==5&&i!==26&&i!==27||a===null||(i=gn(e,n),i!=null&&r.unshift(qf(e,i,a)),i=gn(e,t),i!=null&&r.push(qf(e,i,a))),e.tag===3)return r;e=e.return}return[]}function Yf(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function Xf(e,t,n,r,i){for(var a=t._reactName,o=[];n!==null&&n!==r;){var s=n,c=s.alternate,l=s.stateNode;if(s=s.tag,c!==null&&c===r)break;s!==5&&s!==26&&s!==27||l===null||(c=l,i?(l=gn(n,a),l!=null&&o.unshift(qf(n,l,c))):i||(l=gn(n,a),l!=null&&o.push(qf(n,l,c)))),n=n.return}o.length!==0&&e.push({event:t,listeners:o})}var Zf=/\r\n?/g,Qf=/\u0000|\uFFFD/g;function $f(e){return(typeof e==`string`?e:``+e).replace(Zf,`
`).replace(Qf,``)}function ep(e,t){return t=$f(t),$f(e)===t}function tp(e,t,n,r,a,o){switch(n){case`children`:if(typeof r==`string`)t===`body`||t===`textarea`&&r===``||$t(e,r);else if(typeof r==`number`||typeof r==`bigint`)t!==`body`&&$t(e,``+r);else return;break;case`className`:zt(e,`class`,r);break;case`tabIndex`:zt(e,`tabindex`,r);break;case`dir`:case`role`:case`viewBox`:case`width`:case`height`:zt(e,n,r);break;case`style`:nn(e,r,o);return;case`data`:if(t!==`object`){zt(e,`data`,r);break}case`src`:case`href`:if(r===``&&(t!==`a`||n!==`href`)||r==null||typeof r==`function`||typeof r==`symbol`||typeof r==`boolean`){e.removeAttribute(n);break}r=sn(r),e.setAttribute(n,r);break;case`action`:case`formAction`:if(typeof r==`function`){e.setAttribute(n,`javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')`);break}if(typeof o==`function`&&(n===`formAction`?(t!==`input`&&tp(e,t,`name`,a.name,a,null),tp(e,t,`formEncType`,a.formEncType,a,null),tp(e,t,`formMethod`,a.formMethod,a,null),tp(e,t,`formTarget`,a.formTarget,a,null)):(tp(e,t,`encType`,a.encType,a,null),tp(e,t,`method`,a.method,a,null),tp(e,t,`target`,a.target,a,null))),r==null||typeof r==`symbol`||typeof r==`boolean`){e.removeAttribute(n);break}r=sn(r),e.setAttribute(n,r);break;case`onClick`:r!=null&&(e.onclick=cn);return;case`onScroll`:r!=null&&Vf(`scroll`,e);return;case`onScrollEnd`:r!=null&&Vf(`scrollend`,e);return;case`dangerouslySetInnerHTML`:if(r!=null){if(typeof r!=`object`||!(`__html`in r))throw Error(i(61));if(n=r.__html,n!=null){if(a.children!=null)throw Error(i(60));o?.__html!==n&&(e.innerHTML=n)}}break;case`multiple`:e.multiple=r&&typeof r!=`function`&&typeof r!=`symbol`;break;case`muted`:e.muted=r&&typeof r!=`function`&&typeof r!=`symbol`;break;case`suppressContentEditableWarning`:case`suppressHydrationWarning`:case`defaultValue`:case`defaultChecked`:case`innerHTML`:case`ref`:break;case`autoFocus`:break;case`xlinkHref`:if(r==null||typeof r==`function`||typeof r==`boolean`||typeof r==`symbol`){e.removeAttribute(`xlink:href`);break}n=sn(r),e.setAttributeNS(`http://www.w3.org/1999/xlink`,`xlink:href`,n);break;case`contentEditable`:case`spellCheck`:case`draggable`:case`value`:case`autoReverse`:case`externalResourcesRequired`:case`focusable`:case`preserveAlpha`:r!=null&&typeof r!=`function`&&typeof r!=`symbol`?e.setAttribute(n,r):e.removeAttribute(n);break;case`inert`:case`allowFullScreen`:case`async`:case`autoPlay`:case`controls`:case`credentialless`:case`default`:case`defer`:case`disabled`:case`disablePictureInPicture`:case`disableRemotePlayback`:case`formNoValidate`:case`hidden`:case`loop`:case`noModule`:case`noValidate`:case`open`:case`playsInline`:case`readOnly`:case`required`:case`reversed`:case`scoped`:case`seamless`:case`itemScope`:r&&typeof r!=`function`&&typeof r!=`symbol`?e.setAttribute(n,``):e.removeAttribute(n);break;case`capture`:case`download`:!0===r?e.setAttribute(n,``):!1!==r&&r!=null&&typeof r!=`function`&&typeof r!=`symbol`?e.setAttribute(n,r):e.removeAttribute(n);break;case`cols`:case`rows`:case`size`:case`span`:r!=null&&typeof r!=`function`&&typeof r!=`symbol`&&!isNaN(r)&&1<=r?e.setAttribute(n,r):e.removeAttribute(n);break;case`rowSpan`:case`start`:r==null||typeof r==`function`||typeof r==`symbol`||isNaN(r)?e.removeAttribute(n):e.setAttribute(n,r);break;case`popover`:Vf(`beforetoggle`,e),Vf(`toggle`,e),Rt(e,`popover`,r);break;case`xlinkActuate`:Bt(e,`http://www.w3.org/1999/xlink`,`xlink:actuate`,r);break;case`xlinkArcrole`:Bt(e,`http://www.w3.org/1999/xlink`,`xlink:arcrole`,r);break;case`xlinkRole`:Bt(e,`http://www.w3.org/1999/xlink`,`xlink:role`,r);break;case`xlinkShow`:Bt(e,`http://www.w3.org/1999/xlink`,`xlink:show`,r);break;case`xlinkTitle`:Bt(e,`http://www.w3.org/1999/xlink`,`xlink:title`,r);break;case`xlinkType`:Bt(e,`http://www.w3.org/1999/xlink`,`xlink:type`,r);break;case`xmlBase`:Bt(e,`http://www.w3.org/XML/1998/namespace`,`xml:base`,r);break;case`xmlLang`:Bt(e,`http://www.w3.org/XML/1998/namespace`,`xml:lang`,r);break;case`xmlSpace`:Bt(e,`http://www.w3.org/XML/1998/namespace`,`xml:space`,r);break;case`is`:Rt(e,`is`,r);break;case`innerText`:case`textContent`:return;default:if(!(2<n.length)||n[0]!==`o`&&n[0]!==`O`||n[1]!==`n`&&n[1]!==`N`)n=an.get(n)||n,Rt(e,n,r);else return}It=!0}function np(e,t,n,r,a,o){switch(n){case`style`:nn(e,r,o);return;case`dangerouslySetInnerHTML`:if(r!=null){if(typeof r!=`object`||!(`__html`in r))throw Error(i(61));if(n=r.__html,n!=null){if(a.children!=null)throw Error(i(60));o?.__html!==n&&(e.innerHTML=n)}}break;case`children`:if(typeof r==`string`)$t(e,r);else if(typeof r==`number`||typeof r==`bigint`)$t(e,``+r);else return;break;case`onScroll`:r!=null&&Vf(`scroll`,e);return;case`onScrollEnd`:r!=null&&Vf(`scrollend`,e);return;case`onClick`:r!=null&&(e.onclick=cn);return;case`suppressContentEditableWarning`:case`suppressHydrationWarning`:case`innerHTML`:case`ref`:return;case`innerText`:case`textContent`:return;default:if(!kt.hasOwnProperty(n))a:{if(n[0]===`o`&&n[1]===`n`&&(a=n.endsWith(`Capture`),o=n.slice(2,a?n.length-7:void 0),t=e[q]||null,t=t==null?null:t[n],typeof t==`function`&&e.removeEventListener(o,t,a),typeof r==`function`)){typeof t!=`function`&&t!==null&&(n in e?e[n]=null:e.hasAttribute(n)&&e.removeAttribute(n)),e.addEventListener(o,r,a);break a}It=!0,n in e?e[n]=r:!0===r?e.setAttribute(n,``):Rt(e,n,r)}return}It=!0}function rp(e,t,n){switch(t){case`div`:case`span`:case`svg`:case`path`:case`a`:case`g`:case`p`:case`li`:break;case`img`:Vf(`error`,e),Vf(`load`,e);var r=!1,a=!1,o;for(o in n)if(n.hasOwnProperty(o)){var s=n[o];if(s!=null)switch(o){case`src`:r=!0;break;case`srcSet`:a=!0;break;case`children`:case`dangerouslySetInnerHTML`:throw Error(i(137,t));default:tp(e,t,o,s,n,null)}}a&&tp(e,t,`srcSet`,n.srcSet,n,null),r&&tp(e,t,`src`,n.src,n,null);return;case`input`:Vf(`invalid`,e);var c=o=s=a=null,l=null,u=null;for(r in n)if(n.hasOwnProperty(r)){var d=n[r];if(d!=null)switch(r){case`name`:a=d;break;case`type`:s=d;break;case`checked`:l=d;break;case`defaultChecked`:u=d;break;case`value`:o=d;break;case`defaultValue`:c=d;break;case`children`:case`dangerouslySetInnerHTML`:if(d!=null)throw Error(i(137,t));break;default:tp(e,t,r,d,n,null)}}Jt(e,o,c,l,u,s,a,!1);return;case`select`:for(a in Vf(`invalid`,e),r=s=o=null,n)if(n.hasOwnProperty(a)&&(c=n[a],c!=null))switch(a){case`value`:o=c;break;case`defaultValue`:s=c;break;case`multiple`:r=c;default:tp(e,t,a,c,n,null)}t=o,n=s,e.multiple=!!r,t==null?n!=null&&Xt(e,!!r,n,!0):Xt(e,!!r,t,!1);return;case`textarea`:for(s in Vf(`invalid`,e),o=a=r=null,n)if(n.hasOwnProperty(s)&&(c=n[s],c!=null))switch(s){case`value`:r=c;break;case`defaultValue`:a=c;break;case`children`:o=c;break;case`dangerouslySetInnerHTML`:if(c!=null)throw Error(i(91));break;default:tp(e,t,s,c,n,null)}Qt(e,r,a,o);return;case`option`:for(l in n)if(n.hasOwnProperty(l)&&(r=n[l],r!=null))switch(l){case`selected`:e.selected=r&&typeof r!=`function`&&typeof r!=`symbol`;break;default:tp(e,t,l,r,n,null)}return;case`dialog`:Vf(`beforetoggle`,e),Vf(`toggle`,e),Vf(`cancel`,e),Vf(`close`,e);break;case`iframe`:case`object`:Vf(`load`,e);break;case`video`:case`audio`:for(r=0;r<Rf.length;r++)Vf(Rf[r],e);break;case`image`:Vf(`error`,e),Vf(`load`,e);break;case`details`:Vf(`toggle`,e);break;case`embed`:case`source`:case`link`:Vf(`error`,e),Vf(`load`,e);case`area`:case`base`:case`br`:case`col`:case`hr`:case`keygen`:case`meta`:case`param`:case`track`:case`wbr`:case`menuitem`:for(u in n)if(n.hasOwnProperty(u)&&(r=n[u],r!=null))switch(u){case`children`:case`dangerouslySetInnerHTML`:throw Error(i(137,t));default:tp(e,t,u,r,n,null)}return;default:if(rn(t)){for(d in n)n.hasOwnProperty(d)&&(r=n[d],r!==void 0&&np(e,t,d,r,n,void 0));return}}for(c in n)n.hasOwnProperty(c)&&(r=n[c],r!=null&&tp(e,t,c,r,n,null))}var ip={};function ap(e,t,n,r){switch(t){case`div`:case`span`:case`svg`:case`path`:case`a`:case`g`:case`p`:case`li`:break;case`input`:var a=null,o=null,s=null,c=null,l=null,u=null,d=null;for(m in n){var f=n[m];if(n.hasOwnProperty(m)&&f!=null)switch(m){case`checked`:break;case`value`:break;case`defaultValue`:l=f;default:r.hasOwnProperty(m)||tp(e,t,m,null,r,f)}}for(var p in r){var m=r[p];if(f=n[p],r.hasOwnProperty(p)&&(m!=null||f!=null))switch(p){case`type`:m!==f&&(It=!0),o=m;break;case`name`:m!==f&&(It=!0),a=m;break;case`checked`:m!==f&&(It=!0),u=m;break;case`defaultChecked`:m!==f&&(It=!0),d=m;break;case`value`:m!==f&&(It=!0),s=m;break;case`defaultValue`:m!==f&&(It=!0),c=m;break;case`children`:case`dangerouslySetInnerHTML`:if(m!=null)throw Error(i(137,t));break;default:m!==f&&tp(e,t,p,m,r,f)}}qt(e,s,c,l,u,d,o,a);return;case`select`:for(o in m=s=c=p=null,n)if(l=n[o],n.hasOwnProperty(o)&&l!=null)switch(o){case`value`:break;case`multiple`:m=l;default:r.hasOwnProperty(o)||tp(e,t,o,null,r,l)}for(a in r)if(o=r[a],l=n[a],r.hasOwnProperty(a)&&(o!=null||l!=null))switch(a){case`value`:o!==l&&(It=!0),p=o;break;case`defaultValue`:o!==l&&(It=!0),c=o;break;case`multiple`:o!==l&&(It=!0),s=o;default:o!==l&&tp(e,t,a,o,r,l)}t=c,n=s,r=m,p==null?!!r!=!!n&&(t==null?Xt(e,!!n,n?[]:``,!1):Xt(e,!!n,t,!0)):Xt(e,!!n,p,!1);return;case`textarea`:for(c in m=p=null,n)if(a=n[c],n.hasOwnProperty(c)&&a!=null&&!r.hasOwnProperty(c))switch(c){case`value`:break;case`children`:break;default:tp(e,t,c,null,r,a)}for(s in r)if(a=r[s],o=n[s],r.hasOwnProperty(s)&&(a!=null||o!=null))switch(s){case`value`:a!==o&&(It=!0),p=a;break;case`defaultValue`:a!==o&&(It=!0),m=a;break;case`children`:break;case`dangerouslySetInnerHTML`:if(a!=null)throw Error(i(91));break;default:a!==o&&tp(e,t,s,a,r,o)}Zt(e,p,m);return;case`option`:for(var h in n)if(p=n[h],n.hasOwnProperty(h)&&p!=null&&!r.hasOwnProperty(h))switch(h){case`selected`:e.selected=!1;break;default:tp(e,t,h,null,r,p)}for(l in r)if(p=r[l],m=n[l],r.hasOwnProperty(l)&&p!==m&&(p!=null||m!=null))switch(l){case`selected`:p!==m&&(It=!0),e.selected=p&&typeof p!=`function`&&typeof p!=`symbol`;break;default:tp(e,t,l,p,r,m)}return;case`img`:case`link`:case`area`:case`base`:case`br`:case`col`:case`embed`:case`hr`:case`keygen`:case`meta`:case`param`:case`source`:case`track`:case`wbr`:case`menuitem`:for(var g in n)p=n[g],n.hasOwnProperty(g)&&p!=null&&!r.hasOwnProperty(g)&&tp(e,t,g,null,r,p);for(u in r)if(p=r[u],m=n[u],r.hasOwnProperty(u)&&p!==m&&(p!=null||m!=null))switch(u){case`children`:case`dangerouslySetInnerHTML`:if(p!=null)throw Error(i(137,t));break;default:tp(e,t,u,p,r,m)}return;default:if(rn(t)){for(var _ in n)p=n[_],n.hasOwnProperty(_)&&p!==void 0&&!r.hasOwnProperty(_)&&np(e,t,_,void 0,r,p);for(d in r)p=r[d],m=n[d],!r.hasOwnProperty(d)||p===m||p===void 0&&m===void 0||np(e,t,d,p,r,m);return}}for(var v in n)p=n[v],n.hasOwnProperty(v)&&p!=null&&!r.hasOwnProperty(v)&&tp(e,t,v,null,r,p);for(f in r)p=r[f],m=n[f],!r.hasOwnProperty(f)||p===m||p==null&&m==null||tp(e,t,f,p,r,m)}function op(e){switch(e){case`css`:case`script`:case`font`:case`img`:case`image`:case`input`:case`link`:return!0;default:return!1}}function sp(){if(typeof performance.getEntriesByType==`function`){for(var e=0,t=0,n=performance.getEntriesByType(`resource`),r=0;r<n.length;r++){var i=n[r],a=i.transferSize,o=i.initiatorType,s=i.duration;if(a&&s&&op(o)){for(o=0,s=i.responseEnd,r+=1;r<n.length;r++){var c=n[r],l=c.startTime;if(l>s)break;var u=c.transferSize,d=c.initiatorType;u&&op(d)&&(c=c.responseEnd,o+=u*(c<s?1:(s-l)/(c-l)))}if(--r,t+=8*(a+o)/(i.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e==`number`)?e:5}var cp=null,lp=null;function up(e){return e.nodeType===9?e:e.ownerDocument}function dp(e){switch(e){case`http://www.w3.org/2000/svg`:return 1;case`http://www.w3.org/1998/Math/MathML`:return 2;default:return 0}}function fp(e,t){if(e===0)switch(t){case`svg`:return 1;case`math`:return 2;default:return 0}return e===1&&t===`foreignObject`?0:e}function pp(e,t,n,r){return n=up(n).createElement(e),n[K]=r,n[q]=t,rp(n,e,t),Y(n),n}function mp(e,t){return e===`textarea`||e===`noscript`||typeof t.children==`string`||typeof t.children==`number`||typeof t.children==`bigint`||typeof t.dangerouslySetInnerHTML==`object`&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var hp=null;function gp(){var e=window.event;return e&&e.type===`popstate`?e!==hp&&(hp=e,!0):(hp=null,!1)}var _p=typeof setTimeout==`function`?setTimeout:void 0,vp=typeof clearTimeout==`function`?clearTimeout:void 0,yp=typeof Promise==`function`?Promise:void 0,bp=typeof requestAnimationFrame==`function`?requestAnimationFrame:_p,xp=typeof queueMicrotask==`function`?queueMicrotask:yp===void 0?_p:function(e){return yp.resolve(null).then(e).catch(Sp)};function Sp(e){setTimeout(function(){throw e})}function Cp(e){return e===`head`}function wp(e,t){var n=t,r=0;do{var i=n.nextSibling;if(e.removeChild(n),i&&i.nodeType===8){if(n=i.data,n===`/$`||n===`/&`){if(r===0){e.removeChild(i),Uh(t);return}r--}else if(n===`$`||n===`$?`||n===`$~`||n===`$!`||n===`&`)r++;else if(n===`html`)vm(e.ownerDocument.documentElement);else if(n===`head`){n=e.ownerDocument.head,vm(n);for(var a=n.firstChild;a;){var o=a.nextSibling,s=a.nodeName;a[bt]||s===`SCRIPT`||s===`STYLE`||s===`LINK`&&a.rel.toLowerCase()===`stylesheet`||n.removeChild(a),a=o}}else n===`body`&&vm(e.ownerDocument.body)}n=i}while(n);Uh(t)}function Tp(e,t){var n=e;e=0;do{var r=n.nextSibling;if(n.nodeType===1?t?(n._stashedDisplay=n.style.display,n.style.display=`none`):(n.style.display=n._stashedDisplay||``,n.getAttribute(`style`)===``&&n.removeAttribute(`style`)):n.nodeType===3&&(t?(n._stashedText=n.nodeValue,n.nodeValue=``):n.nodeValue=n._stashedText||``),r&&r.nodeType===8){if(n=r.data,n===`/$`){if(e===0)break;e--}else n!==`$`&&n!==`$?`&&n!==`$~`&&n!==`$!`||e++}n=r}while(n)}function Ep(e,t,n){if(t=CSS.escape(t)===t?t:`r-`+btoa(t).replace(/=/g,``),e.style.viewTransitionName=t,n!=null&&(e.style.viewTransitionClass=n),n=getComputedStyle(e),n.display===`inline`){if(t=e.getClientRects(),t.length===1)var r=1;else for(var i=r=0;i<t.length;i++){var a=t[i];0<a.width&&0<a.height&&r++}r===1&&(e=e.style,e.display=t.length===1?`inline-block`:`block`,e.marginTop=`-`+n.paddingTop,e.marginBottom=`-`+n.paddingBottom)}}function Dp(e,t){e=e.style,t=t.style;var n=t==null?null:t.hasOwnProperty(`viewTransitionName`)?t.viewTransitionName:t.hasOwnProperty(`view-transition-name`)?t[`view-transition-name`]:null;e.viewTransitionName=n==null||typeof n==`boolean`?``:(``+n).trim(),n=t==null?null:t.hasOwnProperty(`viewTransitionClass`)?t.viewTransitionClass:t.hasOwnProperty(`view-transition-class`)?t[`view-transition-class`]:null,e.viewTransitionClass=n==null||typeof n==`boolean`?``:(``+n).trim(),e.display===`inline-block`&&(t==null?e.display=e.margin=``:(n=t.display,e.display=n==null||typeof n==`boolean`?``:n,n=t.margin,n==null?(n=t.hasOwnProperty(`marginTop`)?t.marginTop:t[`margin-top`],e.marginTop=n==null||typeof n==`boolean`?``:n,t=t.hasOwnProperty(`marginBottom`)?t.marginBottom:t[`margin-bottom`],e.marginBottom=t==null||typeof t==`boolean`?``:t):e.margin=n))}function Op(e,t,n){return n=n.ownerDocument.defaultView,{rect:e,abs:t.position===`absolute`||t.position===`fixed`,clip:t.clipPath!==`none`||t.overflow!==`visible`||t.filter!==`none`||t.mask!==`none`||t.mask!==`none`||t.borderRadius!==`0px`,view:0<=e.bottom&&0<=e.right&&e.top<=n.innerHeight&&e.left<=n.innerWidth}}function kp(e){return Op(e.getBoundingClientRect(),getComputedStyle(e),e)}function Ap(e){var t=e.getBoundingClientRect();t=new DOMRect(t.x+2e4,t.y+2e4,t.width,t.height);var n=getComputedStyle(e);return Op(t,n,e)}function jp(e){return e.documentElement.clientHeight}function Mp(e){this.addEventListener(`load`,e),this.addEventListener(`error`,e)}function Np(e,t,n,r,i,a,o,s,c){var l=t.nodeType===9?t:t.ownerDocument;try{var u=l.startViewTransition({update:function(){var t=l.defaultView,n=t.navigation&&t.navigation.transition,o=l.fonts.status;r();var s=[];if(o===`loaded`&&(jp(l),l.fonts.status===`loading`&&s.push(l.fonts.ready)),o=s.length,e!==null)for(var c=e.suspenseyImages,u=0,d=0;d<c.length;d++){var f=c[d];if(!f.complete){var p=f.getBoundingClientRect();if(0<p.bottom&&0<p.right&&p.top<t.innerHeight&&p.left<t.innerWidth){if(u+=Zm(f),u>eh){s.length=o;break}f=new Promise(Mp.bind(f)),s.push(f)}}}if(0<s.length)return t=Promise.race([Promise.all(s),new Promise(function(e){return setTimeout(e,500)})]).then(i,i),(n?Promise.allSettled([n.finished,t]):t).then(a,a);if(i(),n)return n.finished.then(a,a);a()},types:n});l.__reactViewTransition=u;var d=[];return u.ready.then(function(){for(var e=l.documentElement.getAnimations({subtree:!0}),t=0;t<e.length;t++){var n=e[t],r=n.effect,i=r.pseudoElement;if(i!=null&&i.startsWith(`::view-transition`)){d.push(n),n=r.getKeyframes();for(var a=i=void 0,s=!0,c=0;c<n.length;c++){var u=n[c],f=u.width;if(i===void 0)i=f;else if(i!==f){s=!1;break}if(f=u.height,a===void 0)a=f;else if(a!==f){s=!1;break}delete u.width,delete u.height,u.transform===`none`&&delete u.transform}s&&i!==void 0&&a!==void 0&&(r.setKeyframes(n),s=getComputedStyle(r.target,r.pseudoElement),s.width!==i||s.height!==a)&&(s=n[0],s.width=i,s.height=a,s=n[n.length-1],s.width=i,s.height=a,r.setKeyframes(n))}}o()},function(e){l.__reactViewTransition===u&&(l.__reactViewTransition=null);try{if(typeof e==`object`&&e)switch(e.name){case`InvalidStateError`:(e.message===`View transition was skipped because document visibility state is hidden.`||e.message===`Skipping view transition because document visibility state has become hidden.`||e.message===`Skipping view transition because viewport size changed.`||e.message===`Transition was aborted because of invalid state`)&&(e=null)}e!==null&&c(e)}finally{r(),i(),o()}}),u.finished.finally(function(){for(var e=0;e<d.length;e++)d[e].cancel();l.__reactViewTransition===u&&(l.__reactViewTransition=null),s()}),u}catch{return r(),i(),o(),null}}function Pp(e,t){this._scope=document.documentElement,this._selector=`::view-transition-`+e+`(`+t+`)`}Pp.prototype.animate=function(e,t){return t=typeof t==`number`?{duration:t}:D({},t),t.pseudoElement=this._selector,this._scope.animate(e,t)},Pp.prototype.getAnimations=function(){for(var e=this._scope,t=this._selector,n=e.getAnimations({subtree:!0}),r=[],i=0;i<n.length;i++){var a=n[i].effect;a!==null&&a.target===e&&a.pseudoElement===t&&r.push(n[i])}return r},Pp.prototype.getComputedStyle=function(){return getComputedStyle(this._scope,this._selector)};function Fp(e){return{name:e,group:new Pp(`group`,e),imagePair:new Pp(`image-pair`,e),old:new Pp(`old`,e),new:new Pp(`new`,e)}}function Ip(e){this._fragmentFiber=e,this._observers=this._eventListeners=null}Ip.prototype.addEventListener=function(e,t,n){var r=null,i=null;if(!(n!=null&&typeof n!=`boolean`&&(r=n.signal||null,r!==null&&r.aborted))){this._eventListeners===null&&(this._eventListeners=[]);var a=this._eventListeners;if(Vp(a,e,t,n)===-1){var o=this,s=t;n!=null&&typeof n!=`boolean`&&!0===n.once&&(s=function(r){o.removeEventListener(e,t,n),typeof t==`function`?t.call(this,r):t.handleEvent(r)}),r!==null&&(i=o.removeEventListener.bind(o,e,t,n),r.addEventListener(`abort`,i,{once:!0}),i=r.removeEventListener.bind(r,`abort`,i)),r=zp(n),a.push({type:e,listener:t,optionsOrUseCapture:n,attachedListener:s,cleanup:i}),m(this._fragmentFiber.child,!1,Lp,e,s,r)}this._eventListeners=a}};function Lp(e,t,n,r){return b(e).addEventListener(t,n,r),!1}Ip.prototype.removeEventListener=function(e,t,n){var r=this._eventListeners;if(r!==null&&(t=Vp(r,e,t,n),t!==-1)){var i=r[t];n=i.attachedListener;var a=i.cleanup;i=zp(i.optionsOrUseCapture),m(this._fragmentFiber.child,!1,Rp,e,n,i),r.splice(t,1),a!==null&&a()}};function Rp(e,t,n,r){return b(e).removeEventListener(t,n,r),!1}function zp(e){return e!=null&&typeof e!=`boolean`&&(!0===e.once||e.signal instanceof AbortSignal)?{capture:e.capture,passive:e.passive}:e}function Bp(e){return e==null?`c=0`:typeof e==`boolean`?`c=`+(e?`1`:`0`):`c=`+(e.capture?`1`:`0`)}function Vp(e,t,n,r){if(e.length===0)return-1;r=Bp(r);for(var i=0;i<e.length;i++){var a=e[i];if(a.type===t&&a.listener===n&&Bp(a.optionsOrUseCapture)===r)return i}return-1}Ip.prototype.dispatchEvent=function(e){var t=g(this._fragmentFiber);if(t===null)return!0;t=b(t);var n=this._eventListeners;if(n!==null&&0<n.length||!e.bubbles){var r=t.nodeType===9?t.createComment(``):document.createTextNode(``);if(n)for(var i=0;i<n.length;i++){var a=n[i];r.addEventListener(a.type,a.attachedListener,zp(a.optionsOrUseCapture))}if(t.appendChild(r),e=r.dispatchEvent(e),n)for(i=0;i<n.length;i++)a=n[i],r.removeEventListener(a.type,a.attachedListener,zp(a.optionsOrUseCapture));return t.removeChild(r),e}return t.dispatchEvent(e)},Ip.prototype.focus=function(e){m(this._fragmentFiber.child,!0,Hp,e,void 0,void 0)};function Hp(e,t){return e.tag!==6&&(e=b(e),mm(e,t))}Ip.prototype.focusLast=function(e){var t=[];m(this._fragmentFiber.child,!0,Up,t,void 0,void 0);for(var n=t.length-1;0<=n&&!Hp(t[n],e);n--);};function Up(e,t){return t.push(e),!1}Ip.prototype.blur=function(){var e=g(this._fragmentFiber);e!==null&&(e=b(e),e=up(e).activeElement,e!==null&&m(this._fragmentFiber.child,!1,Wp,e,void 0,void 0))};function Wp(e,t){return e.tag!==6&&(e=b(e),e===t||e.contains(t)?(t.blur(),!0):!1)}Ip.prototype.observeUsing=function(e){this._observers===null&&(this._observers=new Set),this._observers.add(e),m(this._fragmentFiber.child,!1,Gp,e,void 0,void 0)};function Gp(e,t){return e.tag===6||(e=b(e),t.observe(e)),!1}Ip.prototype.unobserveUsing=function(e){var t=this._observers;if(t!==null&&t.has(e)){t.delete(e),m(this._fragmentFiber.child,!1,Kp,e,void 0,void 0);for(var n=t=0;n<qp.length;n++){var r=qp[n];r.fragmentInstance===this&&r.observer===e?e.unobserve(r.instance):qp[t++]=r}qp.length=t}};function Kp(e,t){return e.tag===6||(e=b(e),t.unobserve(e)),!1}var qp=[],Jp=!1;function Yp(e,t,n){qp.push({fragmentInstance:e,observer:t,instance:n}),Jp||(Jp=!0,hm(function(){Jp=!1;var e=qp;qp=[];for(var t=0;t<e.length;t++){var n=e[t];n.observer.unobserve(n.instance)}}))}Ip.prototype.getClientRects=function(){var e=[];return m(this._fragmentFiber.child,!1,Xp,e,void 0,void 0),e};function Xp(e,t){if(e.tag===6){e=e.stateNode;var n=e.ownerDocument.createRange();n.selectNodeContents(e),t.push.apply(t,n.getClientRects())}else e=b(e),t.push.apply(t,e.getClientRects());return!1}Ip.prototype.getRootNode=function(e){var t=g(this._fragmentFiber);return t===null?this:b(t).getRootNode(e)},Ip.prototype.compareDocumentPosition=function(e){var t=g(this._fragmentFiber);if(t===null)return Node.DOCUMENT_POSITION_DISCONNECTED;var n=[];m(this._fragmentFiber.child,!1,Up,n,void 0,void 0);var r=b(t);if(n.length===0){if(n=r,_(this._fragmentFiber)){a:{for(t=this._fragmentFiber.return;t!==null;){if(t.tag===4){t=t.stateNode.containerInfo;break a}if(t.tag===3||t.tag===5||t.tag===27)break;t=t.return}t=null}t!=null&&(n=t)}t=this._fragmentFiber;var i=r=n.compareDocumentPosition(e);return n===e?i=Node.DOCUMENT_POSITION_CONTAINS:r&Node.DOCUMENT_POSITION_CONTAINED_BY&&(n=v(t)[1],n===null?i=Node.DOCUMENT_POSITION_PRECEDING:(e=b(n).compareDocumentPosition(e),i=e===0||e&Node.DOCUMENT_POSITION_FOLLOWING?Node.DOCUMENT_POSITION_FOLLOWING:Node.DOCUMENT_POSITION_PRECEDING)),i|=Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC}t=b(n[0]),i=b(n[n.length-1]);var a=_(this._fragmentFiber)?t.parentElement:r;if(a==null)return Node.DOCUMENT_POSITION_DISCONNECTED;r=a.compareDocumentPosition(t)&Node.DOCUMENT_POSITION_CONTAINED_BY,a=a.compareDocumentPosition(i)&Node.DOCUMENT_POSITION_CONTAINED_BY;var o=t.compareDocumentPosition(e),s=i.compareDocumentPosition(e),c=o&Node.DOCUMENT_POSITION_CONTAINED_BY||s&Node.DOCUMENT_POSITION_CONTAINED_BY;return s=r&&a&&o&Node.DOCUMENT_POSITION_FOLLOWING&&s&Node.DOCUMENT_POSITION_PRECEDING,t=r&&t===e||a&&i===e||c||s?Node.DOCUMENT_POSITION_CONTAINED_BY:!r&&t===e||!a&&i===e?Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC:o,t&Node.DOCUMENT_POSITION_DISCONNECTED||t&Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC||Zp(t,this._fragmentFiber,n[0],n[n.length-1],e)?t:Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC};function Zp(e,t,n,r,i){var a=Ct(i);if(e&Node.DOCUMENT_POSITION_CONTAINED_BY){if(n=!!a)a:{for(;a!==null;){if(a.tag===7&&(a===t||a.alternate===t)){n=!0;break a}a=a.return}n=!1}return n}if(e&Node.DOCUMENT_POSITION_CONTAINS){if(a===null)return a=i.ownerDocument,i===a||i===a.documentElement||i===a.body;a:{for(a=t,t=g(t);a!==null;){if(!(a.tag!==5&&a.tag!==3&&a.tag!==27||a!==t&&a.alternate!==t)){a=!0;break a}a=a.return}a=!1}return a}return e&Node.DOCUMENT_POSITION_PRECEDING?((t=!!a)&&!(t=a===n)&&(t=E(n,a,T),t===null?t=!1:(m(t,!0,C,a,n),a=x,x=null,t=a!==null)),t):e&Node.DOCUMENT_POSITION_FOLLOWING?((t=!!a)&&!(t=a===r)&&(t=E(r,a,T),t===null?t=!1:(m(t,!0,w,a,r),a=x,S=x=null,t=a!==null)),t):!1}function Qp(e,t){var n=e.ownerDocument.createRange();n.selectNodeContents(e),e=n.getBoundingClientRect(),window.scrollTo(window.scrollX+e.left,t?window.scrollY+e.top:window.scrollY+e.bottom-window.innerHeight)}Ip.prototype.scrollIntoView=function(e){if(typeof e==`object`)throw Error(i(566));var t=[];m(this._fragmentFiber.child,!1,Up,t,void 0,void 0);var n=!1!==e;if(t.length===0){var r=v(this._fragmentFiber);if(r=n?r[1]||r[0]||g(this._fragmentFiber):r[0]||r[1],r===null)return;if(r.tag===6){e=b(r),Qp(e,n);return}if(r=b(r),r.nodeType!==9){if(r.nodeType===11){n=`host`in r?r.host:null,n!==null&&n.scrollIntoView(e);return}r.scrollIntoView(e)}}for(r=n?t.length-1:0;r!==(n?-1:t.length);){var a=t[r];a.tag===6?(a=b(a),Qp(a,n)):b(a).scrollIntoView(e),r+=n?-1:1}};function $p(e,t){return e=b(e),em(e,t),!1}function em(e,t){e.reactFragments??=new Set,e.reactFragments.add(t)}function tm(e,t){var n=t._eventListeners;if(n!==null)for(var r=0;r<n.length;r++){var i=n[r];e.addEventListener(i.type,i.attachedListener,zp(i.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(n){for(var r=0,i=0;i<qp.length;i++){var a=qp[i];(a.fragmentInstance!==t||a.observer!==n||a.instance!==e)&&(qp[r++]=a)}qp.length=r,n.observe(e)}),em(e,t))}function nm(e,t){var n=t._eventListeners;if(n!==null)for(var r=0;r<n.length;r++){var i=n[r];e.removeEventListener(i.type,i.attachedListener,zp(i.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(n){typeof n.rootMargin==`string`?Yp(t,n,e):n.unobserve(e)}),e.reactFragments!=null&&e.reactFragments.delete(t))}function rm(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var n=t;switch(t=t.nextSibling,n.nodeName){case`HTML`:case`HEAD`:case`BODY`:rm(n),St(n);continue;case`SCRIPT`:case`STYLE`:continue;case`LINK`:if(n.rel.toLowerCase()===`stylesheet`)continue}e.removeChild(n)}}function im(e,t,n,r){for(;e.nodeType===1;){var i=n;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!r&&(e.nodeName!==`INPUT`||e.type!==`hidden`))break}else if(!r){if(t===`input`&&e.type===`hidden`){var a=i.name==null?null:``+i.name;if(i.type===`hidden`&&e.getAttribute(`name`)===a)return e}else return e}else if(!e[bt])switch(t){case`meta`:if(!e.hasAttribute(`itemprop`))break;return e;case`link`:if(a=e.getAttribute(`rel`),a===`stylesheet`&&e.hasAttribute(`data-precedence`)||a!==i.rel||e.getAttribute(`href`)!==(i.href==null||i.href===``?null:i.href)||e.getAttribute(`crossorigin`)!==(i.crossOrigin==null?null:i.crossOrigin)||e.getAttribute(`title`)!==(i.title==null?null:i.title))break;return e;case`style`:if(e.hasAttribute(`data-precedence`))break;return e;case`script`:if(a=e.getAttribute(`src`),(a!==(i.src==null?null:i.src)||e.getAttribute(`type`)!==(i.type==null?null:i.type)||e.getAttribute(`crossorigin`)!==(i.crossOrigin==null?null:i.crossOrigin))&&a&&e.hasAttribute(`async`)&&!e.hasAttribute(`itemprop`))break;return e;default:return e}if(e=um(e.nextSibling),e===null)break}return null}function am(e,t,n){if(t===``)return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!==`INPUT`||e.type!==`hidden`)&&!n||(e=um(e.nextSibling),e===null))return null;return e}function om(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!==`INPUT`||e.type!==`hidden`)&&!t||(e=um(e.nextSibling),e===null))return null;return e}function sm(e){return e.data===`$?`||e.data===`$~`}function cm(e){return e.data===`$!`||e.data===`$?`&&e.ownerDocument.readyState!==`loading`}function lm(e,t){var n=e.ownerDocument;if(e.data===`$~`)e._reactRetry=t;else if(e.data!==`$?`||n.readyState!==`loading`)t();else{var r=function(){t(),n.removeEventListener(`DOMContentLoaded`,r)};n.addEventListener(`DOMContentLoaded`,r),e._reactRetry=r}}function um(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t===`$`||t===`$!`||t===`$?`||t===`$~`||t===`&`||t===`F!`||t===`F`)break;if(t===`/$`||t===`/&`)return null}}return e}var dm=null;function fm(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n===`/$`||n===`/&`){if(t===0)return um(e.nextSibling);t--}else n!==`$`&&n!==`$!`&&n!==`$?`&&n!==`$~`&&n!==`&`||t++}e=e.nextSibling}return null}function pm(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n===`$`||n===`$!`||n===`$?`||n===`$~`||n===`&`){if(t===0)return e;t--}else n!==`/$`&&n!==`/&`||t++}e=e.previousSibling}return null}function mm(e,t){function n(){r=!0}if(e.ownerDocument.activeElement===e)return!0;var r=!1;try{e.ownerDocument.addEventListener(`focus`,n,!0),(e.focus||HTMLElement.prototype.focus).call(e,t)}finally{e.ownerDocument.removeEventListener(`focus`,n,!0)}return r}function hm(e){bp(function(){bp(function(t){return e(t)})})}function gm(e,t,n){switch(t=up(n),e){case`html`:if(e=t.documentElement,!e)throw Error(i(452));return e;case`head`:if(e=t.head,!e)throw Error(i(453));return e;case`body`:if(e=t.body,!e)throw Error(i(454));return e;default:throw Error(i(451))}}function _m(e,t,n){for(var r in n){var i=n[r];n.hasOwnProperty(r)&&i!=null&&tp(e,t,r,null,ip,i)}n.dangerouslySetInnerHTML!=null&&(e.textContent=``),e.onclick===cn&&(e.onclick=null),St(e)}function vm(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);St(e)}var ym=new Map,bm=new Set;function xm(e){if(typeof e.getRootNode==`function`){var t=e.getRootNode();if(t.nodeType===9||t.nodeType===11)return t}return e.nodeType===9?e:e.ownerDocument}var Sm=U.d;U.d={f:Cm,r:wm,D:Dm,C:Om,L:km,m:Am,X:Mm,S:jm,M:Nm};function Cm(){var e=Sm.f(),t=Ld();return e||t}function wm(e){var t=wt(e);t!==null&&t.tag===5&&t.type===`form`?Js(t):Sm.r(e)}var Tm=typeof document>`u`?null:document;function Em(e,t,n){var r=Tm;if(r&&typeof t==`string`&&t){var i=Kt(t);i=`link[rel="`+e+`"][href="`+i+`"]`,typeof n==`string`&&(i+=`[crossorigin="`+n+`"]`),bm.has(i)||(bm.add(i),e={rel:e,crossOrigin:n,href:t},r.querySelector(i)===null&&(t=r.createElement(`link`),rp(t,`link`,e),Y(t),r.head.appendChild(t)))}}function Dm(e){Sm.D(e),Em(`dns-prefetch`,e,null)}function Om(e,t){Sm.C(e,t),Em(`preconnect`,e,t)}function km(e,t,n){Sm.L(e,t,n);var r=Tm;if(r&&e&&t){var i=`link[rel="preload"][as="`+Kt(t)+`"]`;t===`image`&&n&&n.imageSrcSet?(i+=`[imagesrcset="`+Kt(n.imageSrcSet)+`"]`,typeof n.imageSizes==`string`&&(i+=`[imagesizes="`+Kt(n.imageSizes)+`"]`)):i+=`[href="`+Kt(e)+`"]`;var a=i;switch(t){case`style`:a=Fm(e);break;case`script`:a=zm(e)}if(!(ym.has(a)||(e=D({rel:`preload`,href:t===`image`&&n&&n.imageSrcSet?void 0:e,as:t},n),ym.set(a,e),r.querySelector(i)!==null||t===`style`&&r.querySelector(Im(a))||t===`script`&&r.querySelector(Bm(a))))){var o=r.createElement(`link`);rp(o,`link`,e),t===`style`&&(o[xt]=!0,o.onload=o.onerror=function(){Dt(o)}),Y(o),r.head.appendChild(o)}}}function Am(e,t){Sm.m(e,t);var n=Tm;if(n&&e){var r=t&&typeof t.as==`string`?t.as:`script`,i=`link[rel="modulepreload"][as="`+Kt(r)+`"][href="`+Kt(e)+`"]`,a=i;switch(r){case`audioworklet`:case`paintworklet`:case`serviceworker`:case`sharedworker`:case`worker`:case`script`:a=zm(e)}if(!ym.has(a)&&(e=D({rel:`modulepreload`,href:e},t),ym.set(a,e),n.querySelector(i)===null)){switch(r){case`audioworklet`:case`paintworklet`:case`serviceworker`:case`sharedworker`:case`worker`:case`script`:if(n.querySelector(Bm(a)))return}r=n.createElement(`link`),rp(r,`link`,e),Y(r),n.head.appendChild(r)}}}function jm(e,t,n){Sm.S(e,t,n);var r=Tm;if(r&&e){var i=Et(r).hoistableStyles,a=Fm(e);t||=`default`;var o=i.get(a);if(!o){var s={loading:0,preload:null};if(o=r.querySelector(Im(a)))s.loading=5;else{e=D({rel:`stylesheet`,href:e,"data-precedence":t},n),(n=ym.get(a))&&Um(e,n);var c=o=r.createElement(`link`);Y(c),rp(c,`link`,e),c._p=new Promise(function(e,t){c.onload=e,c.onerror=t}),c.addEventListener(`load`,function(){s.loading|=1}),c.addEventListener(`error`,function(){s.loading|=2}),s.loading|=4,Hm(o,t,r)}o={type:`stylesheet`,instance:o,count:1,state:s},i.set(a,o)}}}function Mm(e,t){Sm.X(e,t);var n=Tm;if(n&&e){var r=Et(n).hoistableScripts,i=zm(e),a=r.get(i);a||(a=n.querySelector(Bm(i)),a||(e=D({src:e,async:!0},t),(t=ym.get(i))&&Wm(e,t),a=n.createElement(`script`),Y(a),rp(a,`link`,e),n.head.appendChild(a)),a={type:`script`,instance:a,count:1,state:null},r.set(i,a))}}function Nm(e,t){Sm.M(e,t);var n=Tm;if(n&&e){var r=Et(n).hoistableScripts,i=zm(e),a=r.get(i);a||(a=n.querySelector(Bm(i)),a||(e=D({src:e,async:!0,type:`module`},t),(t=ym.get(i))&&Wm(e,t),a=n.createElement(`script`),Y(a),rp(a,`link`,e),n.head.appendChild(a)),a={type:`script`,instance:a,count:1,state:null},r.set(i,a))}}function Pm(e,t,n,r){var a=(a=ve.current)?xm(a):null;if(!a)throw Error(i(446));switch(e){case`meta`:case`title`:return null;case`style`:return typeof n.precedence==`string`&&typeof n.href==`string`?(n=Fm(n.href),t=Et(a).hoistableStyles,r=t.get(n),r||(r={type:`style`,instance:null,count:0,state:null},t.set(n,r)),r):{type:`void`,instance:null,count:0,state:null};case`link`:if(n.rel===`stylesheet`&&typeof n.href==`string`&&typeof n.precedence==`string`){e=Fm(n.href);var o=Et(a).hoistableStyles,s=o.get(e);if(s||(a=a.ownerDocument||a,s={type:`stylesheet`,instance:null,count:0,state:{loading:0,preload:null}},o.set(e,s),(o=a.querySelector(Im(e)))?o._p||(s.instance=o,s.state.loading=5):(o=ym.get(e),o||(o={rel:`preload`,as:`style`,href:n.href,crossOrigin:n.crossOrigin,integrity:n.integrity,media:n.media,hrefLang:n.hrefLang,referrerPolicy:n.referrerPolicy},ym.set(e,o)),Rm(a,e,o,s.state))),t&&r===null)throw Error(i(528,``));return s}if(t&&r!==null)throw Error(i(529,``));return null;case`script`:return t=n.async,n=n.src,typeof n==`string`&&t&&typeof t!=`function`&&typeof t!=`symbol`?(n=zm(n),t=Et(a).hoistableScripts,r=t.get(n),r||(r={type:`script`,instance:null,count:0,state:null},t.set(n,r)),r):{type:`void`,instance:null,count:0,state:null};default:throw Error(i(444,e))}}function Fm(e){return`href="`+Kt(e)+`"`}function Im(e){return`link[rel="stylesheet"][`+e+`]`}function Lm(e){return D({},e,{"data-precedence":e.precedence,precedence:null})}function Rm(e,t,n,r){if(t=e.querySelector(`link[rel="preload"][as="style"][`+t+`]`)){if(!0!==t[xt]){r.loading=1;return}}else t=e.createElement(`link`),t[xt]=!0,t.onload=t.onerror=Dt.bind(null,t),rp(t,`link`,n),Y(t),e.head.appendChild(t);r.preload=t,t.addEventListener(`load`,function(){return r.loading|=1}),t.addEventListener(`error`,function(){return r.loading|=2})}function zm(e){return`[src="`+Kt(e)+`"]`}function Bm(e){return`script[async]`+e}function Vm(e,t,n){if(t.count++,t.instance===null)switch(t.type){case`style`:var r=e.querySelector(`style[data-href~="`+Kt(n.href)+`"]`);if(r)return t.instance=r,Y(r),r;var a=D({},n,{"data-href":n.href,"data-precedence":n.precedence,href:null,precedence:null});return r=(e.ownerDocument||e).createElement(`style`),Y(r),rp(r,`style`,a),Hm(r,n.precedence,e),t.instance=r;case`stylesheet`:a=Fm(n.href);var o=e.querySelector(Im(a));if(o)return t.state.loading|=4,t.instance=o,Y(o),o;r=Lm(n),(a=ym.get(a))&&Um(r,a),o=(e.ownerDocument||e).createElement(`link`),Y(o);var s=o;return s._p=new Promise(function(e,t){s.onload=e,s.onerror=t}),rp(o,`link`,r),t.state.loading|=4,Hm(o,n.precedence,e),t.instance=o;case`script`:return o=zm(n.src),(a=e.querySelector(Bm(o)))?(t.instance=a,Y(a),a):(r=n,(a=ym.get(o))&&(r=D({},n),Wm(r,a)),e=e.ownerDocument||e,a=e.createElement(`script`),Y(a),rp(a,`link`,r),e.head.appendChild(a),t.instance=a);case`void`:return null;default:throw Error(i(443,t.type))}else t.type===`stylesheet`&&!(t.state.loading&4)&&(r=t.instance,t.state.loading|=4,Hm(r,n.precedence,e));return t.instance}function Hm(e,t,n){for(var r=n.querySelectorAll(`link[rel="stylesheet"][data-precedence],style[data-precedence]`),i=r.length?r[r.length-1]:null,a=i,o=0;o<r.length;o++){var s=r[o];if(s.dataset.precedence===t)a=s;else if(a!==i)break}a?a.parentNode.insertBefore(e,a.nextSibling):(t=n.nodeType===9?n.head:n,t.insertBefore(e,t.firstChild))}function Um(e,t){e.crossOrigin??=t.crossOrigin,e.referrerPolicy??=t.referrerPolicy,e.title??=t.title}function Wm(e,t){e.crossOrigin??=t.crossOrigin,e.referrerPolicy??=t.referrerPolicy,e.integrity??=t.integrity}var Gm=null;function Km(e,t,n){if(Gm===null){var r=new Map,i=Gm=new Map;i.set(n,r)}else i=Gm,r=i.get(n),r||(r=new Map,i.set(n,r));if(r.has(e))return r;for(r.set(e,null),n=n.getElementsByTagName(e),i=0;i<n.length;i++){var a=n[i];if(!(a[bt]||a[K]||e===`link`&&a.getAttribute(`rel`)===`stylesheet`)&&a.namespaceURI!==`http://www.w3.org/2000/svg`){var o=a.getAttribute(t)||``;o=e+o;var s=r.get(o);s?s.push(a):r.set(o,[a])}}return r}function qm(e,t,n){e=e.ownerDocument||e,e.head.insertBefore(n,t===`title`?e.querySelector(`head > title`):null)}function Jm(e,t,n){if(n===1||t.itemProp!=null)return!1;switch(e){case`meta`:case`title`:return!0;case`style`:if(typeof t.precedence!=`string`||typeof t.href!=`string`||t.href===``)break;return!0;case`link`:if(typeof t.rel!=`string`||typeof t.href!=`string`||t.href===``||t.onLoad||t.onError)break;switch(t.rel){case`stylesheet`:return e=t.disabled,typeof t.precedence==`string`&&e==null;default:return!0}case`script`:if(t.async&&typeof t.async!=`function`&&typeof t.async!=`symbol`&&!t.onLoad&&!t.onError&&t.src&&typeof t.src==`string`)return!0}return!1}function Ym(e,t){return e===`img`&&t.src!=null&&t.src!==``&&t.onLoad==null&&t.loading!==`lazy`}function Xm(e){return!(e.type===`stylesheet`&&!(e.state.loading&3))}function Zm(e){return(e.width||100)*(e.height||100)*(typeof devicePixelRatio==`number`?devicePixelRatio:1)*.25}function Qm(e,t){typeof t.decode==`function`&&(e.imgCount++,t.complete||(e.imgBytes+=Zm(t),e.suspenseyImages.push(t)),e=ih.bind(e),t.decode().then(e,e))}function $m(e,t,n,r){if(n.type===`stylesheet`&&(typeof r.media!=`string`||!1!==matchMedia(r.media).matches)&&!(n.state.loading&4)){if(n.instance===null){var i=Fm(r.href),a=t.querySelector(Im(i));if(a){t=a._p,typeof t==`object`&&t&&typeof t.then==`function`&&(e.count++,e=rh.bind(e),t.then(e,e)),n.state.loading|=4,n.instance=a,Y(a);return}a=t.ownerDocument||t,r=Lm(r),(i=ym.get(i))&&Um(r,i),a=a.createElement(`link`),Y(a);var o=a;o._p=new Promise(function(e,t){o.onload=e,o.onerror=t}),rp(a,`link`,r),n.instance=a}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(n,t),(t=n.state.preload)&&!(n.state.loading&3)&&(e.count++,n=rh.bind(e),t.addEventListener(`load`,n),t.addEventListener(`error`,n))}}var eh=0;function th(e,t){return e.stylesheets&&e.count===0&&oh(e,e.stylesheets),0<e.count||0<e.imgCount?function(n){var r=setTimeout(function(){if(e.stylesheets&&oh(e,e.stylesheets),e.unsuspend){var t=e.unsuspend;e.unsuspend=null,t()}},6e4+t);0<e.imgBytes&&eh===0&&(eh=62500*sp());var i=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&oh(e,e.stylesheets),e.unsuspend)){var t=e.unsuspend;e.unsuspend=null,t()}},(e.imgBytes>eh?50:800)+t);return e.unsuspend=n,function(){e.unsuspend=null,clearTimeout(r),clearTimeout(i)}}:null}function nh(e){if(e.count===0&&(e.imgCount===0||!e.waitingForImages)){if(e.stylesheets)oh(e,e.stylesheets);else if(e.unsuspend){var t=e.unsuspend;e.unsuspend=null,t()}}}function rh(){this.count--,nh(this)}function ih(){this.imgCount--,nh(this)}var ah=null;function oh(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,ah=new Map,t.forEach(sh,e),ah=null,rh.call(e))}function sh(e,t){if(!(t.state.loading&4)){var n=ah.get(e);if(n)var r=n.get(null);else{n=new Map,ah.set(e,n);for(var i=e.querySelectorAll(`link[data-precedence],style[data-precedence]`),a=0;a<i.length;a++){var o=i[a];(o.nodeName===`LINK`||o.getAttribute(`media`)!==`not all`)&&(n.set(o.dataset.precedence,o),r=o)}r&&n.set(null,r)}i=t.instance,o=i.getAttribute(`data-precedence`),a=n.get(o)||r,a===r&&n.set(null,i),n.set(o,i),this.count++,r=rh.bind(this),i.addEventListener(`load`,r),i.addEventListener(`error`,r),a?a.parentNode.insertBefore(i,a.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(i,e.firstChild)),t.state.loading|=4}}var ch={$$typeof:P,Provider:null,Consumer:null,_currentValue:ue,_currentValue2:ue,_threadCount:0};function lh(e,t,n,r,i,a,o,s,c){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=at(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=at(0),this.hiddenUpdates=at(null),this.identifierPrefix=r,this.onUncaughtError=i,this.onCaughtError=a,this.onRecoverableError=o,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=c,this.transitionTypes=null,this.incompleteTransitions=new Map}function uh(e,t,n,r,i,a,o,s,c,l,u,d){return e=new lh(e,t,n,o,c,l,u,d,s),t=1,!0===a&&(t|=24),a=Si(3,null,null,t),e.current=a,a.stateNode=e,t=Sa(),t.refCount++,e.pooledCache=t,t.refCount++,a.memoizedState={element:r,isDehydrated:n,cache:t},io(a),e}function dh(e){return e?(e=bi,e):bi}function fh(e,t,n,r,i,a){i=dh(i),r.context===null?r.context=i:r.pendingContext=i,r=oo(t),r.payload={element:n},a=a===void 0?null:a,a!==null&&(r.callback=a),n=so(e,r,t),n!==null&&(Md(n,e,t),co(n,e,t))}function ph(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function mh(e,t){ph(e,t),(e=e.alternate)&&ph(e,t)}function hh(e){if(e.tag===13||e.tag===31){var t=_i(e,67108864);t!==null&&Md(t,e,67108864),mh(e,67108864)}}function gh(e){if(e.tag===13||e.tag===31){var t=kd();t=dt(t);var n=_i(e,t);n!==null&&Md(n,e,t),mh(e,t)}}var _h=!0;function vh(e,t,n,r){var i=H.T;H.T=null;var a=U.p;try{U.p=2,bh(e,t,n,r)}finally{U.p=a,H.T=i}}function yh(e,t,n,r){var i=H.T;H.T=null;var a=U.p;try{U.p=8,bh(e,t,n,r)}finally{U.p=a,H.T=i}}function bh(e,t,n,r){if(_h){var i=xh(r);if(i===null)Kf(e,t,r,Sh,n),Nh(e,r);else if(Fh(i,e,t,n,r))r.stopPropagation();else if(Nh(e,r),t&4&&-1<Mh.indexOf(e)){for(;i!==null;){var a=wt(i);if(a!==null)switch(a.tag){case 3:if(a=a.stateNode,a.current.memoizedState.isDehydrated){var o=$e(a.pendingLanes);if(o!==0){var s=a;for(s.pendingLanes|=2,s.entangledLanes|=2;o;){var c=1<<31-qe(o);s.entanglements[1]|=c,o&=~c}Tf(a),!(Ju&6)&&(md=Ie()+500,Ef(0,!1))}}break;case 31:case 13:s=_i(a,2),s!==null&&Md(s,a,2),Ld(),mh(a,2)}if(a=xh(r),a===null&&Kf(e,t,r,Sh,n),a===i)break;i=a}i!==null&&r.stopPropagation()}else Kf(e,t,r,null,n)}}function xh(e){return e=un(e),Ch(e)}var Sh=null;function Ch(e){if(Sh=null,e=Ct(e),e!==null){var t=o(e);if(t===null)e=null;else{var n=t.tag;if(n===13){if(e=s(t),e!==null)return e;e=null}else if(n===31){if(e=c(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return Sh=e,null}function wh(e){switch(e){case`beforetoggle`:case`cancel`:case`click`:case`close`:case`contextmenu`:case`copy`:case`cut`:case`auxclick`:case`dblclick`:case`dragend`:case`dragstart`:case`drop`:case`focusin`:case`focusout`:case`input`:case`invalid`:case`keydown`:case`keypress`:case`keyup`:case`mousedown`:case`mouseup`:case`paste`:case`pause`:case`play`:case`pointercancel`:case`pointerdown`:case`pointerup`:case`ratechange`:case`reset`:case`seeked`:case`submit`:case`toggle`:case`touchcancel`:case`touchend`:case`touchstart`:case`volumechange`:case`change`:case`selectionchange`:case`textInput`:case`compositionstart`:case`compositionend`:case`compositionupdate`:case`beforeblur`:case`afterblur`:case`beforeinput`:case`blur`:case`fullscreenchange`:case`fullscreenerror`:case`focus`:case`hashchange`:case`popstate`:case`select`:case`selectstart`:return 2;case`drag`:case`dragenter`:case`dragexit`:case`dragleave`:case`dragover`:case`mousemove`:case`mouseout`:case`mouseover`:case`pointermove`:case`pointerout`:case`pointerover`:case`resize`:case`scroll`:case`touchmove`:case`wheel`:case`mouseenter`:case`mouseleave`:case`pointerenter`:case`pointerleave`:return 8;case`message`:switch(Le()){case Re:return 2;case ze:return 8;case Be:case Ve:return 32;case He:return 268435456;default:return 32}default:return 32}}var Th=!1,Eh=null,Dh=null,Oh=null,kh=new Map,Ah=new Map,jh=[],Mh=`mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset`.split(` `);function Nh(e,t){switch(e){case`focusin`:case`focusout`:Eh=null;break;case`dragenter`:case`dragleave`:Dh=null;break;case`mouseover`:case`mouseout`:Oh=null;break;case`pointerover`:case`pointerout`:kh.delete(t.pointerId);break;case`gotpointercapture`:case`lostpointercapture`:Ah.delete(t.pointerId)}}function Ph(e,t,n,r,i,a){return e===null||e.nativeEvent!==a?(e={blockedOn:t,domEventName:n,eventSystemFlags:r,nativeEvent:a,targetContainers:[i]},t!==null&&(t=wt(t),t!==null&&hh(t)),e):(e.eventSystemFlags|=r,t=e.targetContainers,i!==null&&t.indexOf(i)===-1&&t.push(i),e)}function Fh(e,t,n,r,i){switch(t){case`focusin`:return Eh=Ph(Eh,e,t,n,r,i),!0;case`dragenter`:return Dh=Ph(Dh,e,t,n,r,i),!0;case`mouseover`:return Oh=Ph(Oh,e,t,n,r,i),!0;case`pointerover`:var a=i.pointerId;return kh.set(a,Ph(kh.get(a)||null,e,t,n,r,i)),!0;case`gotpointercapture`:return a=i.pointerId,Ah.set(a,Ph(Ah.get(a)||null,e,t,n,r,i)),!0}return!1}function Ih(e){var t=Ct(e.target);if(t!==null){var n=o(t);if(n!==null){if(t=n.tag,t===13){if(t=s(n),t!==null){e.blockedOn=t,mt(e.priority,function(){gh(n)});return}}else if(t===31){if(t=c(n),t!==null){e.blockedOn=t,mt(e.priority,function(){gh(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function Lh(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=xh(e.nativeEvent);if(n===null){n=e.nativeEvent;var r=new n.constructor(n.type,n);ln=r,n.target.dispatchEvent(r),ln=null}else return t=wt(n),t!==null&&hh(t),e.blockedOn=n,!1;t.shift()}return!0}function Rh(e,t,n){Lh(e)&&n.delete(t)}function zh(){Th=!1,Eh!==null&&Lh(Eh)&&(Eh=null),Dh!==null&&Lh(Dh)&&(Dh=null),Oh!==null&&Lh(Oh)&&(Oh=null),kh.forEach(Rh),Ah.forEach(Rh)}function Bh(e,n){e.blockedOn===n&&(e.blockedOn=null,Th||(Th=!0,t.unstable_scheduleCallback(t.unstable_NormalPriority,zh)))}var Vh=null;function Hh(e){Vh!==e&&(Vh=e,t.unstable_scheduleCallback(t.unstable_NormalPriority,function(){Vh===e&&(Vh=null);for(var t=0;t<e.length;t+=3){var n=e[t],r=e[t+1],i=e[t+2];if(typeof r!=`function`){if(Ch(r||n)===null)continue;break}var a=wt(n);a!==null&&(e.splice(t,3),t-=3,Ks(a,{pending:!0,data:i,method:n.method,action:r},r,i))}}))}function Uh(e){function t(t){return Bh(t,e)}Eh!==null&&Bh(Eh,e),Dh!==null&&Bh(Dh,e),Oh!==null&&Bh(Oh,e),kh.forEach(t),Ah.forEach(t);for(var n=0;n<jh.length;n++){var r=jh[n];r.blockedOn===e&&(r.blockedOn=null)}for(;0<jh.length&&(n=jh[0],n.blockedOn===null);)Ih(n),n.blockedOn===null&&jh.shift();if(n=(e.ownerDocument||e).$$reactFormReplay,n!=null)for(r=0;r<n.length;r+=3){var i=n[r],a=n[r+1],o=i[q]||null;if(typeof a==`function`)o||Hh(n);else if(o){var s=null;if(a&&a.hasAttribute(`formAction`)){if(i=a,o=a[q]||null)s=o.formAction;else if(Ch(i)!==null)continue}else s=o.action;typeof s==`function`?n[r+1]=s:(n.splice(r,3),r-=3),Hh(n)}}}function Wh(){function e(e){e.canIntercept&&e.info===`react-transition`&&e.intercept({handler:function(){return new Promise(function(e){return i=e})},focusReset:`manual`,scroll:`manual`})}function t(){i!==null&&(i(),i=null),r||setTimeout(n,20)}function n(){if(!r&&!navigation.transition){var e=navigation.currentEntry;e&&e.url!=null&&navigation.navigate(e.url,{state:e.getState(),info:`react-transition`,history:`replace`})}}if(typeof navigation==`object`){var r=!1,i=null;return navigation.addEventListener(`navigate`,e),navigation.addEventListener(`navigatesuccess`,t),navigation.addEventListener(`navigateerror`,t),setTimeout(n,100),function(){r=!0,navigation.removeEventListener(`navigate`,e),navigation.removeEventListener(`navigatesuccess`,t),navigation.removeEventListener(`navigateerror`,t),i!==null&&(i(),i=null)}}}function Gh(e){this._internalRoot=e}Kh.prototype.render=Gh.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(i(409));var n=t.current;fh(n,kd(),e,t,null,null)},Kh.prototype.unmount=Gh.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;fh(e.current,2,null,e,null,null),Ld(),t[gt]=null}};function Kh(e){this._internalRoot=e}Kh.prototype.unstable_scheduleHydration=function(e){if(e){var t=pt();e={blockedOn:null,target:e,priority:t};for(var n=0;n<jh.length&&t!==0&&t<jh[n].priority;n++);jh.splice(n,0,e),n===0&&Ih(e)}};var qh=n.version;if(qh!==`19.3.1`)throw Error(i(527,qh,`19.3.1`));U.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render==`function`?Error(i(188)):(e=Object.keys(e).join(`,`),Error(i(268,e)));return e=u(t),e=e===null?null:f(e),e=e===null?null:e.stateNode,e};var Jh={bundleType:0,version:`19.3.1`,rendererPackageName:`react-dom`,currentDispatcherRef:H,reconcilerVersion:`19.3.1`};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`){var Yh=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Yh.isDisabled&&Yh.supportsFiber)try{Ge=Yh.inject(Jh),W=Yh}catch{}}e.createRoot=function(e,t){if(!a(e))throw Error(i(299));var n=!1,r=``,o=hc,s=gc,c=_c;return t!=null&&(!0===t.unstable_strictMode&&(n=!0),t.identifierPrefix!==void 0&&(r=t.identifierPrefix),t.onUncaughtError!==void 0&&(o=t.onUncaughtError),t.onCaughtError!==void 0&&(s=t.onCaughtError),t.onRecoverableError!==void 0&&(c=t.onRecoverableError)),t=uh(e,1,!1,null,null,n,r,null,o,s,c,Wh),e[gt]=t.current,Wf(e),new Gh(t)}})),_=o(((e,t)=>{function n(){if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE==`function`)try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)}catch(e){console.error(e)}}n(),t.exports=g()})),v=c(p()),y=_();function b(e){if(!e)return``;let t=e.trim();if(!t||/^location\s*\(?/i.test(t)||/^lat/i.test(t)||t.toLowerCase()===`location unavailable`)return``;t=t.replace(/^(?:stop\s*#?\d+\s*[-:–—]\s*|#?0+\d+\s*[-:–—]\s*)/i,``).trim();let n=t.match(/^(?:apt\.?|apartment|unit|suite|ste\.?|room|rm\.?)\s*#?[a-z0-9-]+\s*,\s*(.+)$/i);n&&(t=n[1].trim());let r=t.match(/^(?:#|no\.?\s*)?(\d+[A-Za-z]?(?:[-\/][A-Za-z0-9]+)?)\s+([A-Za-z0-9#])/i);if(r&&!/^0+\d+$/.test(r[1]))return r[1];let i=t.match(/(?:^|[,\s])(?:#|no\.?\s*)?(\d+[A-Za-z]?(?:[-\/][A-Za-z0-9]+)?)\s+(?:[NSEW]\.?\s+)?([A-Za-z0-9\s]+?\s+(?:st|street|rd|road|ave|avenue|ln|lane|dr|drive|blvd|boulevard|way|ct|court|cir|circle|pl|place|ter|terrace|pkwy|parkway))\b/i);if(i&&!/^0+\d+$/.test(i[1]))return i[1];let a=t.match(/^(?:#|no\.?\s*)?(\d+[A-Za-z]?(?:[-\/][A-Za-z0-9]+)?)\b/i);return a&&!/^0+\d+$/.test(a[1])?a[1]:``}function x(e,t){if(!e)return`—`;let n=[e.fullAddress,e.desc,e.cmt,e.streetName,e.notes];for(let e of n)if(e){let t=b(e);if(t)return t}if(e.houseNumber&&e.houseNumber.trim()){let n=e.houseNumber.trim();if(!(/^0+\d+$/.test(n)||e.orderIndex&&n===String(e.orderIndex)||t!==void 0&&n===String(t+1)))return n}if(e.name){let n=b(e.name);if(n&&!(/^0+\d+$/.test(n)||e.orderIndex&&n===String(e.orderIndex)||t!==void 0&&n===String(t+1)))return n}return`—`}function S(e){let t=(e||``).trim();if(!t)return{houseNumber:``,streetName:``,fullAddress:``};if(/^location\s*\(?/i.test(t)||t.toLowerCase()===`location unavailable`)return{houseNumber:``,streetName:t,fullAddress:t};let n=t.replace(/^(?:stop\s*#?\d+\s*[-:–—]\s*|#?0+\d+\s*[-:–—]\s*)/i,``).trim(),r=n.match(/^(?:apt\.?|apartment|unit|suite|ste\.?|room|rm\.?)\s*#?[a-z0-9-]+\s*,\s*(.+)$/i);r&&(n=r[1].trim());let i=b(n),a=n;if(i){let e=n.indexOf(i);if(e!==-1){let t=n.slice(e+i.length).trim(),r=t.indexOf(`,`);a=r===-1?t:t.slice(0,r).trim()}}return{houseNumber:i,streetName:a||t,fullAddress:t}}function C(e,t){return!isNaN(e)&&!isNaN(t)&&e>=-90&&e<=90&&t>=-180&&t<=180&&(e!==0||t!==0)}function w(e,t){let n=e.getElementsByTagName(t)[0];if(n?.textContent&&n.textContent.trim())return n.textContent.trim();let r=Array.from(e.children);for(let e of r){if((e.localName===t||e.nodeName.endsWith(`:${t}`))&&e.textContent?.trim())return e.textContent.trim();for(let n of Array.from(e.children))if((n.localName===t||n.nodeName.endsWith(`:${t}`))&&n.textContent?.trim())return n.textContent.trim()}return``}function T(e,t=`Imported Route`){let n=(e||``).replace(/^\uFEFF/,``).trim();if(!n)throw Error(`File content is empty.`);let r;if(typeof DOMParser<`u`)r=new DOMParser().parseFromString(n,`text/xml`);else throw Error(`DOMParser unavailable in current runtime`);if(r.getElementsByTagName(`parsererror`)[0])throw Error(`Invalid GPX/XML format. Please verify the file contains valid route/waypoint XML.`);let i=t,a=r.getElementsByTagName(`metadata`)[0],o=a?w(a,`name`):``,s=w(r.documentElement,`name`);o?i=o:s&&(i=s);let c=Array.from(r.getElementsByTagName(`wpt`));if(c.length===0&&(c=Array.from(r.getElementsByTagName(`rtept`))),c.length===0&&(c=Array.from(r.getElementsByTagName(`trkpt`))),c.length===0)throw Error(`No customer waypoints (<wpt> or <rtept>) found in this GPX file.`);let l=[];return c.forEach((e,t)=>{let n=e.getAttribute(`lat`),r=e.getAttribute(`lon`),i=n?parseFloat(n):NaN,a=r?parseFloat(r):NaN,o=C(i,a),s=o?i:0,c=o?a:0,u=w(e,`name`),d=w(e,`desc`),f=w(e,`cmt`),p=w(e,`address`),m=w(e,`housenumber`),h=w(e,`street`),g=u||`Customer #${t+1}`,_=p||d||f,v=``;if(u.includes(` - `)||u.includes(` – `)){let e=u.split(/\s*[-–]\s*/);e.length>=2&&(/^(?:stop\s*)?#?\d+$/i.test(e[0].trim())?(g=e.slice(1).join(` - `).trim(),/^\d+[A-Za-z]?\s+[A-Za-z]/.test(g)&&(v=g)):/^(?:stop\s*)?#?\d+$/i.test(e[e.length-1].trim())&&(g=e.slice(0,e.length-1).join(` - `).trim()))}else/^#?0*\d+$/.test(u.trim())&&(g=`Customer #${parseInt(u.trim().replace(`#`,``),10)||t+1}`);!_&&v&&(_=v),_||=o?`Location (${s.toFixed(5)}, ${c.toFixed(5)})`:`Location unavailable`;let{houseNumber:y,streetName:b,fullAddress:x}=S(_),T=y;if(!T&&m&&!/^0+\d+$/.test(m.trim())&&(T=m.trim()),!T&&g){let e=S(g);e.houseNumber&&!/^0+\d+$/.test(e.houseNumber)&&(T=e.houseNumber)}let E=h||b||``;l.push({id:`stop-${t+1}-${Date.now().toString(36)}-${Math.random().toString(36).substring(2,6)}`,orderIndex:t+1,name:g,houseNumber:T,fullAddress:x,streetName:E,lat:s,lon:c,desc:d||void 0,cmt:f||void 0,status:`pending`})}),{stops:l,routeName:i}}function E(e,t=`Customer Route`){return`<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="OsmAnd Route Companion" xmlns="http://www.topografix.com/GPX/1/1" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.topografix.com/GPX/1/1 http://www.topografix.com/GPX/1/1/gpx.xsd">
  <metadata>
    <name>${D(t)}</name>
    <desc>Customer route stops in sequential order</desc>
    <time>${new Date().toISOString()}</time>
  </metadata>
`+e.map(e=>`  <wpt lat="${e.lat}" lon="${e.lon}">
    <name>${D(e.name)}</name>
    <desc>${D(e.fullAddress)}</desc>
    <cmt>${D(`House #${e.houseNumber||`N/A`} - Status: ${e.status}`)}</cmt>
  </wpt>`).join(`
`)+`
</gpx>`}function D(e){return(e||``).replace(/[<>&'"]/g,e=>{switch(e){case`<`:return`&lt;`;case`>`:return`&gt;`;case`&`:return`&amp;`;case`'`:return`&apos;`;case`"`:return`&quot;`;default:return e}})}var O=[{id:`residential-route-springfield`,title:`North Springfield Residential Route (20 Stops)`,description:`Sequenced customer stops for residential service with distinct house numbers & notes`,stopCount:20,gpxXml:`<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="OsmAnd Route Companion" xmlns="http://www.topografix.com/GPX/1/1">
  <metadata>
    <name>North Springfield Residential Route</name>
    <desc>Customer collection and service route in sequence</desc>
  </metadata>
  <wpt lat="39.7990" lon="-89.6438">
    <name>Eleanor &amp; Frank Davies</name>
    <desc>104 Maple Grove Ave, Springfield, IL 62702</desc>
    <cmt>Side gate accessible, watch for golden retriever</cmt>
  </wpt>
  <wpt lat="39.8005" lon="-89.6450">
    <name>Marcus Vance</name>
    <desc>112 Maple Grove Ave, Springfield, IL 62702</desc>
    <cmt>Bin beside garage, ring bell if blocked</cmt>
  </wpt>
  <wpt lat="39.8018" lon="-89.6462">
    <name>Sophia Ramirez</name>
    <desc>128 Maple Grove Ave, Springfield, IL 62702</desc>
    <cmt>Curbside pickup requested</cmt>
  </wpt>
  <wpt lat="39.8035" lon="-89.6480">
    <name>Dr. Arthur Pendelton</name>
    <desc>215 Willow Creek Rd, Springfield, IL 62702</desc>
    <cmt>Long gravel driveway, turn around at circle</cmt>
  </wpt>
  <wpt lat="39.8049" lon="-89.6495">
    <name>Elena Rostova</name>
    <desc>229 Willow Creek Rd, Springfield, IL 62702</desc>
    <cmt>House number on stone mailbox</cmt>
  </wpt>
  <wpt lat="39.8062" lon="-89.6512">
    <name>Jackson &amp; Maya Miller</name>
    <desc>241 Willow Creek Rd, Springfield, IL 62702</desc>
    <cmt>Yellow house on corner</cmt>
  </wpt>
  <wpt lat="39.8080" lon="-89.6530">
    <name>Robert K. Sterling</name>
    <desc>304 Sycamore Lane, Springfield, IL 62702</desc>
    <cmt>Back alley approach preferred</cmt>
  </wpt>
  <wpt lat="39.8095" lon="-89.6548">
    <name>Hannah &amp; Liam Chen</name>
    <desc>318 Sycamore Lane, Springfield, IL 62702</desc>
    <cmt>Ring doorbell after stop</cmt>
  </wpt>
  <wpt lat="39.8110" lon="-89.6565">
    <name>George Henderson</name>
    <desc>330 Sycamore Lane, Springfield, IL 62702</desc>
    <cmt>Code for gate #4421</cmt>
  </wpt>
  <wpt lat="39.8125" lon="-89.6582">
    <name>Patricia &amp; Carl Kowalski</name>
    <desc>402 Birchwood Court, Springfield, IL 62702</desc>
    <cmt>Cul-de-sac house at end on left</cmt>
  </wpt>
  <wpt lat="39.8138" lon="-89.6601">
    <name>Devon Washington</name>
    <desc>415 Birchwood Court, Springfield, IL 62702</desc>
    <cmt>Leave invoice in mailbox slot</cmt>
  </wpt>
  <wpt lat="39.8152" lon="-89.6618">
    <name>Chloe &amp; Noah Bennett</name>
    <desc>520 Cedar Crest Way, Springfield, IL 62702</desc>
    <cmt>Red brick house with circular portico</cmt>
  </wpt>
  <wpt lat="39.8168" lon="-89.6635">
    <name>Samuel Ortiz</name>
    <desc>534 Cedar Crest Way, Springfield, IL 62702</desc>
    <cmt>Customer works from home, quiet approach</cmt>
  </wpt>
  <wpt lat="39.8182" lon="-89.6652">
    <name>Miriam Goldstein</name>
    <desc>601 Pine Needle Drive, Springfield, IL 62702</desc>
    <cmt>Keycard box next to service door</cmt>
  </wpt>
  <wpt lat="39.8198" lon="-89.6670">
    <name>Thomas &amp; Valerie Reed</name>
    <desc>615 Pine Needle Drive, Springfield, IL 62702</desc>
    <cmt>House number illuminated on porch column</cmt>
  </wpt>
  <wpt lat="39.8215" lon="-89.6690">
    <name>Amina Al-Mansoor</name>
    <desc>722 Juniper Park Blvd, Springfield, IL 62702</desc>
    <cmt>Corner lot with white vinyl fence</cmt>
  </wpt>
  <wpt lat="39.8230" lon="-89.6708">
    <name>Kenneth O'Connor</name>
    <desc>736 Juniper Park Blvd, Springfield, IL 62702</desc>
    <cmt>Please close latch securely</cmt>
  </wpt>
  <wpt lat="39.8248" lon="-89.6725">
    <name>Zoe &amp; Lucas Taylor</name>
    <desc>802 Hawthorn Ridge, Springfield, IL 62702</desc>
    <cmt>Call before arrival if gate locked</cmt>
  </wpt>
  <wpt lat="39.8265" lon="-89.6742">
    <name>Geraldine Brooks</name>
    <desc>818 Hawthorn Ridge, Springfield, IL 62702</desc>
    <cmt>Elderly resident, curbside staging</cmt>
  </wpt>
  <wpt lat="39.8280" lon="-89.6760">
    <name>Victor &amp; Beatrice Moreno</name>
    <desc>834 Hawthorn Ridge, Springfield, IL 62702</desc>
    <cmt>Final customer on morning route block</cmt>
  </wpt>
</gpx>`},{id:`commercial-route-metro`,title:`Metro Commercial Route (10 Stops)`,description:`Commercial facilities, clinics, and businesses with suite numbers`,stopCount:10,gpxXml:`<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="OsmAnd Route Companion" xmlns="http://www.topografix.com/GPX/1/1">
  <metadata>
    <name>Metro Commercial Route</name>
    <desc>Commercial client sequence</desc>
  </metadata>
  <wpt lat="39.7810" lon="-89.6500">
    <name>Apex Medical Labs - Suite 100</name>
    <desc>500 S 6th St, Springfield, IL 62701</desc>
    <cmt>Rear loading dock entrance, press buzzer B</cmt>
  </wpt>
  <wpt lat="39.7835" lon="-89.6520">
    <name>Capitol City Bakery</name>
    <desc>412 E Monroe St, Springfield, IL 62701</desc>
    <cmt>Service alley between 4th &amp; 5th</cmt>
  </wpt>
  <wpt lat="39.7860" lon="-89.6540">
    <name>Heritage Law Offices</name>
    <desc>620 E Adams St, Suite 300, Springfield, IL 62701</desc>
    <cmt>Elevator access to 3rd floor</cmt>
  </wpt>
  <wpt lat="39.7890" lon="-89.6570">
    <name>Lincoln Park Dental Clinic</name>
    <desc>805 N 9th St, Springfield, IL 62702</desc>
    <cmt>Staff entrance on north side</cmt>
  </wpt>
  <wpt lat="39.7920" lon="-89.6600">
    <name>Prairie State Veterinary</name>
    <desc>1120 N Walnut St, Springfield, IL 62702</desc>
    <cmt>Doorbell labeled Delivery/Service</cmt>
  </wpt>
  <wpt lat="39.7950" lon="-89.6630">
    <name>Oak Crest Senior Living</name>
    <desc>1400 W Washington St, Springfield, IL 62702</desc>
    <cmt>Check in at security desk Building A</cmt>
  </wpt>
  <wpt lat="39.7980" lon="-89.6660">
    <name>Green Valley Nursery</name>
    <desc>1850 W Jefferson St, Springfield, IL 62702</desc>
    <cmt>Drive through main gravel yard to warehouse</cmt>
  </wpt>
  <wpt lat="39.8010" lon="-89.6690">
    <name>Westside Auto Diagnostics</name>
    <desc>2204 W Monroe St, Springfield, IL 62704</desc>
    <cmt>Bay 3 entrance, ask for Sal</cmt>
  </wpt>
  <wpt lat="39.8040" lon="-89.6720">
    <name>Midwest Fitness Center</name>
    <desc>2600 S MacArthur Blvd, Springfield, IL 62704</desc>
    <cmt>South equipment dock</cmt>
  </wpt>
  <wpt lat="39.8070" lon="-89.6750">
    <name>Chatham Community Bank</name>
    <desc>3100 S 6th St, Springfield, IL 62703</desc>
    <cmt>Authorized personnel entry only</cmt>
  </wpt>
</gpx>`}];function k(e=`tap`){if(typeof window<`u`){try{let t=window.AndroidBridge;if(t&&typeof t.vibrate==`function`){t.vibrate(e);return}}catch{}if(`vibrate`in navigator)try{switch(e){case`skip`:navigator.vibrate([60,40,80]);break;case`next`:navigator.vibrate(45);break;case`undo`:navigator.vibrate([30,30,30]);break;case`complete`:navigator.vibrate([100,50,100,50,150]);break;default:navigator.vibrate(30)}}catch{}}}function A(e,t,n){if(typeof window>`u`)return;let r=`Next customer: ${e}.`;t&&(r+=` Number ${t}, ${n||``}`);try{let e=window.AndroidBridge;if(e&&typeof e.speak==`function`){e.speak(r);return}}catch{}if(`speechSynthesis`in window)try{window.speechSynthesis.cancel();let e=new SpeechSynthesisUtterance(r);e.rate=1.05,e.pitch=1,e.volume=1,window.speechSynthesis.speak(e)}catch{}}var j=0;function M(){if(typeof window>`u`)return;let e=Date.now();if(e-j<12e3)return;j=e;let t=`Turn around as soon as possible.`;try{let e=window.AndroidBridge;if(e&&typeof e.speak==`function`){e.speak(t);return}}catch{}if(`speechSynthesis`in window)try{window.speechSynthesis.cancel();let e=new SpeechSynthesisUtterance(t);e.rate=1.05,e.pitch=1,e.volume=1,window.speechSynthesis.speak(e)}catch{}}var ee=null;async function N(){if(typeof window>`u`)return!1;if(window.AndroidBridge)return!0;if(!(`wakeLock`in navigator))return!1;try{return ee=await navigator.wakeLock.request(`screen`),ee.addEventListener(`release`,()=>{ee=null}),!0}catch{return!1}}function P(){if(ee){try{ee.release()}catch{}ee=null}}function F(e,t,n,r){if(isNaN(e)||isNaN(t)||isNaN(n)||isNaN(r)||e===0&&t===0||n===0&&r===0)return 1/0;let i=(n-e)*(Math.PI/180),a=(r-t)*(Math.PI/180),o=Math.sin(i/2)*Math.sin(i/2)+Math.cos(Math.PI/180*e)*Math.cos(Math.PI/180*n)*Math.sin(a/2)*Math.sin(a/2);return 6371e3*(2*Math.atan2(Math.sqrt(o),Math.sqrt(1-o)))}function I(e,t,n){if(!n||n.length<2)return 1/0;let r=111132.92,i=111412.84*Math.cos(e*Math.PI/180),a=1/0;for(let o=0;o<n.length-1;o++){let[s,c]=n[o],[l,u]=n[o+1],d=(t-s)*i,f=(e-c)*r,p=(l-s)*i,m=(u-c)*r,h=p*p+m*m,g;if(h===0)g=Math.sqrt(d*d+f*f);else{let e=Math.max(0,Math.min(1,(d*p+f*m)/h)),t=e*p,n=e*m,r=d-t,i=f-n;g=Math.sqrt(r*r+i*i)}g<a&&(a=g)}return a}function R(e,t,n,r=0){if(!n||n.length===0)return{remainingMeters:0,closestSegmentIndex:0};if(n.length===1)return{remainingMeters:F(e,t,n[0][1],n[0][0]),closestSegmentIndex:0};let i=111132.92,a=111412.84*Math.cos(e*Math.PI/180),o=Math.max(0,Math.min(r,n.length-2)),s=1/0,c=0,l=Math.max(0,r-2);for(let r=l;r<n.length-1;r++){let[l,u]=n[r],[d,f]=n[r+1],p=(t-l)*a,m=(e-u)*i,h=(d-l)*a,g=(f-u)*i,_=h*h+g*g;if(_===0)continue;let v=Math.max(0,Math.min(1,(p*h+m*g)/_)),y=v*h,b=v*g,x=p-y,S=m-b,C=x*x+S*S;C<s&&(s=C,o=r,c=v)}let[u,d]=n[o],[f,p]=n[o+1],m=F(d,u,p,f),h=Math.max(0,(1-c)*m);for(let e=o+1;e<n.length-1;e++)h+=F(n[e][1],n[e][0],n[e+1][1],n[e+1][0]);return{remainingMeters:Math.max(0,Math.round(h)),closestSegmentIndex:o}}function z(e,t,n,r){let i=Math.sin((r-t)*(Math.PI/180))*Math.cos(Math.PI/180*n),a=Math.cos(Math.PI/180*e)*Math.sin(Math.PI/180*n)-Math.sin(Math.PI/180*e)*Math.cos(Math.PI/180*n)*Math.cos((r-t)*(Math.PI/180));return(Math.atan2(i,a)*180/Math.PI+360)%360}function B(e,t=!1){if(isNaN(e)||e<0)return`0 ft`;if(t)return e<1e3?`${Math.round(e)} m`:`${(e/1e3).toFixed(1)} km`;let n=e*3.28084;if(n<1e3)return n>200?`${Math.round(n/50)*50} ft`:`${Math.max(10,Math.round(n/10)*10)} ft`;let r=n/5280;return r<10?`${r.toFixed(1)} mi`:`${Math.round(r)} mi`}function te(e,t,n,r){let i=n&&n.trim()?n.trim():``,a=(t||``).toLowerCase(),o=(e||``).toLowerCase();if(o===`arrive`)return r?`Arrive at ${r}`:`Arrive at destination`;if(o===`depart`)return i?`Head out onto ${i}`:`Head toward destination`;if(o===`merge`)return a.includes(`left`)?i?`Merge left onto ${i}`:`Merge left`:i?`Merge right onto ${i}`:`Merge right`;if(o===`on ramp`||o===`off ramp`||o===`ramp`)return i?`Take ramp onto ${i}`:`Take ramp`;if(o===`fork`)return a.includes(`left`)?i?`Keep left at fork onto ${i}`:`Keep left at fork`:i?`Keep right at fork onto ${i}`:`Keep right at fork`;if(o===`roundabout`||o===`rotary`)return i?`Enter roundabout toward ${i}`:`Enter roundabout`;if(o===`end of road`)return a.includes(`left`)?i?`Turn left at end onto ${i}`:`Turn left at end of road`:i?`Turn right at end onto ${i}`:`Turn right at end of road`;if(a.includes(`uturn`)||a===`uturn`||a.includes(`turnaround`)||a.includes(`turn around`)||o===`turnaround`)return`Turn around as soon as possible.`;switch(a){case`left`:return i?`Turn left onto ${i}`:`Turn left`;case`right`:return i?`Turn right onto ${i}`:`Turn right`;case`slight left`:return i?`Bear slightly left onto ${i}`:`Bear slightly left`;case`slight right`:return i?`Bear slightly right onto ${i}`:`Bear slightly right`;case`sharp left`:return i?`Make a sharp left onto ${i}`:`Sharp left`;case`sharp right`:return i?`Make a sharp right onto ${i}`:`Sharp right`;case`straight`:return i?`Continue straight on ${i}`:`Continue straight`;default:return o===`continue`||o===`new name`?i?`Continue onto ${i}`:`Continue straight`:i?`Proceed onto ${i}`:`Proceed along route`}}async function ne(e,t,n,r,i,a){let o=typeof a==`number`&&!isNaN(a)&&a>=0&&a<=360,s=`https://router.project-osrm.org/route/v1/driving/${t},${e};${r},${n}?steps=true&overview=full&geometries=geojson&continue_straight=false`,c=async e=>{let t=new AbortController,n=setTimeout(()=>t.abort(),7e3);try{let r=await fetch(e,{signal:t.signal});if(clearTimeout(n),!r.ok)throw Error(`Routing server HTTP ${r.status}`);return await r.json()}catch(e){throw clearTimeout(n),e}},l=null;if(o)try{let e=await c(`${s}&bearings=${Math.round(a)},60;`);e.code===`Ok`&&e.routes&&e.routes.length>0&&(l=e)}catch{}if(l||=await c(s),l.code!==`Ok`||!l.routes||l.routes.length===0)throw Error(`No driving route found between coordinates`);let u=l.routes[0],d=u.legs?.[0]?.steps||[],f=u.geometry?.coordinates||[],p=!1;return{maneuvers:d.map(e=>{let t=e.maneuver?.type||`turn`,a=e.maneuver?.modifier,o=e.name||``,s=te(t,a,o,i),c=e.maneuver?.location||[r,n];return a&&a.toLowerCase().includes(`uturn`)&&(p=!0),{type:t,modifier:a,instruction:s,streetName:o,distanceMeters:e.distance||0,location:c}}),totalDistance:u.distance||0,totalDuration:u.duration||0,coordinates:f,hasUturn:p}}var re=e=>e.replace(/([a-z0-9])([A-Z])/g,`$1-$2`).toLowerCase(),ie=e=>e.replace(/^([A-Z])|[\s-_]+(\w)/g,(e,t,n)=>n?n.toUpperCase():t.toLowerCase()),ae=e=>{let t=ie(e);return t.charAt(0).toUpperCase()+t.slice(1)},oe=(...e)=>e.filter((e,t,n)=>!!e&&e.trim()!==``&&n.indexOf(e)===t).join(` `).trim(),se=e=>{for(let t in e)if(t.startsWith(`aria-`)||t===`role`||t===`title`)return!0},ce={xmlns:`http://www.w3.org/2000/svg`,width:24,height:24,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:2,strokeLinecap:`round`,strokeLinejoin:`round`},le=(0,v.forwardRef)(({color:e=`currentColor`,size:t=24,strokeWidth:n=2,absoluteStrokeWidth:r,className:i=``,children:a,iconNode:o,...s},c)=>(0,v.createElement)(`svg`,{ref:c,...ce,width:t,height:t,stroke:e,strokeWidth:r?Number(n)*24/Number(t):n,className:oe(`lucide`,i),...!a&&!se(s)&&{"aria-hidden":`true`},...s},[...o.map(([e,t])=>(0,v.createElement)(e,t)),...Array.isArray(a)?a:[a]])),V=(e,t)=>{let n=(0,v.forwardRef)(({className:n,...r},i)=>(0,v.createElement)(le,{ref:i,iconNode:t,className:oe(`lucide-${re(ae(e))}`,`lucide-${e}`,n),...r}));return n.displayName=ae(e),n},H=V(`arrow-up-left`,[[`path`,{d:`M7 17V7h10`,key:`11bw93`}],[`path`,{d:`M17 17 7 7`,key:`2786uv`}]]),U=V(`arrow-up-right`,[[`path`,{d:`M7 7h10v10`,key:`1tivn9`}],[`path`,{d:`M7 17 17 7`,key:`1vkiza`}]]),ue=V(`arrow-up`,[[`path`,{d:`m5 12 7-7 7 7`,key:`hav0vg`}],[`path`,{d:`M12 19V5`,key:`x0mq9r`}]]),de=V(`chevron-left`,[[`path`,{d:`m15 18-6-6 6-6`,key:`1wnfg3`}]]),fe=V(`circle-alert`,[[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}],[`line`,{x1:`12`,x2:`12`,y1:`8`,y2:`12`,key:`1pkeuh`}],[`line`,{x1:`12`,x2:`12.01`,y1:`16`,y2:`16`,key:`4dfq90`}]]),pe=V(`circle-check-big`,[[`path`,{d:`M21.801 10A10 10 0 1 1 17 3.335`,key:`yps3ct`}],[`path`,{d:`m9 11 3 3L22 4`,key:`1pflzl`}]]),me=V(`circle-check`,[[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}],[`path`,{d:`m9 12 2 2 4-4`,key:`dzmm74`}]]),he=V(`circle-dot`,[[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}],[`circle`,{cx:`12`,cy:`12`,r:`1`,key:`41hilf`}]]),ge=V(`clock`,[[`path`,{d:`M12 6v6l4 2`,key:`mmk7yg`}],[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}]]),_e=V(`cloud-upload`,[[`path`,{d:`M12 13v8`,key:`1l5pq0`}],[`path`,{d:`M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242`,key:`1pljnt`}],[`path`,{d:`m8 17 4-4 4 4`,key:`1quai1`}]]),ve=V(`compass`,[[`path`,{d:`m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z`,key:`9ktpf1`}],[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}]]),ye=V(`corner-up-left`,[[`path`,{d:`M20 20v-7a4 4 0 0 0-4-4H4`,key:`1nkjon`}],[`path`,{d:`M9 14 4 9l5-5`,key:`102s5s`}]]),be=V(`corner-up-right`,[[`path`,{d:`m15 14 5-5-5-5`,key:`12vg1m`}],[`path`,{d:`M4 20v-7a4 4 0 0 1 4-4h12`,key:`1lu4f8`}]]),xe=V(`crosshair`,[[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}],[`line`,{x1:`22`,x2:`18`,y1:`12`,y2:`12`,key:`l9bcsi`}],[`line`,{x1:`6`,x2:`2`,y1:`12`,y2:`12`,key:`13hhkx`}],[`line`,{x1:`12`,x2:`12`,y1:`6`,y2:`2`,key:`10w3f3`}],[`line`,{x1:`12`,x2:`12`,y1:`22`,y2:`18`,key:`15g9kq`}]]),Se=V(`download`,[[`path`,{d:`M12 15V3`,key:`m9g1x1`}],[`path`,{d:`M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4`,key:`ih7n3h`}],[`path`,{d:`m7 10 5 5 5-5`,key:`brsn70`}]]),Ce=V(`eye`,[[`path`,{d:`M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0`,key:`1nclc0`}],[`circle`,{cx:`12`,cy:`12`,r:`3`,key:`1v7zrd`}]]),we=V(`file-archive`,[[`path`,{d:`M10 12v-1`,key:`v7bkov`}],[`path`,{d:`M10 18v-2`,key:`1cjy8d`}],[`path`,{d:`M10 7V6`,key:`dljcrl`}],[`path`,{d:`M14 2v4a2 2 0 0 0 2 2h4`,key:`tnqrlb`}],[`path`,{d:`M15.5 22H18a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v16a2 2 0 0 0 .274 1.01`,key:`gkbcor`}],[`circle`,{cx:`10`,cy:`20`,r:`2`,key:`1xzdoj`}]]),Te=V(`file-code`,[[`path`,{d:`M10 12.5 8 15l2 2.5`,key:`1tg20x`}],[`path`,{d:`m14 12.5 2 2.5-2 2.5`,key:`yinavb`}],[`path`,{d:`M14 2v4a2 2 0 0 0 2 2h4`,key:`tnqrlb`}],[`path`,{d:`M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z`,key:`1mlx9k`}]]),Ee=V(`flag`,[[`path`,{d:`M4 22V4a1 1 0 0 1 .4-.8A6 6 0 0 1 8 2c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10a1 1 0 0 1-.4.8A6 6 0 0 1 16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528`,key:`1jaruq`}]]),De=V(`folder-open`,[[`path`,{d:`m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2`,key:`usdka0`}]]),Oe=V(`git-fork`,[[`circle`,{cx:`12`,cy:`18`,r:`3`,key:`1mpf1b`}],[`circle`,{cx:`6`,cy:`6`,r:`3`,key:`1lh9wr`}],[`circle`,{cx:`18`,cy:`6`,r:`3`,key:`1h7g24`}],[`path`,{d:`M18 9v2c0 .6-.4 1-1 1H7c-.6 0-1-.4-1-1V9`,key:`1uq4wg`}],[`path`,{d:`M12 12v3`,key:`158kv8`}]]),ke=V(`info`,[[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}],[`path`,{d:`M12 16v-4`,key:`1dtifu`}],[`path`,{d:`M12 8h.01`,key:`e9boi3`}]]),Ae=V(`list-filter`,[[`path`,{d:`M2 5h20`,key:`1fs1ex`}],[`path`,{d:`M6 12h12`,key:`8npq4p`}],[`path`,{d:`M9 19h6`,key:`456am0`}]]),je=V(`list`,[[`path`,{d:`M3 5h.01`,key:`18ugdj`}],[`path`,{d:`M3 12h.01`,key:`nlz23k`}],[`path`,{d:`M3 19h.01`,key:`noohij`}],[`path`,{d:`M8 5h13`,key:`1pao27`}],[`path`,{d:`M8 12h13`,key:`1za7za`}],[`path`,{d:`M8 19h13`,key:`m83p4d`}]]),Me=V(`map`,[[`path`,{d:`M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z`,key:`169xi5`}],[`path`,{d:`M15 5.764v15`,key:`1pn4in`}],[`path`,{d:`M9 3.236v15`,key:`1uimfh`}]]),Ne=V(`moon`,[[`path`,{d:`M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401`,key:`kfwtm`}]]),Pe=V(`navigation`,[[`polygon`,{points:`3 11 22 2 13 21 11 13 3 11`,key:`1ltx0t`}]]),Fe=V(`play`,[[`path`,{d:`M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z`,key:`10ikf1`}]]),Ie=V(`rotate-ccw`,[[`path`,{d:`M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8`,key:`1357e3`}],[`path`,{d:`M3 3v5h5`,key:`1xhq8a`}]]),Le=V(`search`,[[`path`,{d:`m21 21-4.34-4.34`,key:`14j7rj`}],[`circle`,{cx:`11`,cy:`11`,r:`8`,key:`4ej97u`}]]),Re=V(`settings`,[[`path`,{d:`M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915`,key:`1i5ecw`}],[`circle`,{cx:`12`,cy:`12`,r:`3`,key:`1v7zrd`}]]),ze=V(`shield-check`,[[`path`,{d:`M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z`,key:`oel41y`}],[`path`,{d:`m9 12 2 2 4-4`,key:`dzmm74`}]]),Be=V(`skip-forward`,[[`path`,{d:`M21 4v16`,key:`7j8fe9`}],[`path`,{d:`M6.029 4.285A2 2 0 0 0 3 6v12a2 2 0 0 0 3.029 1.715l9.997-5.998a2 2 0 0 0 .003-3.432z`,key:`zs4d6`}]]),Ve=V(`smartphone`,[[`rect`,{width:`14`,height:`20`,x:`5`,y:`2`,rx:`2`,ry:`2`,key:`1yt0o3`}],[`path`,{d:`M12 18h.01`,key:`mhygvu`}]]),He=V(`sparkles`,[[`path`,{d:`M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z`,key:`1s2grr`}],[`path`,{d:`M20 2v4`,key:`1rf3ol`}],[`path`,{d:`M22 4h-4`,key:`gwowj6`}],[`circle`,{cx:`4`,cy:`20`,r:`2`,key:`6kqj1y`}]]),Ue=V(`square`,[[`rect`,{width:`18`,height:`18`,x:`3`,y:`3`,rx:`2`,key:`afitv7`}]]),We=V(`sun`,[[`circle`,{cx:`12`,cy:`12`,r:`4`,key:`4exip2`}],[`path`,{d:`M12 2v2`,key:`tus03m`}],[`path`,{d:`M12 20v2`,key:`1lh1kg`}],[`path`,{d:`m4.93 4.93 1.41 1.41`,key:`149t6j`}],[`path`,{d:`m17.66 17.66 1.41 1.41`,key:`ptbguv`}],[`path`,{d:`M2 12h2`,key:`1t8f8n`}],[`path`,{d:`M20 12h2`,key:`1q8mjw`}],[`path`,{d:`m6.34 17.66-1.41 1.41`,key:`1m8zz5`}],[`path`,{d:`m19.07 4.93-1.41 1.41`,key:`1shlcs`}]]),Ge=V(`trash-2`,[[`path`,{d:`M10 11v6`,key:`nco0om`}],[`path`,{d:`M14 11v6`,key:`outv1u`}],[`path`,{d:`M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6`,key:`miytrc`}],[`path`,{d:`M3 6h18`,key:`d0wm0j`}],[`path`,{d:`M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2`,key:`e791ji`}]]),W=V(`upload`,[[`path`,{d:`M12 3v12`,key:`1x0j5s`}],[`path`,{d:`m17 8-5-5-5 5`,key:`7q97r8`}],[`path`,{d:`M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4`,key:`ih7n3h`}]]),Ke=V(`volume-2`,[[`path`,{d:`M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z`,key:`uqj9uw`}],[`path`,{d:`M16 9a5 5 0 0 1 0 6`,key:`1q6k2b`}],[`path`,{d:`M19.364 18.364a9 9 0 0 0 0-12.728`,key:`ijwkga`}]]),qe=V(`x`,[[`path`,{d:`M18 6 6 18`,key:`1bl5f8`}],[`path`,{d:`m6 6 12 12`,key:`d8bk6v`}]]),Je=o((e=>{var t=Symbol.for(`react.transitional.element`),n=Symbol.for(`react.fragment`);function r(e,n,r){var i=null;if(r!==void 0&&(i=``+r),n.key!==void 0&&(i=``+n.key),`key`in n)for(var a in r={},n)a!==`key`&&(r[a]=n[a]);else r=n;return n=r.ref,{$$typeof:t,type:e,key:i,ref:n===void 0?null:n,props:r}}e.Fragment=n,e.jsx=r,e.jsxs=r})),G=o(((e,t)=>{t.exports=Je()}))();function Ye(e,t){return!isNaN(e)&&!isNaN(t)&&e>=-90&&e<=90&&t>=-180&&t<=180&&(e!==0||t!==0)}var Xe=({type:e=`turn`,modifier:t=`straight`,className:n=`w-10 h-10`})=>{let r=(t||``).toLowerCase(),i=(e||``).toLowerCase();return i===`arrive`?(0,G.jsx)(Ee,{className:n}):i===`roundabout`||i===`rotary`?(0,G.jsx)(he,{className:n}):i===`fork`?(0,G.jsx)(Oe,{className:n}):r.includes(`uturn`)||r===`uturn`||r.includes(`turnaround`)||r.includes(`turn around`)||i===`turnaround`?(0,G.jsxs)(`svg`,{viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2.75`,strokeLinecap:`round`,strokeLinejoin:`round`,className:n,children:[(0,G.jsx)(`path`,{d:`M9 19V9a5 5 0 0 1 10 0v7`}),(0,G.jsx)(`polyline`,{points:`6 16 9 19 12 16`})]}):r===`sharp right`?(0,G.jsxs)(`svg`,{viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2.75`,strokeLinecap:`round`,strokeLinejoin:`round`,className:n,children:[(0,G.jsx)(`path`,{d:`M12 21V11a4 4 0 0 1 4-4h5`}),(0,G.jsx)(`polyline`,{points:`18 4 21 7 18 10`})]}):r===`sharp left`?(0,G.jsxs)(`svg`,{viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2.75`,strokeLinecap:`round`,strokeLinejoin:`round`,className:n,children:[(0,G.jsx)(`path`,{d:`M12 21V11a4 4 0 0 0-4-4H3`}),(0,G.jsx)(`polyline`,{points:`6 4 3 7 6 10`})]}):r===`slight right`?(0,G.jsx)(U,{className:n,strokeWidth:2.75}):r===`slight left`?(0,G.jsx)(H,{className:n,strokeWidth:2.75}):r===`right`?(0,G.jsx)(be,{className:n,strokeWidth:2.75}):r===`left`?(0,G.jsx)(ye,{className:n,strokeWidth:2.75}):r===`straight`||i===`continue`||i===`depart`?(0,G.jsx)(ue,{className:n,strokeWidth:2.75}):(0,G.jsx)(ve,{className:n,strokeWidth:2.5})},Ze=({currentStop:e,previousStop:t,nextStop:n,userLocation:r,distanceToCurrentFeet:i,isDark:a,arrivalRadiusMeters:o=50,isWithinGeofence:s=!1,autoArrivalStatus:c,isPassedWithoutCompletion:l=!1,simulateApproachAndPass:u,simulateApproachAndArrive:d,isSimulatingGps:f=!1,stopGpsSimulation:p,onRouteCoordinatesUpdate:m,onSkipCustomer:h,voiceAnnouncement:g=!0})=>{let[_,y]=(0,v.useState)(!1),[b,x]=(0,v.useState)(!1),[S,C]=(0,v.useState)(null);(0,v.useEffect)(()=>(window.onOsmAndNavUpdate=(e,t,n)=>{C({maneuver:e||`straight`,street:t||``,distanceMeters:typeof n==`number`?n:0,lastReceived:Date.now()})},()=>{delete window.onOsmAndNavUpdate}),[]);let w=!!(S&&Date.now()-S.lastReceived<2e4),[T,E]=(0,v.useState)([]),[D,O]=(0,v.useState)([]),[k,A]=(0,v.useState)(0),[j,ee]=(0,v.useState)(0),[N,P]=(0,v.useState)(0),[te,re]=(0,v.useState)(null),[ie,ae]=(0,v.useState)(0),[oe,se]=(0,v.useState)(!1),[ce,le]=(0,v.useState)(null),[V,H]=(0,v.useState)(null),U=(0,v.useRef)(0),ue=(0,v.useRef)(null),de=(0,v.useRef)(1/0),fe=(0,v.useRef)(null),pe=(0,v.useRef)(0),he=(0,v.useRef)(null);(0,v.useEffect)(()=>{r&&Ye(r.lat,r.lon)&&(he.current={lat:r.lat,lon:r.lon})},[r]);let ge=(0,v.useCallback)(()=>{if(r&&Ye(r.lat,r.lon)){let e=r.heading??null;return e===null&&he.current&&(e=z(he.current.lat,he.current.lon,r.lat,r.lon)),{lat:r.lat,lon:r.lon,heading:e}}return t&&Ye(t.lat,t.lon)?{lat:t.lat,lon:t.lon,heading:null}:e&&Ye(e.lat,e.lon)?{lat:e.lat-.005,lon:e.lon-.004,heading:35}:null},[r,t,e]),_e=(0,v.useCallback)(async(t,n)=>{if(!e||!Ye(e.lat,e.lon)){E([]),O([]),re(null);return}let r=t||ge();if(r){se(!0),le(null);try{let t=await ne(r.lat,r.lon,e.lat,e.lon,e.name,r.heading);t.maneuvers.length>0&&(E(t.maneuvers),O(t.coordinates),m&&m(t.coordinates),A(0),pe.current=0,P(t.totalDistance),re(t.totalDistance),ae(t.totalDuration),ee(t.maneuvers[0]?.distanceMeters||0),U.current=Date.now(),ue.current={lat:r.lat,lon:r.lon},n?(H(n),setTimeout(()=>H(null),5e3)):t.hasUturn&&(H(`Turn Around Route Active`),setTimeout(()=>H(null),5e3)),t.hasUturn&&g&&M())}catch(e){console.warn(`Road routing error:`,e),le(e.message||`Routing unavailable`)}finally{se(!1)}}},[e,ge,m,g]);(0,v.useEffect)(()=>{let t=e?.id||null;t!==fe.current&&(fe.current=t,A(0),pe.current=0,re(null),de.current=1/0,ue.current=null,U.current=0,H(null),_e())},[e?.id,e?.lat,e?.lon,_e]),(0,v.useEffect)(()=>{if(!r||!Ye(r.lat,r.lon)||!e||!Ye(e.lat,e.lon))return;let t=Date.now(),n=F(r.lat,r.lon,e.lat,e.lon);n<de.current&&(de.current=n);let a=t-U.current,o=ue.current?F(r.lat,r.lon,ue.current.lat,ue.current.lon):1/0,s=!!(l||de.current<=80&&n>=de.current+22),c=!1;if(D.length>1&&(c=I(r.lat,r.lon,D)>45&&n>30),(s||c)&&a>3500&&o>15&&!oe){let e=s?`Passed Stop · Recalculating`:`Off-Route · Rerouting`;de.current=n;let t=r.heading??null;t===null&&he.current&&(t=z(he.current.lat,he.current.lon,r.lat,r.lon)),_e({lat:r.lat,lon:r.lon,heading:t},e)}else{if(D.length>1){let{remainingMeters:e,closestSegmentIndex:t}=R(r.lat,r.lon,D,pe.current);pe.current=t,re(e)}else re(Math.round(i===null?n:i/3.28084));if(T.length>0&&k<T.length){let e=T[k];if(e){let[t,n]=e.location,i=F(r.lat,r.lon,n,t);if(i<25&&k<T.length-1){A(e=>e+1);let e=T[k+1];ee(e?e.distanceMeters:0)}else ee(Math.max(0,Math.round(i)))}}}},[r,e,T,k,D,l,oe,_e,i]);let ye=T[k]||null,be=T[k+1]||null,xe=r&&Ye(r.lat,r.lon)&&Ye(e.lat,e.lon)?F(r.lat,r.lon,e.lat,e.lon):1/0,Se=!!(l||de.current<=80&&xe>=de.current+22),Ce=!!(e&&(!n||e.streetName&&n.streetName&&e.streetName.toLowerCase().trim()!==n.streetName.toLowerCase().trim())),we=!!T.some(e=>{let t=(e.modifier||``).toLowerCase(),n=(e.type||``).toLowerCase();return t.includes(`uturn`)||t.includes(`turnaround`)||t.includes(`turn around`)||n===`turnaround`}),Te=!!(Se&&(we||k<=1)||ye?.modifier?.toLowerCase().includes(`uturn`)||ye?.instruction?.includes(`Turn around as soon as possible.`));(0,v.useEffect)(()=>{Te&&g&&M()},[Te,g]);let Ee=w&&S?S.maneuver.includes(`roundabout`)?`roundabout`:S.maneuver.includes(`uturn`)||S.maneuver.includes(`turnaround`)?`turnaround`:`turn`:Te?`turnaround`:ye?.type||`turn`,De=w&&S?S.maneuver:Te?`uturn`:ye?.modifier||`straight`,Oe=w&&S?S.maneuver.includes(`uturn`)||S.maneuver.includes(`turnaround`)?`Turn around as soon as possible.`:S.street?`Turn onto ${S.street}`:S.maneuver:Te?`Turn around as soon as possible.`:ye?.instruction||(e.streetName?`Proceed along route to ${e.streetName}`:`Proceed toward customer destination`),Ae=w&&S?S.street:ye?.streetName||e.streetName||e.fullAddress||``,je=w&&S?B(S.distanceMeters):B(j)||`0 ft`,Me=Ye(e.lat,e.lon),Ne=Math.round((o||50)*3.28084),Pe=!!(s||i!==null&&i<=Ne),Le=Pe?`0 ft`:te===null?i!==null&&Me?B(i/3.28084):N>0?B(N):`0 ft`:B(te),Re=!(!ye||ye.type===`arrive`)&&(k<T.length-1||j>15);return(0,G.jsxs)(G.Fragment,{children:[(0,G.jsxs)(`div`,{className:`w-full rounded-2xl border-2 transition-all shadow-xl relative mb-2 flex flex-col shrink-0 ${Pe?`bg-emerald-950/95 border-emerald-400 text-white shadow-emerald-950/90`:a?`bg-neutral-950 border-neutral-800 text-white shadow-neutral-950/95`:`bg-neutral-900 border-neutral-700 text-white shadow-neutral-500/40`}`,children:[(0,G.jsx)(`div`,{className:`w-full h-1 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-400 rounded-t-2xl`}),(0,G.jsxs)(`div`,{className:`px-3 py-1 flex items-center justify-between border-b border-neutral-800/90 gap-1.5 flex-wrap`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-1.5`,children:[(0,G.jsxs)(`span`,{className:`relative flex h-2 w-2 shrink-0`,children:[(0,G.jsx)(`span`,{className:`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${w?`bg-emerald-400`:f?`bg-amber-400`:`bg-orange-400`}`}),(0,G.jsx)(`span`,{className:`relative inline-flex rounded-full h-2 w-2 ${w?`bg-emerald-400`:f?`bg-amber-400`:`bg-orange-500`}`})]}),(0,G.jsx)(`span`,{className:`font-mono font-bold uppercase tracking-wider text-[10px] text-neutral-300`,children:V||(w?`OsmAnd Native AIDL`:f?`Test Simulation Active`:oe?`Recalculating...`:`OpenStreetMap Routing`)})]}),(0,G.jsxs)(`div`,{className:`flex items-center gap-1.5 relative`,children:[f?(0,G.jsxs)(`button`,{onClick:()=>{p&&p()},className:`flex items-center gap-1 px-2.5 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-wider bg-amber-400 text-black shadow-md shadow-amber-950/60 animate-pulse transition-all active:scale-95`,title:`Pause active simulation`,children:[(0,G.jsx)(Ue,{className:`w-2.5 h-2.5 fill-current`}),(0,G.jsx)(`span`,{children:`Stop`})]}):(0,G.jsxs)(`div`,{className:`relative`,children:[(0,G.jsxs)(`button`,{onClick:()=>x(e=>!e),className:`flex items-center gap-1 px-2.5 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-wider bg-neutral-900 hover:bg-neutral-800 text-amber-400 border border-neutral-700 transition-all active:scale-95`,title:`Test in-phone without driving`,children:[(0,G.jsx)(Fe,{className:`w-2.5 h-2.5 fill-current`}),(0,G.jsx)(`span`,{children:`Test Drive`})]}),b&&(0,G.jsxs)(`div`,{className:`absolute right-0 top-full mt-1.5 w-52 bg-neutral-900 border border-neutral-700 rounded-xl shadow-2xl p-1.5 z-40 space-y-1 animate-in fade-in zoom-in-95 duration-150`,children:[(0,G.jsxs)(`button`,{onClick:()=>{x(!1),d?d():u&&u()},className:`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-bold text-white hover:bg-neutral-800 flex items-center justify-between`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-1.5`,children:[(0,G.jsx)(me,{className:`w-3.5 h-3.5 text-emerald-400 shrink-0`}),(0,G.jsx)(`span`,{children:`Approach & Stop`})]}),(0,G.jsx)(`span`,{className:`text-[9px] text-neutral-400 uppercase font-mono`,children:`Arrival`})]}),(0,G.jsxs)(`button`,{onClick:()=>{x(!1),u&&u()},className:`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-bold text-white hover:bg-neutral-800 flex items-center justify-between`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-1.5`,children:[(0,G.jsx)(Ie,{className:`w-3.5 h-3.5 text-amber-400 shrink-0`}),(0,G.jsx)(`span`,{children:`Miss Stop & Reroute`})]}),(0,G.jsx)(`span`,{className:`text-[9px] text-amber-400 uppercase font-mono`,children:`Turn Around`})]})]})]}),(0,G.jsx)(`button`,{onClick:()=>y(!0),className:`p-1 text-neutral-400 hover:text-white rounded hover:bg-neutral-800 transition-colors`,title:`Navigation details & instructions`,children:(0,G.jsx)(ke,{className:`w-3.5 h-3.5`})})]})]}),(0,G.jsxs)(`div`,{className:`px-3 py-2 flex items-center justify-between gap-3 border-b border-neutral-800/60`,children:[(0,G.jsx)(`div`,{className:`w-12 h-12 sm:w-14 sm:h-14 rounded-xl flex items-center justify-center shrink-0 border-2 shadow-lg transition-all ${Pe?`bg-emerald-500 border-emerald-300 text-black shadow-emerald-500/50`:w?`bg-emerald-500/25 border-emerald-400 text-emerald-400`:`bg-amber-400 border-amber-300 text-black shadow-amber-400/20`}`,children:Pe?(0,G.jsx)(me,{className:`w-8 h-8 sm:w-9 sm:h-9 stroke-[3] text-black`}):(0,G.jsx)(Xe,{type:Ee,modifier:De,className:`w-8 h-8 sm:w-9 sm:h-9 stroke-[2.75]`})}),(0,G.jsxs)(`div`,{className:`flex-1 text-right min-w-0`,children:[(0,G.jsx)(`div`,{className:`text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-amber-400 font-mono mb-0.5`,children:Pe?`ARRIVED AT CUSTOMER`:`DISTANCE TO CUSTOMER`}),(0,G.jsx)(`div`,{className:`font-black text-3xl sm:text-4xl font-mono text-white tracking-tight leading-none drop-shadow`,children:Le}),!Pe&&(0,G.jsx)(`div`,{className:`mt-1 flex items-center justify-end gap-1.5 text-xs font-mono`,children:Re?(0,G.jsxs)(G.Fragment,{children:[(0,G.jsx)(`span`,{className:`text-[9px] font-black uppercase tracking-wider text-black bg-amber-400 px-1.5 py-0.5 rounded shrink-0`,children:`NEXT TURN`}),(0,G.jsx)(`span`,{className:`text-white font-extrabold text-[11px] sm:text-xs`,children:je})]}):(0,G.jsxs)(`span`,{className:`text-[10px] font-bold text-emerald-400 flex items-center gap-1`,children:[(0,G.jsx)(`span`,{className:`w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block animate-pulse`}),(0,G.jsx)(`span`,{children:`Straight to Stop`})]})})]})]}),(0,G.jsxs)(`div`,{className:`px-3 py-1.5 space-y-1`,children:[(0,G.jsx)(`h2`,{className:`text-base sm:text-lg font-black text-amber-300 tracking-tight leading-snug whitespace-normal break-words`,children:Oe}),Ae&&(0,G.jsxs)(`div`,{className:`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-neutral-900 border border-neutral-700/80 text-white font-bold text-xs max-w-full whitespace-normal break-words`,children:[(0,G.jsx)(`span`,{className:`w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0`}),(0,G.jsxs)(`span`,{className:`break-words`,children:[`Road: `,Ae]})]})]}),Se&&Ce&&!Pe&&(0,G.jsxs)(`div`,{className:`mx-3 my-1 px-3 py-1.5 rounded-xl bg-amber-500/15 border border-amber-400/40 text-amber-300 text-[11px] font-bold flex items-center justify-between gap-2`,children:[(0,G.jsx)(`span`,{children:`Customer is last stop on road · Turn around as soon as possible, or tap Skip to continue`}),h&&(0,G.jsx)(`button`,{onClick:h,className:`shrink-0 px-2 py-0.5 bg-amber-400 text-black rounded-lg text-[10px] font-black uppercase tracking-wider hover:bg-amber-300 active:scale-95 transition-all shadow`,children:`Skip`})]}),be&&!Pe&&(0,G.jsxs)(`div`,{className:`px-3 py-1 bg-neutral-900/95 border-t border-neutral-800 rounded-b-2xl flex items-center gap-2 text-xs font-semibold text-neutral-300 whitespace-normal break-words`,children:[(0,G.jsx)(`span`,{className:`text-[9px] font-black uppercase tracking-wider text-black bg-amber-400 px-1.5 py-0.5 rounded shrink-0`,children:`THEN`}),(0,G.jsx)(`div`,{className:`w-4 h-4 flex items-center justify-center shrink-0 text-amber-400`,children:(0,G.jsx)(Xe,{type:be.type,modifier:be.modifier,className:`w-3.5 h-3.5 stroke-[2.5]`})}),(0,G.jsxs)(`div`,{className:`flex-1 min-w-0 whitespace-normal break-words text-neutral-200 text-xs`,children:[(0,G.jsxs)(`span`,{className:`font-mono text-amber-400 font-bold`,children:[`In `,B(be.distanceMeters),`:`]}),` `,(0,G.jsx)(`span`,{children:be.instruction})]})]}),Pe&&(0,G.jsxs)(`div`,{className:`p-2 bg-emerald-500 text-black font-black text-xs text-center tracking-wide uppercase rounded-b-2xl flex items-center justify-center gap-1.5`,children:[(0,G.jsx)(me,{className:`w-4 h-4 stroke-[3]`}),(0,G.jsxs)(`span`,{children:[`ARRIVED WITHIN `,Ne,` FT GEOFENCE`]})]}),ce&&(0,G.jsxs)(`div`,{className:`px-4 py-2 bg-red-950/80 border-t border-red-900 text-xs text-red-300 flex items-center justify-between`,children:[(0,G.jsxs)(`span`,{children:[`Routing server: `,ce]}),(0,G.jsxs)(`button`,{onClick:()=>_e(),className:`underline text-red-200 flex items-center gap-1 font-bold`,children:[(0,G.jsx)(Ie,{className:`w-3.5 h-3.5`}),` Retry`]})]})]}),_&&(0,G.jsx)(`div`,{className:`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200`,children:(0,G.jsxs)(`div`,{className:`w-full max-w-md rounded-3xl border border-neutral-700 bg-neutral-900 text-white shadow-2xl p-6 max-h-[90vh] overflow-y-auto`,children:[(0,G.jsxs)(`div`,{className:`flex items-center justify-between mb-4`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,G.jsx)(`div`,{className:`w-10 h-10 rounded-2xl bg-orange-600 flex items-center justify-center text-white shrink-0`,children:(0,G.jsx)(ve,{className:`w-6 h-6`})}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h3`,{className:`font-black text-base`,children:`True Road Navigation`}),(0,G.jsx)(`p`,{className:`text-xs text-neutral-400`,children:`Intelligent Rerouting & Legal Maneuvers`})]})]}),(0,G.jsx)(`button`,{onClick:()=>y(!1),className:`p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800`,children:(0,G.jsx)(qe,{className:`w-5 h-5`})})]}),(0,G.jsxs)(`div`,{className:`space-y-3.5 text-xs text-neutral-300`,children:[(0,G.jsxs)(`div`,{className:`p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2`,children:[(0,G.jsxs)(`div`,{className:`font-bold text-amber-400 flex items-center gap-1.5`,children:[(0,G.jsx)(He,{className:`w-4 h-4`}),(0,G.jsx)(`span`,{children:`Legal Maneuvers & Missed Destinations`})]}),(0,G.jsx)(`p`,{children:`Calculates genuine OpenStreetMap driving routes with exact road names, turn angles, and step distances.`}),(0,G.jsxs)(`ul`,{className:`list-disc pl-4 space-y-1 text-neutral-400`,children:[(0,G.jsxs)(`li`,{children:[(0,G.jsx)(`strong`,{children:`Turnaround Guidance:`}),` When turning around is the appropriate way to return to the customer, the app instructs "Turn around as soon as possible.".`]}),(0,G.jsxs)(`li`,{children:[(0,G.jsx)(`strong`,{children:`Around the Block:`}),` If a turnaround is restricted by road dividers or one-way rules, the app routes you around the block via legal side streets.`]}),(0,G.jsxs)(`li`,{children:[(0,G.jsx)(`strong`,{children:`Last Stop on Road:`}),` If the customer is the last stop on the road and you pass it, the app guides you to turn around while keeping the active customer until arrival or manual skip.`]}),(0,G.jsxs)(`li`,{children:[(0,G.jsx)(`strong`,{children:`No Accidental Advance:`}),` Passing an address without stopping does not mark the customer complete; it keeps the customer active and recalculates the return route.`]})]})]}),(0,G.jsxs)(`div`,{className:`p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2`,children:[(0,G.jsx)(`div`,{className:`font-bold text-amber-300`,children:`How to Test on Android:`}),(0,G.jsxs)(`ol`,{className:`list-decimal pl-4 space-y-1.5 text-neutral-400`,children:[(0,G.jsxs)(`li`,{children:[`Tap `,(0,G.jsx)(`strong`,{children:`Test Drive`}),` in the navigation header.`]}),(0,G.jsxs)(`li`,{children:[`Select `,(0,G.jsx)(`strong`,{children:`Approach & Stop`}),` to verify confirmed arrival and automatic stop advancement.`]}),(0,G.jsxs)(`li`,{children:[`Select `,(0,G.jsx)(`strong`,{children:`Miss Stop & Reroute`}),` to simulate driving past without stopping. Watch the app keep the active customer and instantly recalculate a legal return route.`]}),(0,G.jsx)(`li`,{children:`While driving on the road, the app automatically tracks your real-time GPS position.`})]})]})]}),(0,G.jsx)(`button`,{onClick:()=>y(!1),className:`w-full mt-5 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-sm transition-all`,children:`Close`})]})})]})},Qe=c(o(((e,t,n)=>{(function(n,r){typeof e==`object`&&t!==void 0?r(e):typeof define==`function`&&define.amd?define([`exports`],r):(n=typeof globalThis<`u`?globalThis:n||self,r(n.leaflet={}))})(n,(function(e){var t=`1.9.4`;function n(e){for(var t,n=1,r=arguments.length,i;n<r;n++)for(t in i=arguments[n],i)e[t]=i[t];return e}var r=Object.create||(function(){function e(){}return function(t){return e.prototype=t,new e}})();function i(e,t){var n=Array.prototype.slice;if(e.bind)return e.bind.apply(e,n.call(arguments,1));var r=n.call(arguments,2);return function(){return e.apply(t,r.length?r.concat(n.call(arguments)):arguments)}}var a=0;function o(e){return`_leaflet_id`in e||(e._leaflet_id=++a),e._leaflet_id}function s(e,t,n){var r,i,a,o=function(){r=!1,i&&=(a.apply(n,i),!1)};return a=function(){r?i=arguments:(e.apply(n,arguments),setTimeout(o,t),r=!0)},a}function c(e,t,n){var r=t[1],i=t[0],a=r-i;return e===r&&n?e:((e-i)%a+a)%a+i}function l(){return!1}function u(e,t){if(t===!1)return e;var n=10**(t===void 0?6:t);return Math.round(e*n)/n}function d(e){return e.trim?e.trim():e.replace(/^\s+|\s+$/g,``)}function f(e){return d(e).split(/\s+/)}function p(e,t){for(var n in Object.prototype.hasOwnProperty.call(e,`options`)||(e.options=e.options?r(e.options):{}),t)e.options[n]=t[n];return e.options}function m(e,t,n){var r=[];for(var i in e)r.push(encodeURIComponent(n?i.toUpperCase():i)+`=`+encodeURIComponent(e[i]));return(!t||t.indexOf(`?`)===-1?`?`:`&`)+r.join(`&`)}var h=/\{ *([\w_ -]+) *\}/g;function g(e,t){return e.replace(h,function(e,n){var r=t[n];if(r===void 0)throw Error(`No value provided for variable `+e);return typeof r==`function`&&(r=r(t)),r})}var _=Array.isArray||function(e){return Object.prototype.toString.call(e)===`[object Array]`};function v(e,t){for(var n=0;n<e.length;n++)if(e[n]===t)return n;return-1}var y=`data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=`;function b(e){return window[`webkit`+e]||window[`moz`+e]||window[`ms`+e]}var x=0;function S(e){var t=+new Date,n=Math.max(0,16-(t-x));return x=t+n,window.setTimeout(e,n)}var C=window.requestAnimationFrame||b(`RequestAnimationFrame`)||S,w=window.cancelAnimationFrame||b(`CancelAnimationFrame`)||b(`CancelRequestAnimationFrame`)||function(e){window.clearTimeout(e)};function T(e,t,n){if(n&&C===S)e.call(t);else return C.call(window,i(e,t))}function E(e){e&&w.call(window,e)}var D={__proto__:null,extend:n,create:r,bind:i,get lastId(){return a},stamp:o,throttle:s,wrapNum:c,falseFn:l,formatNum:u,trim:d,splitWords:f,setOptions:p,getParamString:m,template:g,isArray:_,indexOf:v,emptyImageUrl:y,requestFn:C,cancelFn:w,requestAnimFrame:T,cancelAnimFrame:E};function O(){}O.extend=function(e){var t=function(){p(this),this.initialize&&this.initialize.apply(this,arguments),this.callInitHooks()},i=t.__super__=this.prototype,a=r(i);for(var o in a.constructor=t,t.prototype=a,this)Object.prototype.hasOwnProperty.call(this,o)&&o!==`prototype`&&o!==`__super__`&&(t[o]=this[o]);return e.statics&&n(t,e.statics),e.includes&&(k(e.includes),n.apply(null,[a].concat(e.includes))),n(a,e),delete a.statics,delete a.includes,a.options&&(a.options=i.options?r(i.options):{},n(a.options,e.options)),a._initHooks=[],a.callInitHooks=function(){if(!this._initHooksCalled){i.callInitHooks&&i.callInitHooks.call(this),this._initHooksCalled=!0;for(var e=0,t=a._initHooks.length;e<t;e++)a._initHooks[e].call(this)}},t},O.include=function(e){var t=this.prototype.options;return n(this.prototype,e),e.options&&(this.prototype.options=t,this.mergeOptions(e.options)),this},O.mergeOptions=function(e){return n(this.prototype.options,e),this},O.addInitHook=function(e){var t=Array.prototype.slice.call(arguments,1),n=typeof e==`function`?e:function(){this[e].apply(this,t)};return this.prototype._initHooks=this.prototype._initHooks||[],this.prototype._initHooks.push(n),this};function k(e){if(typeof L<`u`&&L&&L.Mixin){e=_(e)?e:[e];for(var t=0;t<e.length;t++)e[t]===L.Mixin.Events&&console.warn(`Deprecated include of L.Mixin.Events: this property will be removed in future releases, please inherit from L.Evented instead.`,Error().stack)}}var A={on:function(e,t,n){if(typeof e==`object`)for(var r in e)this._on(r,e[r],t);else{e=f(e);for(var i=0,a=e.length;i<a;i++)this._on(e[i],t,n)}return this},off:function(e,t,n){if(!arguments.length)delete this._events;else if(typeof e==`object`)for(var r in e)this._off(r,e[r],t);else{e=f(e);for(var i=arguments.length===1,a=0,o=e.length;a<o;a++)i?this._off(e[a]):this._off(e[a],t,n)}return this},_on:function(e,t,n,r){if(typeof t!=`function`)console.warn(`wrong listener type: `+typeof t);else if(this._listens(e,t,n)===!1){n===this&&(n=void 0);var i={fn:t,ctx:n};r&&(i.once=!0),this._events=this._events||{},this._events[e]=this._events[e]||[],this._events[e].push(i)}},_off:function(e,t,n){var r,i,a;if(this._events&&(r=this._events[e],r)){if(arguments.length===1){if(this._firingCount)for(i=0,a=r.length;i<a;i++)r[i].fn=l;delete this._events[e]}else if(typeof t!=`function`)console.warn(`wrong listener type: `+typeof t);else{var o=this._listens(e,t,n);if(o!==!1){var s=r[o];this._firingCount&&(s.fn=l,this._events[e]=r=r.slice()),r.splice(o,1)}}}},fire:function(e,t,r){if(!this.listens(e,r))return this;var i=n({},t,{type:e,target:this,sourceTarget:t&&t.sourceTarget||this});if(this._events){var a=this._events[e];if(a){this._firingCount=this._firingCount+1||1;for(var o=0,s=a.length;o<s;o++){var c=a[o],l=c.fn;c.once&&this.off(e,l,c.ctx),l.call(c.ctx||this,i)}this._firingCount--}}return r&&this._propagateEvent(i),this},listens:function(e,t,n,r){typeof e!=`string`&&console.warn(`"string" type argument expected`);var i=t;typeof t!=`function`&&(r=!!t,i=void 0,n=void 0);var a=this._events&&this._events[e];if(a&&a.length&&this._listens(e,i,n)!==!1)return!0;if(r){for(var o in this._eventParents)if(this._eventParents[o].listens(e,t,n,r))return!0}return!1},_listens:function(e,t,n){if(!this._events)return!1;var r=this._events[e]||[];if(!t)return!!r.length;n===this&&(n=void 0);for(var i=0,a=r.length;i<a;i++)if(r[i].fn===t&&r[i].ctx===n)return i;return!1},once:function(e,t,n){if(typeof e==`object`)for(var r in e)this._on(r,e[r],t,!0);else{e=f(e);for(var i=0,a=e.length;i<a;i++)this._on(e[i],t,n,!0)}return this},addEventParent:function(e){return this._eventParents=this._eventParents||{},this._eventParents[o(e)]=e,this},removeEventParent:function(e){return this._eventParents&&delete this._eventParents[o(e)],this},_propagateEvent:function(e){for(var t in this._eventParents)this._eventParents[t].fire(e.type,n({layer:e.target,propagatedFrom:e.target},e),!0)}};A.addEventListener=A.on,A.removeEventListener=A.clearAllEventListeners=A.off,A.addOneTimeEventListener=A.once,A.fireEvent=A.fire,A.hasEventListeners=A.listens;var j=O.extend(A);function M(e,t,n){this.x=n?Math.round(e):e,this.y=n?Math.round(t):t}var ee=Math.trunc||function(e){return e>0?Math.floor(e):Math.ceil(e)};M.prototype={clone:function(){return new M(this.x,this.y)},add:function(e){return this.clone()._add(N(e))},_add:function(e){return this.x+=e.x,this.y+=e.y,this},subtract:function(e){return this.clone()._subtract(N(e))},_subtract:function(e){return this.x-=e.x,this.y-=e.y,this},divideBy:function(e){return this.clone()._divideBy(e)},_divideBy:function(e){return this.x/=e,this.y/=e,this},multiplyBy:function(e){return this.clone()._multiplyBy(e)},_multiplyBy:function(e){return this.x*=e,this.y*=e,this},scaleBy:function(e){return new M(this.x*e.x,this.y*e.y)},unscaleBy:function(e){return new M(this.x/e.x,this.y/e.y)},round:function(){return this.clone()._round()},_round:function(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this},floor:function(){return this.clone()._floor()},_floor:function(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this},ceil:function(){return this.clone()._ceil()},_ceil:function(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this},trunc:function(){return this.clone()._trunc()},_trunc:function(){return this.x=ee(this.x),this.y=ee(this.y),this},distanceTo:function(e){e=N(e);var t=e.x-this.x,n=e.y-this.y;return Math.sqrt(t*t+n*n)},equals:function(e){return e=N(e),e.x===this.x&&e.y===this.y},contains:function(e){return e=N(e),Math.abs(e.x)<=Math.abs(this.x)&&Math.abs(e.y)<=Math.abs(this.y)},toString:function(){return`Point(`+u(this.x)+`, `+u(this.y)+`)`}};function N(e,t,n){return e instanceof M?e:_(e)?new M(e[0],e[1]):e==null?e:typeof e==`object`&&`x`in e&&`y`in e?new M(e.x,e.y):new M(e,t,n)}function P(e,t){if(e)for(var n=t?[e,t]:e,r=0,i=n.length;r<i;r++)this.extend(n[r])}P.prototype={extend:function(e){var t,n;if(!e)return this;if(e instanceof M||typeof e[0]==`number`||`x`in e)t=n=N(e);else if(e=F(e),t=e.min,n=e.max,!t||!n)return this;return!this.min&&!this.max?(this.min=t.clone(),this.max=n.clone()):(this.min.x=Math.min(t.x,this.min.x),this.max.x=Math.max(n.x,this.max.x),this.min.y=Math.min(t.y,this.min.y),this.max.y=Math.max(n.y,this.max.y)),this},getCenter:function(e){return N((this.min.x+this.max.x)/2,(this.min.y+this.max.y)/2,e)},getBottomLeft:function(){return N(this.min.x,this.max.y)},getTopRight:function(){return N(this.max.x,this.min.y)},getTopLeft:function(){return this.min},getBottomRight:function(){return this.max},getSize:function(){return this.max.subtract(this.min)},contains:function(e){var t,n;return e=typeof e[0]==`number`||e instanceof M?N(e):F(e),e instanceof P?(t=e.min,n=e.max):t=n=e,t.x>=this.min.x&&n.x<=this.max.x&&t.y>=this.min.y&&n.y<=this.max.y},intersects:function(e){e=F(e);var t=this.min,n=this.max,r=e.min,i=e.max,a=i.x>=t.x&&r.x<=n.x,o=i.y>=t.y&&r.y<=n.y;return a&&o},overlaps:function(e){e=F(e);var t=this.min,n=this.max,r=e.min,i=e.max,a=i.x>t.x&&r.x<n.x,o=i.y>t.y&&r.y<n.y;return a&&o},isValid:function(){return!!(this.min&&this.max)},pad:function(e){var t=this.min,n=this.max,r=Math.abs(t.x-n.x)*e,i=Math.abs(t.y-n.y)*e;return F(N(t.x-r,t.y-i),N(n.x+r,n.y+i))},equals:function(e){return e?(e=F(e),this.min.equals(e.getTopLeft())&&this.max.equals(e.getBottomRight())):!1}};function F(e,t){return!e||e instanceof P?e:new P(e,t)}function I(e,t){if(e)for(var n=t?[e,t]:e,r=0,i=n.length;r<i;r++)this.extend(n[r])}I.prototype={extend:function(e){var t=this._southWest,n=this._northEast,r,i;if(e instanceof z)r=e,i=e;else if(e instanceof I){if(r=e._southWest,i=e._northEast,!r||!i)return this}else return e?this.extend(B(e)||R(e)):this;return!t&&!n?(this._southWest=new z(r.lat,r.lng),this._northEast=new z(i.lat,i.lng)):(t.lat=Math.min(r.lat,t.lat),t.lng=Math.min(r.lng,t.lng),n.lat=Math.max(i.lat,n.lat),n.lng=Math.max(i.lng,n.lng)),this},pad:function(e){var t=this._southWest,n=this._northEast,r=Math.abs(t.lat-n.lat)*e,i=Math.abs(t.lng-n.lng)*e;return new I(new z(t.lat-r,t.lng-i),new z(n.lat+r,n.lng+i))},getCenter:function(){return new z((this._southWest.lat+this._northEast.lat)/2,(this._southWest.lng+this._northEast.lng)/2)},getSouthWest:function(){return this._southWest},getNorthEast:function(){return this._northEast},getNorthWest:function(){return new z(this.getNorth(),this.getWest())},getSouthEast:function(){return new z(this.getSouth(),this.getEast())},getWest:function(){return this._southWest.lng},getSouth:function(){return this._southWest.lat},getEast:function(){return this._northEast.lng},getNorth:function(){return this._northEast.lat},contains:function(e){e=typeof e[0]==`number`||e instanceof z||`lat`in e?B(e):R(e);var t=this._southWest,n=this._northEast,r,i;return e instanceof I?(r=e.getSouthWest(),i=e.getNorthEast()):r=i=e,r.lat>=t.lat&&i.lat<=n.lat&&r.lng>=t.lng&&i.lng<=n.lng},intersects:function(e){e=R(e);var t=this._southWest,n=this._northEast,r=e.getSouthWest(),i=e.getNorthEast(),a=i.lat>=t.lat&&r.lat<=n.lat,o=i.lng>=t.lng&&r.lng<=n.lng;return a&&o},overlaps:function(e){e=R(e);var t=this._southWest,n=this._northEast,r=e.getSouthWest(),i=e.getNorthEast(),a=i.lat>t.lat&&r.lat<n.lat,o=i.lng>t.lng&&r.lng<n.lng;return a&&o},toBBoxString:function(){return[this.getWest(),this.getSouth(),this.getEast(),this.getNorth()].join(`,`)},equals:function(e,t){return e?(e=R(e),this._southWest.equals(e.getSouthWest(),t)&&this._northEast.equals(e.getNorthEast(),t)):!1},isValid:function(){return!!(this._southWest&&this._northEast)}};function R(e,t){return e instanceof I?e:new I(e,t)}function z(e,t,n){if(isNaN(e)||isNaN(t))throw Error(`Invalid LatLng object: (`+e+`, `+t+`)`);this.lat=+e,this.lng=+t,n!==void 0&&(this.alt=+n)}z.prototype={equals:function(e,t){return e?(e=B(e),Math.max(Math.abs(this.lat-e.lat),Math.abs(this.lng-e.lng))<=(t===void 0?1e-9:t)):!1},toString:function(e){return`LatLng(`+u(this.lat,e)+`, `+u(this.lng,e)+`)`},distanceTo:function(e){return ne.distance(this,B(e))},wrap:function(){return ne.wrapLatLng(this)},toBounds:function(e){var t=180*e/40075017,n=t/Math.cos(Math.PI/180*this.lat);return R([this.lat-t,this.lng-n],[this.lat+t,this.lng+n])},clone:function(){return new z(this.lat,this.lng,this.alt)}};function B(e,t,n){return e instanceof z?e:_(e)&&typeof e[0]!=`object`?e.length===3?new z(e[0],e[1],e[2]):e.length===2?new z(e[0],e[1]):null:e==null?e:typeof e==`object`&&`lat`in e?new z(e.lat,`lng`in e?e.lng:e.lon,e.alt):t===void 0?null:new z(e,t,n)}var te={latLngToPoint:function(e,t){var n=this.projection.project(e),r=this.scale(t);return this.transformation._transform(n,r)},pointToLatLng:function(e,t){var n=this.scale(t),r=this.transformation.untransform(e,n);return this.projection.unproject(r)},project:function(e){return this.projection.project(e)},unproject:function(e){return this.projection.unproject(e)},scale:function(e){return 256*2**e},zoom:function(e){return Math.log(e/256)/Math.LN2},getProjectedBounds:function(e){if(this.infinite)return null;var t=this.projection.bounds,n=this.scale(e);return new P(this.transformation.transform(t.min,n),this.transformation.transform(t.max,n))},infinite:!1,wrapLatLng:function(e){var t=this.wrapLng?c(e.lng,this.wrapLng,!0):e.lng,n=this.wrapLat?c(e.lat,this.wrapLat,!0):e.lat,r=e.alt;return new z(n,t,r)},wrapLatLngBounds:function(e){var t=e.getCenter(),n=this.wrapLatLng(t),r=t.lat-n.lat,i=t.lng-n.lng;if(r===0&&i===0)return e;var a=e.getSouthWest(),o=e.getNorthEast();return new I(new z(a.lat-r,a.lng-i),new z(o.lat-r,o.lng-i))}},ne=n({},te,{wrapLng:[-180,180],R:6371e3,distance:function(e,t){var n=Math.PI/180,r=e.lat*n,i=t.lat*n,a=Math.sin((t.lat-e.lat)*n/2),o=Math.sin((t.lng-e.lng)*n/2),s=a*a+Math.cos(r)*Math.cos(i)*o*o,c=2*Math.atan2(Math.sqrt(s),Math.sqrt(1-s));return this.R*c}}),re=6378137,ie={R:re,MAX_LATITUDE:85.0511287798,project:function(e){var t=Math.PI/180,n=this.MAX_LATITUDE,r=Math.max(Math.min(n,e.lat),-n),i=Math.sin(r*t);return new M(this.R*e.lng*t,this.R*Math.log((1+i)/(1-i))/2)},unproject:function(e){var t=180/Math.PI;return new z((2*Math.atan(Math.exp(e.y/this.R))-Math.PI/2)*t,e.x*t/this.R)},bounds:(function(){var e=re*Math.PI;return new P([-e,-e],[e,e])})()};function ae(e,t,n,r){_(e)?(this._a=e[0],this._b=e[1],this._c=e[2],this._d=e[3]):(this._a=e,this._b=t,this._c=n,this._d=r)}ae.prototype={transform:function(e,t){return this._transform(e.clone(),t)},_transform:function(e,t){return t||=1,e.x=t*(this._a*e.x+this._b),e.y=t*(this._c*e.y+this._d),e},untransform:function(e,t){return t||=1,new M((e.x/t-this._b)/this._a,(e.y/t-this._d)/this._c)}};function oe(e,t,n,r){return new ae(e,t,n,r)}var se=n({},ne,{code:`EPSG:3857`,projection:ie,transformation:function(){var e=.5/(Math.PI*ie.R);return oe(e,.5,-e,.5)}()}),ce=n({},se,{code:`EPSG:900913`});function le(e){return document.createElementNS(`http://www.w3.org/2000/svg`,e)}function V(e,t){for(var n=``,r=0,i,a=e.length,o,s,c;r<a;r++){for(s=e[r],i=0,o=s.length;i<o;i++)c=s[i],n+=(i?`L`:`M`)+c.x+` `+c.y;n+=t?W.svg?`z`:`x`:``}return n||`M0 0`}var H=document.documentElement.style,U=`ActiveXObject`in window,ue=U&&!document.addEventListener,de=`msLaunchUri`in navigator&&!(`documentMode`in document),fe=Ge(`webkit`),pe=Ge(`android`),me=Ge(`android 2`)||Ge(`android 3`),he=parseInt(/WebKit\/([0-9]+)|$/.exec(navigator.userAgent)[1],10),ge=pe&&Ge(`Google`)&&he<537&&!(`AudioNode`in window),_e=!!window.opera,ve=!de&&Ge(`chrome`),ye=Ge(`gecko`)&&!fe&&!_e&&!U,be=!ve&&Ge(`safari`),xe=Ge(`phantom`),Se=`OTransition`in H,Ce=navigator.platform.indexOf(`Win`)===0,we=U&&`transition`in H,Te=`WebKitCSSMatrix`in window&&`m11`in new window.WebKitCSSMatrix&&!me,Ee=`MozPerspective`in H,De=!window.L_DISABLE_3D&&(we||Te||Ee)&&!Se&&!xe,Oe=typeof orientation<`u`||Ge(`mobile`),ke=Oe&&fe,Ae=Oe&&Te,je=!window.PointerEvent&&window.MSPointerEvent,Me=!!(window.PointerEvent||je),Ne=`ontouchstart`in window||!!window.TouchEvent,Pe=!window.L_NO_TOUCH&&(Ne||Me),Fe=Oe&&_e,Ie=Oe&&ye,Le=(window.devicePixelRatio||window.screen.deviceXDPI/window.screen.logicalXDPI)>1,Re=function(){var e=!1;try{var t=Object.defineProperty({},"passive",{get:function(){e=!0}});window.addEventListener(`testPassiveEventSupport`,l,t),window.removeEventListener(`testPassiveEventSupport`,l,t)}catch{}return e}(),ze=function(){return!!document.createElement(`canvas`).getContext}(),Be=!!(document.createElementNS&&le(`svg`).createSVGRect),Ve=!!Be&&(function(){var e=document.createElement(`div`);return e.innerHTML=`<svg/>`,(e.firstChild&&e.firstChild.namespaceURI)===`http://www.w3.org/2000/svg`})(),He=!Be&&function(){try{var e=document.createElement(`div`);e.innerHTML=`<v:shape adj="1"/>`;var t=e.firstChild;return t.style.behavior=`url(#default#VML)`,t&&typeof t.adj==`object`}catch{return!1}}(),Ue=navigator.platform.indexOf(`Mac`)===0,We=navigator.platform.indexOf(`Linux`)===0;function Ge(e){return navigator.userAgent.toLowerCase().indexOf(e)>=0}var W={ie:U,ielt9:ue,edge:de,webkit:fe,android:pe,android23:me,androidStock:ge,opera:_e,chrome:ve,gecko:ye,safari:be,phantom:xe,opera12:Se,win:Ce,ie3d:we,webkit3d:Te,gecko3d:Ee,any3d:De,mobile:Oe,mobileWebkit:ke,mobileWebkit3d:Ae,msPointer:je,pointer:Me,touch:Pe,touchNative:Ne,mobileOpera:Fe,mobileGecko:Ie,retina:Le,passiveEvents:Re,canvas:ze,svg:Be,vml:He,inlineSvg:Ve,mac:Ue,linux:We},Ke=W.msPointer?`MSPointerDown`:`pointerdown`,qe=W.msPointer?`MSPointerMove`:`pointermove`,Je=W.msPointer?`MSPointerUp`:`pointerup`,G=W.msPointer?`MSPointerCancel`:`pointercancel`,Ye={touchstart:Ke,touchmove:qe,touchend:Je,touchcancel:G},Xe={touchstart:ot,touchmove:at,touchend:at,touchcancel:at},Ze={},Qe=!1;function $e(e,t,n){return t===`touchstart`&&it(),Xe[t]?(n=Xe[t].bind(this,n),e.addEventListener(Ye[t],n,!1),n):(console.warn(`wrong event specified:`,t),l)}function et(e,t,n){Ye[t]?e.removeEventListener(Ye[t],n,!1):console.warn(`wrong event specified:`,t)}function tt(e){Ze[e.pointerId]=e}function nt(e){Ze[e.pointerId]&&(Ze[e.pointerId]=e)}function rt(e){delete Ze[e.pointerId]}function it(){Qe||=(document.addEventListener(Ke,tt,!0),document.addEventListener(qe,nt,!0),document.addEventListener(Je,rt,!0),document.addEventListener(G,rt,!0),!0)}function at(e,t){if(t.pointerType!==(t.MSPOINTER_TYPE_MOUSE||`mouse`)){for(var n in t.touches=[],Ze)t.touches.push(Ze[n]);t.changedTouches=[t],e(t)}}function ot(e,t){t.MSPOINTER_TYPE_TOUCH&&t.pointerType===t.MSPOINTER_TYPE_TOUCH&&Xt(t),at(e,t)}function st(e){var t={},n,r;for(r in e)n=e[r],t[r]=n&&n.bind?n.bind(e):n;return e=t,t.type=`dblclick`,t.detail=2,t.isTrusted=!1,t._simulated=!0,t}var ct=200;function lt(e,t){e.addEventListener(`dblclick`,t);var n=0,r;function i(e){if(e.detail!==1)r=e.detail;else if(!(e.pointerType===`mouse`||e.sourceCapabilities&&!e.sourceCapabilities.firesTouchEvents)){var i=Qt(e);if(!i.some(function(e){return e instanceof HTMLLabelElement&&e.attributes.for})||i.some(function(e){return e instanceof HTMLInputElement||e instanceof HTMLSelectElement})){var a=Date.now();a-n<=ct?(r++,r===2&&t(st(e))):r=1,n=a}}}return e.addEventListener(`click`,i),{dblclick:t,simDblclick:i}}function ut(e,t){e.removeEventListener(`dblclick`,t.dblclick),e.removeEventListener(`click`,t.simDblclick)}var dt=Tt([`transform`,`webkitTransform`,`OTransform`,`MozTransform`,`msTransform`]),ft=Tt([`webkitTransition`,`transition`,`OTransition`,`MozTransition`,`msTransition`]),pt=ft===`webkitTransition`||ft===`OTransition`?ft+`End`:`transitionend`;function mt(e){return typeof e==`string`?document.getElementById(e):e}function ht(e,t){var n=e.style[t]||e.currentStyle&&e.currentStyle[t];if((!n||n===`auto`)&&document.defaultView){var r=document.defaultView.getComputedStyle(e,null);n=r?r[t]:null}return n===`auto`?null:n}function K(e,t,n){var r=document.createElement(e);return r.className=t||``,n&&n.appendChild(r),r}function q(e){var t=e.parentNode;t&&t.removeChild(e)}function gt(e){for(;e.firstChild;)e.removeChild(e.firstChild)}function _t(e){var t=e.parentNode;t&&t.lastChild!==e&&t.appendChild(e)}function vt(e){var t=e.parentNode;t&&t.firstChild!==e&&t.insertBefore(e,t.firstChild)}function yt(e,t){if(e.classList!==void 0)return e.classList.contains(t);var n=St(e);return n.length>0&&RegExp(`(^|\\s)`+t+`(\\s|$)`).test(n)}function J(e,t){if(e.classList!==void 0)for(var n=f(t),r=0,i=n.length;r<i;r++)e.classList.add(n[r]);else if(!yt(e,t)){var a=St(e);xt(e,(a?a+` `:``)+t)}}function bt(e,t){e.classList===void 0?xt(e,d((` `+St(e)+` `).replace(` `+t+` `,` `))):e.classList.remove(t)}function xt(e,t){e.className.baseVal===void 0?e.className=t:e.className.baseVal=t}function St(e){return e.correspondingElement&&(e=e.correspondingElement),e.className.baseVal===void 0?e.className:e.className.baseVal}function Ct(e,t){`opacity`in e.style?e.style.opacity=t:`filter`in e.style&&wt(e,t)}function wt(e,t){var n=!1,r=`DXImageTransform.Microsoft.Alpha`;try{n=e.filters.item(r)}catch{if(t===1)return}t=Math.round(t*100),n?(n.Enabled=t!==100,n.Opacity=t):e.style.filter+=` progid:`+r+`(opacity=`+t+`)`}function Tt(e){for(var t=document.documentElement.style,n=0;n<e.length;n++)if(e[n]in t)return e[n];return!1}function Et(e,t,n){var r=t||new M(0,0);e.style[dt]=(W.ie3d?`translate(`+r.x+`px,`+r.y+`px)`:`translate3d(`+r.x+`px,`+r.y+`px,0)`)+(n?` scale(`+n+`)`:``)}function Y(e,t){e._leaflet_pos=t,W.any3d?Et(e,t):(e.style.left=t.x+`px`,e.style.top=t.y+`px`)}function Dt(e){return e._leaflet_pos||new M(0,0)}var Ot,kt,At;if(`onselectstart`in document)Ot=function(){X(window,`selectstart`,Xt)},kt=function(){Ht(window,`selectstart`,Xt)};else{var jt=Tt([`userSelect`,`WebkitUserSelect`,`OUserSelect`,`MozUserSelect`,`msUserSelect`]);Ot=function(){if(jt){var e=document.documentElement.style;At=e[jt],e[jt]=`none`}},kt=function(){jt&&(document.documentElement.style[jt]=At,At=void 0)}}function Mt(){X(window,`dragstart`,Xt)}function Nt(){Ht(window,`dragstart`,Xt)}var Pt,Ft;function It(e){for(;e.tabIndex===-1;)e=e.parentNode;e.style&&(Lt(),Pt=e,Ft=e.style.outlineStyle,e.style.outlineStyle=`none`,X(window,`keydown`,Lt))}function Lt(){Pt&&(Pt.style.outlineStyle=Ft,Pt=void 0,Ft=void 0,Ht(window,`keydown`,Lt))}function Rt(e){do e=e.parentNode;while((!e.offsetWidth||!e.offsetHeight)&&e!==document.body);return e}function zt(e){var t=e.getBoundingClientRect();return{x:t.width/e.offsetWidth||1,y:t.height/e.offsetHeight||1,boundingClientRect:t}}var Bt={__proto__:null,TRANSFORM:dt,TRANSITION:ft,TRANSITION_END:pt,get:mt,getStyle:ht,create:K,remove:q,empty:gt,toFront:_t,toBack:vt,hasClass:yt,addClass:J,removeClass:bt,setClass:xt,getClass:St,setOpacity:Ct,testProp:Tt,setTransform:Et,setPosition:Y,getPosition:Dt,get disableTextSelection(){return Ot},get enableTextSelection(){return kt},disableImageDrag:Mt,enableImageDrag:Nt,preventOutline:It,restoreOutline:Lt,getSizedParentNode:Rt,getScale:zt};function X(e,t,n,r){if(t&&typeof t==`object`)for(var i in t)Gt(e,i,t[i],n);else{t=f(t);for(var a=0,o=t.length;a<o;a++)Gt(e,t[a],n,r)}return this}var Vt=`_leaflet_events`;function Ht(e,t,n,r){if(arguments.length===1)Ut(e),delete e[Vt];else if(t&&typeof t==`object`)for(var i in t)Kt(e,i,t[i],n);else if(t=f(t),arguments.length===2)Ut(e,function(e){return v(t,e)!==-1});else for(var a=0,o=t.length;a<o;a++)Kt(e,t[a],n,r);return this}function Ut(e,t){for(var n in e[Vt]){var r=n.split(/\d/)[0];(!t||t(r))&&Kt(e,r,null,null,n)}}var Wt={mouseenter:`mouseover`,mouseleave:`mouseout`,wheel:!(`onwheel`in window)&&`mousewheel`};function Gt(e,t,n,r){var i=t+o(n)+(r?`_`+o(r):``);if(e[Vt]&&e[Vt][i])return this;var a=function(t){return n.call(r||e,t||window.event)},s=a;!W.touchNative&&W.pointer&&t.indexOf(`touch`)===0?a=$e(e,t,a):W.touch&&t===`dblclick`?a=lt(e,a):`addEventListener`in e?t===`touchstart`||t===`touchmove`||t===`wheel`||t===`mousewheel`?e.addEventListener(Wt[t]||t,a,W.passiveEvents?{passive:!1}:!1):t===`mouseenter`||t===`mouseleave`?(a=function(t){t||=window.event,nn(e,t)&&s(t)},e.addEventListener(Wt[t],a,!1)):e.addEventListener(t,s,!1):e.attachEvent(`on`+t,a),e[Vt]=e[Vt]||{},e[Vt][i]=a}function Kt(e,t,n,r,i){i||=t+o(n)+(r?`_`+o(r):``);var a=e[Vt]&&e[Vt][i];if(!a)return this;!W.touchNative&&W.pointer&&t.indexOf(`touch`)===0?et(e,t,a):W.touch&&t===`dblclick`?ut(e,a):`removeEventListener`in e?e.removeEventListener(Wt[t]||t,a,!1):e.detachEvent(`on`+t,a),e[Vt][i]=null}function qt(e){return e.stopPropagation?e.stopPropagation():e.originalEvent?e.originalEvent._stopped=!0:e.cancelBubble=!0,this}function Jt(e){return Gt(e,`wheel`,qt),this}function Yt(e){return X(e,`mousedown touchstart dblclick contextmenu`,qt),e._leaflet_disable_click=!0,this}function Xt(e){return e.preventDefault?e.preventDefault():e.returnValue=!1,this}function Zt(e){return Xt(e),qt(e),this}function Qt(e){if(e.composedPath)return e.composedPath();for(var t=[],n=e.target;n;)t.push(n),n=n.parentNode;return t}function $t(e,t){if(!t)return new M(e.clientX,e.clientY);var n=zt(t),r=n.boundingClientRect;return new M((e.clientX-r.left)/n.x-t.clientLeft,(e.clientY-r.top)/n.y-t.clientTop)}var en=W.linux&&W.chrome?window.devicePixelRatio:W.mac?window.devicePixelRatio*3:window.devicePixelRatio>0?2*window.devicePixelRatio:1;function tn(e){return W.edge?e.wheelDeltaY/2:e.deltaY&&e.deltaMode===0?-e.deltaY/en:e.deltaY&&e.deltaMode===1?-e.deltaY*20:e.deltaY&&e.deltaMode===2?-e.deltaY*60:e.deltaX||e.deltaZ?0:e.wheelDelta?(e.wheelDeltaY||e.wheelDelta)/2:e.detail&&Math.abs(e.detail)<32765?-e.detail*20:e.detail?e.detail/-32765*60:0}function nn(e,t){var n=t.relatedTarget;if(!n)return!0;try{for(;n&&n!==e;)n=n.parentNode}catch{return!1}return n!==e}var rn={__proto__:null,on:X,off:Ht,stopPropagation:qt,disableScrollPropagation:Jt,disableClickPropagation:Yt,preventDefault:Xt,stop:Zt,getPropagationPath:Qt,getMousePosition:$t,getWheelDelta:tn,isExternalTarget:nn,addListener:X,removeListener:Ht},an=j.extend({run:function(e,t,n,r){this.stop(),this._el=e,this._inProgress=!0,this._duration=n||.25,this._easeOutPower=1/Math.max(r||.5,.2),this._startPos=Dt(e),this._offset=t.subtract(this._startPos),this._startTime=+new Date,this.fire(`start`),this._animate()},stop:function(){this._inProgress&&(this._step(!0),this._complete())},_animate:function(){this._animId=T(this._animate,this),this._step()},_step:function(e){var t=+new Date-this._startTime,n=this._duration*1e3;t<n?this._runFrame(this._easeOut(t/n),e):(this._runFrame(1),this._complete())},_runFrame:function(e,t){var n=this._startPos.add(this._offset.multiplyBy(e));t&&n._round(),Y(this._el,n),this.fire(`step`)},_complete:function(){E(this._animId),this._inProgress=!1,this.fire(`end`)},_easeOut:function(e){return 1-(1-e)**this._easeOutPower}}),on=j.extend({options:{crs:se,center:void 0,zoom:void 0,minZoom:void 0,maxZoom:void 0,layers:[],maxBounds:void 0,renderer:void 0,zoomAnimation:!0,zoomAnimationThreshold:4,fadeAnimation:!0,markerZoomAnimation:!0,transform3DLimit:8388608,zoomSnap:1,zoomDelta:1,trackResize:!0},initialize:function(e,t){t=p(this,t),this._handlers=[],this._layers={},this._zoomBoundLayers={},this._sizeChanged=!0,this._initContainer(e),this._initLayout(),this._onResize=i(this._onResize,this),this._initEvents(),t.maxBounds&&this.setMaxBounds(t.maxBounds),t.zoom!==void 0&&(this._zoom=this._limitZoom(t.zoom)),t.center&&t.zoom!==void 0&&this.setView(B(t.center),t.zoom,{reset:!0}),this.callInitHooks(),this._zoomAnimated=ft&&W.any3d&&!W.mobileOpera&&this.options.zoomAnimation,this._zoomAnimated&&(this._createAnimProxy(),X(this._proxy,pt,this._catchTransitionEnd,this)),this._addLayers(this.options.layers)},setView:function(e,t,r){return t=t===void 0?this._zoom:this._limitZoom(t),e=this._limitCenter(B(e),t,this.options.maxBounds),r||={},this._stop(),this._loaded&&!r.reset&&r!==!0&&(r.animate!==void 0&&(r.zoom=n({animate:r.animate},r.zoom),r.pan=n({animate:r.animate,duration:r.duration},r.pan)),this._zoom===t?this._tryAnimatedPan(e,r.pan):this._tryAnimatedZoom&&this._tryAnimatedZoom(e,t,r.zoom))?(clearTimeout(this._sizeTimer),this):(this._resetView(e,t,r.pan&&r.pan.noMoveStart),this)},setZoom:function(e,t){return this._loaded?this.setView(this.getCenter(),e,{zoom:t}):(this._zoom=e,this)},zoomIn:function(e,t){return e||=W.any3d?this.options.zoomDelta:1,this.setZoom(this._zoom+e,t)},zoomOut:function(e,t){return e||=W.any3d?this.options.zoomDelta:1,this.setZoom(this._zoom-e,t)},setZoomAround:function(e,t,n){var r=this.getZoomScale(t),i=this.getSize().divideBy(2),a=(e instanceof M?e:this.latLngToContainerPoint(e)).subtract(i).multiplyBy(1-1/r),o=this.containerPointToLatLng(i.add(a));return this.setView(o,t,{zoom:n})},_getBoundsCenterZoom:function(e,t){t||={},e=e.getBounds?e.getBounds():R(e);var n=N(t.paddingTopLeft||t.padding||[0,0]),r=N(t.paddingBottomRight||t.padding||[0,0]),i=this.getBoundsZoom(e,!1,n.add(r));if(i=typeof t.maxZoom==`number`?Math.min(t.maxZoom,i):i,i===1/0)return{center:e.getCenter(),zoom:i};var a=r.subtract(n).divideBy(2),o=this.project(e.getSouthWest(),i),s=this.project(e.getNorthEast(),i);return{center:this.unproject(o.add(s).divideBy(2).add(a),i),zoom:i}},fitBounds:function(e,t){if(e=R(e),!e.isValid())throw Error(`Bounds are not valid.`);var n=this._getBoundsCenterZoom(e,t);return this.setView(n.center,n.zoom,t)},fitWorld:function(e){return this.fitBounds([[-90,-180],[90,180]],e)},panTo:function(e,t){return this.setView(e,this._zoom,{pan:t})},panBy:function(e,t){if(e=N(e).round(),t||={},!e.x&&!e.y)return this.fire(`moveend`);if(t.animate!==!0&&!this.getSize().contains(e))return this._resetView(this.unproject(this.project(this.getCenter()).add(e)),this.getZoom()),this;if(this._panAnim||(this._panAnim=new an,this._panAnim.on({step:this._onPanTransitionStep,end:this._onPanTransitionEnd},this)),t.noMoveStart||this.fire(`movestart`),t.animate!==!1){J(this._mapPane,`leaflet-pan-anim`);var n=this._getMapPanePos().subtract(e).round();this._panAnim.run(this._mapPane,n,t.duration||.25,t.easeLinearity)}else this._rawPanBy(e),this.fire(`move`).fire(`moveend`);return this},flyTo:function(e,t,n){if(n||={},n.animate===!1||!W.any3d)return this.setView(e,t,n);this._stop();var r=this.project(this.getCenter()),i=this.project(e),a=this.getSize(),o=this._zoom;e=B(e),t=t===void 0?o:t;var s=Math.max(a.x,a.y),c=s*this.getZoomScale(o,t),l=i.distanceTo(r)||1,u=1.42,d=u*u;function f(e){var t=e?-1:1,n=e?c:s,r=(c*c-s*s+t*d*d*l*l)/(2*n*d*l),i=Math.sqrt(r*r+1)-r;return i<1e-9?-18:Math.log(i)}function p(e){return(Math.exp(e)-Math.exp(-e))/2}function m(e){return(Math.exp(e)+Math.exp(-e))/2}function h(e){return p(e)/m(e)}var g=f(0);function _(e){return s*(m(g)/m(g+u*e))}function v(e){return s*(m(g)*h(g+u*e)-p(g))/d}function y(e){return 1-(1-e)**1.5}var b=Date.now(),x=(f(1)-g)/u,S=n.duration?1e3*n.duration:1e3*x*.8;function C(){var n=(Date.now()-b)/S,a=y(n)*x;n<=1?(this._flyToFrame=T(C,this),this._move(this.unproject(r.add(i.subtract(r).multiplyBy(v(a)/l)),o),this.getScaleZoom(s/_(a),o),{flyTo:!0})):this._move(e,t)._moveEnd(!0)}return this._moveStart(!0,n.noMoveStart),C.call(this),this},flyToBounds:function(e,t){var n=this._getBoundsCenterZoom(e,t);return this.flyTo(n.center,n.zoom,t)},setMaxBounds:function(e){return e=R(e),this.listens(`moveend`,this._panInsideMaxBounds)&&this.off(`moveend`,this._panInsideMaxBounds),e.isValid()?(this.options.maxBounds=e,this._loaded&&this._panInsideMaxBounds(),this.on(`moveend`,this._panInsideMaxBounds)):(this.options.maxBounds=null,this)},setMinZoom:function(e){var t=this.options.minZoom;return this.options.minZoom=e,this._loaded&&t!==e&&(this.fire(`zoomlevelschange`),this.getZoom()<this.options.minZoom)?this.setZoom(e):this},setMaxZoom:function(e){var t=this.options.maxZoom;return this.options.maxZoom=e,this._loaded&&t!==e&&(this.fire(`zoomlevelschange`),this.getZoom()>this.options.maxZoom)?this.setZoom(e):this},panInsideBounds:function(e,t){this._enforcingBounds=!0;var n=this.getCenter(),r=this._limitCenter(n,this._zoom,R(e));return n.equals(r)||this.panTo(r,t),this._enforcingBounds=!1,this},panInside:function(e,t){t||={};var n=N(t.paddingTopLeft||t.padding||[0,0]),r=N(t.paddingBottomRight||t.padding||[0,0]),i=this.project(this.getCenter()),a=this.project(e),o=this.getPixelBounds(),s=F([o.min.add(n),o.max.subtract(r)]),c=s.getSize();if(!s.contains(a)){this._enforcingBounds=!0;var l=a.subtract(s.getCenter()),u=s.extend(a).getSize().subtract(c);i.x+=l.x<0?-u.x:u.x,i.y+=l.y<0?-u.y:u.y,this.panTo(this.unproject(i),t),this._enforcingBounds=!1}return this},invalidateSize:function(e){if(!this._loaded)return this;e=n({animate:!1,pan:!0},e===!0?{animate:!0}:e);var t=this.getSize();this._sizeChanged=!0,this._lastCenter=null;var r=this.getSize(),a=t.divideBy(2).round(),o=r.divideBy(2).round(),s=a.subtract(o);return!s.x&&!s.y?this:(e.animate&&e.pan?this.panBy(s):(e.pan&&this._rawPanBy(s),this.fire(`move`),e.debounceMoveend?(clearTimeout(this._sizeTimer),this._sizeTimer=setTimeout(i(this.fire,this,`moveend`),200)):this.fire(`moveend`)),this.fire(`resize`,{oldSize:t,newSize:r}))},stop:function(){return this.setZoom(this._limitZoom(this._zoom)),this.options.zoomSnap||this.fire(`viewreset`),this._stop()},locate:function(e){if(e=this._locateOptions=n({timeout:1e4,watch:!1},e),!(`geolocation`in navigator))return this._handleGeolocationError({code:0,message:`Geolocation not supported.`}),this;var t=i(this._handleGeolocationResponse,this),r=i(this._handleGeolocationError,this);return e.watch?this._locationWatchId=navigator.geolocation.watchPosition(t,r,e):navigator.geolocation.getCurrentPosition(t,r,e),this},stopLocate:function(){return navigator.geolocation&&navigator.geolocation.clearWatch&&navigator.geolocation.clearWatch(this._locationWatchId),this._locateOptions&&(this._locateOptions.setView=!1),this},_handleGeolocationError:function(e){if(this._container._leaflet_id){var t=e.code,n=e.message||(t===1?`permission denied`:t===2?`position unavailable`:`timeout`);this._locateOptions.setView&&!this._loaded&&this.fitWorld(),this.fire(`locationerror`,{code:t,message:`Geolocation error: `+n+`.`})}},_handleGeolocationResponse:function(e){if(this._container._leaflet_id){var t=e.coords.latitude,n=e.coords.longitude,r=new z(t,n),i=r.toBounds(e.coords.accuracy*2),a=this._locateOptions;if(a.setView){var o=this.getBoundsZoom(i);this.setView(r,a.maxZoom?Math.min(o,a.maxZoom):o)}var s={latlng:r,bounds:i,timestamp:e.timestamp};for(var c in e.coords)typeof e.coords[c]==`number`&&(s[c]=e.coords[c]);this.fire(`locationfound`,s)}},addHandler:function(e,t){if(!t)return this;var n=this[e]=new t(this);return this._handlers.push(n),this.options[e]&&n.enable(),this},remove:function(){if(this._initEvents(!0),this.options.maxBounds&&this.off(`moveend`,this._panInsideMaxBounds),this._containerId!==this._container._leaflet_id)throw Error(`Map container is being reused by another instance`);try{delete this._container._leaflet_id,delete this._containerId}catch{this._container._leaflet_id=void 0,this._containerId=void 0}for(var e in this._locationWatchId!==void 0&&this.stopLocate(),this._stop(),q(this._mapPane),this._clearControlPos&&this._clearControlPos(),this._resizeRequest&&=(E(this._resizeRequest),null),this._clearHandlers(),this._loaded&&this.fire(`unload`),this._layers)this._layers[e].remove();for(e in this._panes)q(this._panes[e]);return this._layers=[],this._panes=[],delete this._mapPane,delete this._renderer,this},createPane:function(e,t){var n=K(`div`,`leaflet-pane`+(e?` leaflet-`+e.replace(`Pane`,``)+`-pane`:``),t||this._mapPane);return e&&(this._panes[e]=n),n},getCenter:function(){return this._checkIfLoaded(),this._lastCenter&&!this._moved()?this._lastCenter.clone():this.layerPointToLatLng(this._getCenterLayerPoint())},getZoom:function(){return this._zoom},getBounds:function(){var e=this.getPixelBounds();return new I(this.unproject(e.getBottomLeft()),this.unproject(e.getTopRight()))},getMinZoom:function(){return this.options.minZoom===void 0?this._layersMinZoom||0:this.options.minZoom},getMaxZoom:function(){return this.options.maxZoom===void 0?this._layersMaxZoom===void 0?1/0:this._layersMaxZoom:this.options.maxZoom},getBoundsZoom:function(e,t,n){e=R(e),n=N(n||[0,0]);var r=this.getZoom()||0,i=this.getMinZoom(),a=this.getMaxZoom(),o=e.getNorthWest(),s=e.getSouthEast(),c=this.getSize().subtract(n),l=F(this.project(s,r),this.project(o,r)).getSize(),u=W.any3d?this.options.zoomSnap:1,d=c.x/l.x,f=c.y/l.y,p=t?Math.max(d,f):Math.min(d,f);return r=this.getScaleZoom(p,r),u&&(r=Math.round(r/(u/100))*(u/100),r=t?Math.ceil(r/u)*u:Math.floor(r/u)*u),Math.max(i,Math.min(a,r))},getSize:function(){return(!this._size||this._sizeChanged)&&(this._size=new M(this._container.clientWidth||0,this._container.clientHeight||0),this._sizeChanged=!1),this._size.clone()},getPixelBounds:function(e,t){var n=this._getTopLeftPoint(e,t);return new P(n,n.add(this.getSize()))},getPixelOrigin:function(){return this._checkIfLoaded(),this._pixelOrigin},getPixelWorldBounds:function(e){return this.options.crs.getProjectedBounds(e===void 0?this.getZoom():e)},getPane:function(e){return typeof e==`string`?this._panes[e]:e},getPanes:function(){return this._panes},getContainer:function(){return this._container},getZoomScale:function(e,t){var n=this.options.crs;return t=t===void 0?this._zoom:t,n.scale(e)/n.scale(t)},getScaleZoom:function(e,t){var n=this.options.crs;t=t===void 0?this._zoom:t;var r=n.zoom(e*n.scale(t));return isNaN(r)?1/0:r},project:function(e,t){return t=t===void 0?this._zoom:t,this.options.crs.latLngToPoint(B(e),t)},unproject:function(e,t){return t=t===void 0?this._zoom:t,this.options.crs.pointToLatLng(N(e),t)},layerPointToLatLng:function(e){var t=N(e).add(this.getPixelOrigin());return this.unproject(t)},latLngToLayerPoint:function(e){return this.project(B(e))._round()._subtract(this.getPixelOrigin())},wrapLatLng:function(e){return this.options.crs.wrapLatLng(B(e))},wrapLatLngBounds:function(e){return this.options.crs.wrapLatLngBounds(R(e))},distance:function(e,t){return this.options.crs.distance(B(e),B(t))},containerPointToLayerPoint:function(e){return N(e).subtract(this._getMapPanePos())},layerPointToContainerPoint:function(e){return N(e).add(this._getMapPanePos())},containerPointToLatLng:function(e){var t=this.containerPointToLayerPoint(N(e));return this.layerPointToLatLng(t)},latLngToContainerPoint:function(e){return this.layerPointToContainerPoint(this.latLngToLayerPoint(B(e)))},mouseEventToContainerPoint:function(e){return $t(e,this._container)},mouseEventToLayerPoint:function(e){return this.containerPointToLayerPoint(this.mouseEventToContainerPoint(e))},mouseEventToLatLng:function(e){return this.layerPointToLatLng(this.mouseEventToLayerPoint(e))},_initContainer:function(e){var t=this._container=mt(e);if(!t)throw Error(`Map container not found.`);if(t._leaflet_id)throw Error(`Map container is already initialized.`);X(t,`scroll`,this._onScroll,this),this._containerId=o(t)},_initLayout:function(){var e=this._container;this._fadeAnimated=this.options.fadeAnimation&&W.any3d,J(e,`leaflet-container`+(W.touch?` leaflet-touch`:``)+(W.retina?` leaflet-retina`:``)+(W.ielt9?` leaflet-oldie`:``)+(W.safari?` leaflet-safari`:``)+(this._fadeAnimated?` leaflet-fade-anim`:``));var t=ht(e,`position`);t!==`absolute`&&t!==`relative`&&t!==`fixed`&&t!==`sticky`&&(e.style.position=`relative`),this._initPanes(),this._initControlPos&&this._initControlPos()},_initPanes:function(){var e=this._panes={};this._paneRenderers={},this._mapPane=this.createPane(`mapPane`,this._container),Y(this._mapPane,new M(0,0)),this.createPane(`tilePane`),this.createPane(`overlayPane`),this.createPane(`shadowPane`),this.createPane(`markerPane`),this.createPane(`tooltipPane`),this.createPane(`popupPane`),this.options.markerZoomAnimation||(J(e.markerPane,`leaflet-zoom-hide`),J(e.shadowPane,`leaflet-zoom-hide`))},_resetView:function(e,t,n){Y(this._mapPane,new M(0,0));var r=!this._loaded;this._loaded=!0,t=this._limitZoom(t),this.fire(`viewprereset`);var i=this._zoom!==t;this._moveStart(i,n)._move(e,t)._moveEnd(i),this.fire(`viewreset`),r&&this.fire(`load`)},_moveStart:function(e,t){return e&&this.fire(`zoomstart`),t||this.fire(`movestart`),this},_move:function(e,t,n,r){t===void 0&&(t=this._zoom);var i=this._zoom!==t;return this._zoom=t,this._lastCenter=e,this._pixelOrigin=this._getNewPixelOrigin(e),r?n&&n.pinch&&this.fire(`zoom`,n):((i||n&&n.pinch)&&this.fire(`zoom`,n),this.fire(`move`,n)),this},_moveEnd:function(e){return e&&this.fire(`zoomend`),this.fire(`moveend`)},_stop:function(){return E(this._flyToFrame),this._panAnim&&this._panAnim.stop(),this},_rawPanBy:function(e){Y(this._mapPane,this._getMapPanePos().subtract(e))},_getZoomSpan:function(){return this.getMaxZoom()-this.getMinZoom()},_panInsideMaxBounds:function(){this._enforcingBounds||this.panInsideBounds(this.options.maxBounds)},_checkIfLoaded:function(){if(!this._loaded)throw Error(`Set map center and zoom first.`)},_initEvents:function(e){this._targets={},this._targets[o(this._container)]=this;var t=e?Ht:X;t(this._container,`click dblclick mousedown mouseup mouseover mouseout mousemove contextmenu keypress keydown keyup`,this._handleDOMEvent,this),this.options.trackResize&&t(window,`resize`,this._onResize,this),W.any3d&&this.options.transform3DLimit&&(e?this.off:this.on).call(this,`moveend`,this._onMoveEnd)},_onResize:function(){E(this._resizeRequest),this._resizeRequest=T(function(){this.invalidateSize({debounceMoveend:!0})},this)},_onScroll:function(){this._container.scrollTop=0,this._container.scrollLeft=0},_onMoveEnd:function(){var e=this._getMapPanePos();Math.max(Math.abs(e.x),Math.abs(e.y))>=this.options.transform3DLimit&&this._resetView(this.getCenter(),this.getZoom())},_findEventTargets:function(e,t){for(var n=[],r,i=t===`mouseout`||t===`mouseover`,a=e.target||e.srcElement,s=!1;a;){if(r=this._targets[o(a)],r&&(t===`click`||t===`preclick`)&&this._draggableMoved(r)){s=!0;break}if(r&&r.listens(t,!0)&&(i&&!nn(a,e)||(n.push(r),i))||a===this._container)break;a=a.parentNode}return!n.length&&!s&&!i&&this.listens(t,!0)&&(n=[this]),n},_isClickDisabled:function(e){for(;e&&e!==this._container;){if(e._leaflet_disable_click)return!0;e=e.parentNode}},_handleDOMEvent:function(e){var t=e.target||e.srcElement;if(!(!this._loaded||t._leaflet_disable_events||e.type===`click`&&this._isClickDisabled(t))){var n=e.type;n===`mousedown`&&It(t),this._fireDOMEvent(e,n)}},_mouseEvents:[`click`,`dblclick`,`mouseover`,`mouseout`,`contextmenu`],_fireDOMEvent:function(e,t,r){if(e.type===`click`){var i=n({},e);i.type=`preclick`,this._fireDOMEvent(i,i.type,r)}var a=this._findEventTargets(e,t);if(r){for(var o=[],s=0;s<r.length;s++)r[s].listens(t,!0)&&o.push(r[s]);a=o.concat(a)}if(a.length){t===`contextmenu`&&Xt(e);var c=a[0],l={originalEvent:e};if(e.type!==`keypress`&&e.type!==`keydown`&&e.type!==`keyup`){var u=c.getLatLng&&(!c._radius||c._radius<=10);l.containerPoint=u?this.latLngToContainerPoint(c.getLatLng()):this.mouseEventToContainerPoint(e),l.layerPoint=this.containerPointToLayerPoint(l.containerPoint),l.latlng=u?c.getLatLng():this.layerPointToLatLng(l.layerPoint)}for(s=0;s<a.length;s++)if(a[s].fire(t,l,!0),l.originalEvent._stopped||a[s].options.bubblingMouseEvents===!1&&v(this._mouseEvents,t)!==-1)return}},_draggableMoved:function(e){return e=e.dragging&&e.dragging.enabled()?e:this,e.dragging&&e.dragging.moved()||this.boxZoom&&this.boxZoom.moved()},_clearHandlers:function(){for(var e=0,t=this._handlers.length;e<t;e++)this._handlers[e].disable()},whenReady:function(e,t){return this._loaded?e.call(t||this,{target:this}):this.on(`load`,e,t),this},_getMapPanePos:function(){return Dt(this._mapPane)||new M(0,0)},_moved:function(){var e=this._getMapPanePos();return e&&!e.equals([0,0])},_getTopLeftPoint:function(e,t){return(e&&t!==void 0?this._getNewPixelOrigin(e,t):this.getPixelOrigin()).subtract(this._getMapPanePos())},_getNewPixelOrigin:function(e,t){var n=this.getSize()._divideBy(2);return this.project(e,t)._subtract(n)._add(this._getMapPanePos())._round()},_latLngToNewLayerPoint:function(e,t,n){var r=this._getNewPixelOrigin(n,t);return this.project(e,t)._subtract(r)},_latLngBoundsToNewLayerBounds:function(e,t,n){var r=this._getNewPixelOrigin(n,t);return F([this.project(e.getSouthWest(),t)._subtract(r),this.project(e.getNorthWest(),t)._subtract(r),this.project(e.getSouthEast(),t)._subtract(r),this.project(e.getNorthEast(),t)._subtract(r)])},_getCenterLayerPoint:function(){return this.containerPointToLayerPoint(this.getSize()._divideBy(2))},_getCenterOffset:function(e){return this.latLngToLayerPoint(e).subtract(this._getCenterLayerPoint())},_limitCenter:function(e,t,n){if(!n)return e;var r=this.project(e,t),i=this.getSize().divideBy(2),a=new P(r.subtract(i),r.add(i)),o=this._getBoundsOffset(a,n,t);return Math.abs(o.x)<=1&&Math.abs(o.y)<=1?e:this.unproject(r.add(o),t)},_limitOffset:function(e,t){if(!t)return e;var n=this.getPixelBounds(),r=new P(n.min.add(e),n.max.add(e));return e.add(this._getBoundsOffset(r,t))},_getBoundsOffset:function(e,t,n){var r=F(this.project(t.getNorthEast(),n),this.project(t.getSouthWest(),n)),i=r.min.subtract(e.min),a=r.max.subtract(e.max);return new M(this._rebound(i.x,-a.x),this._rebound(i.y,-a.y))},_rebound:function(e,t){return e+t>0?Math.round(e-t)/2:Math.max(0,Math.ceil(e))-Math.max(0,Math.floor(t))},_limitZoom:function(e){var t=this.getMinZoom(),n=this.getMaxZoom(),r=W.any3d?this.options.zoomSnap:1;return r&&(e=Math.round(e/r)*r),Math.max(t,Math.min(n,e))},_onPanTransitionStep:function(){this.fire(`move`)},_onPanTransitionEnd:function(){bt(this._mapPane,`leaflet-pan-anim`),this.fire(`moveend`)},_tryAnimatedPan:function(e,t){var n=this._getCenterOffset(e)._trunc();return(t&&t.animate)!==!0&&!this.getSize().contains(n)?!1:(this.panBy(n,t),!0)},_createAnimProxy:function(){var e=this._proxy=K(`div`,`leaflet-proxy leaflet-zoom-animated`);this._panes.mapPane.appendChild(e),this.on(`zoomanim`,function(e){var t=dt,n=this._proxy.style[t];Et(this._proxy,this.project(e.center,e.zoom),this.getZoomScale(e.zoom,1)),n===this._proxy.style[t]&&this._animatingZoom&&this._onZoomTransitionEnd()},this),this.on(`load moveend`,this._animMoveEnd,this),this._on(`unload`,this._destroyAnimProxy,this)},_destroyAnimProxy:function(){q(this._proxy),this.off(`load moveend`,this._animMoveEnd,this),delete this._proxy},_animMoveEnd:function(){var e=this.getCenter(),t=this.getZoom();Et(this._proxy,this.project(e,t),this.getZoomScale(t,1))},_catchTransitionEnd:function(e){this._animatingZoom&&e.propertyName.indexOf(`transform`)>=0&&this._onZoomTransitionEnd()},_nothingToAnimate:function(){return!this._container.getElementsByClassName(`leaflet-zoom-animated`).length},_tryAnimatedZoom:function(e,t,n){if(this._animatingZoom)return!0;if(n||={},!this._zoomAnimated||n.animate===!1||this._nothingToAnimate()||Math.abs(t-this._zoom)>this.options.zoomAnimationThreshold)return!1;var r=this.getZoomScale(t),i=this._getCenterOffset(e)._divideBy(1-1/r);return n.animate!==!0&&!this.getSize().contains(i)?!1:(T(function(){this._moveStart(!0,n.noMoveStart||!1)._animateZoom(e,t,!0)},this),!0)},_animateZoom:function(e,t,n,r){this._mapPane&&(n&&(this._animatingZoom=!0,this._animateToCenter=e,this._animateToZoom=t,J(this._mapPane,`leaflet-zoom-anim`)),this.fire(`zoomanim`,{center:e,zoom:t,noUpdate:r}),this._tempFireZoomEvent||=this._zoom!==this._animateToZoom,this._move(this._animateToCenter,this._animateToZoom,void 0,!0),setTimeout(i(this._onZoomTransitionEnd,this),250))},_onZoomTransitionEnd:function(){this._animatingZoom&&(this._mapPane&&bt(this._mapPane,`leaflet-zoom-anim`),this._animatingZoom=!1,this._move(this._animateToCenter,this._animateToZoom,void 0,!0),this._tempFireZoomEvent&&this.fire(`zoom`),delete this._tempFireZoomEvent,this.fire(`move`),this._moveEnd(!0))}});function sn(e,t){return new on(e,t)}var cn=O.extend({options:{position:`topright`},initialize:function(e){p(this,e)},getPosition:function(){return this.options.position},setPosition:function(e){var t=this._map;return t&&t.removeControl(this),this.options.position=e,t&&t.addControl(this),this},getContainer:function(){return this._container},addTo:function(e){this.remove(),this._map=e;var t=this._container=this.onAdd(e),n=this.getPosition(),r=e._controlCorners[n];return J(t,`leaflet-control`),n.indexOf(`bottom`)===-1?r.appendChild(t):r.insertBefore(t,r.firstChild),this._map.on(`unload`,this.remove,this),this},remove:function(){return this._map&&=(q(this._container),this.onRemove&&this.onRemove(this._map),this._map.off(`unload`,this.remove,this),null),this},_refocusOnMap:function(e){this._map&&e&&e.screenX>0&&e.screenY>0&&this._map.getContainer().focus()}}),ln=function(e){return new cn(e)};on.include({addControl:function(e){return e.addTo(this),this},removeControl:function(e){return e.remove(),this},_initControlPos:function(){var e=this._controlCorners={},t=`leaflet-`,n=this._controlContainer=K(`div`,t+`control-container`,this._container);function r(r,i){var a=t+r+` `+t+i;e[r+i]=K(`div`,a,n)}r(`top`,`left`),r(`top`,`right`),r(`bottom`,`left`),r(`bottom`,`right`)},_clearControlPos:function(){for(var e in this._controlCorners)q(this._controlCorners[e]);q(this._controlContainer),delete this._controlCorners,delete this._controlContainer}});var un=cn.extend({options:{collapsed:!0,position:`topright`,autoZIndex:!0,hideSingleBase:!1,sortLayers:!1,sortFunction:function(e,t,n,r){return n<r?-1:+(r<n)}},initialize:function(e,t,n){for(var r in p(this,n),this._layerControlInputs=[],this._layers=[],this._lastZIndex=0,this._handlingClick=!1,this._preventClick=!1,e)this._addLayer(e[r],r);for(r in t)this._addLayer(t[r],r,!0)},onAdd:function(e){this._initLayout(),this._update(),this._map=e,e.on(`zoomend`,this._checkDisabledLayers,this);for(var t=0;t<this._layers.length;t++)this._layers[t].layer.on(`add remove`,this._onLayerChange,this);return this._container},addTo:function(e){return cn.prototype.addTo.call(this,e),this._expandIfNotCollapsed()},onRemove:function(){this._map.off(`zoomend`,this._checkDisabledLayers,this);for(var e=0;e<this._layers.length;e++)this._layers[e].layer.off(`add remove`,this._onLayerChange,this)},addBaseLayer:function(e,t){return this._addLayer(e,t),this._map?this._update():this},addOverlay:function(e,t){return this._addLayer(e,t,!0),this._map?this._update():this},removeLayer:function(e){e.off(`add remove`,this._onLayerChange,this);var t=this._getLayer(o(e));return t&&this._layers.splice(this._layers.indexOf(t),1),this._map?this._update():this},expand:function(){J(this._container,`leaflet-control-layers-expanded`),this._section.style.height=null;var e=this._map.getSize().y-(this._container.offsetTop+50);return e<this._section.clientHeight?(J(this._section,`leaflet-control-layers-scrollbar`),this._section.style.height=e+`px`):bt(this._section,`leaflet-control-layers-scrollbar`),this._checkDisabledLayers(),this},collapse:function(){return bt(this._container,`leaflet-control-layers-expanded`),this},_initLayout:function(){var e=`leaflet-control-layers`,t=this._container=K(`div`,e),n=this.options.collapsed;t.setAttribute(`aria-haspopup`,!0),Yt(t),Jt(t);var r=this._section=K(`section`,e+`-list`);n&&(this._map.on(`click`,this.collapse,this),X(t,{mouseenter:this._expandSafely,mouseleave:this.collapse},this));var i=this._layersLink=K(`a`,e+`-toggle`,t);i.href=`#`,i.title=`Layers`,i.setAttribute(`role`,`button`),X(i,{keydown:function(e){e.keyCode===13&&this._expandSafely()},click:function(e){Xt(e),this._expandSafely()}},this),n||this.expand(),this._baseLayersList=K(`div`,e+`-base`,r),this._separator=K(`div`,e+`-separator`,r),this._overlaysList=K(`div`,e+`-overlays`,r),t.appendChild(r)},_getLayer:function(e){for(var t=0;t<this._layers.length;t++)if(this._layers[t]&&o(this._layers[t].layer)===e)return this._layers[t]},_addLayer:function(e,t,n){this._map&&e.on(`add remove`,this._onLayerChange,this),this._layers.push({layer:e,name:t,overlay:n}),this.options.sortLayers&&this._layers.sort(i(function(e,t){return this.options.sortFunction(e.layer,t.layer,e.name,t.name)},this)),this.options.autoZIndex&&e.setZIndex&&(this._lastZIndex++,e.setZIndex(this._lastZIndex)),this._expandIfNotCollapsed()},_update:function(){if(!this._container)return this;gt(this._baseLayersList),gt(this._overlaysList),this._layerControlInputs=[];var e,t,n,r,i=0;for(n=0;n<this._layers.length;n++)r=this._layers[n],this._addItem(r),t||=r.overlay,e||=!r.overlay,i+=+!r.overlay;return this.options.hideSingleBase&&(e&&=i>1,this._baseLayersList.style.display=e?``:`none`),this._separator.style.display=t&&e?``:`none`,this},_onLayerChange:function(e){this._handlingClick||this._update();var t=this._getLayer(o(e.target)),n=t.overlay?e.type===`add`?`overlayadd`:`overlayremove`:e.type===`add`?`baselayerchange`:null;n&&this._map.fire(n,t)},_createRadioElement:function(e,t){var n=`<input type="radio" class="leaflet-control-layers-selector" name="`+e+`"`+(t?` checked="checked"`:``)+`/>`,r=document.createElement(`div`);return r.innerHTML=n,r.firstChild},_addItem:function(e){var t=document.createElement(`label`),n=this._map.hasLayer(e.layer),r;e.overlay?(r=document.createElement(`input`),r.type=`checkbox`,r.className=`leaflet-control-layers-selector`,r.defaultChecked=n):r=this._createRadioElement(`leaflet-base-layers_`+o(this),n),this._layerControlInputs.push(r),r.layerId=o(e.layer),X(r,`click`,this._onInputClick,this);var i=document.createElement(`span`);i.innerHTML=` `+e.name;var a=document.createElement(`span`);return t.appendChild(a),a.appendChild(r),a.appendChild(i),(e.overlay?this._overlaysList:this._baseLayersList).appendChild(t),this._checkDisabledLayers(),t},_onInputClick:function(){if(!this._preventClick){var e=this._layerControlInputs,t,n,r=[],i=[];this._handlingClick=!0;for(var a=e.length-1;a>=0;a--)t=e[a],n=this._getLayer(t.layerId).layer,t.checked?r.push(n):t.checked||i.push(n);for(a=0;a<i.length;a++)this._map.hasLayer(i[a])&&this._map.removeLayer(i[a]);for(a=0;a<r.length;a++)this._map.hasLayer(r[a])||this._map.addLayer(r[a]);this._handlingClick=!1,this._refocusOnMap()}},_checkDisabledLayers:function(){for(var e=this._layerControlInputs,t,n,r=this._map.getZoom(),i=e.length-1;i>=0;i--)t=e[i],n=this._getLayer(t.layerId).layer,t.disabled=n.options.minZoom!==void 0&&r<n.options.minZoom||n.options.maxZoom!==void 0&&r>n.options.maxZoom},_expandIfNotCollapsed:function(){return this._map&&!this.options.collapsed&&this.expand(),this},_expandSafely:function(){var e=this._section;this._preventClick=!0,X(e,`click`,Xt),this.expand();var t=this;setTimeout(function(){Ht(e,`click`,Xt),t._preventClick=!1})}}),dn=function(e,t,n){return new un(e,t,n)},fn=cn.extend({options:{position:`topleft`,zoomInText:`<span aria-hidden="true">+</span>`,zoomInTitle:`Zoom in`,zoomOutText:`<span aria-hidden="true">&#x2212;</span>`,zoomOutTitle:`Zoom out`},onAdd:function(e){var t=`leaflet-control-zoom`,n=K(`div`,t+` leaflet-bar`),r=this.options;return this._zoomInButton=this._createButton(r.zoomInText,r.zoomInTitle,t+`-in`,n,this._zoomIn),this._zoomOutButton=this._createButton(r.zoomOutText,r.zoomOutTitle,t+`-out`,n,this._zoomOut),this._updateDisabled(),e.on(`zoomend zoomlevelschange`,this._updateDisabled,this),n},onRemove:function(e){e.off(`zoomend zoomlevelschange`,this._updateDisabled,this)},disable:function(){return this._disabled=!0,this._updateDisabled(),this},enable:function(){return this._disabled=!1,this._updateDisabled(),this},_zoomIn:function(e){!this._disabled&&this._map._zoom<this._map.getMaxZoom()&&this._map.zoomIn(this._map.options.zoomDelta*(e.shiftKey?3:1))},_zoomOut:function(e){!this._disabled&&this._map._zoom>this._map.getMinZoom()&&this._map.zoomOut(this._map.options.zoomDelta*(e.shiftKey?3:1))},_createButton:function(e,t,n,r,i){var a=K(`a`,n,r);return a.innerHTML=e,a.href=`#`,a.title=t,a.setAttribute(`role`,`button`),a.setAttribute(`aria-label`,t),Yt(a),X(a,`click`,Zt),X(a,`click`,i,this),X(a,`click`,this._refocusOnMap,this),a},_updateDisabled:function(){var e=this._map,t=`leaflet-disabled`;bt(this._zoomInButton,t),bt(this._zoomOutButton,t),this._zoomInButton.setAttribute(`aria-disabled`,`false`),this._zoomOutButton.setAttribute(`aria-disabled`,`false`),(this._disabled||e._zoom===e.getMinZoom())&&(J(this._zoomOutButton,t),this._zoomOutButton.setAttribute(`aria-disabled`,`true`)),(this._disabled||e._zoom===e.getMaxZoom())&&(J(this._zoomInButton,t),this._zoomInButton.setAttribute(`aria-disabled`,`true`))}});on.mergeOptions({zoomControl:!0}),on.addInitHook(function(){this.options.zoomControl&&(this.zoomControl=new fn,this.addControl(this.zoomControl))});var pn=function(e){return new fn(e)},mn=cn.extend({options:{position:`bottomleft`,maxWidth:100,metric:!0,imperial:!0},onAdd:function(e){var t=`leaflet-control-scale`,n=K(`div`,t),r=this.options;return this._addScales(r,t+`-line`,n),e.on(r.updateWhenIdle?`moveend`:`move`,this._update,this),e.whenReady(this._update,this),n},onRemove:function(e){e.off(this.options.updateWhenIdle?`moveend`:`move`,this._update,this)},_addScales:function(e,t,n){e.metric&&(this._mScale=K(`div`,t,n)),e.imperial&&(this._iScale=K(`div`,t,n))},_update:function(){var e=this._map,t=e.getSize().y/2,n=e.distance(e.containerPointToLatLng([0,t]),e.containerPointToLatLng([this.options.maxWidth,t]));this._updateScales(n)},_updateScales:function(e){this.options.metric&&e&&this._updateMetric(e),this.options.imperial&&e&&this._updateImperial(e)},_updateMetric:function(e){var t=this._getRoundNum(e),n=t<1e3?t+` m`:t/1e3+` km`;this._updateScale(this._mScale,n,t/e)},_updateImperial:function(e){var t=e*3.2808399,n,r,i;t>5280?(n=t/5280,r=this._getRoundNum(n),this._updateScale(this._iScale,r+` mi`,r/n)):(i=this._getRoundNum(t),this._updateScale(this._iScale,i+` ft`,i/t))},_updateScale:function(e,t,n){e.style.width=Math.round(this.options.maxWidth*n)+`px`,e.innerHTML=t},_getRoundNum:function(e){var t=10**((Math.floor(e)+``).length-1),n=e/t;return n=n>=10?10:n>=5?5:n>=3?3:n>=2?2:1,t*n}}),hn=function(e){return new mn(e)},gn=cn.extend({options:{position:`bottomright`,prefix:`<a href="https://leafletjs.com" title="A JavaScript library for interactive maps">`+(W.inlineSvg?`<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="12" height="8" viewBox="0 0 12 8" class="leaflet-attribution-flag"><path fill="#4C7BE1" d="M0 0h12v4H0z"/><path fill="#FFD500" d="M0 4h12v3H0z"/><path fill="#E0BC00" d="M0 7h12v1H0z"/></svg> `:``)+`Leaflet</a>`},initialize:function(e){p(this,e),this._attributions={}},onAdd:function(e){for(var t in e.attributionControl=this,this._container=K(`div`,`leaflet-control-attribution`),Yt(this._container),e._layers)e._layers[t].getAttribution&&this.addAttribution(e._layers[t].getAttribution());return this._update(),e.on(`layeradd`,this._addAttribution,this),this._container},onRemove:function(e){e.off(`layeradd`,this._addAttribution,this)},_addAttribution:function(e){e.layer.getAttribution&&(this.addAttribution(e.layer.getAttribution()),e.layer.once(`remove`,function(){this.removeAttribution(e.layer.getAttribution())},this))},setPrefix:function(e){return this.options.prefix=e,this._update(),this},addAttribution:function(e){return e&&(this._attributions[e]||(this._attributions[e]=0),this._attributions[e]++,this._update()),this},removeAttribution:function(e){return e&&this._attributions[e]&&(this._attributions[e]--,this._update()),this},_update:function(){if(this._map){var e=[];for(var t in this._attributions)this._attributions[t]&&e.push(t);var n=[];this.options.prefix&&n.push(this.options.prefix),e.length&&n.push(e.join(`, `)),this._container.innerHTML=n.join(` <span aria-hidden="true">|</span> `)}}});on.mergeOptions({attributionControl:!0}),on.addInitHook(function(){this.options.attributionControl&&new gn().addTo(this)}),cn.Layers=un,cn.Zoom=fn,cn.Scale=mn,cn.Attribution=gn,ln.layers=dn,ln.zoom=pn,ln.scale=hn,ln.attribution=function(e){return new gn(e)};var _n=O.extend({initialize:function(e){this._map=e},enable:function(){return this._enabled||(this._enabled=!0,this.addHooks()),this},disable:function(){return this._enabled&&(this._enabled=!1,this.removeHooks()),this},enabled:function(){return!!this._enabled}});_n.addTo=function(e,t){return e.addHandler(t,this),this};var vn={Events:A},yn=W.touch?`touchstart mousedown`:`mousedown`,bn=j.extend({options:{clickTolerance:3},initialize:function(e,t,n,r){p(this,r),this._element=e,this._dragStartTarget=t||e,this._preventOutline=n},enable:function(){this._enabled||=(X(this._dragStartTarget,yn,this._onDown,this),!0)},disable:function(){this._enabled&&(bn._dragging===this&&this.finishDrag(!0),Ht(this._dragStartTarget,yn,this._onDown,this),this._enabled=!1,this._moved=!1)},_onDown:function(e){if(this._enabled&&(this._moved=!1,!yt(this._element,`leaflet-zoom-anim`))){if(e.touches&&e.touches.length!==1)bn._dragging===this&&this.finishDrag();else if(!(bn._dragging||e.shiftKey||e.which!==1&&e.button!==1&&!e.touches)&&(bn._dragging=this,this._preventOutline&&It(this._element),Mt(),Ot(),!this._moving)){this.fire(`down`);var t=e.touches?e.touches[0]:e,n=Rt(this._element);this._startPoint=new M(t.clientX,t.clientY),this._startPos=Dt(this._element),this._parentScale=zt(n);var r=e.type===`mousedown`;X(document,r?`mousemove`:`touchmove`,this._onMove,this),X(document,r?`mouseup`:`touchend touchcancel`,this._onUp,this)}}},_onMove:function(e){if(this._enabled){if(e.touches&&e.touches.length>1)this._moved=!0;else{var t=e.touches&&e.touches.length===1?e.touches[0]:e,n=new M(t.clientX,t.clientY)._subtract(this._startPoint);(n.x||n.y)&&(Math.abs(n.x)+Math.abs(n.y)<this.options.clickTolerance||(n.x/=this._parentScale.x,n.y/=this._parentScale.y,Xt(e),this._moved||(this.fire(`dragstart`),this._moved=!0,J(document.body,`leaflet-dragging`),this._lastTarget=e.target||e.srcElement,window.SVGElementInstance&&this._lastTarget instanceof window.SVGElementInstance&&(this._lastTarget=this._lastTarget.correspondingUseElement),J(this._lastTarget,`leaflet-drag-target`)),this._newPos=this._startPos.add(n),this._moving=!0,this._lastEvent=e,this._updatePosition()))}}},_updatePosition:function(){var e={originalEvent:this._lastEvent};this.fire(`predrag`,e),Y(this._element,this._newPos),this.fire(`drag`,e)},_onUp:function(){this._enabled&&this.finishDrag()},finishDrag:function(e){bt(document.body,`leaflet-dragging`),this._lastTarget&&=(bt(this._lastTarget,`leaflet-drag-target`),null),Ht(document,`mousemove touchmove`,this._onMove,this),Ht(document,`mouseup touchend touchcancel`,this._onUp,this),Nt(),kt();var t=this._moved&&this._moving;this._moving=!1,bn._dragging=!1,t&&this.fire(`dragend`,{noInertia:e,distance:this._newPos.distanceTo(this._startPos)})}});function xn(e,t,n){for(var r,i=[1,4,2,8],a=0,o,s,c,l,u=e.length,d,f;a<u;a++)e[a]._code=Pn(e[a],t);for(s=0;s<4;s++){for(d=i[s],r=[],a=0,u=e.length,o=u-1;a<u;o=a++)c=e[a],l=e[o],c._code&d?l._code&d||(f=Nn(l,c,d,t,n),f._code=Pn(f,t),r.push(f)):(l._code&d&&(f=Nn(l,c,d,t,n),f._code=Pn(f,t),r.push(f)),r.push(c));e=r}return e}function Sn(e,t){var n,r,i,a,o,s,c,l,u;if(!e||e.length===0)throw Error(`latlngs not passed`);Ln(e)||(console.warn(`latlngs are not flat! Only the first ring will be used`),e=e[0]);var d=B([0,0]),f=R(e);f.getNorthWest().distanceTo(f.getSouthWest())*f.getNorthEast().distanceTo(f.getNorthWest())<1700&&(d=Cn(e));var p=e.length,m=[];for(n=0;n<p;n++){var h=B(e[n]);m.push(t.project(B([h.lat-d.lat,h.lng-d.lng])))}for(s=c=l=0,n=0,r=p-1;n<p;r=n++)i=m[n],a=m[r],o=i.y*a.x-a.y*i.x,c+=(i.x+a.x)*o,l+=(i.y+a.y)*o,s+=o*3;u=s===0?m[0]:[c/s,l/s];var g=t.unproject(N(u));return B([g.lat+d.lat,g.lng+d.lng])}function Cn(e){for(var t=0,n=0,r=0,i=0;i<e.length;i++){var a=B(e[i]);t+=a.lat,n+=a.lng,r++}return B([t/r,n/r])}var wn={__proto__:null,clipPolygon:xn,polygonCenter:Sn,centroid:Cn};function Tn(e,t){if(!t||!e.length)return e.slice();var n=t*t;return e=An(e,n),e=On(e,n),e}function En(e,t,n){return Math.sqrt(In(e,t,n,!0))}function Dn(e,t,n){return In(e,t,n)}function On(e,t){var n=e.length,r=new(typeof Uint8Array<`u`?Uint8Array:Array)(n);r[0]=r[n-1]=1,kn(e,r,t,0,n-1);var i,a=[];for(i=0;i<n;i++)r[i]&&a.push(e[i]);return a}function kn(e,t,n,r,i){for(var a=0,o,s=r+1,c;s<=i-1;s++)c=In(e[s],e[r],e[i],!0),c>a&&(o=s,a=c);a>n&&(t[o]=1,kn(e,t,n,r,o),kn(e,t,n,o,i))}function An(e,t){for(var n=[e[0]],r=1,i=0,a=e.length;r<a;r++)Fn(e[r],e[i])>t&&(n.push(e[r]),i=r);return i<a-1&&n.push(e[a-1]),n}var jn;function Mn(e,t,n,r,i){var a=r?jn:Pn(e,n),o=Pn(t,n),s,c,l;for(jn=o;;){if(!(a|o))return[e,t];if(a&o)return!1;s=a||o,c=Nn(e,t,s,n,i),l=Pn(c,n),s===a?(e=c,a=l):(t=c,o=l)}}function Nn(e,t,n,r,i){var a=t.x-e.x,o=t.y-e.y,s=r.min,c=r.max,l,u;return n&8?(l=e.x+a*(c.y-e.y)/o,u=c.y):n&4?(l=e.x+a*(s.y-e.y)/o,u=s.y):n&2?(l=c.x,u=e.y+o*(c.x-e.x)/a):n&1&&(l=s.x,u=e.y+o*(s.x-e.x)/a),new M(l,u,i)}function Pn(e,t){var n=0;return e.x<t.min.x?n|=1:e.x>t.max.x&&(n|=2),e.y<t.min.y?n|=4:e.y>t.max.y&&(n|=8),n}function Fn(e,t){var n=t.x-e.x,r=t.y-e.y;return n*n+r*r}function In(e,t,n,r){var i=t.x,a=t.y,o=n.x-i,s=n.y-a,c=o*o+s*s,l;return c>0&&(l=((e.x-i)*o+(e.y-a)*s)/c,l>1?(i=n.x,a=n.y):l>0&&(i+=o*l,a+=s*l)),o=e.x-i,s=e.y-a,r?o*o+s*s:new M(i,a)}function Ln(e){return!_(e[0])||typeof e[0][0]!=`object`&&e[0][0]!==void 0}function Rn(e){return console.warn(`Deprecated use of _flat, please use L.LineUtil.isFlat instead.`),Ln(e)}function zn(e,t){var n,r,i,a,o,s,c,l;if(!e||e.length===0)throw Error(`latlngs not passed`);Ln(e)||(console.warn(`latlngs are not flat! Only the first ring will be used`),e=e[0]);var u=B([0,0]),d=R(e);d.getNorthWest().distanceTo(d.getSouthWest())*d.getNorthEast().distanceTo(d.getNorthWest())<1700&&(u=Cn(e));var f=e.length,p=[];for(n=0;n<f;n++){var m=B(e[n]);p.push(t.project(B([m.lat-u.lat,m.lng-u.lng])))}for(n=0,r=0;n<f-1;n++)r+=p[n].distanceTo(p[n+1])/2;if(r===0)l=p[0];else for(n=0,a=0;n<f-1;n++)if(o=p[n],s=p[n+1],i=o.distanceTo(s),a+=i,a>r){c=(a-r)/i,l=[s.x-c*(s.x-o.x),s.y-c*(s.y-o.y)];break}var h=t.unproject(N(l));return B([h.lat+u.lat,h.lng+u.lng])}var Bn={__proto__:null,simplify:Tn,pointToSegmentDistance:En,closestPointOnSegment:Dn,clipSegment:Mn,_getEdgeIntersection:Nn,_getBitCode:Pn,_sqClosestPointOnSegment:In,isFlat:Ln,_flat:Rn,polylineCenter:zn},Vn={project:function(e){return new M(e.lng,e.lat)},unproject:function(e){return new z(e.y,e.x)},bounds:new P([-180,-90],[180,90])},Hn={R:6378137,R_MINOR:6356752.314245179,bounds:new P([-20037508.34279,-15496570.73972],[20037508.34279,18764656.23138]),project:function(e){var t=Math.PI/180,n=this.R,r=e.lat*t,i=this.R_MINOR/n,a=Math.sqrt(1-i*i),o=a*Math.sin(r),s=Math.tan(Math.PI/4-r/2)/((1-o)/(1+o))**(a/2);return r=-n*Math.log(Math.max(s,1e-10)),new M(e.lng*t*n,r)},unproject:function(e){for(var t=180/Math.PI,n=this.R,r=this.R_MINOR/n,i=Math.sqrt(1-r*r),a=Math.exp(-e.y/n),o=Math.PI/2-2*Math.atan(a),s=0,c=.1,l;s<15&&Math.abs(c)>1e-7;s++)l=i*Math.sin(o),l=((1-l)/(1+l))**(i/2),c=Math.PI/2-2*Math.atan(a*l)-o,o+=c;return new z(o*t,e.x*t/n)}},Un={__proto__:null,LonLat:Vn,Mercator:Hn,SphericalMercator:ie},Wn=n({},ne,{code:`EPSG:3395`,projection:Hn,transformation:function(){var e=.5/(Math.PI*Hn.R);return oe(e,.5,-e,.5)}()}),Gn=n({},ne,{code:`EPSG:4326`,projection:Vn,transformation:oe(1/180,1,-1/180,.5)}),Kn=n({},te,{projection:Vn,transformation:oe(1,0,-1,0),scale:function(e){return 2**e},zoom:function(e){return Math.log(e)/Math.LN2},distance:function(e,t){var n=t.lng-e.lng,r=t.lat-e.lat;return Math.sqrt(n*n+r*r)},infinite:!0});te.Earth=ne,te.EPSG3395=Wn,te.EPSG3857=se,te.EPSG900913=ce,te.EPSG4326=Gn,te.Simple=Kn;var qn=j.extend({options:{pane:`overlayPane`,attribution:null,bubblingMouseEvents:!0},addTo:function(e){return e.addLayer(this),this},remove:function(){return this.removeFrom(this._map||this._mapToAdd)},removeFrom:function(e){return e&&e.removeLayer(this),this},getPane:function(e){return this._map.getPane(e?this.options[e]||e:this.options.pane)},addInteractiveTarget:function(e){return this._map._targets[o(e)]=this,this},removeInteractiveTarget:function(e){return delete this._map._targets[o(e)],this},getAttribution:function(){return this.options.attribution},_layerAdd:function(e){var t=e.target;if(t.hasLayer(this)){if(this._map=t,this._zoomAnimated=t._zoomAnimated,this.getEvents){var n=this.getEvents();t.on(n,this),this.once(`remove`,function(){t.off(n,this)},this)}this.onAdd(t),this.fire(`add`),t.fire(`layeradd`,{layer:this})}}});on.include({addLayer:function(e){if(!e._layerAdd)throw Error(`The provided object is not a Layer.`);var t=o(e);return this._layers[t]||(this._layers[t]=e,e._mapToAdd=this,e.beforeAdd&&e.beforeAdd(this),this.whenReady(e._layerAdd,e)),this},removeLayer:function(e){var t=o(e);return this._layers[t]&&(this._loaded&&e.onRemove(this),delete this._layers[t],this._loaded&&(this.fire(`layerremove`,{layer:e}),e.fire(`remove`)),e._map=e._mapToAdd=null),this},hasLayer:function(e){return o(e)in this._layers},eachLayer:function(e,t){for(var n in this._layers)e.call(t,this._layers[n]);return this},_addLayers:function(e){e=e?_(e)?e:[e]:[];for(var t=0,n=e.length;t<n;t++)this.addLayer(e[t])},_addZoomLimit:function(e){(!isNaN(e.options.maxZoom)||!isNaN(e.options.minZoom))&&(this._zoomBoundLayers[o(e)]=e,this._updateZoomLevels())},_removeZoomLimit:function(e){var t=o(e);this._zoomBoundLayers[t]&&(delete this._zoomBoundLayers[t],this._updateZoomLevels())},_updateZoomLevels:function(){var e=1/0,t=-1/0,n=this._getZoomSpan();for(var r in this._zoomBoundLayers){var i=this._zoomBoundLayers[r].options;e=i.minZoom===void 0?e:Math.min(e,i.minZoom),t=i.maxZoom===void 0?t:Math.max(t,i.maxZoom)}this._layersMaxZoom=t===-1/0?void 0:t,this._layersMinZoom=e===1/0?void 0:e,n!==this._getZoomSpan()&&this.fire(`zoomlevelschange`),this.options.maxZoom===void 0&&this._layersMaxZoom&&this.getZoom()>this._layersMaxZoom&&this.setZoom(this._layersMaxZoom),this.options.minZoom===void 0&&this._layersMinZoom&&this.getZoom()<this._layersMinZoom&&this.setZoom(this._layersMinZoom)}});var Jn=qn.extend({initialize:function(e,t){p(this,t),this._layers={};var n,r;if(e)for(n=0,r=e.length;n<r;n++)this.addLayer(e[n])},addLayer:function(e){var t=this.getLayerId(e);return this._layers[t]=e,this._map&&this._map.addLayer(e),this},removeLayer:function(e){var t=e in this._layers?e:this.getLayerId(e);return this._map&&this._layers[t]&&this._map.removeLayer(this._layers[t]),delete this._layers[t],this},hasLayer:function(e){return(typeof e==`number`?e:this.getLayerId(e))in this._layers},clearLayers:function(){return this.eachLayer(this.removeLayer,this)},invoke:function(e){var t=Array.prototype.slice.call(arguments,1),n,r;for(n in this._layers)r=this._layers[n],r[e]&&r[e].apply(r,t);return this},onAdd:function(e){this.eachLayer(e.addLayer,e)},onRemove:function(e){this.eachLayer(e.removeLayer,e)},eachLayer:function(e,t){for(var n in this._layers)e.call(t,this._layers[n]);return this},getLayer:function(e){return this._layers[e]},getLayers:function(){var e=[];return this.eachLayer(e.push,e),e},setZIndex:function(e){return this.invoke(`setZIndex`,e)},getLayerId:function(e){return o(e)}}),Yn=function(e,t){return new Jn(e,t)},Xn=Jn.extend({addLayer:function(e){return this.hasLayer(e)?this:(e.addEventParent(this),Jn.prototype.addLayer.call(this,e),this.fire(`layeradd`,{layer:e}))},removeLayer:function(e){return this.hasLayer(e)?(e in this._layers&&(e=this._layers[e]),e.removeEventParent(this),Jn.prototype.removeLayer.call(this,e),this.fire(`layerremove`,{layer:e})):this},setStyle:function(e){return this.invoke(`setStyle`,e)},bringToFront:function(){return this.invoke(`bringToFront`)},bringToBack:function(){return this.invoke(`bringToBack`)},getBounds:function(){var e=new I;for(var t in this._layers){var n=this._layers[t];e.extend(n.getBounds?n.getBounds():n.getLatLng())}return e}}),Zn=function(e,t){return new Xn(e,t)},Qn=O.extend({options:{popupAnchor:[0,0],tooltipAnchor:[0,0],crossOrigin:!1},initialize:function(e){p(this,e)},createIcon:function(e){return this._createIcon(`icon`,e)},createShadow:function(e){return this._createIcon(`shadow`,e)},_createIcon:function(e,t){var n=this._getIconUrl(e);if(!n){if(e===`icon`)throw Error(`iconUrl not set in Icon options (see the docs).`);return null}var r=this._createImg(n,t&&t.tagName===`IMG`?t:null);return this._setIconStyles(r,e),(this.options.crossOrigin||this.options.crossOrigin===``)&&(r.crossOrigin=this.options.crossOrigin===!0?``:this.options.crossOrigin),r},_setIconStyles:function(e,t){var n=this.options,r=n[t+`Size`];typeof r==`number`&&(r=[r,r]);var i=N(r),a=N(t===`shadow`&&n.shadowAnchor||n.iconAnchor||i&&i.divideBy(2,!0));e.className=`leaflet-marker-`+t+` `+(n.className||``),a&&(e.style.marginLeft=-a.x+`px`,e.style.marginTop=-a.y+`px`),i&&(e.style.width=i.x+`px`,e.style.height=i.y+`px`)},_createImg:function(e,t){return t||=document.createElement(`img`),t.src=e,t},_getIconUrl:function(e){return W.retina&&this.options[e+`RetinaUrl`]||this.options[e+`Url`]}});function $n(e){return new Qn(e)}var er=Qn.extend({options:{iconUrl:`marker-icon.png`,iconRetinaUrl:`marker-icon-2x.png`,shadowUrl:`marker-shadow.png`,iconSize:[25,41],iconAnchor:[12,41],popupAnchor:[1,-34],tooltipAnchor:[16,-28],shadowSize:[41,41]},_getIconUrl:function(e){return typeof er.imagePath!=`string`&&(er.imagePath=this._detectIconPath()),(this.options.imagePath||er.imagePath)+Qn.prototype._getIconUrl.call(this,e)},_stripUrl:function(e){var t=function(e,t,n){var r=t.exec(e);return r&&r[n]};return e=t(e,/^url\((['"])?(.+)\1\)$/,2),e&&t(e,/^(.*)marker-icon\.png$/,1)},_detectIconPath:function(){var e=K(`div`,`leaflet-default-icon-path`,document.body),t=ht(e,`background-image`)||ht(e,`backgroundImage`);if(document.body.removeChild(e),t=this._stripUrl(t),t)return t;var n=document.querySelector(`link[href$="leaflet.css"]`);return n?n.href.substring(0,n.href.length-11-1):``}}),tr=_n.extend({initialize:function(e){this._marker=e},addHooks:function(){var e=this._marker._icon;this._draggable||=new bn(e,e,!0),this._draggable.on({dragstart:this._onDragStart,predrag:this._onPreDrag,drag:this._onDrag,dragend:this._onDragEnd},this).enable(),J(e,`leaflet-marker-draggable`)},removeHooks:function(){this._draggable.off({dragstart:this._onDragStart,predrag:this._onPreDrag,drag:this._onDrag,dragend:this._onDragEnd},this).disable(),this._marker._icon&&bt(this._marker._icon,`leaflet-marker-draggable`)},moved:function(){return this._draggable&&this._draggable._moved},_adjustPan:function(e){var t=this._marker,n=t._map,r=this._marker.options.autoPanSpeed,i=this._marker.options.autoPanPadding,a=Dt(t._icon),o=n.getPixelBounds(),s=n.getPixelOrigin(),c=F(o.min._subtract(s).add(i),o.max._subtract(s).subtract(i));if(!c.contains(a)){var l=N((Math.max(c.max.x,a.x)-c.max.x)/(o.max.x-c.max.x)-(Math.min(c.min.x,a.x)-c.min.x)/(o.min.x-c.min.x),(Math.max(c.max.y,a.y)-c.max.y)/(o.max.y-c.max.y)-(Math.min(c.min.y,a.y)-c.min.y)/(o.min.y-c.min.y)).multiplyBy(r);n.panBy(l,{animate:!1}),this._draggable._newPos._add(l),this._draggable._startPos._add(l),Y(t._icon,this._draggable._newPos),this._onDrag(e),this._panRequest=T(this._adjustPan.bind(this,e))}},_onDragStart:function(){this._oldLatLng=this._marker.getLatLng(),this._marker.closePopup&&this._marker.closePopup(),this._marker.fire(`movestart`).fire(`dragstart`)},_onPreDrag:function(e){this._marker.options.autoPan&&(E(this._panRequest),this._panRequest=T(this._adjustPan.bind(this,e)))},_onDrag:function(e){var t=this._marker,n=t._shadow,r=Dt(t._icon),i=t._map.layerPointToLatLng(r);n&&Y(n,r),t._latlng=i,e.latlng=i,e.oldLatLng=this._oldLatLng,t.fire(`move`,e).fire(`drag`,e)},_onDragEnd:function(e){E(this._panRequest),delete this._oldLatLng,this._marker.fire(`moveend`).fire(`dragend`,e)}}),nr=qn.extend({options:{icon:new er,interactive:!0,keyboard:!0,title:``,alt:`Marker`,zIndexOffset:0,opacity:1,riseOnHover:!1,riseOffset:250,pane:`markerPane`,shadowPane:`shadowPane`,bubblingMouseEvents:!1,autoPanOnFocus:!0,draggable:!1,autoPan:!1,autoPanPadding:[50,50],autoPanSpeed:10},initialize:function(e,t){p(this,t),this._latlng=B(e)},onAdd:function(e){this._zoomAnimated=this._zoomAnimated&&e.options.markerZoomAnimation,this._zoomAnimated&&e.on(`zoomanim`,this._animateZoom,this),this._initIcon(),this.update()},onRemove:function(e){this.dragging&&this.dragging.enabled()&&(this.options.draggable=!0,this.dragging.removeHooks()),delete this.dragging,this._zoomAnimated&&e.off(`zoomanim`,this._animateZoom,this),this._removeIcon(),this._removeShadow()},getEvents:function(){return{zoom:this.update,viewreset:this.update}},getLatLng:function(){return this._latlng},setLatLng:function(e){var t=this._latlng;return this._latlng=B(e),this.update(),this.fire(`move`,{oldLatLng:t,latlng:this._latlng})},setZIndexOffset:function(e){return this.options.zIndexOffset=e,this.update()},getIcon:function(){return this.options.icon},setIcon:function(e){return this.options.icon=e,this._map&&(this._initIcon(),this.update()),this._popup&&this.bindPopup(this._popup,this._popup.options),this},getElement:function(){return this._icon},update:function(){if(this._icon&&this._map){var e=this._map.latLngToLayerPoint(this._latlng).round();this._setPos(e)}return this},_initIcon:function(){var e=this.options,t=`leaflet-zoom-`+(this._zoomAnimated?`animated`:`hide`),n=e.icon.createIcon(this._icon),r=!1;n!==this._icon&&(this._icon&&this._removeIcon(),r=!0,e.title&&(n.title=e.title),n.tagName===`IMG`&&(n.alt=e.alt||``)),J(n,t),e.keyboard&&(n.tabIndex=`0`,n.setAttribute(`role`,`button`)),this._icon=n,e.riseOnHover&&this.on({mouseover:this._bringToFront,mouseout:this._resetZIndex}),this.options.autoPanOnFocus&&X(n,`focus`,this._panOnFocus,this);var i=e.icon.createShadow(this._shadow),a=!1;i!==this._shadow&&(this._removeShadow(),a=!0),i&&(J(i,t),i.alt=``),this._shadow=i,e.opacity<1&&this._updateOpacity(),r&&this.getPane().appendChild(this._icon),this._initInteraction(),i&&a&&this.getPane(e.shadowPane).appendChild(this._shadow)},_removeIcon:function(){this.options.riseOnHover&&this.off({mouseover:this._bringToFront,mouseout:this._resetZIndex}),this.options.autoPanOnFocus&&Ht(this._icon,`focus`,this._panOnFocus,this),q(this._icon),this.removeInteractiveTarget(this._icon),this._icon=null},_removeShadow:function(){this._shadow&&q(this._shadow),this._shadow=null},_setPos:function(e){this._icon&&Y(this._icon,e),this._shadow&&Y(this._shadow,e),this._zIndex=e.y+this.options.zIndexOffset,this._resetZIndex()},_updateZIndex:function(e){this._icon&&(this._icon.style.zIndex=this._zIndex+e)},_animateZoom:function(e){var t=this._map._latLngToNewLayerPoint(this._latlng,e.zoom,e.center).round();this._setPos(t)},_initInteraction:function(){if(this.options.interactive&&(J(this._icon,`leaflet-interactive`),this.addInteractiveTarget(this._icon),tr)){var e=this.options.draggable;this.dragging&&(e=this.dragging.enabled(),this.dragging.disable()),this.dragging=new tr(this),e&&this.dragging.enable()}},setOpacity:function(e){return this.options.opacity=e,this._map&&this._updateOpacity(),this},_updateOpacity:function(){var e=this.options.opacity;this._icon&&Ct(this._icon,e),this._shadow&&Ct(this._shadow,e)},_bringToFront:function(){this._updateZIndex(this.options.riseOffset)},_resetZIndex:function(){this._updateZIndex(0)},_panOnFocus:function(){var e=this._map;if(e){var t=this.options.icon.options,n=t.iconSize?N(t.iconSize):N(0,0),r=t.iconAnchor?N(t.iconAnchor):N(0,0);e.panInside(this._latlng,{paddingTopLeft:r,paddingBottomRight:n.subtract(r)})}},_getPopupAnchor:function(){return this.options.icon.options.popupAnchor},_getTooltipAnchor:function(){return this.options.icon.options.tooltipAnchor}});function rr(e,t){return new nr(e,t)}var ir=qn.extend({options:{stroke:!0,color:`#3388ff`,weight:3,opacity:1,lineCap:`round`,lineJoin:`round`,dashArray:null,dashOffset:null,fill:!1,fillColor:null,fillOpacity:.2,fillRule:`evenodd`,interactive:!0,bubblingMouseEvents:!0},beforeAdd:function(e){this._renderer=e.getRenderer(this)},onAdd:function(){this._renderer._initPath(this),this._reset(),this._renderer._addPath(this)},onRemove:function(){this._renderer._removePath(this)},redraw:function(){return this._map&&this._renderer._updatePath(this),this},setStyle:function(e){return p(this,e),this._renderer&&(this._renderer._updateStyle(this),this.options.stroke&&e&&Object.prototype.hasOwnProperty.call(e,`weight`)&&this._updateBounds()),this},bringToFront:function(){return this._renderer&&this._renderer._bringToFront(this),this},bringToBack:function(){return this._renderer&&this._renderer._bringToBack(this),this},getElement:function(){return this._path},_reset:function(){this._project(),this._update()},_clickTolerance:function(){return(this.options.stroke?this.options.weight/2:0)+(this._renderer.options.tolerance||0)}}),ar=ir.extend({options:{fill:!0,radius:10},initialize:function(e,t){p(this,t),this._latlng=B(e),this._radius=this.options.radius},setLatLng:function(e){var t=this._latlng;return this._latlng=B(e),this.redraw(),this.fire(`move`,{oldLatLng:t,latlng:this._latlng})},getLatLng:function(){return this._latlng},setRadius:function(e){return this.options.radius=this._radius=e,this.redraw()},getRadius:function(){return this._radius},setStyle:function(e){var t=e&&e.radius||this._radius;return ir.prototype.setStyle.call(this,e),this.setRadius(t),this},_project:function(){this._point=this._map.latLngToLayerPoint(this._latlng),this._updateBounds()},_updateBounds:function(){var e=this._radius,t=this._radiusY||e,n=this._clickTolerance(),r=[e+n,t+n];this._pxBounds=new P(this._point.subtract(r),this._point.add(r))},_update:function(){this._map&&this._updatePath()},_updatePath:function(){this._renderer._updateCircle(this)},_empty:function(){return this._radius&&!this._renderer._bounds.intersects(this._pxBounds)},_containsPoint:function(e){return e.distanceTo(this._point)<=this._radius+this._clickTolerance()}});function or(e,t){return new ar(e,t)}var sr=ar.extend({initialize:function(e,t,r){if(typeof t==`number`&&(t=n({},r,{radius:t})),p(this,t),this._latlng=B(e),isNaN(this.options.radius))throw Error(`Circle radius cannot be NaN`);this._mRadius=this.options.radius},setRadius:function(e){return this._mRadius=e,this.redraw()},getRadius:function(){return this._mRadius},getBounds:function(){var e=[this._radius,this._radiusY||this._radius];return new I(this._map.layerPointToLatLng(this._point.subtract(e)),this._map.layerPointToLatLng(this._point.add(e)))},setStyle:ir.prototype.setStyle,_project:function(){var e=this._latlng.lng,t=this._latlng.lat,n=this._map,r=n.options.crs;if(r.distance===ne.distance){var i=Math.PI/180,a=this._mRadius/ne.R/i,o=n.project([t+a,e]),s=n.project([t-a,e]),c=o.add(s).divideBy(2),l=n.unproject(c).lat,u=Math.acos((Math.cos(a*i)-Math.sin(t*i)*Math.sin(l*i))/(Math.cos(t*i)*Math.cos(l*i)))/i;(isNaN(u)||u===0)&&(u=a/Math.cos(Math.PI/180*t)),this._point=c.subtract(n.getPixelOrigin()),this._radius=isNaN(u)?0:c.x-n.project([l,e-u]).x,this._radiusY=c.y-o.y}else{var d=r.unproject(r.project(this._latlng).subtract([this._mRadius,0]));this._point=n.latLngToLayerPoint(this._latlng),this._radius=this._point.x-n.latLngToLayerPoint(d).x}this._updateBounds()}});function cr(e,t,n){return new sr(e,t,n)}var lr=ir.extend({options:{smoothFactor:1,noClip:!1},initialize:function(e,t){p(this,t),this._setLatLngs(e)},getLatLngs:function(){return this._latlngs},setLatLngs:function(e){return this._setLatLngs(e),this.redraw()},isEmpty:function(){return!this._latlngs.length},closestLayerPoint:function(e){for(var t=1/0,n=null,r=In,i,a,o=0,s=this._parts.length;o<s;o++)for(var c=this._parts[o],l=1,u=c.length;l<u;l++){i=c[l-1],a=c[l];var d=r(e,i,a,!0);d<t&&(t=d,n=r(e,i,a))}return n&&(n.distance=Math.sqrt(t)),n},getCenter:function(){if(!this._map)throw Error(`Must add layer to map before using getCenter()`);return zn(this._defaultShape(),this._map.options.crs)},getBounds:function(){return this._bounds},addLatLng:function(e,t){return t||=this._defaultShape(),e=B(e),t.push(e),this._bounds.extend(e),this.redraw()},_setLatLngs:function(e){this._bounds=new I,this._latlngs=this._convertLatLngs(e)},_defaultShape:function(){return Ln(this._latlngs)?this._latlngs:this._latlngs[0]},_convertLatLngs:function(e){for(var t=[],n=Ln(e),r=0,i=e.length;r<i;r++)n?(t[r]=B(e[r]),this._bounds.extend(t[r])):t[r]=this._convertLatLngs(e[r]);return t},_project:function(){var e=new P;this._rings=[],this._projectLatlngs(this._latlngs,this._rings,e),this._bounds.isValid()&&e.isValid()&&(this._rawPxBounds=e,this._updateBounds())},_updateBounds:function(){var e=this._clickTolerance(),t=new M(e,e);this._rawPxBounds&&(this._pxBounds=new P([this._rawPxBounds.min.subtract(t),this._rawPxBounds.max.add(t)]))},_projectLatlngs:function(e,t,n){var r=e[0]instanceof z,i=e.length,a,o;if(r){for(o=[],a=0;a<i;a++)o[a]=this._map.latLngToLayerPoint(e[a]),n.extend(o[a]);t.push(o)}else for(a=0;a<i;a++)this._projectLatlngs(e[a],t,n)},_clipPoints:function(){var e=this._renderer._bounds;if(this._parts=[],this._pxBounds&&this._pxBounds.intersects(e)){if(this.options.noClip)this._parts=this._rings;else for(var t=this._parts,n=0,r,i=0,a=this._rings.length,o,s,c;n<a;n++)for(c=this._rings[n],r=0,o=c.length;r<o-1;r++)s=Mn(c[r],c[r+1],e,r,!0),s&&(t[i]=t[i]||[],t[i].push(s[0]),(s[1]!==c[r+1]||r===o-2)&&(t[i].push(s[1]),i++))}},_simplifyPoints:function(){for(var e=this._parts,t=this.options.smoothFactor,n=0,r=e.length;n<r;n++)e[n]=Tn(e[n],t)},_update:function(){this._map&&(this._clipPoints(),this._simplifyPoints(),this._updatePath())},_updatePath:function(){this._renderer._updatePoly(this)},_containsPoint:function(e,t){var n,r,i,a,o,s,c=this._clickTolerance();if(!this._pxBounds||!this._pxBounds.contains(e))return!1;for(n=0,a=this._parts.length;n<a;n++)for(s=this._parts[n],r=0,o=s.length,i=o-1;r<o;i=r++)if((t||r!==0)&&En(e,s[i],s[r])<=c)return!0;return!1}});function ur(e,t){return new lr(e,t)}lr._flat=Rn;var dr=lr.extend({options:{fill:!0},isEmpty:function(){return!this._latlngs.length||!this._latlngs[0].length},getCenter:function(){if(!this._map)throw Error(`Must add layer to map before using getCenter()`);return Sn(this._defaultShape(),this._map.options.crs)},_convertLatLngs:function(e){var t=lr.prototype._convertLatLngs.call(this,e),n=t.length;return n>=2&&t[0]instanceof z&&t[0].equals(t[n-1])&&t.pop(),t},_setLatLngs:function(e){lr.prototype._setLatLngs.call(this,e),Ln(this._latlngs)&&(this._latlngs=[this._latlngs])},_defaultShape:function(){return Ln(this._latlngs[0])?this._latlngs[0]:this._latlngs[0][0]},_clipPoints:function(){var e=this._renderer._bounds,t=this.options.weight,n=new M(t,t);if(e=new P(e.min.subtract(n),e.max.add(n)),this._parts=[],this._pxBounds&&this._pxBounds.intersects(e)){if(this.options.noClip)this._parts=this._rings;else for(var r=0,i=this._rings.length,a;r<i;r++)a=xn(this._rings[r],e,!0),a.length&&this._parts.push(a)}},_updatePath:function(){this._renderer._updatePoly(this,!0)},_containsPoint:function(e){var t=!1,n,r,i,a,o,s,c,l;if(!this._pxBounds||!this._pxBounds.contains(e))return!1;for(a=0,c=this._parts.length;a<c;a++)for(n=this._parts[a],o=0,l=n.length,s=l-1;o<l;s=o++)r=n[o],i=n[s],r.y>e.y!=i.y>e.y&&e.x<(i.x-r.x)*(e.y-r.y)/(i.y-r.y)+r.x&&(t=!t);return t||lr.prototype._containsPoint.call(this,e,!0)}});function fr(e,t){return new dr(e,t)}var pr=Xn.extend({initialize:function(e,t){p(this,t),this._layers={},e&&this.addData(e)},addData:function(e){var t=_(e)?e:e.features,n,r,i;if(t){for(n=0,r=t.length;n<r;n++)i=t[n],(i.geometries||i.geometry||i.features||i.coordinates)&&this.addData(i);return this}var a=this.options;if(a.filter&&!a.filter(e))return this;var o=mr(e,a);return o?(o.feature=xr(e),o.defaultOptions=o.options,this.resetStyle(o),a.onEachFeature&&a.onEachFeature(e,o),this.addLayer(o)):this},resetStyle:function(e){return e===void 0?this.eachLayer(this.resetStyle,this):(e.options=n({},e.defaultOptions),this._setLayerStyle(e,this.options.style),this)},setStyle:function(e){return this.eachLayer(function(t){this._setLayerStyle(t,e)},this)},_setLayerStyle:function(e,t){e.setStyle&&(typeof t==`function`&&(t=t(e.feature)),e.setStyle(t))}});function mr(e,t){var n=e.type===`Feature`?e.geometry:e,r=n?n.coordinates:null,i=[],a=t&&t.pointToLayer,o=t&&t.coordsToLatLng||gr,s,c,l,u;if(!r&&!n)return null;switch(n.type){case`Point`:return s=o(r),hr(a,e,s,t);case`MultiPoint`:for(l=0,u=r.length;l<u;l++)s=o(r[l]),i.push(hr(a,e,s,t));return new Xn(i);case`LineString`:case`MultiLineString`:return c=_r(r,n.type===`LineString`?0:1,o),new lr(c,t);case`Polygon`:case`MultiPolygon`:return c=_r(r,n.type===`Polygon`?1:2,o),new dr(c,t);case`GeometryCollection`:for(l=0,u=n.geometries.length;l<u;l++){var d=mr({geometry:n.geometries[l],type:`Feature`,properties:e.properties},t);d&&i.push(d)}return new Xn(i);case`FeatureCollection`:for(l=0,u=n.features.length;l<u;l++){var f=mr(n.features[l],t);f&&i.push(f)}return new Xn(i);default:throw Error(`Invalid GeoJSON object.`)}}function hr(e,t,n,r){return e?e(t,n):new nr(n,r&&r.markersInheritOptions&&r)}function gr(e){return new z(e[1],e[0],e[2])}function _r(e,t,n){for(var r=[],i=0,a=e.length,o;i<a;i++)o=t?_r(e[i],t-1,n):(n||gr)(e[i]),r.push(o);return r}function vr(e,t){return e=B(e),e.alt===void 0?[u(e.lng,t),u(e.lat,t)]:[u(e.lng,t),u(e.lat,t),u(e.alt,t)]}function yr(e,t,n,r){for(var i=[],a=0,o=e.length;a<o;a++)i.push(t?yr(e[a],Ln(e[a])?0:t-1,n,r):vr(e[a],r));return!t&&n&&i.length>0&&i.push(i[0].slice()),i}function br(e,t){return e.feature?n({},e.feature,{geometry:t}):xr(t)}function xr(e){return e.type===`Feature`||e.type===`FeatureCollection`?e:{type:`Feature`,properties:{},geometry:e}}var Sr={toGeoJSON:function(e){return br(this,{type:`Point`,coordinates:vr(this.getLatLng(),e)})}};nr.include(Sr),sr.include(Sr),ar.include(Sr),lr.include({toGeoJSON:function(e){var t=!Ln(this._latlngs),n=yr(this._latlngs,+!!t,!1,e);return br(this,{type:(t?`Multi`:``)+`LineString`,coordinates:n})}}),dr.include({toGeoJSON:function(e){var t=!Ln(this._latlngs),n=t&&!Ln(this._latlngs[0]),r=yr(this._latlngs,n?2:+!!t,!0,e);return t||(r=[r]),br(this,{type:(n?`Multi`:``)+`Polygon`,coordinates:r})}}),Jn.include({toMultiPoint:function(e){var t=[];return this.eachLayer(function(n){t.push(n.toGeoJSON(e).geometry.coordinates)}),br(this,{type:`MultiPoint`,coordinates:t})},toGeoJSON:function(e){var t=this.feature&&this.feature.geometry&&this.feature.geometry.type;if(t===`MultiPoint`)return this.toMultiPoint(e);var n=t===`GeometryCollection`,r=[];return this.eachLayer(function(t){if(t.toGeoJSON){var i=t.toGeoJSON(e);if(n)r.push(i.geometry);else{var a=xr(i);a.type===`FeatureCollection`?r.push.apply(r,a.features):r.push(a)}}}),n?br(this,{geometries:r,type:`GeometryCollection`}):{type:`FeatureCollection`,features:r}}});function Cr(e,t){return new pr(e,t)}var wr=Cr,Tr=qn.extend({options:{opacity:1,alt:``,interactive:!1,crossOrigin:!1,errorOverlayUrl:``,zIndex:1,className:``},initialize:function(e,t,n){this._url=e,this._bounds=R(t),p(this,n)},onAdd:function(){this._image||(this._initImage(),this.options.opacity<1&&this._updateOpacity()),this.options.interactive&&(J(this._image,`leaflet-interactive`),this.addInteractiveTarget(this._image)),this.getPane().appendChild(this._image),this._reset()},onRemove:function(){q(this._image),this.options.interactive&&this.removeInteractiveTarget(this._image)},setOpacity:function(e){return this.options.opacity=e,this._image&&this._updateOpacity(),this},setStyle:function(e){return e.opacity&&this.setOpacity(e.opacity),this},bringToFront:function(){return this._map&&_t(this._image),this},bringToBack:function(){return this._map&&vt(this._image),this},setUrl:function(e){return this._url=e,this._image&&(this._image.src=e),this},setBounds:function(e){return this._bounds=R(e),this._map&&this._reset(),this},getEvents:function(){var e={zoom:this._reset,viewreset:this._reset};return this._zoomAnimated&&(e.zoomanim=this._animateZoom),e},setZIndex:function(e){return this.options.zIndex=e,this._updateZIndex(),this},getBounds:function(){return this._bounds},getElement:function(){return this._image},_initImage:function(){var e=this._url.tagName===`IMG`,t=this._image=e?this._url:K(`img`);J(t,`leaflet-image-layer`),this._zoomAnimated&&J(t,`leaflet-zoom-animated`),this.options.className&&J(t,this.options.className),t.onselectstart=l,t.onmousemove=l,t.onload=i(this.fire,this,`load`),t.onerror=i(this._overlayOnError,this,`error`),(this.options.crossOrigin||this.options.crossOrigin===``)&&(t.crossOrigin=this.options.crossOrigin===!0?``:this.options.crossOrigin),this.options.zIndex&&this._updateZIndex(),e?this._url=t.src:(t.src=this._url,t.alt=this.options.alt)},_animateZoom:function(e){var t=this._map.getZoomScale(e.zoom),n=this._map._latLngBoundsToNewLayerBounds(this._bounds,e.zoom,e.center).min;Et(this._image,n,t)},_reset:function(){var e=this._image,t=new P(this._map.latLngToLayerPoint(this._bounds.getNorthWest()),this._map.latLngToLayerPoint(this._bounds.getSouthEast())),n=t.getSize();Y(e,t.min),e.style.width=n.x+`px`,e.style.height=n.y+`px`},_updateOpacity:function(){Ct(this._image,this.options.opacity)},_updateZIndex:function(){this._image&&this.options.zIndex!==void 0&&this.options.zIndex!==null&&(this._image.style.zIndex=this.options.zIndex)},_overlayOnError:function(){this.fire(`error`);var e=this.options.errorOverlayUrl;e&&this._url!==e&&(this._url=e,this._image.src=e)},getCenter:function(){return this._bounds.getCenter()}}),Er=function(e,t,n){return new Tr(e,t,n)},Dr=Tr.extend({options:{autoplay:!0,loop:!0,keepAspectRatio:!0,muted:!1,playsInline:!0},_initImage:function(){var e=this._url.tagName===`VIDEO`,t=this._image=e?this._url:K(`video`);if(J(t,`leaflet-image-layer`),this._zoomAnimated&&J(t,`leaflet-zoom-animated`),this.options.className&&J(t,this.options.className),t.onselectstart=l,t.onmousemove=l,t.onloadeddata=i(this.fire,this,`load`),e){for(var n=t.getElementsByTagName(`source`),r=[],a=0;a<n.length;a++)r.push(n[a].src);this._url=n.length>0?r:[t.src]}else{_(this._url)||(this._url=[this._url]),!this.options.keepAspectRatio&&Object.prototype.hasOwnProperty.call(t.style,`objectFit`)&&(t.style.objectFit=`fill`),t.autoplay=!!this.options.autoplay,t.loop=!!this.options.loop,t.muted=!!this.options.muted,t.playsInline=!!this.options.playsInline;for(var o=0;o<this._url.length;o++){var s=K(`source`);s.src=this._url[o],t.appendChild(s)}}}});function Or(e,t,n){return new Dr(e,t,n)}var kr=Tr.extend({_initImage:function(){var e=this._image=this._url;J(e,`leaflet-image-layer`),this._zoomAnimated&&J(e,`leaflet-zoom-animated`),this.options.className&&J(e,this.options.className),e.onselectstart=l,e.onmousemove=l}});function Ar(e,t,n){return new kr(e,t,n)}var jr=qn.extend({options:{interactive:!1,offset:[0,0],className:``,pane:void 0,content:``},initialize:function(e,t){e&&(e instanceof z||_(e))?(this._latlng=B(e),p(this,t)):(p(this,e),this._source=t),this.options.content&&(this._content=this.options.content)},openOn:function(e){return e=arguments.length?e:this._source._map,e.hasLayer(this)||e.addLayer(this),this},close:function(){return this._map&&this._map.removeLayer(this),this},toggle:function(e){return this._map?this.close():(arguments.length?this._source=e:e=this._source,this._prepareOpen(),this.openOn(e._map)),this},onAdd:function(e){this._zoomAnimated=e._zoomAnimated,this._container||this._initLayout(),e._fadeAnimated&&Ct(this._container,0),clearTimeout(this._removeTimeout),this.getPane().appendChild(this._container),this.update(),e._fadeAnimated&&Ct(this._container,1),this.bringToFront(),this.options.interactive&&(J(this._container,`leaflet-interactive`),this.addInteractiveTarget(this._container))},onRemove:function(e){e._fadeAnimated?(Ct(this._container,0),this._removeTimeout=setTimeout(i(q,void 0,this._container),200)):q(this._container),this.options.interactive&&(bt(this._container,`leaflet-interactive`),this.removeInteractiveTarget(this._container))},getLatLng:function(){return this._latlng},setLatLng:function(e){return this._latlng=B(e),this._map&&(this._updatePosition(),this._adjustPan()),this},getContent:function(){return this._content},setContent:function(e){return this._content=e,this.update(),this},getElement:function(){return this._container},update:function(){this._map&&(this._container.style.visibility=`hidden`,this._updateContent(),this._updateLayout(),this._updatePosition(),this._container.style.visibility=``,this._adjustPan())},getEvents:function(){var e={zoom:this._updatePosition,viewreset:this._updatePosition};return this._zoomAnimated&&(e.zoomanim=this._animateZoom),e},isOpen:function(){return!!this._map&&this._map.hasLayer(this)},bringToFront:function(){return this._map&&_t(this._container),this},bringToBack:function(){return this._map&&vt(this._container),this},_prepareOpen:function(e){var t=this._source;if(!t._map)return!1;if(t instanceof Xn){t=null;var n=this._source._layers;for(var r in n)if(n[r]._map){t=n[r];break}if(!t)return!1;this._source=t}if(!e){if(t.getCenter)e=t.getCenter();else if(t.getLatLng)e=t.getLatLng();else if(t.getBounds)e=t.getBounds().getCenter();else throw Error(`Unable to get source layer LatLng.`)}return this.setLatLng(e),this._map&&this.update(),!0},_updateContent:function(){if(this._content){var e=this._contentNode,t=typeof this._content==`function`?this._content(this._source||this):this._content;if(typeof t==`string`)e.innerHTML=t;else{for(;e.hasChildNodes();)e.removeChild(e.firstChild);e.appendChild(t)}this.fire(`contentupdate`)}},_updatePosition:function(){if(this._map){var e=this._map.latLngToLayerPoint(this._latlng),t=N(this.options.offset),n=this._getAnchor();this._zoomAnimated?Y(this._container,e.add(n)):t=t.add(e).add(n);var r=this._containerBottom=-t.y,i=this._containerLeft=-Math.round(this._containerWidth/2)+t.x;this._container.style.bottom=r+`px`,this._container.style.left=i+`px`}},_getAnchor:function(){return[0,0]}});on.include({_initOverlay:function(e,t,n,r){var i=t;return i instanceof e||(i=new e(r).setContent(t)),n&&i.setLatLng(n),i}}),qn.include({_initOverlay:function(e,t,n,r){var i=n;return i instanceof e?(p(i,r),i._source=this):(i=t&&!r?t:new e(r,this),i.setContent(n)),i}});var Mr=jr.extend({options:{pane:`popupPane`,offset:[0,7],maxWidth:300,minWidth:50,maxHeight:null,autoPan:!0,autoPanPaddingTopLeft:null,autoPanPaddingBottomRight:null,autoPanPadding:[5,5],keepInView:!1,closeButton:!0,autoClose:!0,closeOnEscapeKey:!0,className:``},openOn:function(e){return e=arguments.length?e:this._source._map,!e.hasLayer(this)&&e._popup&&e._popup.options.autoClose&&e.removeLayer(e._popup),e._popup=this,jr.prototype.openOn.call(this,e)},onAdd:function(e){jr.prototype.onAdd.call(this,e),e.fire(`popupopen`,{popup:this}),this._source&&(this._source.fire(`popupopen`,{popup:this},!0),this._source instanceof ir||this._source.on(`preclick`,qt))},onRemove:function(e){jr.prototype.onRemove.call(this,e),e.fire(`popupclose`,{popup:this}),this._source&&(this._source.fire(`popupclose`,{popup:this},!0),this._source instanceof ir||this._source.off(`preclick`,qt))},getEvents:function(){var e=jr.prototype.getEvents.call(this);return(this.options.closeOnClick===void 0?this._map.options.closePopupOnClick:this.options.closeOnClick)&&(e.preclick=this.close),this.options.keepInView&&(e.moveend=this._adjustPan),e},_initLayout:function(){var e=`leaflet-popup`,t=this._container=K(`div`,e+` `+(this.options.className||``)+` leaflet-zoom-animated`),n=this._wrapper=K(`div`,e+`-content-wrapper`,t);if(this._contentNode=K(`div`,e+`-content`,n),Yt(t),Jt(this._contentNode),X(t,`contextmenu`,qt),this._tipContainer=K(`div`,e+`-tip-container`,t),this._tip=K(`div`,e+`-tip`,this._tipContainer),this.options.closeButton){var r=this._closeButton=K(`a`,e+`-close-button`,t);r.setAttribute(`role`,`button`),r.setAttribute(`aria-label`,`Close popup`),r.href=`#close`,r.innerHTML=`<span aria-hidden="true">&#215;</span>`,X(r,`click`,function(e){Xt(e),this.close()},this)}},_updateLayout:function(){var e=this._contentNode,t=e.style;t.width=``,t.whiteSpace=`nowrap`;var n=e.offsetWidth;n=Math.min(n,this.options.maxWidth),n=Math.max(n,this.options.minWidth),t.width=n+1+`px`,t.whiteSpace=``,t.height=``;var r=e.offsetHeight,i=this.options.maxHeight,a=`leaflet-popup-scrolled`;i&&r>i?(t.height=i+`px`,J(e,a)):bt(e,a),this._containerWidth=this._container.offsetWidth},_animateZoom:function(e){var t=this._map._latLngToNewLayerPoint(this._latlng,e.zoom,e.center),n=this._getAnchor();Y(this._container,t.add(n))},_adjustPan:function(){if(this.options.autoPan){if(this._map._panAnim&&this._map._panAnim.stop(),this._autopanning)this._autopanning=!1;else{var e=this._map,t=parseInt(ht(this._container,`marginBottom`),10)||0,n=this._container.offsetHeight+t,r=this._containerWidth,i=new M(this._containerLeft,-n-this._containerBottom);i._add(Dt(this._container));var a=e.layerPointToContainerPoint(i),o=N(this.options.autoPanPadding),s=N(this.options.autoPanPaddingTopLeft||o),c=N(this.options.autoPanPaddingBottomRight||o),l=e.getSize(),u=0,d=0;a.x+r+c.x>l.x&&(u=a.x+r-l.x+c.x),a.x-u-s.x<0&&(u=a.x-s.x),a.y+n+c.y>l.y&&(d=a.y+n-l.y+c.y),a.y-d-s.y<0&&(d=a.y-s.y),(u||d)&&(this.options.keepInView&&(this._autopanning=!0),e.fire(`autopanstart`).panBy([u,d]))}}},_getAnchor:function(){return N(this._source&&this._source._getPopupAnchor?this._source._getPopupAnchor():[0,0])}}),Nr=function(e,t){return new Mr(e,t)};on.mergeOptions({closePopupOnClick:!0}),on.include({openPopup:function(e,t,n){return this._initOverlay(Mr,e,t,n).openOn(this),this},closePopup:function(e){return e=arguments.length?e:this._popup,e&&e.close(),this}}),qn.include({bindPopup:function(e,t){return this._popup=this._initOverlay(Mr,this._popup,e,t),this._popupHandlersAdded||=(this.on({click:this._openPopup,keypress:this._onKeyPress,remove:this.closePopup,move:this._movePopup}),!0),this},unbindPopup:function(){return this._popup&&=(this.off({click:this._openPopup,keypress:this._onKeyPress,remove:this.closePopup,move:this._movePopup}),this._popupHandlersAdded=!1,null),this},openPopup:function(e){return this._popup&&(this instanceof Xn||(this._popup._source=this),this._popup._prepareOpen(e||this._latlng)&&this._popup.openOn(this._map)),this},closePopup:function(){return this._popup&&this._popup.close(),this},togglePopup:function(){return this._popup&&this._popup.toggle(this),this},isPopupOpen:function(){return this._popup?this._popup.isOpen():!1},setPopupContent:function(e){return this._popup&&this._popup.setContent(e),this},getPopup:function(){return this._popup},_openPopup:function(e){if(this._popup&&this._map){Zt(e);var t=e.layer||e.target;this._popup._source===t&&!(t instanceof ir)?this._map.hasLayer(this._popup)?this.closePopup():this.openPopup(e.latlng):(this._popup._source=t,this.openPopup(e.latlng))}},_movePopup:function(e){this._popup.setLatLng(e.latlng)},_onKeyPress:function(e){e.originalEvent.keyCode===13&&this._openPopup(e)}});var Pr=jr.extend({options:{pane:`tooltipPane`,offset:[0,0],direction:`auto`,permanent:!1,sticky:!1,opacity:.9},onAdd:function(e){jr.prototype.onAdd.call(this,e),this.setOpacity(this.options.opacity),e.fire(`tooltipopen`,{tooltip:this}),this._source&&(this.addEventParent(this._source),this._source.fire(`tooltipopen`,{tooltip:this},!0))},onRemove:function(e){jr.prototype.onRemove.call(this,e),e.fire(`tooltipclose`,{tooltip:this}),this._source&&(this.removeEventParent(this._source),this._source.fire(`tooltipclose`,{tooltip:this},!0))},getEvents:function(){var e=jr.prototype.getEvents.call(this);return this.options.permanent||(e.preclick=this.close),e},_initLayout:function(){var e=`leaflet-tooltip `+(this.options.className||``)+` leaflet-zoom-`+(this._zoomAnimated?`animated`:`hide`);this._contentNode=this._container=K(`div`,e),this._container.setAttribute(`role`,`tooltip`),this._container.setAttribute(`id`,`leaflet-tooltip-`+o(this))},_updateLayout:function(){},_adjustPan:function(){},_setPosition:function(e){var t,n,r=this._map,i=this._container,a=r.latLngToContainerPoint(r.getCenter()),o=r.layerPointToContainerPoint(e),s=this.options.direction,c=i.offsetWidth,l=i.offsetHeight,u=N(this.options.offset),d=this._getAnchor();s===`top`?(t=c/2,n=l):s===`bottom`?(t=c/2,n=0):s===`center`?(t=c/2,n=l/2):s===`right`?(t=0,n=l/2):s===`left`?(t=c,n=l/2):o.x<a.x?(s=`right`,t=0,n=l/2):(s=`left`,t=c+(u.x+d.x)*2,n=l/2),e=e.subtract(N(t,n,!0)).add(u).add(d),bt(i,`leaflet-tooltip-right`),bt(i,`leaflet-tooltip-left`),bt(i,`leaflet-tooltip-top`),bt(i,`leaflet-tooltip-bottom`),J(i,`leaflet-tooltip-`+s),Y(i,e)},_updatePosition:function(){var e=this._map.latLngToLayerPoint(this._latlng);this._setPosition(e)},setOpacity:function(e){this.options.opacity=e,this._container&&Ct(this._container,e)},_animateZoom:function(e){var t=this._map._latLngToNewLayerPoint(this._latlng,e.zoom,e.center);this._setPosition(t)},_getAnchor:function(){return N(this._source&&this._source._getTooltipAnchor&&!this.options.sticky?this._source._getTooltipAnchor():[0,0])}}),Fr=function(e,t){return new Pr(e,t)};on.include({openTooltip:function(e,t,n){return this._initOverlay(Pr,e,t,n).openOn(this),this},closeTooltip:function(e){return e.close(),this}}),qn.include({bindTooltip:function(e,t){return this._tooltip&&this.isTooltipOpen()&&this.unbindTooltip(),this._tooltip=this._initOverlay(Pr,this._tooltip,e,t),this._initTooltipInteractions(),this._tooltip.options.permanent&&this._map&&this._map.hasLayer(this)&&this.openTooltip(),this},unbindTooltip:function(){return this._tooltip&&=(this._initTooltipInteractions(!0),this.closeTooltip(),null),this},_initTooltipInteractions:function(e){if(e||!this._tooltipHandlersAdded){var t=e?`off`:`on`,n={remove:this.closeTooltip,move:this._moveTooltip};this._tooltip.options.permanent?n.add=this._openTooltip:(n.mouseover=this._openTooltip,n.mouseout=this.closeTooltip,n.click=this._openTooltip,this._map?this._addFocusListeners():n.add=this._addFocusListeners),this._tooltip.options.sticky&&(n.mousemove=this._moveTooltip),this[t](n),this._tooltipHandlersAdded=!e}},openTooltip:function(e){return this._tooltip&&(this instanceof Xn||(this._tooltip._source=this),this._tooltip._prepareOpen(e)&&(this._tooltip.openOn(this._map),this.getElement?this._setAriaDescribedByOnLayer(this):this.eachLayer&&this.eachLayer(this._setAriaDescribedByOnLayer,this))),this},closeTooltip:function(){if(this._tooltip)return this._tooltip.close()},toggleTooltip:function(){return this._tooltip&&this._tooltip.toggle(this),this},isTooltipOpen:function(){return this._tooltip.isOpen()},setTooltipContent:function(e){return this._tooltip&&this._tooltip.setContent(e),this},getTooltip:function(){return this._tooltip},_addFocusListeners:function(){this.getElement?this._addFocusListenersOnLayer(this):this.eachLayer&&this.eachLayer(this._addFocusListenersOnLayer,this)},_addFocusListenersOnLayer:function(e){var t=typeof e.getElement==`function`&&e.getElement();t&&(X(t,`focus`,function(){this._tooltip._source=e,this.openTooltip()},this),X(t,`blur`,this.closeTooltip,this))},_setAriaDescribedByOnLayer:function(e){var t=typeof e.getElement==`function`&&e.getElement();t&&t.setAttribute(`aria-describedby`,this._tooltip._container.id)},_openTooltip:function(e){if(this._tooltip&&this._map){if(this._map.dragging&&this._map.dragging.moving()&&!this._openOnceFlag){this._openOnceFlag=!0;var t=this;this._map.once(`moveend`,function(){t._openOnceFlag=!1,t._openTooltip(e)})}else this._tooltip._source=e.layer||e.target,this.openTooltip(this._tooltip.options.sticky?e.latlng:void 0)}},_moveTooltip:function(e){var t=e.latlng,n,r;this._tooltip.options.sticky&&e.originalEvent&&(n=this._map.mouseEventToContainerPoint(e.originalEvent),r=this._map.containerPointToLayerPoint(n),t=this._map.layerPointToLatLng(r)),this._tooltip.setLatLng(t)}});var Ir=Qn.extend({options:{iconSize:[12,12],html:!1,bgPos:null,className:`leaflet-div-icon`},createIcon:function(e){var t=e&&e.tagName===`DIV`?e:document.createElement(`div`),n=this.options;if(n.html instanceof Element?(gt(t),t.appendChild(n.html)):t.innerHTML=n.html===!1?``:n.html,n.bgPos){var r=N(n.bgPos);t.style.backgroundPosition=-r.x+`px `+-r.y+`px`}return this._setIconStyles(t,`icon`),t},createShadow:function(){return null}});function Lr(e){return new Ir(e)}Qn.Default=er;var Rr=qn.extend({options:{tileSize:256,opacity:1,updateWhenIdle:W.mobile,updateWhenZooming:!0,updateInterval:200,zIndex:1,bounds:null,minZoom:0,maxZoom:void 0,maxNativeZoom:void 0,minNativeZoom:void 0,noWrap:!1,pane:`tilePane`,className:``,keepBuffer:2},initialize:function(e){p(this,e)},onAdd:function(){this._initContainer(),this._levels={},this._tiles={},this._resetView()},beforeAdd:function(e){e._addZoomLimit(this)},onRemove:function(e){this._removeAllTiles(),q(this._container),e._removeZoomLimit(this),this._container=null,this._tileZoom=void 0},bringToFront:function(){return this._map&&(_t(this._container),this._setAutoZIndex(Math.max)),this},bringToBack:function(){return this._map&&(vt(this._container),this._setAutoZIndex(Math.min)),this},getContainer:function(){return this._container},setOpacity:function(e){return this.options.opacity=e,this._updateOpacity(),this},setZIndex:function(e){return this.options.zIndex=e,this._updateZIndex(),this},isLoading:function(){return this._loading},redraw:function(){if(this._map){this._removeAllTiles();var e=this._clampZoom(this._map.getZoom());e!==this._tileZoom&&(this._tileZoom=e,this._updateLevels()),this._update()}return this},getEvents:function(){var e={viewprereset:this._invalidateAll,viewreset:this._resetView,zoom:this._resetView,moveend:this._onMoveEnd};return this.options.updateWhenIdle||(this._onMove||=s(this._onMoveEnd,this.options.updateInterval,this),e.move=this._onMove),this._zoomAnimated&&(e.zoomanim=this._animateZoom),e},createTile:function(){return document.createElement(`div`)},getTileSize:function(){var e=this.options.tileSize;return e instanceof M?e:new M(e,e)},_updateZIndex:function(){this._container&&this.options.zIndex!==void 0&&this.options.zIndex!==null&&(this._container.style.zIndex=this.options.zIndex)},_setAutoZIndex:function(e){for(var t=this.getPane().children,n=-e(-1/0,1/0),r=0,i=t.length,a;r<i;r++)a=t[r].style.zIndex,t[r]!==this._container&&a&&(n=e(n,+a));isFinite(n)&&(this.options.zIndex=n+e(-1,1),this._updateZIndex())},_updateOpacity:function(){if(this._map&&!W.ielt9){Ct(this._container,this.options.opacity);var e=+new Date,t=!1,n=!1;for(var r in this._tiles){var i=this._tiles[r];if(i.current&&i.loaded){var a=Math.min(1,(e-i.loaded)/200);Ct(i.el,a),a<1?t=!0:(i.active?n=!0:this._onOpaqueTile(i),i.active=!0)}}n&&!this._noPrune&&this._pruneTiles(),t&&(E(this._fadeFrame),this._fadeFrame=T(this._updateOpacity,this))}},_onOpaqueTile:l,_initContainer:function(){this._container||(this._container=K(`div`,`leaflet-layer `+(this.options.className||``)),this._updateZIndex(),this.options.opacity<1&&this._updateOpacity(),this.getPane().appendChild(this._container))},_updateLevels:function(){var e=this._tileZoom,t=this.options.maxZoom;if(e!==void 0){for(var n in this._levels)n=Number(n),this._levels[n].el.children.length||n===e?(this._levels[n].el.style.zIndex=t-Math.abs(e-n),this._onUpdateLevel(n)):(q(this._levels[n].el),this._removeTilesAtZoom(n),this._onRemoveLevel(n),delete this._levels[n]);var r=this._levels[e],i=this._map;return r||(r=this._levels[e]={},r.el=K(`div`,`leaflet-tile-container leaflet-zoom-animated`,this._container),r.el.style.zIndex=t,r.origin=i.project(i.unproject(i.getPixelOrigin()),e).round(),r.zoom=e,this._setZoomTransform(r,i.getCenter(),i.getZoom()),r.el.offsetWidth,this._onCreateLevel(r)),this._level=r,r}},_onUpdateLevel:l,_onRemoveLevel:l,_onCreateLevel:l,_pruneTiles:function(){if(this._map){var e,t,n=this._map.getZoom();if(n>this.options.maxZoom||n<this.options.minZoom)this._removeAllTiles();else{for(e in this._tiles)t=this._tiles[e],t.retain=t.current;for(e in this._tiles)if(t=this._tiles[e],t.current&&!t.active){var r=t.coords;this._retainParent(r.x,r.y,r.z,r.z-5)||this._retainChildren(r.x,r.y,r.z,r.z+2)}for(e in this._tiles)this._tiles[e].retain||this._removeTile(e)}}},_removeTilesAtZoom:function(e){for(var t in this._tiles)this._tiles[t].coords.z===e&&this._removeTile(t)},_removeAllTiles:function(){for(var e in this._tiles)this._removeTile(e)},_invalidateAll:function(){for(var e in this._levels)q(this._levels[e].el),this._onRemoveLevel(Number(e)),delete this._levels[e];this._removeAllTiles(),this._tileZoom=void 0},_retainParent:function(e,t,n,r){var i=Math.floor(e/2),a=Math.floor(t/2),o=n-1,s=new M(+i,+a);s.z=+o;var c=this._tileCoordsToKey(s),l=this._tiles[c];return l&&l.active?(l.retain=!0,!0):(l&&l.loaded&&(l.retain=!0),o>r&&this._retainParent(i,a,o,r))},_retainChildren:function(e,t,n,r){for(var i=2*e;i<2*e+2;i++)for(var a=2*t;a<2*t+2;a++){var o=new M(i,a);o.z=n+1;var s=this._tileCoordsToKey(o),c=this._tiles[s];c&&c.active?c.retain=!0:(c&&c.loaded&&(c.retain=!0),n+1<r&&this._retainChildren(i,a,n+1,r))}},_resetView:function(e){var t=e&&(e.pinch||e.flyTo);this._setView(this._map.getCenter(),this._map.getZoom(),t,t)},_animateZoom:function(e){this._setView(e.center,e.zoom,!0,e.noUpdate)},_clampZoom:function(e){var t=this.options;return t.minNativeZoom!==void 0&&e<t.minNativeZoom?t.minNativeZoom:t.maxNativeZoom!==void 0&&t.maxNativeZoom<e?t.maxNativeZoom:e},_setView:function(e,t,n,r){var i=Math.round(t);i=this.options.maxZoom!==void 0&&i>this.options.maxZoom||this.options.minZoom!==void 0&&i<this.options.minZoom?void 0:this._clampZoom(i);var a=this.options.updateWhenZooming&&i!==this._tileZoom;(!r||a)&&(this._tileZoom=i,this._abortLoading&&this._abortLoading(),this._updateLevels(),this._resetGrid(),i!==void 0&&this._update(e),n||this._pruneTiles(),this._noPrune=!!n),this._setZoomTransforms(e,t)},_setZoomTransforms:function(e,t){for(var n in this._levels)this._setZoomTransform(this._levels[n],e,t)},_setZoomTransform:function(e,t,n){var r=this._map.getZoomScale(n,e.zoom),i=e.origin.multiplyBy(r).subtract(this._map._getNewPixelOrigin(t,n)).round();W.any3d?Et(e.el,i,r):Y(e.el,i)},_resetGrid:function(){var e=this._map,t=e.options.crs,n=this._tileSize=this.getTileSize(),r=this._tileZoom,i=this._map.getPixelWorldBounds(this._tileZoom);i&&(this._globalTileRange=this._pxBoundsToTileRange(i)),this._wrapX=t.wrapLng&&!this.options.noWrap&&[Math.floor(e.project([0,t.wrapLng[0]],r).x/n.x),Math.ceil(e.project([0,t.wrapLng[1]],r).x/n.y)],this._wrapY=t.wrapLat&&!this.options.noWrap&&[Math.floor(e.project([t.wrapLat[0],0],r).y/n.x),Math.ceil(e.project([t.wrapLat[1],0],r).y/n.y)]},_onMoveEnd:function(){this._map&&!this._map._animatingZoom&&this._update()},_getTiledPixelBounds:function(e){var t=this._map,n=t._animatingZoom?Math.max(t._animateToZoom,t.getZoom()):t.getZoom(),r=t.getZoomScale(n,this._tileZoom),i=t.project(e,this._tileZoom).floor(),a=t.getSize().divideBy(r*2);return new P(i.subtract(a),i.add(a))},_update:function(e){var t=this._map;if(t){var n=this._clampZoom(t.getZoom());if(e===void 0&&(e=t.getCenter()),this._tileZoom!==void 0){var r=this._getTiledPixelBounds(e),i=this._pxBoundsToTileRange(r),a=i.getCenter(),o=[],s=this.options.keepBuffer,c=new P(i.getBottomLeft().subtract([s,-s]),i.getTopRight().add([s,-s]));if(!(isFinite(i.min.x)&&isFinite(i.min.y)&&isFinite(i.max.x)&&isFinite(i.max.y)))throw Error(`Attempted to load an infinite number of tiles`);for(var l in this._tiles){var u=this._tiles[l].coords;(u.z!==this._tileZoom||!c.contains(new M(u.x,u.y)))&&(this._tiles[l].current=!1)}if(Math.abs(n-this._tileZoom)>1)this._setView(e,n);else{for(var d=i.min.y;d<=i.max.y;d++)for(var f=i.min.x;f<=i.max.x;f++){var p=new M(f,d);if(p.z=this._tileZoom,this._isValidTile(p)){var m=this._tiles[this._tileCoordsToKey(p)];m?m.current=!0:o.push(p)}}if(o.sort(function(e,t){return e.distanceTo(a)-t.distanceTo(a)}),o.length!==0){this._loading||(this._loading=!0,this.fire(`loading`));var h=document.createDocumentFragment();for(f=0;f<o.length;f++)this._addTile(o[f],h);this._level.el.appendChild(h)}}}}},_isValidTile:function(e){var t=this._map.options.crs;if(!t.infinite){var n=this._globalTileRange;if(!t.wrapLng&&(e.x<n.min.x||e.x>n.max.x)||!t.wrapLat&&(e.y<n.min.y||e.y>n.max.y))return!1}if(!this.options.bounds)return!0;var r=this._tileCoordsToBounds(e);return R(this.options.bounds).overlaps(r)},_keyToBounds:function(e){return this._tileCoordsToBounds(this._keyToTileCoords(e))},_tileCoordsToNwSe:function(e){var t=this._map,n=this.getTileSize(),r=e.scaleBy(n),i=r.add(n);return[t.unproject(r,e.z),t.unproject(i,e.z)]},_tileCoordsToBounds:function(e){var t=this._tileCoordsToNwSe(e),n=new I(t[0],t[1]);return this.options.noWrap||(n=this._map.wrapLatLngBounds(n)),n},_tileCoordsToKey:function(e){return e.x+`:`+e.y+`:`+e.z},_keyToTileCoords:function(e){var t=e.split(`:`),n=new M(+t[0],+t[1]);return n.z=+t[2],n},_removeTile:function(e){var t=this._tiles[e];t&&(q(t.el),delete this._tiles[e],this.fire(`tileunload`,{tile:t.el,coords:this._keyToTileCoords(e)}))},_initTile:function(e){J(e,`leaflet-tile`);var t=this.getTileSize();e.style.width=t.x+`px`,e.style.height=t.y+`px`,e.onselectstart=l,e.onmousemove=l,W.ielt9&&this.options.opacity<1&&Ct(e,this.options.opacity)},_addTile:function(e,t){var n=this._getTilePos(e),r=this._tileCoordsToKey(e),a=this.createTile(this._wrapCoords(e),i(this._tileReady,this,e));this._initTile(a),this.createTile.length<2&&T(i(this._tileReady,this,e,null,a)),Y(a,n),this._tiles[r]={el:a,coords:e,current:!0},t.appendChild(a),this.fire(`tileloadstart`,{tile:a,coords:e})},_tileReady:function(e,t,n){t&&this.fire(`tileerror`,{error:t,tile:n,coords:e});var r=this._tileCoordsToKey(e);n=this._tiles[r],n&&(n.loaded=+new Date,this._map._fadeAnimated?(Ct(n.el,0),E(this._fadeFrame),this._fadeFrame=T(this._updateOpacity,this)):(n.active=!0,this._pruneTiles()),t||(J(n.el,`leaflet-tile-loaded`),this.fire(`tileload`,{tile:n.el,coords:e})),this._noTilesToLoad()&&(this._loading=!1,this.fire(`load`),W.ielt9||!this._map._fadeAnimated?T(this._pruneTiles,this):setTimeout(i(this._pruneTiles,this),250)))},_getTilePos:function(e){return e.scaleBy(this.getTileSize()).subtract(this._level.origin)},_wrapCoords:function(e){var t=new M(this._wrapX?c(e.x,this._wrapX):e.x,this._wrapY?c(e.y,this._wrapY):e.y);return t.z=e.z,t},_pxBoundsToTileRange:function(e){var t=this.getTileSize();return new P(e.min.unscaleBy(t).floor(),e.max.unscaleBy(t).ceil().subtract([1,1]))},_noTilesToLoad:function(){for(var e in this._tiles)if(!this._tiles[e].loaded)return!1;return!0}});function zr(e){return new Rr(e)}var Br=Rr.extend({options:{minZoom:0,maxZoom:18,subdomains:`abc`,errorTileUrl:``,zoomOffset:0,tms:!1,zoomReverse:!1,detectRetina:!1,crossOrigin:!1,referrerPolicy:!1},initialize:function(e,t){this._url=e,t=p(this,t),t.detectRetina&&W.retina&&t.maxZoom>0?(t.tileSize=Math.floor(t.tileSize/2),t.zoomReverse?(t.zoomOffset--,t.minZoom=Math.min(t.maxZoom,t.minZoom+1)):(t.zoomOffset++,t.maxZoom=Math.max(t.minZoom,t.maxZoom-1)),t.minZoom=Math.max(0,t.minZoom)):t.zoomReverse?t.minZoom=Math.min(t.maxZoom,t.minZoom):t.maxZoom=Math.max(t.minZoom,t.maxZoom),typeof t.subdomains==`string`&&(t.subdomains=t.subdomains.split(``)),this.on(`tileunload`,this._onTileRemove)},setUrl:function(e,t){return this._url===e&&t===void 0&&(t=!0),this._url=e,t||this.redraw(),this},createTile:function(e,t){var n=document.createElement(`img`);return X(n,`load`,i(this._tileOnLoad,this,t,n)),X(n,`error`,i(this._tileOnError,this,t,n)),(this.options.crossOrigin||this.options.crossOrigin===``)&&(n.crossOrigin=this.options.crossOrigin===!0?``:this.options.crossOrigin),typeof this.options.referrerPolicy==`string`&&(n.referrerPolicy=this.options.referrerPolicy),n.alt=``,n.src=this.getTileUrl(e),n},getTileUrl:function(e){var t={r:W.retina?`@2x`:``,s:this._getSubdomain(e),x:e.x,y:e.y,z:this._getZoomForUrl()};if(this._map&&!this._map.options.crs.infinite){var r=this._globalTileRange.max.y-e.y;this.options.tms&&(t.y=r),t[`-y`]=r}return g(this._url,n(t,this.options))},_tileOnLoad:function(e,t){W.ielt9?setTimeout(i(e,this,null,t),0):e(null,t)},_tileOnError:function(e,t,n){var r=this.options.errorTileUrl;r&&t.getAttribute(`src`)!==r&&(t.src=r),e(n,t)},_onTileRemove:function(e){e.tile.onload=null},_getZoomForUrl:function(){var e=this._tileZoom,t=this.options.maxZoom,n=this.options.zoomReverse,r=this.options.zoomOffset;return n&&(e=t-e),e+r},_getSubdomain:function(e){var t=Math.abs(e.x+e.y)%this.options.subdomains.length;return this.options.subdomains[t]},_abortLoading:function(){var e,t;for(e in this._tiles)if(this._tiles[e].coords.z!==this._tileZoom&&(t=this._tiles[e].el,t.onload=l,t.onerror=l,!t.complete)){t.src=y;var n=this._tiles[e].coords;q(t),delete this._tiles[e],this.fire(`tileabort`,{tile:t,coords:n})}},_removeTile:function(e){var t=this._tiles[e];if(t)return t.el.setAttribute(`src`,y),Rr.prototype._removeTile.call(this,e)},_tileReady:function(e,t,n){if(!(!this._map||n&&n.getAttribute(`src`)===y))return Rr.prototype._tileReady.call(this,e,t,n)}});function Vr(e,t){return new Br(e,t)}var Hr=Br.extend({defaultWmsParams:{service:`WMS`,request:`GetMap`,layers:``,styles:``,format:`image/jpeg`,transparent:!1,version:`1.1.1`},options:{crs:null,uppercase:!1},initialize:function(e,t){this._url=e;var r=n({},this.defaultWmsParams);for(var i in t)i in this.options||(r[i]=t[i]);t=p(this,t);var a=t.detectRetina&&W.retina?2:1,o=this.getTileSize();r.width=o.x*a,r.height=o.y*a,this.wmsParams=r},onAdd:function(e){this._crs=this.options.crs||e.options.crs,this._wmsVersion=parseFloat(this.wmsParams.version);var t=this._wmsVersion>=1.3?`crs`:`srs`;this.wmsParams[t]=this._crs.code,Br.prototype.onAdd.call(this,e)},getTileUrl:function(e){var t=this._tileCoordsToNwSe(e),n=this._crs,r=F(n.project(t[0]),n.project(t[1])),i=r.min,a=r.max,o=(this._wmsVersion>=1.3&&this._crs===Gn?[i.y,i.x,a.y,a.x]:[i.x,i.y,a.x,a.y]).join(`,`),s=Br.prototype.getTileUrl.call(this,e);return s+m(this.wmsParams,s,this.options.uppercase)+(this.options.uppercase?`&BBOX=`:`&bbox=`)+o},setParams:function(e,t){return n(this.wmsParams,e),t||this.redraw(),this}});function Ur(e,t){return new Hr(e,t)}Br.WMS=Hr,Vr.wms=Ur;var Wr=qn.extend({options:{padding:.1},initialize:function(e){p(this,e),o(this),this._layers=this._layers||{}},onAdd:function(){this._container||(this._initContainer(),J(this._container,`leaflet-zoom-animated`)),this.getPane().appendChild(this._container),this._update(),this.on(`update`,this._updatePaths,this)},onRemove:function(){this.off(`update`,this._updatePaths,this),this._destroyContainer()},getEvents:function(){var e={viewreset:this._reset,zoom:this._onZoom,moveend:this._update,zoomend:this._onZoomEnd};return this._zoomAnimated&&(e.zoomanim=this._onAnimZoom),e},_onAnimZoom:function(e){this._updateTransform(e.center,e.zoom)},_onZoom:function(){this._updateTransform(this._map.getCenter(),this._map.getZoom())},_updateTransform:function(e,t){var n=this._map.getZoomScale(t,this._zoom),r=this._map.getSize().multiplyBy(.5+this.options.padding),i=this._map.project(this._center,t),a=r.multiplyBy(-n).add(i).subtract(this._map._getNewPixelOrigin(e,t));W.any3d?Et(this._container,a,n):Y(this._container,a)},_reset:function(){for(var e in this._update(),this._updateTransform(this._center,this._zoom),this._layers)this._layers[e]._reset()},_onZoomEnd:function(){for(var e in this._layers)this._layers[e]._project()},_updatePaths:function(){for(var e in this._layers)this._layers[e]._update()},_update:function(){var e=this.options.padding,t=this._map.getSize(),n=this._map.containerPointToLayerPoint(t.multiplyBy(-e)).round();this._bounds=new P(n,n.add(t.multiplyBy(1+e*2)).round()),this._center=this._map.getCenter(),this._zoom=this._map.getZoom()}}),Gr=Wr.extend({options:{tolerance:0},getEvents:function(){var e=Wr.prototype.getEvents.call(this);return e.viewprereset=this._onViewPreReset,e},_onViewPreReset:function(){this._postponeUpdatePaths=!0},onAdd:function(){Wr.prototype.onAdd.call(this),this._draw()},_initContainer:function(){var e=this._container=document.createElement(`canvas`);X(e,`mousemove`,this._onMouseMove,this),X(e,`click dblclick mousedown mouseup contextmenu`,this._onClick,this),X(e,`mouseout`,this._handleMouseOut,this),e._leaflet_disable_events=!0,this._ctx=e.getContext(`2d`)},_destroyContainer:function(){E(this._redrawRequest),delete this._ctx,q(this._container),Ht(this._container),delete this._container},_updatePaths:function(){if(!this._postponeUpdatePaths){var e;for(var t in this._redrawBounds=null,this._layers)e=this._layers[t],e._update();this._redraw()}},_update:function(){if(!(this._map._animatingZoom&&this._bounds)){Wr.prototype._update.call(this);var e=this._bounds,t=this._container,n=e.getSize(),r=W.retina?2:1;Y(t,e.min),t.width=r*n.x,t.height=r*n.y,t.style.width=n.x+`px`,t.style.height=n.y+`px`,W.retina&&this._ctx.scale(2,2),this._ctx.translate(-e.min.x,-e.min.y),this.fire(`update`)}},_reset:function(){Wr.prototype._reset.call(this),this._postponeUpdatePaths&&(this._postponeUpdatePaths=!1,this._updatePaths())},_initPath:function(e){this._updateDashArray(e),this._layers[o(e)]=e;var t=e._order={layer:e,prev:this._drawLast,next:null};this._drawLast&&(this._drawLast.next=t),this._drawLast=t,this._drawFirst=this._drawFirst||this._drawLast},_addPath:function(e){this._requestRedraw(e)},_removePath:function(e){var t=e._order,n=t.next,r=t.prev;n?n.prev=r:this._drawLast=r,r?r.next=n:this._drawFirst=n,delete e._order,delete this._layers[o(e)],this._requestRedraw(e)},_updatePath:function(e){this._extendRedrawBounds(e),e._project(),e._update(),this._requestRedraw(e)},_updateStyle:function(e){this._updateDashArray(e),this._requestRedraw(e)},_updateDashArray:function(e){if(typeof e.options.dashArray==`string`){for(var t=e.options.dashArray.split(/[, ]+/),n=[],r,i=0;i<t.length;i++){if(r=Number(t[i]),isNaN(r))return;n.push(r)}e.options._dashArray=n}else e.options._dashArray=e.options.dashArray},_requestRedraw:function(e){this._map&&(this._extendRedrawBounds(e),this._redrawRequest=this._redrawRequest||T(this._redraw,this))},_extendRedrawBounds:function(e){if(e._pxBounds){var t=(e.options.weight||0)+1;this._redrawBounds=this._redrawBounds||new P,this._redrawBounds.extend(e._pxBounds.min.subtract([t,t])),this._redrawBounds.extend(e._pxBounds.max.add([t,t]))}},_redraw:function(){this._redrawRequest=null,this._redrawBounds&&(this._redrawBounds.min._floor(),this._redrawBounds.max._ceil()),this._clear(),this._draw(),this._redrawBounds=null},_clear:function(){var e=this._redrawBounds;if(e){var t=e.getSize();this._ctx.clearRect(e.min.x,e.min.y,t.x,t.y)}else this._ctx.save(),this._ctx.setTransform(1,0,0,1,0,0),this._ctx.clearRect(0,0,this._container.width,this._container.height),this._ctx.restore()},_draw:function(){var e,t=this._redrawBounds;if(this._ctx.save(),t){var n=t.getSize();this._ctx.beginPath(),this._ctx.rect(t.min.x,t.min.y,n.x,n.y),this._ctx.clip()}this._drawing=!0;for(var r=this._drawFirst;r;r=r.next)e=r.layer,(!t||e._pxBounds&&e._pxBounds.intersects(t))&&e._updatePath();this._drawing=!1,this._ctx.restore()},_updatePoly:function(e,t){if(this._drawing){var n,r,i,a,o=e._parts,s=o.length,c=this._ctx;if(s){for(c.beginPath(),n=0;n<s;n++){for(r=0,i=o[n].length;r<i;r++)a=o[n][r],c[r?`lineTo`:`moveTo`](a.x,a.y);t&&c.closePath()}this._fillStroke(c,e)}}},_updateCircle:function(e){if(this._drawing&&!e._empty()){var t=e._point,n=this._ctx,r=Math.max(Math.round(e._radius),1),i=(Math.max(Math.round(e._radiusY),1)||r)/r;i!==1&&(n.save(),n.scale(1,i)),n.beginPath(),n.arc(t.x,t.y/i,r,0,Math.PI*2,!1),i!==1&&n.restore(),this._fillStroke(n,e)}},_fillStroke:function(e,t){var n=t.options;n.fill&&(e.globalAlpha=n.fillOpacity,e.fillStyle=n.fillColor||n.color,e.fill(n.fillRule||`evenodd`)),n.stroke&&n.weight!==0&&(e.setLineDash&&e.setLineDash(t.options&&t.options._dashArray||[]),e.globalAlpha=n.opacity,e.lineWidth=n.weight,e.strokeStyle=n.color,e.lineCap=n.lineCap,e.lineJoin=n.lineJoin,e.stroke())},_onClick:function(e){for(var t=this._map.mouseEventToLayerPoint(e),n,r,i=this._drawFirst;i;i=i.next)n=i.layer,n.options.interactive&&n._containsPoint(t)&&(e.type!==`click`&&e.type!==`preclick`||!this._map._draggableMoved(n))&&(r=n);this._fireEvent(r?[r]:!1,e)},_onMouseMove:function(e){if(!(!this._map||this._map.dragging.moving()||this._map._animatingZoom)){var t=this._map.mouseEventToLayerPoint(e);this._handleMouseHover(e,t)}},_handleMouseOut:function(e){var t=this._hoveredLayer;t&&(bt(this._container,`leaflet-interactive`),this._fireEvent([t],e,`mouseout`),this._hoveredLayer=null,this._mouseHoverThrottled=!1)},_handleMouseHover:function(e,t){if(!this._mouseHoverThrottled){for(var n,r,a=this._drawFirst;a;a=a.next)n=a.layer,n.options.interactive&&n._containsPoint(t)&&(r=n);r!==this._hoveredLayer&&(this._handleMouseOut(e),r&&(J(this._container,`leaflet-interactive`),this._fireEvent([r],e,`mouseover`),this._hoveredLayer=r)),this._fireEvent(this._hoveredLayer?[this._hoveredLayer]:!1,e),this._mouseHoverThrottled=!0,setTimeout(i(function(){this._mouseHoverThrottled=!1},this),32)}},_fireEvent:function(e,t,n){this._map._fireDOMEvent(t,n||t.type,e)},_bringToFront:function(e){var t=e._order;if(t){var n=t.next,r=t.prev;if(n)n.prev=r;else return;r?r.next=n:n&&(this._drawFirst=n),t.prev=this._drawLast,this._drawLast.next=t,t.next=null,this._drawLast=t,this._requestRedraw(e)}},_bringToBack:function(e){var t=e._order;if(t){var n=t.next,r=t.prev;if(r)r.next=n;else return;n?n.prev=r:r&&(this._drawLast=r),t.prev=null,t.next=this._drawFirst,this._drawFirst.prev=t,this._drawFirst=t,this._requestRedraw(e)}}});function Kr(e){return W.canvas?new Gr(e):null}var qr=(function(){try{return document.namespaces.add(`lvml`,`urn:schemas-microsoft-com:vml`),function(e){return document.createElement(`<lvml:`+e+` class="lvml">`)}}catch{}return function(e){return document.createElement(`<`+e+` xmlns="urn:schemas-microsoft.com:vml" class="lvml">`)}})(),Jr={_initContainer:function(){this._container=K(`div`,`leaflet-vml-container`)},_update:function(){this._map._animatingZoom||(Wr.prototype._update.call(this),this.fire(`update`))},_initPath:function(e){var t=e._container=qr(`shape`);J(t,`leaflet-vml-shape `+(this.options.className||``)),t.coordsize=`1 1`,e._path=qr(`path`),t.appendChild(e._path),this._updateStyle(e),this._layers[o(e)]=e},_addPath:function(e){var t=e._container;this._container.appendChild(t),e.options.interactive&&e.addInteractiveTarget(t)},_removePath:function(e){var t=e._container;q(t),e.removeInteractiveTarget(t),delete this._layers[o(e)]},_updateStyle:function(e){var t=e._stroke,n=e._fill,r=e.options,i=e._container;i.stroked=!!r.stroke,i.filled=!!r.fill,r.stroke?(t||=e._stroke=qr(`stroke`),i.appendChild(t),t.weight=r.weight+`px`,t.color=r.color,t.opacity=r.opacity,r.dashArray?t.dashStyle=_(r.dashArray)?r.dashArray.join(` `):r.dashArray.replace(/( *, *)/g,` `):t.dashStyle=``,t.endcap=r.lineCap.replace(`butt`,`flat`),t.joinstyle=r.lineJoin):t&&(i.removeChild(t),e._stroke=null),r.fill?(n||=e._fill=qr(`fill`),i.appendChild(n),n.color=r.fillColor||r.color,n.opacity=r.fillOpacity):n&&(i.removeChild(n),e._fill=null)},_updateCircle:function(e){var t=e._point.round(),n=Math.round(e._radius),r=Math.round(e._radiusY||n);this._setPath(e,e._empty()?`M0 0`:`AL `+t.x+`,`+t.y+` `+n+`,`+r+` 0,23592600`)},_setPath:function(e,t){e._path.v=t},_bringToFront:function(e){_t(e._container)},_bringToBack:function(e){vt(e._container)}},Yr=W.vml?qr:le,Xr=Wr.extend({_initContainer:function(){this._container=Yr(`svg`),this._container.setAttribute(`pointer-events`,`none`),this._rootGroup=Yr(`g`),this._container.appendChild(this._rootGroup)},_destroyContainer:function(){q(this._container),Ht(this._container),delete this._container,delete this._rootGroup,delete this._svgSize},_update:function(){if(!(this._map._animatingZoom&&this._bounds)){Wr.prototype._update.call(this);var e=this._bounds,t=e.getSize(),n=this._container;(!this._svgSize||!this._svgSize.equals(t))&&(this._svgSize=t,n.setAttribute(`width`,t.x),n.setAttribute(`height`,t.y)),Y(n,e.min),n.setAttribute(`viewBox`,[e.min.x,e.min.y,t.x,t.y].join(` `)),this.fire(`update`)}},_initPath:function(e){var t=e._path=Yr(`path`);e.options.className&&J(t,e.options.className),e.options.interactive&&J(t,`leaflet-interactive`),this._updateStyle(e),this._layers[o(e)]=e},_addPath:function(e){this._rootGroup||this._initContainer(),this._rootGroup.appendChild(e._path),e.addInteractiveTarget(e._path)},_removePath:function(e){q(e._path),e.removeInteractiveTarget(e._path),delete this._layers[o(e)]},_updatePath:function(e){e._project(),e._update()},_updateStyle:function(e){var t=e._path,n=e.options;t&&(n.stroke?(t.setAttribute(`stroke`,n.color),t.setAttribute(`stroke-opacity`,n.opacity),t.setAttribute(`stroke-width`,n.weight),t.setAttribute(`stroke-linecap`,n.lineCap),t.setAttribute(`stroke-linejoin`,n.lineJoin),n.dashArray?t.setAttribute(`stroke-dasharray`,n.dashArray):t.removeAttribute(`stroke-dasharray`),n.dashOffset?t.setAttribute(`stroke-dashoffset`,n.dashOffset):t.removeAttribute(`stroke-dashoffset`)):t.setAttribute(`stroke`,`none`),n.fill?(t.setAttribute(`fill`,n.fillColor||n.color),t.setAttribute(`fill-opacity`,n.fillOpacity),t.setAttribute(`fill-rule`,n.fillRule||`evenodd`)):t.setAttribute(`fill`,`none`))},_updatePoly:function(e,t){this._setPath(e,V(e._parts,t))},_updateCircle:function(e){var t=e._point,n=Math.max(Math.round(e._radius),1),r=Math.max(Math.round(e._radiusY),1)||n,i=`a`+n+`,`+r+` 0 1,0 `,a=e._empty()?`M0 0`:`M`+(t.x-n)+`,`+t.y+i+n*2+`,0 `+i+-n*2+`,0 `;this._setPath(e,a)},_setPath:function(e,t){e._path.setAttribute(`d`,t)},_bringToFront:function(e){_t(e._path)},_bringToBack:function(e){vt(e._path)}});W.vml&&Xr.include(Jr);function Zr(e){return W.svg||W.vml?new Xr(e):null}on.include({getRenderer:function(e){var t=e.options.renderer||this._getPaneRenderer(e.options.pane)||this.options.renderer||this._renderer;return t||=this._renderer=this._createRenderer(),this.hasLayer(t)||this.addLayer(t),t},_getPaneRenderer:function(e){if(e===`overlayPane`||e===void 0)return!1;var t=this._paneRenderers[e];return t===void 0&&(t=this._createRenderer({pane:e}),this._paneRenderers[e]=t),t},_createRenderer:function(e){return this.options.preferCanvas&&Kr(e)||Zr(e)}});var Qr=dr.extend({initialize:function(e,t){dr.prototype.initialize.call(this,this._boundsToLatLngs(e),t)},setBounds:function(e){return this.setLatLngs(this._boundsToLatLngs(e))},_boundsToLatLngs:function(e){return e=R(e),[e.getSouthWest(),e.getNorthWest(),e.getNorthEast(),e.getSouthEast()]}});function $r(e,t){return new Qr(e,t)}Xr.create=Yr,Xr.pointsToPath=V,pr.geometryToLayer=mr,pr.coordsToLatLng=gr,pr.coordsToLatLngs=_r,pr.latLngToCoords=vr,pr.latLngsToCoords=yr,pr.getFeature=br,pr.asFeature=xr,on.mergeOptions({boxZoom:!0});var ei=_n.extend({initialize:function(e){this._map=e,this._container=e._container,this._pane=e._panes.overlayPane,this._resetStateTimeout=0,e.on(`unload`,this._destroy,this)},addHooks:function(){X(this._container,`mousedown`,this._onMouseDown,this)},removeHooks:function(){Ht(this._container,`mousedown`,this._onMouseDown,this)},moved:function(){return this._moved},_destroy:function(){q(this._pane),delete this._pane},_resetState:function(){this._resetStateTimeout=0,this._moved=!1},_clearDeferredResetState:function(){this._resetStateTimeout!==0&&(clearTimeout(this._resetStateTimeout),this._resetStateTimeout=0)},_onMouseDown:function(e){if(!e.shiftKey||e.which!==1&&e.button!==1)return!1;this._clearDeferredResetState(),this._resetState(),Ot(),Mt(),this._startPoint=this._map.mouseEventToContainerPoint(e),X(document,{contextmenu:Zt,mousemove:this._onMouseMove,mouseup:this._onMouseUp,keydown:this._onKeyDown},this)},_onMouseMove:function(e){this._moved||(this._moved=!0,this._box=K(`div`,`leaflet-zoom-box`,this._container),J(this._container,`leaflet-crosshair`),this._map.fire(`boxzoomstart`)),this._point=this._map.mouseEventToContainerPoint(e);var t=new P(this._point,this._startPoint),n=t.getSize();Y(this._box,t.min),this._box.style.width=n.x+`px`,this._box.style.height=n.y+`px`},_finish:function(){this._moved&&(q(this._box),bt(this._container,`leaflet-crosshair`)),kt(),Nt(),Ht(document,{contextmenu:Zt,mousemove:this._onMouseMove,mouseup:this._onMouseUp,keydown:this._onKeyDown},this)},_onMouseUp:function(e){if((e.which===1||e.button===1)&&(this._finish(),this._moved)){this._clearDeferredResetState(),this._resetStateTimeout=setTimeout(i(this._resetState,this),0);var t=new I(this._map.containerPointToLatLng(this._startPoint),this._map.containerPointToLatLng(this._point));this._map.fitBounds(t).fire(`boxzoomend`,{boxZoomBounds:t})}},_onKeyDown:function(e){e.keyCode===27&&(this._finish(),this._clearDeferredResetState(),this._resetState())}});on.addInitHook(`addHandler`,`boxZoom`,ei),on.mergeOptions({doubleClickZoom:!0});var ti=_n.extend({addHooks:function(){this._map.on(`dblclick`,this._onDoubleClick,this)},removeHooks:function(){this._map.off(`dblclick`,this._onDoubleClick,this)},_onDoubleClick:function(e){var t=this._map,n=t.getZoom(),r=t.options.zoomDelta,i=e.originalEvent.shiftKey?n-r:n+r;t.options.doubleClickZoom===`center`?t.setZoom(i):t.setZoomAround(e.containerPoint,i)}});on.addInitHook(`addHandler`,`doubleClickZoom`,ti),on.mergeOptions({dragging:!0,inertia:!0,inertiaDeceleration:3400,inertiaMaxSpeed:1/0,easeLinearity:.2,worldCopyJump:!1,maxBoundsViscosity:0});var ni=_n.extend({addHooks:function(){if(!this._draggable){var e=this._map;this._draggable=new bn(e._mapPane,e._container),this._draggable.on({dragstart:this._onDragStart,drag:this._onDrag,dragend:this._onDragEnd},this),this._draggable.on(`predrag`,this._onPreDragLimit,this),e.options.worldCopyJump&&(this._draggable.on(`predrag`,this._onPreDragWrap,this),e.on(`zoomend`,this._onZoomEnd,this),e.whenReady(this._onZoomEnd,this))}J(this._map._container,`leaflet-grab leaflet-touch-drag`),this._draggable.enable(),this._positions=[],this._times=[]},removeHooks:function(){bt(this._map._container,`leaflet-grab`),bt(this._map._container,`leaflet-touch-drag`),this._draggable.disable()},moved:function(){return this._draggable&&this._draggable._moved},moving:function(){return this._draggable&&this._draggable._moving},_onDragStart:function(){var e=this._map;if(e._stop(),this._map.options.maxBounds&&this._map.options.maxBoundsViscosity){var t=R(this._map.options.maxBounds);this._offsetLimit=F(this._map.latLngToContainerPoint(t.getNorthWest()).multiplyBy(-1),this._map.latLngToContainerPoint(t.getSouthEast()).multiplyBy(-1).add(this._map.getSize())),this._viscosity=Math.min(1,Math.max(0,this._map.options.maxBoundsViscosity))}else this._offsetLimit=null;e.fire(`movestart`).fire(`dragstart`),e.options.inertia&&(this._positions=[],this._times=[])},_onDrag:function(e){if(this._map.options.inertia){var t=this._lastTime=+new Date,n=this._lastPos=this._draggable._absPos||this._draggable._newPos;this._positions.push(n),this._times.push(t),this._prunePositions(t)}this._map.fire(`move`,e).fire(`drag`,e)},_prunePositions:function(e){for(;this._positions.length>1&&e-this._times[0]>50;)this._positions.shift(),this._times.shift()},_onZoomEnd:function(){var e=this._map.getSize().divideBy(2),t=this._map.latLngToLayerPoint([0,0]);this._initialWorldOffset=t.subtract(e).x,this._worldWidth=this._map.getPixelWorldBounds().getSize().x},_viscousLimit:function(e,t){return e-(e-t)*this._viscosity},_onPreDragLimit:function(){if(this._viscosity&&this._offsetLimit){var e=this._draggable._newPos.subtract(this._draggable._startPos),t=this._offsetLimit;e.x<t.min.x&&(e.x=this._viscousLimit(e.x,t.min.x)),e.y<t.min.y&&(e.y=this._viscousLimit(e.y,t.min.y)),e.x>t.max.x&&(e.x=this._viscousLimit(e.x,t.max.x)),e.y>t.max.y&&(e.y=this._viscousLimit(e.y,t.max.y)),this._draggable._newPos=this._draggable._startPos.add(e)}},_onPreDragWrap:function(){var e=this._worldWidth,t=Math.round(e/2),n=this._initialWorldOffset,r=this._draggable._newPos.x,i=(r-t+n)%e+t-n,a=(r+t+n)%e-t-n,o=Math.abs(i+n)<Math.abs(a+n)?i:a;this._draggable._absPos=this._draggable._newPos.clone(),this._draggable._newPos.x=o},_onDragEnd:function(e){var t=this._map,n=t.options,r=!n.inertia||e.noInertia||this._times.length<2;if(t.fire(`dragend`,e),r)t.fire(`moveend`);else{this._prunePositions(+new Date);var i=this._lastPos.subtract(this._positions[0]),a=(this._lastTime-this._times[0])/1e3,o=n.easeLinearity,s=i.multiplyBy(o/a),c=s.distanceTo([0,0]),l=Math.min(n.inertiaMaxSpeed,c),u=s.multiplyBy(l/c),d=l/(n.inertiaDeceleration*o),f=u.multiplyBy(-d/2).round();!f.x&&!f.y?t.fire(`moveend`):(f=t._limitOffset(f,t.options.maxBounds),T(function(){t.panBy(f,{duration:d,easeLinearity:o,noMoveStart:!0,animate:!0})}))}}});on.addInitHook(`addHandler`,`dragging`,ni),on.mergeOptions({keyboard:!0,keyboardPanDelta:80});var ri=_n.extend({keyCodes:{left:[37],right:[39],down:[40],up:[38],zoomIn:[187,107,61,171],zoomOut:[189,109,54,173]},initialize:function(e){this._map=e,this._setPanDelta(e.options.keyboardPanDelta),this._setZoomDelta(e.options.zoomDelta)},addHooks:function(){var e=this._map._container;e.tabIndex<=0&&(e.tabIndex=`0`),X(e,{focus:this._onFocus,blur:this._onBlur,mousedown:this._onMouseDown},this),this._map.on({focus:this._addHooks,blur:this._removeHooks},this)},removeHooks:function(){this._removeHooks(),Ht(this._map._container,{focus:this._onFocus,blur:this._onBlur,mousedown:this._onMouseDown},this),this._map.off({focus:this._addHooks,blur:this._removeHooks},this)},_onMouseDown:function(){if(!this._focused){var e=document.body,t=document.documentElement,n=e.scrollTop||t.scrollTop,r=e.scrollLeft||t.scrollLeft;this._map._container.focus(),window.scrollTo(r,n)}},_onFocus:function(){this._focused=!0,this._map.fire(`focus`)},_onBlur:function(){this._focused=!1,this._map.fire(`blur`)},_setPanDelta:function(e){for(var t=this._panKeys={},n=this.keyCodes,r=0,i=n.left.length;r<i;r++)t[n.left[r]]=[-1*e,0];for(r=0,i=n.right.length;r<i;r++)t[n.right[r]]=[e,0];for(r=0,i=n.down.length;r<i;r++)t[n.down[r]]=[0,e];for(r=0,i=n.up.length;r<i;r++)t[n.up[r]]=[0,-1*e]},_setZoomDelta:function(e){for(var t=this._zoomKeys={},n=this.keyCodes,r=0,i=n.zoomIn.length;r<i;r++)t[n.zoomIn[r]]=e;for(r=0,i=n.zoomOut.length;r<i;r++)t[n.zoomOut[r]]=-e},_addHooks:function(){X(document,`keydown`,this._onKeyDown,this)},_removeHooks:function(){Ht(document,`keydown`,this._onKeyDown,this)},_onKeyDown:function(e){if(!(e.altKey||e.ctrlKey||e.metaKey)){var t=e.keyCode,n=this._map,r;if(t in this._panKeys){if(!n._panAnim||!n._panAnim._inProgress){if(r=this._panKeys[t],e.shiftKey&&(r=N(r).multiplyBy(3)),n.options.maxBounds&&(r=n._limitOffset(N(r),n.options.maxBounds)),n.options.worldCopyJump){var i=n.wrapLatLng(n.unproject(n.project(n.getCenter()).add(r)));n.panTo(i)}else n.panBy(r)}}else if(t in this._zoomKeys)n.setZoom(n.getZoom()+(e.shiftKey?3:1)*this._zoomKeys[t]);else if(t===27&&n._popup&&n._popup.options.closeOnEscapeKey)n.closePopup();else return;Zt(e)}}});on.addInitHook(`addHandler`,`keyboard`,ri),on.mergeOptions({scrollWheelZoom:!0,wheelDebounceTime:40,wheelPxPerZoomLevel:60});var ii=_n.extend({addHooks:function(){X(this._map._container,`wheel`,this._onWheelScroll,this),this._delta=0},removeHooks:function(){Ht(this._map._container,`wheel`,this._onWheelScroll,this)},_onWheelScroll:function(e){var t=tn(e),n=this._map.options.wheelDebounceTime;this._delta+=t,this._lastMousePos=this._map.mouseEventToContainerPoint(e),this._startTime||=+new Date;var r=Math.max(n-(+new Date-this._startTime),0);clearTimeout(this._timer),this._timer=setTimeout(i(this._performZoom,this),r),Zt(e)},_performZoom:function(){var e=this._map,t=e.getZoom(),n=this._map.options.zoomSnap||0;e._stop();var r=this._delta/(this._map.options.wheelPxPerZoomLevel*4),i=4*Math.log(2/(1+Math.exp(-Math.abs(r))))/Math.LN2,a=n?Math.ceil(i/n)*n:i,o=e._limitZoom(t+(this._delta>0?a:-a))-t;this._delta=0,this._startTime=null,o&&(e.options.scrollWheelZoom===`center`?e.setZoom(t+o):e.setZoomAround(this._lastMousePos,t+o))}});on.addInitHook(`addHandler`,`scrollWheelZoom`,ii);var ai=600;on.mergeOptions({tapHold:W.touchNative&&W.safari&&W.mobile,tapTolerance:15});var oi=_n.extend({addHooks:function(){X(this._map._container,`touchstart`,this._onDown,this)},removeHooks:function(){Ht(this._map._container,`touchstart`,this._onDown,this)},_onDown:function(e){if(clearTimeout(this._holdTimeout),e.touches.length===1){var t=e.touches[0];this._startPos=this._newPos=new M(t.clientX,t.clientY),this._holdTimeout=setTimeout(i(function(){this._cancel(),this._isTapValid()&&(X(document,`touchend`,Xt),X(document,`touchend touchcancel`,this._cancelClickPrevent),this._simulateEvent(`contextmenu`,t))},this),ai),X(document,`touchend touchcancel contextmenu`,this._cancel,this),X(document,`touchmove`,this._onMove,this)}},_cancelClickPrevent:function e(){Ht(document,`touchend`,Xt),Ht(document,`touchend touchcancel`,e)},_cancel:function(){clearTimeout(this._holdTimeout),Ht(document,`touchend touchcancel contextmenu`,this._cancel,this),Ht(document,`touchmove`,this._onMove,this)},_onMove:function(e){var t=e.touches[0];this._newPos=new M(t.clientX,t.clientY)},_isTapValid:function(){return this._newPos.distanceTo(this._startPos)<=this._map.options.tapTolerance},_simulateEvent:function(e,t){var n=new MouseEvent(e,{bubbles:!0,cancelable:!0,view:window,screenX:t.screenX,screenY:t.screenY,clientX:t.clientX,clientY:t.clientY});n._simulated=!0,t.target.dispatchEvent(n)}});on.addInitHook(`addHandler`,`tapHold`,oi),on.mergeOptions({touchZoom:W.touch,bounceAtZoomLimits:!0});var si=_n.extend({addHooks:function(){J(this._map._container,`leaflet-touch-zoom`),X(this._map._container,`touchstart`,this._onTouchStart,this)},removeHooks:function(){bt(this._map._container,`leaflet-touch-zoom`),Ht(this._map._container,`touchstart`,this._onTouchStart,this)},_onTouchStart:function(e){var t=this._map;if(!(!e.touches||e.touches.length!==2||t._animatingZoom||this._zooming)){var n=t.mouseEventToContainerPoint(e.touches[0]),r=t.mouseEventToContainerPoint(e.touches[1]);this._centerPoint=t.getSize()._divideBy(2),this._startLatLng=t.containerPointToLatLng(this._centerPoint),t.options.touchZoom!==`center`&&(this._pinchStartLatLng=t.containerPointToLatLng(n.add(r)._divideBy(2))),this._startDist=n.distanceTo(r),this._startZoom=t.getZoom(),this._moved=!1,this._zooming=!0,t._stop(),X(document,`touchmove`,this._onTouchMove,this),X(document,`touchend touchcancel`,this._onTouchEnd,this),Xt(e)}},_onTouchMove:function(e){if(e.touches&&e.touches.length===2&&this._zooming){var t=this._map,n=t.mouseEventToContainerPoint(e.touches[0]),r=t.mouseEventToContainerPoint(e.touches[1]),a=n.distanceTo(r)/this._startDist;if(this._zoom=t.getScaleZoom(a,this._startZoom),!t.options.bounceAtZoomLimits&&(this._zoom<t.getMinZoom()&&a<1||this._zoom>t.getMaxZoom()&&a>1)&&(this._zoom=t._limitZoom(this._zoom)),t.options.touchZoom===`center`){if(this._center=this._startLatLng,a===1)return}else{var o=n._add(r)._divideBy(2)._subtract(this._centerPoint);if(a===1&&o.x===0&&o.y===0)return;this._center=t.unproject(t.project(this._pinchStartLatLng,this._zoom).subtract(o),this._zoom)}this._moved||=(t._moveStart(!0,!1),!0),E(this._animRequest);var s=i(t._move,t,this._center,this._zoom,{pinch:!0,round:!1},void 0);this._animRequest=T(s,this,!0),Xt(e)}},_onTouchEnd:function(){!this._moved||!this._zooming?this._zooming=!1:(this._zooming=!1,E(this._animRequest),Ht(document,`touchmove`,this._onTouchMove,this),Ht(document,`touchend touchcancel`,this._onTouchEnd,this),this._map.options.zoomAnimation?this._map._animateZoom(this._center,this._map._limitZoom(this._zoom),!0,this._map.options.zoomSnap):this._map._resetView(this._center,this._map._limitZoom(this._zoom)))}});on.addInitHook(`addHandler`,`touchZoom`,si),on.BoxZoom=ei,on.DoubleClickZoom=ti,on.Drag=ni,on.Keyboard=ri,on.ScrollWheelZoom=ii,on.TapHold=oi,on.TouchZoom=si,e.Bounds=P,e.Browser=W,e.CRS=te,e.Canvas=Gr,e.Circle=sr,e.CircleMarker=ar,e.Class=O,e.Control=cn,e.DivIcon=Ir,e.DivOverlay=jr,e.DomEvent=rn,e.DomUtil=Bt,e.Draggable=bn,e.Evented=j,e.FeatureGroup=Xn,e.GeoJSON=pr,e.GridLayer=Rr,e.Handler=_n,e.Icon=Qn,e.ImageOverlay=Tr,e.LatLng=z,e.LatLngBounds=I,e.Layer=qn,e.LayerGroup=Jn,e.LineUtil=Bn,e.Map=on,e.Marker=nr,e.Mixin=vn,e.Path=ir,e.Point=M,e.PolyUtil=wn,e.Polygon=dr,e.Polyline=lr,e.Popup=Mr,e.PosAnimation=an,e.Projection=Un,e.Rectangle=Qr,e.Renderer=Wr,e.SVG=Xr,e.SVGOverlay=kr,e.TileLayer=Br,e.Tooltip=Pr,e.Transformation=ae,e.Util=D,e.VideoOverlay=Dr,e.bind=i,e.bounds=F,e.canvas=Kr,e.circle=cr,e.circleMarker=or,e.control=ln,e.divIcon=Lr,e.extend=n,e.featureGroup=Zn,e.geoJSON=Cr,e.geoJson=wr,e.gridLayer=zr,e.icon=$n,e.imageOverlay=Er,e.latLng=B,e.latLngBounds=R,e.layerGroup=Yn,e.map=sn,e.marker=rr,e.point=N,e.polygon=fr,e.polyline=ur,e.popup=Nr,e.rectangle=$r,e.setOptions=p,e.stamp=o,e.svg=Zr,e.svgOverlay=Ar,e.tileLayer=Vr,e.tooltip=Fr,e.transformation=oe,e.version=t,e.videoOverlay=Or;var ci=window.L;e.noConflict=function(){return window.L=ci,this},window.L=e}))}))(),1),$e=({userLocation:e,destination:t,routeCoordinates:n=[],isDark:r=!0})=>{let i=(0,v.useRef)(null),a=(0,v.useRef)(null),o=(0,v.useRef)(null),s=(0,v.useRef)(null),c=(0,v.useRef)(null);return(0,v.useEffect)(()=>{if(!i.current||a.current)return;let n=e?.lat||t.lat,l=e?.lon||t.lon,u=Qe.default.map(i.current,{center:[n,l],zoom:16,zoomControl:!1,attributionControl:!1});return Qe.default.tileLayer(`https://tile.openstreetmap.org/{z}/{x}/{y}.png`,{maxZoom:19,className:r?`dark-map-tiles`:``}).addTo(u),a.current=u,setTimeout(()=>{u.invalidateSize()},150),()=>{u.remove(),a.current=null,o.current=null,s.current=null,c.current=null}},[]),(0,v.useEffect)(()=>{let e=a.current;if(e&&(c.current&&=(e.removeLayer(c.current),null),n&&n.length>1)){let t=Qe.default.polyline(n,{color:`#f59e0b`,weight:5,opacity:.9,lineCap:`round`,lineJoin:`round`}).addTo(e);c.current=t;try{e.fitBounds(t.getBounds(),{padding:[25,25],maxZoom:17})}catch{}}},[n]),(0,v.useEffect)(()=>{let e=a.current;if(e&&t&&!isNaN(t.lat)&&!isNaN(t.lon)){if(s.current)s.current.setLatLng([t.lat,t.lon]);else{let n=`
        <div style="display:flex; flex-direction:column; align-items:center; transform: translate(-50%, -100%);">
          <div style="background:#fbbf24; color:#000; font-weight:900; font-family:monospace; font-size:12px; padding:3px 7px; border-radius:8px; border:2px solid #000; box-shadow:0 4px 8px rgba(0,0,0,0.5); white-space:nowrap;">
            ${t.houseNumber||`STOP`}
          </div>
          <div style="width:0; height:0; border-left:6px solid transparent; border-right:6px solid transparent; border-top:8px solid #fbbf24;"></div>
        </div>
      `,r=Qe.default.divIcon({html:n,className:`custom-dest-pin`,iconSize:[40,40],iconAnchor:[20,36]});s.current=Qe.default.marker([t.lat,t.lon],{icon:r}).addTo(e)}}},[t.lat,t.lon,t.houseNumber]),(0,v.useEffect)(()=>{let t=a.current;if(t){if(e&&!isNaN(e.lat)&&!isNaN(e.lon)){let n=[e.lat,e.lon];if(o.current)o.current.setLatLng(n);else{let e=Qe.default.divIcon({html:`
          <div style="position:relative; width:22px; height:22px; display:flex; align-items:center; justify-content:center;">
            <div style="position:absolute; width:100%; height:100%; border-radius:50%; background:#38bdf8; opacity:0.4; animation:ping 1.5s cubic-bezier(0,0,0.2,1) infinite;"></div>
            <div style="width:14px; height:14px; border-radius:50%; background:#0284c7; border:2.5px solid #ffffff; box-shadow:0 0 8px rgba(2,132,199,0.9);"></div>
          </div>
        `,className:`custom-user-dot`,iconSize:[22,22],iconAnchor:[11,11]});o.current=Qe.default.marker(n,{icon:e,zIndexOffset:1e3}).addTo(t)}}else o.current&&=(t.removeLayer(o.current),null)}},[e?.lat,e?.lon]),(0,G.jsxs)(`div`,{className:`relative w-full h-full min-h-[170px] max-h-[260px] rounded-2xl overflow-hidden border border-neutral-800 bg-neutral-950 shadow-inner`,children:[(0,G.jsx)(`div`,{ref:i,className:`w-full h-full`}),(0,G.jsxs)(`div`,{className:`absolute bottom-2.5 right-2.5 z-[1000] flex flex-col gap-1.5`,children:[(0,G.jsx)(`button`,{onClick:()=>{let n=a.current;n&&(e&&!isNaN(e.lat)&&!isNaN(e.lon)?n.setView([e.lat,e.lon],17,{animate:!0}):t&&!isNaN(t.lat)&&!isNaN(t.lon)&&n.setView([t.lat,t.lon],17,{animate:!0}))},className:`p-2 bg-neutral-900/90 hover:bg-neutral-800 text-amber-400 rounded-xl border border-neutral-700 shadow-lg backdrop-blur-sm transition-transform active:scale-90`,title:`Center on current location`,children:(0,G.jsx)(Pe,{className:`w-4 h-4`})}),(0,G.jsx)(`button`,{onClick:()=>{let n=a.current;if(n){if(c.current)n.fitBounds(c.current.getBounds(),{padding:[25,25],maxZoom:17});else if(e&&t){let r=Qe.default.latLngBounds([e.lat,e.lon],[t.lat,t.lon]);n.fitBounds(r,{padding:[30,30],maxZoom:17})}}},className:`p-2 bg-neutral-900/90 hover:bg-neutral-800 text-neutral-300 rounded-xl border border-neutral-700 shadow-lg backdrop-blur-sm transition-transform active:scale-90`,title:`Fit full route to customer`,children:(0,G.jsx)(xe,{className:`w-4 h-4`})})]}),(0,G.jsx)(`div`,{className:`absolute bottom-1 left-2 z-[1000] pointer-events-none text-[9px] font-mono text-neutral-400/80 bg-black/60 px-1.5 py-0.5 rounded`,children:`© OpenStreetMap`})]})},et=({stop:e,previousStop:t,nextStop:n,userLocation:r,gpsStatus:i,gpsErrorMsg:a,distanceToCurrentFeet:o,isWithinGeofence:s,autoArrivalStatus:c,currentIndex:l,totalStops:u,settings:d,onSkip:f,onPrevious:p,onJumpToStopList:m,arrivalRadiusMeters:h,isPassedWithoutCompletion:g,simulateApproachAndPass:_,simulateApproachAndArrive:y,isSimulatingGps:b,stopGpsSimulation:S})=>{let C=d.theme===`amoled-black`,[w,T]=(0,v.useState)(!1),[E,D]=(0,v.useState)([]),O=x(e,l);return(0,G.jsxs)(`div`,{className:`flex flex-col h-full justify-between pb-safe select-none overflow-hidden`,children:[(0,G.jsx)(`div`,{className:`shrink-0`,children:(0,G.jsx)(Ze,{currentStop:e,previousStop:t,nextStop:n,userLocation:r,gpsStatus:i,gpsErrorMsg:a,distanceToCurrentFeet:o,isDark:C,arrivalRadiusMeters:h||d.arrivalRadiusMeters||50,isWithinGeofence:s,autoArrivalStatus:c,isPassedWithoutCompletion:g,simulateApproachAndPass:_,simulateApproachAndArrive:y,isSimulatingGps:b,stopGpsSimulation:S,onRouteCoordinatesUpdate:D,onSkipCustomer:f,voiceAnnouncement:d.voiceAnnouncement})}),(0,G.jsxs)(`div`,{className:`shrink-0 flex items-center justify-between px-1 py-0.5 mb-1 gap-2`,children:[(0,G.jsxs)(`button`,{onClick:m,className:`flex items-center gap-1.5 text-xs font-mono font-bold text-neutral-400 hover:text-white transition-colors`,title:`Open Stop List`,children:[(0,G.jsxs)(`span`,{className:`text-emerald-400`,children:[`STOP `,l+1,` OF `,u]}),(0,G.jsx)(je,{className:`w-3.5 h-3.5 text-neutral-500`})]}),(0,G.jsxs)(`div`,{className:`flex items-center gap-1.5`,children:[(0,G.jsxs)(`button`,{onClick:()=>T(e=>!e),className:`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-black uppercase tracking-wider transition-all active:scale-95 border ${w?`bg-amber-400 text-black border-amber-300 shadow-md shadow-amber-950/40`:`bg-neutral-900 hover:bg-neutral-800 text-amber-400 border-neutral-700`}`,title:w?`Hide road map`:`Show road map`,children:[(0,G.jsx)(Me,{className:`w-3.5 h-3.5`}),(0,G.jsx)(`span`,{children:w?`Hide Map`:`Show Map`})]}),l>0&&(0,G.jsxs)(`button`,{onClick:p,className:`flex items-center gap-1 text-[11px] font-semibold text-neutral-400 hover:text-white px-2 py-1 rounded-lg bg-neutral-900 border border-neutral-800 transition-colors active:scale-95`,title:`Return to previous customer`,children:[(0,G.jsx)(de,{className:`w-3.5 h-3.5`}),(0,G.jsx)(`span`,{children:`Prev`})]})]})]}),w?(0,G.jsxs)(`div`,{className:`flex-1 flex flex-col min-h-0 my-auto py-1 space-y-1.5`,children:[(0,G.jsxs)(`div`,{className:`shrink-0 flex items-center justify-between bg-neutral-900/90 border border-neutral-800 rounded-xl px-3 py-1.5`,children:[(0,G.jsxs)(`div`,{className:`min-w-0 flex-1 pr-2`,children:[(0,G.jsx)(`div`,{className:`text-sm font-black text-white truncate`,children:e.name}),e.fullAddress&&(0,G.jsx)(`div`,{className:`text-[11px] font-semibold text-neutral-400 truncate`,children:e.fullAddress})]}),(0,G.jsx)(`div`,{className:`shrink-0 px-2.5 py-0.5 bg-amber-400 text-black font-black font-mono text-xl rounded-lg border border-amber-300 shadow`,children:O})]}),(0,G.jsx)(`div`,{className:`flex-1 min-h-[160px] max-h-[250px] w-full`,children:(0,G.jsx)($e,{userLocation:r,destination:{lat:e.lat,lon:e.lon,name:e.name,houseNumber:O,address:e.fullAddress},routeCoordinates:E,isDark:C})})]}):(0,G.jsxs)(`div`,{className:`flex-1 flex flex-col items-center justify-center my-auto py-1 text-center min-h-0`,children:[(0,G.jsx)(`h1`,{className:`text-2xl sm:text-3xl font-black text-white tracking-tight leading-snug mb-2 px-2 max-w-md break-words line-clamp-2`,children:e.name}),(0,G.jsx)(`div`,{className:`bg-amber-400 text-black border-2 border-amber-300 rounded-2xl px-6 py-2.5 sm:py-3 flex items-center justify-center shadow-xl min-w-[160px] max-w-[260px] transition-transform active:scale-95`,children:(0,G.jsx)(`span`,{className:`text-5xl sm:text-6xl font-black font-mono tracking-tighter leading-none`,children:O})})]}),(0,G.jsx)(`div`,{className:`shrink-0 pt-1.5`,children:(0,G.jsxs)(`button`,{onClick:f,className:`w-full h-12 sm:h-13 rounded-xl flex items-center justify-center gap-2 font-black text-base sm:text-lg tracking-wide uppercase bg-amber-500 hover:bg-amber-400 text-black border-2 border-amber-300 shadow-lg shadow-amber-950/40 transition-all active:scale-[0.98]`,children:[(0,G.jsx)(Be,{className:`w-5 h-5 stroke-[3]`}),(0,G.jsx)(`span`,{children:`Skip Customer`})]})})]})},tt=({isOpen:e,isDark:t,onClose:n,onImportSuccess:r})=>{let[i,a]=(0,v.useState)(`upload`),[o,s]=(0,v.useState)(``),[c,l]=(0,v.useState)(!1),[u,d]=(0,v.useState)(null),[f,p]=(0,v.useState)(null);if(!e)return null;let m=e=>{d(null);try{let t=new FileReader;t.onload=t=>{try{let n=t.target?.result;if(!n||typeof n!=`string`)throw Error(`File content is empty or unreadable.`);let r=T(n,e.name.replace(/\.[^/.]+$/,``));if(!r.stops||r.stops.length===0)throw Error(`No valid customer stops found in GPX file.`);p({stops:r.stops,routeName:r.routeName,filename:e.name})}catch(e){d(e.message||`Failed to parse GPX file.`)}},t.onerror=()=>{d(`Error reading file from disk.`)},t.readAsText(e)}catch(e){d(e.message||`Error processing file.`)}},h=e=>{e.preventDefault(),l(!1),e.dataTransfer.files&&e.dataTransfer.files[0]&&m(e.dataTransfer.files[0])},g=e=>{e.target.files&&e.target.files[0]&&m(e.target.files[0]),e.target&&(e.target.value=``)},_=()=>{d(null);try{if(!o.trim()){d(`Please paste GPX XML content.`);return}let e=T(o,`Pasted GPX Route`);p({stops:e.stops,routeName:e.routeName,filename:`pasted_route.gpx`})}catch(e){d(e.message||`Invalid GPX content.`)}},y=e=>{d(null);try{let t=T(e.gpxXml,e.title);p({stops:t.stops,routeName:t.routeName,filename:`${e.id}.gpx`})}catch(e){d(e.message)}},b=()=>{f&&(r(f.stops,f.routeName,f.filename),n())},x=e=>{let t=new Blob([e.gpxXml],{type:`application/gpx+xml`}),n=URL.createObjectURL(t),r=document.createElement(`a`);r.href=n,r.download=`${e.id}.gpx`,r.click(),URL.revokeObjectURL(n)};return(0,G.jsx)(`div`,{className:`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200`,children:(0,G.jsxs)(`div`,{className:`w-full max-w-lg rounded-3xl border shadow-2xl overflow-hidden flex flex-col max-h-[90vh] ${t?`bg-neutral-900 border-neutral-700 text-white`:`bg-white border-neutral-300 text-black`}`,children:[(0,G.jsxs)(`div`,{className:`flex items-center justify-between px-6 py-4 border-b border-neutral-800`,children:[(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h2`,{className:`text-lg font-black tracking-tight`,children:`Import Customer GPX Route`}),(0,G.jsx)(`p`,{className:`text-xs text-neutral-400 mt-0.5`,children:`Exact customer waypoint sequence will be preserved`})]}),(0,G.jsx)(`button`,{onClick:n,className:`p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors`,children:(0,G.jsx)(qe,{className:`w-5 h-5`})})]}),(0,G.jsxs)(`div`,{className:`flex border-b border-neutral-800 px-6 pt-3 gap-2 bg-neutral-950/40`,children:[(0,G.jsxs)(`button`,{onClick:()=>{a(`samples`),d(null)},className:`pb-2.5 px-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 ${i===`samples`?`border-emerald-400 text-emerald-400`:`border-transparent text-neutral-400 hover:text-neutral-200`}`,children:[(0,G.jsx)(He,{className:`w-3.5 h-3.5`}),(0,G.jsx)(`span`,{children:`Sample Routes`})]}),(0,G.jsxs)(`button`,{onClick:()=>{a(`upload`),d(null)},className:`pb-2.5 px-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 ${i===`upload`?`border-emerald-400 text-emerald-400`:`border-transparent text-neutral-400 hover:text-neutral-200`}`,children:[(0,G.jsx)(_e,{className:`w-3.5 h-3.5`}),(0,G.jsx)(`span`,{children:`Upload GPX File`})]}),(0,G.jsxs)(`button`,{onClick:()=>{a(`paste`),d(null)},className:`pb-2.5 px-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 ${i===`paste`?`border-emerald-400 text-emerald-400`:`border-transparent text-neutral-400 hover:text-neutral-200`}`,children:[(0,G.jsx)(Te,{className:`w-3.5 h-3.5`}),(0,G.jsx)(`span`,{children:`Paste XML`})]})]}),(0,G.jsxs)(`div`,{className:`p-6 overflow-y-auto flex-1 space-y-4`,children:[u&&(0,G.jsxs)(`div`,{className:`p-3 rounded-xl bg-red-950/80 border border-red-800 text-red-200 text-xs flex items-center gap-2`,children:[(0,G.jsx)(fe,{className:`w-4 h-4 shrink-0 text-red-400`}),(0,G.jsx)(`span`,{children:u})]}),i===`samples`&&(0,G.jsxs)(`div`,{className:`space-y-3`,children:[(0,G.jsx)(`p`,{className:`text-xs text-neutral-400`,children:`Instantly load ready-to-test customer routes, or download the GPX to import into OsmAnd:`}),O.map(e=>(0,G.jsxs)(`div`,{className:`p-4 rounded-2xl border transition-all ${f?.filename===`${e.id}.gpx`?`border-emerald-500 bg-emerald-950/20`:t?`border-neutral-800 bg-neutral-950 hover:border-neutral-700`:`border-neutral-200 bg-neutral-50 hover:border-neutral-300`}`,children:[(0,G.jsx)(`div`,{className:`flex items-start justify-between gap-3`,children:(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h3`,{className:`font-bold text-sm text-neutral-100`,children:e.title}),(0,G.jsx)(`p`,{className:`text-xs text-neutral-400 mt-1 leading-relaxed`,children:e.description}),(0,G.jsxs)(`span`,{className:`inline-block mt-2 text-[11px] font-mono font-bold px-2 py-0.5 rounded bg-neutral-800 text-emerald-400`,children:[e.stopCount,` Sequenced Stops`]})]})}),(0,G.jsxs)(`div`,{className:`mt-3 pt-3 border-t border-neutral-800/80 flex items-center justify-between gap-2`,children:[(0,G.jsx)(`button`,{onClick:()=>y(e),className:`px-3.5 py-1.5 text-xs font-bold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors`,children:`Select Route`}),(0,G.jsxs)(`button`,{onClick:()=>x(e),className:`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border border-neutral-700 text-neutral-300 hover:text-white hover:bg-neutral-800 transition-colors`,title:`Download .gpx file to load into OsmAnd`,children:[(0,G.jsx)(Se,{className:`w-3.5 h-3.5`}),(0,G.jsx)(`span`,{children:`Download GPX`})]})]})]},e.id))]}),i===`upload`&&(0,G.jsxs)(`div`,{onDragOver:e=>{e.preventDefault(),l(!0)},onDragLeave:()=>l(!1),onDrop:h,className:`border-2 border-dashed rounded-2xl p-8 text-center flex flex-col items-center justify-center transition-all ${c?`border-emerald-400 bg-emerald-950/20`:t?`border-neutral-700 bg-neutral-950/60`:`border-neutral-300 bg-neutral-50`}`,children:[(0,G.jsx)(_e,{className:`w-10 h-10 text-emerald-400 mb-3`}),(0,G.jsx)(`p`,{className:`font-bold text-sm mb-1`,children:`Drag and drop your GPX file here`}),(0,G.jsx)(`p`,{className:`text-xs text-neutral-400 mb-4`,children:`Supports OsmAnd waypoints, routepoints, and favorites (.gpx)`}),(0,G.jsxs)(`label`,{className:`cursor-pointer px-4 py-2 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white transition-colors`,children:[`Browse Files`,(0,G.jsx)(`input`,{type:`file`,className:`hidden`,onChange:g})]}),(0,G.jsxs)(`p`,{className:`text-[11px] text-neutral-400 mt-3 max-w-xs`,children:[`💡 Tip: If Samsung shows "No files", tap `,(0,G.jsx)(`span`,{className:`font-semibold text-neutral-200`,children:`Recent files`}),` at the top, or switch to the `,(0,G.jsx)(`span`,{className:`font-semibold text-emerald-400`,children:`Paste GPX`}),` tab!`]})]}),i===`paste`&&(0,G.jsxs)(`div`,{className:`space-y-3`,children:[(0,G.jsx)(`label`,{className:`block text-xs font-bold uppercase text-neutral-400`,children:`Paste GPX XML Code`}),(0,G.jsx)(`textarea`,{value:o,onChange:e=>s(e.target.value),placeholder:`<?xml version='1.0' encoding='UTF-8'?>\\n<gpx version='1.1' ...>\\n  <wpt lat='...' lon='...'>\\n    <name>Customer Name</name>\\n    <desc>123 Main St</desc>\\n  </wpt>\\n</gpx>`,rows:7,className:`w-full rounded-xl p-3 text-xs font-mono bg-neutral-950 border border-neutral-700 text-neutral-200 focus:outline-none focus:border-emerald-400 resize-none`}),(0,G.jsx)(`button`,{onClick:_,className:`w-full py-2.5 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white transition-colors`,children:`Parse GPX Text`})]}),f&&(0,G.jsxs)(`div`,{className:`p-4 rounded-2xl border border-emerald-500/50 bg-emerald-950/20 space-y-2`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-2 text-emerald-400 font-bold text-sm`,children:[(0,G.jsx)(pe,{className:`w-4 h-4`}),(0,G.jsxs)(`span`,{children:[`Ready to load: `,f.routeName]})]}),(0,G.jsxs)(`div`,{className:`text-xs text-neutral-300 space-y-1`,children:[(0,G.jsxs)(`p`,{children:[`Found `,(0,G.jsxs)(`strong`,{className:`text-emerald-300`,children:[f.stops.length,` stops`]}),` in exact GPX order.`]}),(0,G.jsxs)(`p`,{className:`text-[11px] text-neutral-400`,children:[`Stop #1: `,(0,G.jsx)(`strong`,{children:f.stops[0]?.name}),` (`,f.stops[0]?.houseNumber?`#${f.stops[0].houseNumber} `:``,f.stops[0]?.streetName,`)`]}),f.stops.length>1&&(0,G.jsxs)(`p`,{className:`text-[11px] text-neutral-400`,children:[`Final Stop #`,f.stops.length,`: `,(0,G.jsx)(`strong`,{children:f.stops[f.stops.length-1]?.name})]})]})]})]}),(0,G.jsxs)(`div`,{className:`px-6 py-4 border-t border-neutral-800 flex items-center justify-end gap-3 bg-neutral-950/40`,children:[(0,G.jsx)(`button`,{onClick:n,className:`px-4 py-2 text-xs font-semibold rounded-xl border border-neutral-700 text-neutral-300 hover:bg-neutral-800 transition-colors`,children:`Cancel`}),(0,G.jsxs)(`button`,{disabled:!f,onClick:b,className:`px-5 py-2.5 text-xs font-extrabold rounded-xl transition-all ${f?`bg-emerald-500 hover:bg-emerald-400 text-black shadow-lg shadow-emerald-950/50`:`opacity-40 cursor-not-allowed bg-neutral-800 text-neutral-500`}`,children:[`Start Route with `,f?.stops.length||0,` Stops`]})]})]})})},nt=({isOpen:e,isDark:t,stops:n,currentIndex:r,routeName:i,onClose:a,onSelectStop:o,onResetRoute:s})=>{let[c,l]=(0,v.useState)(``);if(!e)return null;let u=n.map((e,t)=>({stop:e,originalIndex:t})).filter(({stop:e,originalIndex:t})=>{let n=c.toLowerCase(),r=x(e,t);return e.name.toLowerCase().includes(n)||e.fullAddress.toLowerCase().includes(n)||r!==`—`&&r.toLowerCase().includes(n)||String(e.orderIndex).includes(n)});return(0,G.jsx)(`div`,{className:`fixed inset-0 z-50 flex justify-end bg-black/85 backdrop-blur-sm animate-in fade-in duration-200`,children:(0,G.jsxs)(`div`,{className:`w-full max-w-md h-full flex flex-col shadow-2xl border-l ${t?`bg-neutral-950 border-neutral-800 text-white`:`bg-white border-neutral-300 text-black`}`,children:[(0,G.jsxs)(`div`,{className:`p-4 border-b border-neutral-800 flex items-center justify-between`,children:[(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h2`,{className:`font-black text-base tracking-tight`,children:`Customer Sequence`}),(0,G.jsxs)(`p`,{className:`text-xs text-neutral-400`,children:[n.length,` Total Waypoints · Preserved Order`]})]}),(0,G.jsx)(`button`,{onClick:a,className:`p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors`,children:(0,G.jsx)(qe,{className:`w-5 h-5`})})]}),(0,G.jsx)(`div`,{className:`p-3 border-b border-neutral-800 bg-neutral-900/60`,children:(0,G.jsxs)(`div`,{className:`relative`,children:[(0,G.jsx)(Le,{className:`w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400`}),(0,G.jsx)(`input`,{type:`text`,value:c,onChange:e=>l(e.target.value),placeholder:`Search customer, house #, or street...`,className:`w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-100 placeholder:text-neutral-500 focus:outline-none focus:border-emerald-400`}),c&&(0,G.jsx)(`button`,{onClick:()=>l(``),className:`absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white text-xs`,children:`Clear`})]})}),(0,G.jsx)(`div`,{className:`flex-1 overflow-y-auto divide-y divide-neutral-800/60 p-2`,children:u.length===0?(0,G.jsxs)(`div`,{className:`text-center py-12 text-neutral-400 text-xs`,children:[`No customers found matching "`,c,`"`]}):u.map(({stop:e,originalIndex:n})=>{let i=n===r;return(0,G.jsxs)(`div`,{onClick:()=>{o(n),a()},className:`p-3 rounded-xl transition-all cursor-pointer flex items-center gap-3 my-1 ${i?`bg-emerald-950/40 border-2 border-emerald-500/80 shadow-md`:t?`hover:bg-neutral-900/80 border border-transparent`:`hover:bg-neutral-100 border border-transparent`}`,children:[(0,G.jsxs)(`div`,{className:`w-9 h-9 rounded-xl flex items-center justify-center font-mono font-bold text-xs shrink-0 ${i?`bg-emerald-500 text-black shadow-md`:e.status===`completed`?`bg-neutral-800 text-emerald-400 border border-emerald-800/50`:e.status===`skipped`?`bg-amber-950 text-amber-400 border border-amber-800/50`:`bg-neutral-900 text-neutral-300 border border-neutral-800`}`,children:[`#`,e.orderIndex]}),(0,G.jsxs)(`div`,{className:`flex-1 min-w-0`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,G.jsx)(`span`,{className:`font-bold text-sm truncate ${i?`text-emerald-300`:`text-neutral-100`}`,children:e.name}),(()=>{let t=x(e,n);return t===`—`?null:(0,G.jsxs)(`span`,{className:`text-[10px] font-mono px-1.5 py-0.2 rounded bg-neutral-800 text-amber-300 border border-neutral-700`,children:[`#`,t]})})()]}),(0,G.jsx)(`p`,{className:`text-xs text-neutral-400 truncate mt-0.5`,children:e.fullAddress})]}),(0,G.jsxs)(`div`,{className:`shrink-0 flex items-center gap-1.5`,children:[e.status===`completed`&&(0,G.jsx)(`span`,{className:`flex items-center gap-1 text-[11px] font-semibold text-emerald-400`,children:(0,G.jsx)(pe,{className:`w-4 h-4`})}),e.status===`skipped`&&(0,G.jsx)(`span`,{className:`flex items-center gap-1 text-[11px] font-semibold text-amber-400`,children:(0,G.jsx)(Be,{className:`w-4 h-4`})}),e.status===`pending`&&!i&&(0,G.jsx)(`span`,{className:`text-[11px] text-neutral-500`,children:(0,G.jsx)(ge,{className:`w-3.5 h-3.5`})}),i&&(0,G.jsx)(`span`,{className:`px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-500 text-black tracking-wider`,children:`Active`})]})]},e.id)})}),(0,G.jsxs)(`div`,{className:`p-3 border-t border-neutral-800 bg-neutral-900/60 flex items-center justify-between gap-2`,children:[(0,G.jsxs)(`button`,{onClick:s,className:`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors`,children:[(0,G.jsx)(Ie,{className:`w-3.5 h-3.5`}),(0,G.jsx)(`span`,{children:`Reset to Stop 1`})]}),(0,G.jsxs)(`button`,{onClick:()=>{let e=E(n,i),t=new Blob([e],{type:`application/gpx+xml`}),r=URL.createObjectURL(t),a=document.createElement(`a`);a.href=r,a.download=`${i.replace(/\s+/g,`_`)}_updated.gpx`,a.click(),URL.revokeObjectURL(r)},className:`flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white transition-colors`,children:[(0,G.jsx)(Se,{className:`w-3.5 h-3.5 text-emerald-400`}),(0,G.jsx)(`span`,{children:`Export GPX`})]})]})]})})},rt=({isOpen:e,isDark:t,settings:n,onClose:r,onUpdateSettings:i,onOpenImport:a,onResetProgress:o,onClearRoute:s,onOpenExport:c})=>e?(0,G.jsx)(`div`,{className:`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200`,children:(0,G.jsxs)(`div`,{className:`w-full max-w-md rounded-3xl border shadow-2xl overflow-hidden flex flex-col max-h-[90vh] ${t?`bg-neutral-900 border-neutral-700 text-white`:`bg-white border-neutral-300 text-black`}`,children:[(0,G.jsxs)(`div`,{className:`flex items-center justify-between px-6 py-4 border-b border-neutral-800`,children:[(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h2`,{className:`text-lg font-black tracking-tight`,children:`Driver & Screen Settings`}),(0,G.jsx)(`p`,{className:`text-xs text-neutral-400 mt-0.5`,children:`Optimized for Samsung Android & OsmAnd`})]}),(0,G.jsx)(`button`,{onClick:r,className:`p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors`,children:(0,G.jsx)(qe,{className:`w-5 h-5`})})]}),(0,G.jsxs)(`div`,{className:`p-6 overflow-y-auto space-y-5`,children:[(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`label`,{className:`text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-2`,children:`Display Mode`}),(0,G.jsxs)(`div`,{className:`grid grid-cols-2 gap-3`,children:[(0,G.jsxs)(`button`,{onClick:()=>i({theme:`amoled-black`}),className:`p-3.5 rounded-2xl border flex flex-col items-center justify-center gap-2 transition-all ${n.theme===`amoled-black`?`border-emerald-400 bg-neutral-950 text-white ring-2 ring-emerald-500/30`:`border-neutral-800 bg-neutral-950/40 text-neutral-400 hover:text-neutral-200`}`,children:[(0,G.jsx)(Ne,{className:`w-5 h-5 text-emerald-400`}),(0,G.jsx)(`span`,{className:`text-xs font-bold`,children:`AMOLED Pitch Black`}),(0,G.jsx)(`span`,{className:`text-[10px] text-neutral-400`,children:`Saves battery & high OLED contrast`})]}),(0,G.jsxs)(`button`,{onClick:()=>i({theme:`high-contrast-day`}),className:`p-3.5 rounded-2xl border flex flex-col items-center justify-center gap-2 transition-all ${n.theme===`high-contrast-day`?`border-emerald-400 bg-neutral-100 text-black ring-2 ring-emerald-500/30`:`border-neutral-800 bg-neutral-950/40 text-neutral-400 hover:text-neutral-200`}`,children:[(0,G.jsx)(We,{className:`w-5 h-5 text-amber-500`}),(0,G.jsx)(`span`,{className:`text-xs font-bold`,children:`Daylight High Contrast`}),(0,G.jsx)(`span`,{className:`text-[10px] text-neutral-400`,children:`Direct sunlight in vehicle mount`})]})]})]}),(0,G.jsxs)(`div`,{className:`flex items-center justify-between p-3.5 rounded-2xl border border-neutral-800 bg-neutral-950/50`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,G.jsx)(`div`,{className:`p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-emerald-400`,children:(0,G.jsx)(Ve,{className:`w-4 h-4`})}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h4`,{className:`text-xs font-bold text-neutral-100`,children:`Keep Screen Awake`}),(0,G.jsx)(`p`,{className:`text-[11px] text-neutral-400`,children:`Prevents phone display from sleeping while on route`})]})]}),(0,G.jsx)(`input`,{type:`checkbox`,checked:n.keepScreenAwake,onChange:e=>i({keepScreenAwake:e.target.checked}),className:`w-5 h-5 accent-emerald-500 rounded cursor-pointer`})]}),(0,G.jsxs)(`div`,{className:`flex items-center justify-between p-3.5 rounded-2xl border border-neutral-800 bg-neutral-950/50`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,G.jsx)(`div`,{className:`p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-emerald-400`,children:(0,G.jsx)(Ke,{className:`w-4 h-4`})}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h4`,{className:`text-xs font-bold text-neutral-100`,children:`Voice Announcement`}),(0,G.jsx)(`p`,{className:`text-[11px] text-neutral-400`,children:`Speaks next customer name & address on advance`})]})]}),(0,G.jsx)(`input`,{type:`checkbox`,checked:n.voiceAnnouncement,onChange:e=>i({voiceAnnouncement:e.target.checked}),className:`w-5 h-5 accent-emerald-500 rounded cursor-pointer`})]}),(0,G.jsxs)(`div`,{className:`flex items-center justify-between p-3.5 rounded-2xl border border-neutral-800 bg-neutral-950/50`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,G.jsx)(`div`,{className:`p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-amber-400`,children:(0,G.jsx)(He,{className:`w-4 h-4`})}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h4`,{className:`text-xs font-bold text-neutral-100`,children:`Haptic Vibration`}),(0,G.jsx)(`p`,{className:`text-[11px] text-neutral-400`,children:`Tactile vibration feedback on button press`})]})]}),(0,G.jsx)(`input`,{type:`checkbox`,checked:n.hapticFeedback,onChange:e=>i({hapticFeedback:e.target.checked}),className:`w-5 h-5 accent-emerald-500 rounded cursor-pointer`})]}),(0,G.jsxs)(`div`,{className:`flex items-center justify-between p-3.5 rounded-2xl border border-neutral-800 bg-neutral-950/50`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,G.jsx)(`div`,{className:`p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-blue-400`,children:(0,G.jsx)(Ce,{className:`w-4 h-4`})}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h4`,{className:`text-xs font-bold text-neutral-100`,children:`Extra Large Typography`}),(0,G.jsx)(`p`,{className:`text-[11px] text-neutral-400`,children:`Maximizes readability from distance on dash mount`})]})]}),(0,G.jsx)(`input`,{type:`checkbox`,checked:n.extraLargeText,onChange:e=>i({extraLargeText:e.target.checked}),className:`w-5 h-5 accent-emerald-500 rounded cursor-pointer`})]}),(0,G.jsxs)(`div`,{className:`p-4 rounded-2xl border border-neutral-800 bg-neutral-950/50 space-y-2.5`,children:[(0,G.jsxs)(`div`,{className:`flex items-center justify-between`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-2.5`,children:[(0,G.jsx)(`div`,{className:`p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-amber-400`,children:(0,G.jsx)(Ie,{className:`w-4 h-4`})}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h4`,{className:`text-xs font-bold text-neutral-100`,children:`Arrival Detection Radius`}),(0,G.jsx)(`p`,{className:`text-[11px] text-neutral-400`,children:`Geofence distance when approaching or passing stops`})]})]}),(0,G.jsxs)(`span`,{className:`text-xs font-mono font-bold text-amber-400`,children:[n.arrivalRadiusMeters||50,`m (~`,Math.round((n.arrivalRadiusMeters||50)*3.28084),` ft)`]})]}),(0,G.jsx)(`div`,{className:`grid grid-cols-5 gap-1.5 pt-1`,children:[{meters:25,label:`25m`,sub:`82 ft`},{meters:40,label:`40m`,sub:`131 ft`},{meters:50,label:`50m`,sub:`164 ft`,rec:!0},{meters:75,label:`75m`,sub:`246 ft`},{meters:100,label:`100m`,sub:`328 ft`}].map(e=>{let t=(n.arrivalRadiusMeters||50)===e.meters;return(0,G.jsxs)(`button`,{type:`button`,onClick:()=>i({arrivalRadiusMeters:e.meters}),className:`py-2 px-1 rounded-xl border flex flex-col items-center justify-center transition-all ${t?`border-amber-400 bg-amber-400/15 text-amber-300 font-bold ring-1 ring-amber-400/50`:`border-neutral-800 bg-neutral-900/60 text-neutral-400 hover:text-white`}`,children:[(0,G.jsx)(`span`,{className:`text-xs`,children:e.label}),(0,G.jsx)(`span`,{className:`text-[9px] text-neutral-500`,children:e.sub}),e.rec&&(0,G.jsx)(`span`,{className:`text-[8px] text-emerald-400 font-mono mt-0.5`,children:`Rec`})]},e.meters)})}),(0,G.jsx)(`p`,{className:`text-[10px] text-neutral-500`,children:`50m (~164 ft) ensures reliable arrival recognition when passing at driving speed or on wide roads.`})]}),(0,G.jsxs)(`div`,{className:`pt-3 border-t border-neutral-800 space-y-2`,children:[(0,G.jsx)(`label`,{className:`text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-2`,children:`Route Management`}),(0,G.jsxs)(`button`,{onClick:()=>{r(),c?.()},className:`w-full flex items-center justify-between p-3 rounded-xl border border-blue-800 hover:border-blue-700 bg-blue-950/40 text-xs font-bold text-blue-300 hover:text-white transition-colors`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,G.jsx)(De,{className:`w-4 h-4 text-blue-400`}),(0,G.jsx)(`span`,{children:`Export Project Source (.ZIP)`})]}),(0,G.jsx)(`span`,{className:`text-[10px] px-2 py-0.5 rounded bg-blue-900/60 text-blue-200 font-mono`,children:`Step 1`})]}),(0,G.jsxs)(`button`,{onClick:()=>{r(),a()},className:`w-full flex items-center justify-between p-3 rounded-xl border border-neutral-800 hover:border-neutral-700 bg-neutral-950/40 text-xs font-bold text-neutral-200 hover:text-white transition-colors`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,G.jsx)(De,{className:`w-4 h-4 text-neutral-400`}),(0,G.jsx)(`span`,{children:`Import Different GPX File`})]}),(0,G.jsx)(`span`,{className:`text-[10px] text-neutral-400`,children:`Browse...`})]}),(0,G.jsxs)(`button`,{onClick:()=>{o(),r()},className:`w-full flex items-center justify-between p-3 rounded-xl border border-neutral-800 hover:border-neutral-700 bg-neutral-950/40 text-xs font-bold text-neutral-200 hover:text-white transition-colors`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,G.jsx)(Ie,{className:`w-4 h-4 text-amber-400`}),(0,G.jsx)(`span`,{children:`Reset Progress to Stop 1`})]}),(0,G.jsx)(`span`,{className:`text-[10px] text-neutral-400`,children:`Keep stops`})]}),(0,G.jsxs)(`button`,{onClick:()=>{confirm(`Clear current route and load fresh GPX?`)&&(s(),r())},className:`w-full flex items-center justify-between p-3 rounded-xl border border-red-900/60 hover:border-red-800 bg-red-950/20 text-xs font-bold text-red-300 hover:text-red-200 transition-colors`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,G.jsx)(Ge,{className:`w-4 h-4 text-red-400`}),(0,G.jsx)(`span`,{children:`Clear Loaded Route`})]}),(0,G.jsx)(`span`,{className:`text-[10px] text-red-400/80`,children:`Delete`})]})]})]}),(0,G.jsx)(`div`,{className:`px-6 py-4 border-t border-neutral-800 flex justify-end bg-neutral-950/40`,children:(0,G.jsx)(`button`,{onClick:r,className:`px-5 py-2 text-xs font-bold rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black transition-colors`,children:`Done`})})]})}):null,it=({stops:e,routeName:t,isDark:n,onRestart:r,onJumpToStop:i,onLoadNewRoute:a})=>{let o=e.filter(e=>e.status===`completed`).length,s=e.map((e,t)=>({stop:e,index:t})).filter(({stop:e})=>e.status===`skipped`);return(0,G.jsxs)(`div`,{className:`flex flex-col h-full justify-between p-4 max-w-lg mx-auto w-full text-center`,children:[(0,G.jsxs)(`div`,{className:`my-auto space-y-5`,children:[(0,G.jsx)(`div`,{className:`w-20 h-20 mx-auto rounded-3xl bg-emerald-500/20 border-2 border-emerald-500 flex items-center justify-center text-emerald-400 shadow-xl shadow-emerald-950/40`,children:(0,G.jsx)(me,{className:`w-10 h-10 stroke-[2.5]`})}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`span`,{className:`text-xs font-bold tracking-widest uppercase text-emerald-400`,children:`Route Complete`}),(0,G.jsx)(`h1`,{className:`text-3xl font-black mt-1 text-white`,children:`All Customers Processed`}),(0,G.jsx)(`p`,{className:`text-xs text-neutral-400 mt-1`,children:t})]}),(0,G.jsxs)(`div`,{className:`grid grid-cols-2 gap-3 max-w-xs mx-auto`,children:[(0,G.jsxs)(`div`,{className:`p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-center`,children:[(0,G.jsx)(`span`,{className:`text-[11px] font-bold uppercase tracking-wider text-neutral-400 block`,children:`Completed`}),(0,G.jsx)(`span`,{className:`text-2xl font-black text-emerald-400 mt-0.5 block font-mono`,children:o})]}),(0,G.jsxs)(`div`,{className:`p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-center`,children:[(0,G.jsx)(`span`,{className:`text-[11px] font-bold uppercase tracking-wider text-neutral-400 block`,children:`Skipped`}),(0,G.jsx)(`span`,{className:`text-2xl font-black text-amber-400 mt-0.5 block font-mono`,children:s.length})]})]}),s.length>0?(0,G.jsxs)(`div`,{className:`text-left bg-neutral-950 rounded-2xl border border-neutral-800 p-4 max-h-56 overflow-y-auto space-y-2`,children:[(0,G.jsxs)(`div`,{className:`flex items-center justify-between text-xs font-bold text-amber-400 border-b border-neutral-800 pb-2`,children:[(0,G.jsxs)(`span`,{className:`flex items-center gap-1.5`,children:[(0,G.jsx)(Be,{className:`w-3.5 h-3.5`}),`Skipped Customers (`,s.length,`)`]}),(0,G.jsx)(`span`,{className:`text-[10px] text-neutral-400`,children:`Tap to Revisit`})]}),s.map(({stop:e,index:t})=>(0,G.jsxs)(`div`,{onClick:()=>i(t),className:`p-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 transition-colors cursor-pointer flex items-center justify-between text-xs`,children:[(0,G.jsxs)(`div`,{children:[(0,G.jsxs)(`span`,{className:`font-bold text-neutral-200`,children:[`#`,e.orderIndex,`. `,e.name]}),(0,G.jsx)(`p`,{className:`text-[11px] text-neutral-400 truncate max-w-[220px]`,children:e.fullAddress})]}),(0,G.jsx)(`span`,{className:`text-[10px] font-bold px-2 py-1 rounded bg-amber-950 text-amber-300 border border-amber-800`,children:`Re-visit`})]},e.id))]}):(0,G.jsx)(`div`,{className:`p-3 rounded-2xl bg-emerald-950/40 border border-emerald-800/60 text-xs text-emerald-300`,children:`★ Perfect run! Zero skipped customers.`})]}),(0,G.jsxs)(`div`,{className:`space-y-2.5 pt-4`,children:[(0,G.jsxs)(`button`,{onClick:()=>{let n=E(e,t),r=new Blob([n],{type:`application/gpx+xml`}),i=URL.createObjectURL(r),a=document.createElement(`a`);a.href=i,a.download=`${t.replace(/\s+/g,`_`)}_summary.gpx`,a.click(),URL.revokeObjectURL(i)},className:`w-full h-12 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs flex items-center justify-center gap-2 border border-neutral-700 transition-colors`,children:[(0,G.jsx)(Se,{className:`w-4 h-4 text-emerald-400`}),(0,G.jsx)(`span`,{children:`Export Final GPX Route`})]}),(0,G.jsxs)(`div`,{className:`grid grid-cols-2 gap-2`,children:[(0,G.jsxs)(`button`,{onClick:r,className:`h-12 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-200 font-bold text-xs flex items-center justify-center gap-2 border border-neutral-800 transition-colors`,children:[(0,G.jsx)(Ie,{className:`w-4 h-4 text-amber-400`}),(0,G.jsx)(`span`,{children:`Restart Route`})]}),(0,G.jsxs)(`button`,{onClick:a,className:`h-12 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors`,children:[(0,G.jsx)(He,{className:`w-4 h-4`}),(0,G.jsx)(`span`,{children:`Load New GPX`})]})]})]})]})},at=`# Step-by-Step Guide: Build & Install on Samsung Galaxy S26

This guide walks you through building and installing your **OsmAnd Route Companion** as a native Android app (\`.apk\`) using only your Samsung S26 phone—with **no computer**, **no programming experience**, and **no paid subscriptions**.

---

## Step 1: Export Source Code from Google AI Studio

1. In Google AI Studio Build on your Samsung S26 browser:
2. Look at the top menu bar or top-right controls.
3. Tap the **Export / Download** button (or tap the \`⋮\` menu > **Download ZIP**).
4. Save the \`.zip\` archive to your Samsung **My Files > Downloads** folder.
5. In **My Files**, tap on the downloaded \`.zip\` and tap **Extract** to unpack it into a folder.

---

## Step 2: Set Up Free Cloud Build on GitHub (Using Only Your Phone)

Because an Android compiler requires high memory and CPU, we use GitHub's free cloud builder. You do not write any code—GitHub does it automatically in the cloud:

1. Open Samsung Internet or Chrome on your S26 and go to **[github.com](https://github.com)**.
2. Sign up for a free account (takes 1 minute).
3. Tap the **+** icon in the top right > **New repository**.
4. Name the repository: \`route-companion\` and select **Private** (or Public). Tap **Create repository**.
5. On the next screen, tap **uploading an existing file**.
6. Select and upload the extracted files from your phone. Tap **Commit changes**.

---

## Step 3: Download Your APK

1. On your GitHub repository page on your phone, tap the **Actions** tab at the top.
2. You will see a workflow named **"Build Android APK"** running (indicated by a yellow spinning circle).
3. Wait approximately 2–3 minutes until it turns into a green checkmark (**Passed**).
4. Tap the completed run.
5. Scroll down to the **Artifacts** section at the bottom.
6. Tap **OsmAnd-Route-Companion-APK** to download the ZIP file (\`OsmAnd-Route-Companion-APK.zip\`) to your phone.

---

## Step 4: Install the APK on Samsung S26

### ⚠️ If you see "App not installed" even after clicking "Install anyway":
1. **Uninstall any previous version of Route Companion first**:
   - Android **strictly blocks** installing an updated APK over an existing one if the build signing certificates differ (every cloud build on GitHub generates a fresh build certificate).
   - Find the old "Route Companion" icon on your phone's home screen or apps list.
   - **Long-press the icon and tap "Uninstall"**.
2. **Check Samsung Auto Blocker (Samsung Galaxy One UI 6+)**:
   - Open your phone's **Settings** > **Security and privacy** > **Auto Blocker**.
   - Make sure **Auto Blocker** is temporarily toggled **OFF** (Samsung Auto Blocker silently blocks sideloaded APK installations).
3. **Extract the ZIP before installing**:
   - GitHub downloads the artifact as a \`.zip\` archive.
   - Open **My Files** > **Downloads**.
   - Tap \`OsmAnd-Route-Companion-APK.zip\` and tap **Extract**.
   - Inside the extracted folder, tap \`app-debug.apk\`.

### Installation steps:
1. Open the **My Files** app on your Samsung S26.
2. Go to **Downloads** and tap \`app-debug.apk\` (inside the extracted folder).
3. If prompted with *"For your security, your phone is not allowed to install unknown apps from this source"*:
   - Tap **Settings** in the dialog.
   - Switch the toggle next to **My Files** to **ON**.
   - Tap Back.
4. If Google Play Protect shows *"Blocked by Play Protect / Unrecognized app"*:
   - Tap **More details** > **Install anyway**.
5. Once installed, tap **Open**.
6. When prompted, grant **Location Permission** (*"While using the app"*).

---

## Step 5: How OsmAnd Communicates with the Native App

1. Open **OsmAnd** on your phone.
2. Open **Route Companion** in **Samsung Split-Screen Mode**:
   - Swipe up and hold to open Recent Apps.
   - Tap the Route Companion app icon at the top of its card.
   - Tap **Open in split screen view**.
   - Select **OsmAnd** as the second app.
3. In Route Companion, tap **Import GPX** and select your \`OsmAnd_Customer_Markers.gpx\`.
4. Tap **Open in OsmAnd** on customer #1.
5. Because the app is now running as a native Android app:
   - The native Kotlin component binds directly to OsmAnd's background service (\`net.osmand.aidl.OsmandAidlService\`).
   - Turn maneuver arrows, street names, and distances update directly in the top panel!
   - 50-ft automatic arrival advance marks the stop done as you arrive.
`,ot=`<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
    <title>OsmAnd Route Companion</title>
    <meta name="description" content="High-contrast Android customer route assistant for OsmAnd with sequential GPX stop guidance, address display, and one-tap stop skip." />
    <meta property="og:title" content="OsmAnd Route Companion" />
    <meta property="og:description" content="High-contrast Android customer route assistant for OsmAnd with sequential GPX stop guidance, address display, and one-tap stop skip." />
    <meta property="og:type" content="website" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="theme-color" content="#000000" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@500;700;800&display=swap" rel="stylesheet" />
  </head>
  <body class="bg-black text-white antialiased select-none">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"><\/script>
  </body>
</html>
`,st=`{
  "name": "react-example",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite --port=3000 --host=0.0.0.0",
    "build": "vite build && node scripts/package_zip.js",
    "preview": "vite preview",
    "clean": "rm -rf dist server.js",
    "lint": "tsc --noEmit"
  },
  "dependencies": {
    "@google/genai": "^2.4.0",
    "@tailwindcss/vite": "^4.3.3",
    "@types/jszip": "^3.4.1",
    "@types/leaflet": "^1.9.22",
    "@vitejs/plugin-react": "^6.1.1",
    "dotenv": "^17.2.3",
    "express": "^4.21.2",
    "jszip": "^3.10.2",
    "leaflet": "^1.9.4",
    "lucide-react": "^0.546.0",
    "motion": "^12.23.24",
    "react": "^19.0.1",
    "react-dom": "^19.0.1",
    "vite": "^8.3.0"
  },
  "devDependencies": {
    "@types/node": "^22.14.0",
    "@types/react": "^19.3.0",
    "@types/react-dom": "^19.3.0",
    "autoprefixer": "^10.4.21",
    "esbuild": "^0.25.0",
    "tailwindcss": "^4.3.3",
    "tsx": "^4.21.0",
    "typescript": "^7.0.2",
    "@types/express": "^4.17.21"
  }
}
`,ct=`/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { RouteData, RouteStop, AppSettings } from './types/route';
import { parseGPX, getStopHouseNumber } from './utils/gpxParser';
import { SAMPLE_GPX_ROUTES } from './utils/sampleRoutes';
import { triggerHaptic, announceStop, requestWakeLock, releaseWakeLock } from './utils/voiceAndHaptics';
import { StopCard } from './components/StopCard';
import { GpxImportModal } from './components/GpxImportModal';
import { RouteListDrawer } from './components/RouteListDrawer';
import { SettingsModal } from './components/SettingsModal';
import { RouteCompletionView } from './components/RouteCompletionView';
import { ExportModal } from './components/ExportModal';
import { useGpsTracker } from './utils/useGpsTracker';
import { 
  Compass, 
  Settings as SettingsIcon, 
  ListFilter, 
  Upload, 
  Download,
  RotateCcw,
  Sparkles,
  Sun,
  Moon,
  CheckCircle2
} from 'lucide-react';

const STORAGE_KEY = 'osmand_route_assistant_v1';
const SETTINGS_KEY = 'osmand_route_assistant_settings_v1';

const DEFAULT_SETTINGS: AppSettings = {
  theme: 'amoled-black',
  voiceAnnouncement: false,
  hapticFeedback: true,
  keepScreenAwake: true,
  extraLargeText: false,
  arrivalRadiusMeters: 50,
};

export default function App() {
  // Load settings from localStorage
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(SETTINGS_KEY);
      if (saved) {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
      }
    } catch (e) {
      // fallback
    }
    return DEFAULT_SETTINGS;
  });

  // Load route data from localStorage or initialize with sample route
  const [routeData, setRouteData] = useState<RouteData | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && Array.isArray(parsed.stops) && parsed.stops.length > 0) {
          // Sanitize/re-extract house numbers so any stale "002" stop sequence numbers
          // are restored to the genuine house number extracted from the customer's delivery address!
          const healedStops = parsed.stops.map((s: RouteStop, idx: number) => {
            const trueHouseNumber = getStopHouseNumber(s, idx);
            return {
              ...s,
              houseNumber: trueHouseNumber !== '—' ? trueHouseNumber : (s.houseNumber && !/^0+\\d+$/.test(s.houseNumber) ? s.houseNumber : ''),
            };
          });
          return {
            ...parsed,
            stops: healedStops,
          };
        }
      }
    } catch (e) {
      // fallback
    }

    // Default: initialize with first sample route so app is immediately usable
    try {
      const defaultPreset = SAMPLE_GPX_ROUTES[0];
      const parsed = parseGPX(defaultPreset.gpxXml, defaultPreset.title);
      return {
        id: defaultPreset.id,
        name: parsed.routeName,
        filename: \`\${defaultPreset.id}.gpx\`,
        stops: parsed.stops,
        currentIndex: 0,
        importedAt: Date.now(),
        lastUpdated: Date.now(),
      };
    } catch (e) {
      return null;
    }
  });

  // Modals & Drawers state
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [skipToast, setSkipToast] = useState<{ message: string; previousIndex: number } | null>(null);
  const [arrivalToast, setArrivalToast] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Direct Android file picker import handler
  const handleDirectFileImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const cleanFileName = file.name.replace(/\\.[^/.]+$/, '');
      const { stops, routeName } = parseGPX(text, cleanFileName);

      if (stops.length === 0) {
        throw new Error('No waypoints found in the selected GPX file.');
      }

      if (settings.hapticFeedback) triggerHaptic('complete');

      // Replace sample customers with the imported customers
      const newRoute: RouteData = {
        id: \`route-\${Date.now().toString(36)}\`,
        name: routeName || file.name,
        filename: file.name,
        stops: stops, // exact file order preserved
        currentIndex: 0,
        importedAt: Date.now(),
        lastUpdated: Date.now(),
      };

      setRouteData(newRoute);
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(newRoute));
      } catch (err) {
        console.error('Storage error', err);
      }

      setArrivalToast(\`Imported \${file.name} (\${stops.length} stops)\`);
      setTimeout(() => setArrivalToast(null), 4000);
    } catch (err: any) {
      setArrivalToast(err.message || 'Failed to read or parse GPX file.');
      setTimeout(() => setArrivalToast(null), 4000);
    } finally {
      if (e.target) {
        e.target.value = '';
      }
    }
  };

  // Sync route data to localStorage whenever it changes
  useEffect(() => {
    if (routeData) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(routeData));
      } catch (e) {
        console.error('Failed to save route to localStorage', e);
      }
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
  }, [routeData]);

  // Sync settings to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch (e) {
      console.error('Failed to save settings', e);
    }
  }, [settings]);

  // Handle Screen WakeLock
  useEffect(() => {
    if (settings.keepScreenAwake) {
      requestWakeLock();
    } else {
      releaseWakeLock();
    }

    return () => {
      releaseWakeLock();
    };
  }, [settings.keepScreenAwake]);

  // Voice announcement on customer stop change
  const isFirstMount = useRef(true);
  useEffect(() => {
    if (isFirstMount.current) {
      isFirstMount.current = false;
      return;
    }
    if (settings.voiceAnnouncement && routeData && routeData.stops[routeData.currentIndex]) {
      const current = routeData.stops[routeData.currentIndex];
      const houseNumber = getStopHouseNumber(current, routeData.currentIndex);
      announceStop(current.name, houseNumber !== '—' ? houseNumber : '', current.streetName);
    }
  }, [routeData?.currentIndex, settings.voiceAnnouncement]);

  const isDark = settings.theme === 'amoled-black';

  // Automatic GPS Arrival Advance (within ~50 feet / 15m)
  const handleAutoArrive = () => {
    if (!routeData) return;
    if (settings.hapticFeedback) triggerHaptic('complete');

    const arrivedStop = routeData.stops[routeData.currentIndex];

    setRouteData((prev) => {
      if (!prev) return null;
      const nextIndex = prev.currentIndex + 1;
      const updatedStops = [...prev.stops];

      // Mark current stop as completed
      if (updatedStops[prev.currentIndex]) {
        updatedStops[prev.currentIndex] = {
          ...updatedStops[prev.currentIndex],
          status: 'completed',
          statusTimestamp: Date.now(),
        };
      }

      return {
        ...prev,
        stops: updatedStops,
        currentIndex: nextIndex,
        lastUpdated: Date.now(),
      };
    });

    if (arrivedStop) {
      setArrivalToast(\`Auto-Arrived: #\${arrivedStop.orderIndex} \${arrivedStop.name}\`);
      setTimeout(() => {
        setArrivalToast(null);
      }, 3500);
    }
  };

  // Skip Customer Immediately
  const handleSkipCustomer = () => {
    if (!routeData) return;
    if (settings.hapticFeedback) triggerHaptic('skip');

    const skippedStop = routeData.stops[routeData.currentIndex];
    const prevIdx = routeData.currentIndex;

    setRouteData((prev) => {
      if (!prev) return null;
      const nextIndex = prev.currentIndex + 1;
      const updatedStops = [...prev.stops];

      if (updatedStops[prev.currentIndex]) {
        updatedStops[prev.currentIndex] = {
          ...updatedStops[prev.currentIndex],
          status: 'skipped',
          statusTimestamp: Date.now(),
        };
      }

      return {
        ...prev,
        stops: updatedStops,
        currentIndex: nextIndex,
        lastUpdated: Date.now(),
      };
    });

    // Show temporary Undo toast
    if (skippedStop) {
      setSkipToast({
        message: \`Skipped: #\${skippedStop.orderIndex} \${skippedStop.name}\`,
        previousIndex: prevIdx,
      });
      setTimeout(() => {
        setSkipToast(null);
      }, 4000);
    }
  };

  // Return to Previous Customer
  const handlePreviousCustomer = () => {
    if (!routeData || routeData.currentIndex <= 0) return;
    if (settings.hapticFeedback) triggerHaptic('undo');

    setRouteData((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        currentIndex: prev.currentIndex - 1,
        lastUpdated: Date.now(),
      };
    });
  };

  // Undo accidental skip from toast
  const handleUndoSkip = () => {
    if (!skipToast || !routeData) return;
    if (settings.hapticFeedback) triggerHaptic('undo');

    const restoreIndex = skipToast.previousIndex;
    setRouteData((prev) => {
      if (!prev) return null;
      const updatedStops = [...prev.stops];
      if (updatedStops[restoreIndex]) {
        updatedStops[restoreIndex] = {
          ...updatedStops[restoreIndex],
          status: 'pending',
        };
      }
      return {
        ...prev,
        stops: updatedStops,
        currentIndex: restoreIndex,
        lastUpdated: Date.now(),
      };
    });
    setSkipToast(null);
  };

  // Jump to specific stop from list
  const handleJumpToStop = (index: number) => {
    if (!routeData) return;
    if (settings.hapticFeedback) triggerHaptic('tap');

    setRouteData((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        currentIndex: Math.max(0, Math.min(index, prev.stops.length)),
        lastUpdated: Date.now(),
      };
    });
  };

  // Reset route progress to Stop 1
  const handleResetProgress = () => {
    if (!routeData) return;
    if (settings.hapticFeedback) triggerHaptic('tap');

    setRouteData((prev) => {
      if (!prev) return null;
      const resetStops = prev.stops.map((s) => ({
        ...s,
        status: 'pending' as const,
        statusTimestamp: undefined,
      }));
      return {
        ...prev,
        stops: resetStops,
        currentIndex: 0,
        lastUpdated: Date.now(),
      };
    });
  };

  // Handle successful import of new GPX
  const handleImportSuccess = (stops: RouteStop[], routeName: string, filename: string) => {
    if (settings.hapticFeedback) triggerHaptic('tap');
    const newRoute: RouteData = {
      id: \`route-\${Date.now().toString(36)}\`,
      name: routeName,
      filename,
      stops,
      currentIndex: 0,
      importedAt: Date.now(),
      lastUpdated: Date.now(),
    };
    setRouteData(newRoute);
  };

  // Clear current route
  const handleClearRoute = () => {
    setRouteData(null);
  };

  const currentStop = routeData && routeData.currentIndex < routeData.stops.length
    ? routeData.stops[routeData.currentIndex]
    : null;

  const previousStop = routeData && routeData.currentIndex > 0
    ? routeData.stops[routeData.currentIndex - 1]
    : null;

  const nextStop = routeData && routeData.currentIndex < routeData.stops.length - 1
    ? routeData.stops[routeData.currentIndex + 1]
    : null;

  // Real GPS hardware tracking & configurable arrival engine with passing detection
  const {
    location: userLocation,
    gpsStatus,
    gpsErrorMsg,
    distanceToCurrentFeet,
    isWithinGeofence,
    isSharedLocationWithPrevious,
    isSharedLocationWithNext,
    autoArrivalStatus,
    arrivalRadiusMeters,
    isPassedWithoutCompletion,
    simulateApproachAndPass,
    simulateApproachAndArrive,
    isSimulatingGps,
    stopGpsSimulation,
  } = useGpsTracker(
    currentStop, 
    previousStop, 
    nextStop, 
    handleAutoArrive, 
    settings.arrivalRadiusMeters || 50
  );

  const isRouteFinished = routeData && routeData.currentIndex >= routeData.stops.length;

  const completedCount = routeData ? routeData.stops.filter((s) => s.status === 'completed').length : 0;
  const skippedCount = routeData ? routeData.stops.filter((s) => s.status === 'skipped').length : 0;

  return (
    <div 
      className={\`h-dvh max-h-dvh w-full overflow-hidden flex flex-col font-sans transition-colors duration-150 \${
        isDark 
          ? 'bg-black text-white' 
          : 'bg-white text-black'
      }\`}
    >
      {/* Top Application Bar - Designed for Samsung One UI status ergonomics */}
      <header 
        className={\`w-full shrink-0 border-b px-3 py-1.5 flex items-center justify-between z-20 \${
          isDark 
            ? 'bg-neutral-950/95 border-neutral-800' 
            : 'bg-neutral-50/95 border-neutral-200'
        }\`}
      >
        {/* Brand & OsmAnd Companion Tag */}
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-7 h-7 rounded-lg bg-orange-600 flex items-center justify-center text-white shrink-0 shadow-sm">
            <Compass className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="font-black text-xs sm:text-sm tracking-tight truncate">
                OsmAnd Companion
              </span>
            </div>
            {routeData && (
              <p className="text-[10px] text-neutral-400 truncate">
                {routeData.name} ({routeData.stops.length} stops)
              </p>
            )}
          </div>
        </div>

        {/* Top Actions: Theme, Stops List, Settings, Import */}
        <div className="flex items-center gap-1 shrink-0">
          {/* Quick theme toggle */}
          <button
            onClick={() => setSettings((s) => ({ ...s, theme: s.theme === 'amoled-black' ? 'high-contrast-day' : 'amoled-black' }))}
            className={\`p-1.5 rounded-lg transition-colors \${
              isDark ? 'text-neutral-300 hover:text-white hover:bg-neutral-900' : 'text-neutral-700 hover:text-black hover:bg-neutral-200'
            }\`}
            title="Toggle AMOLED Black / Daylight High-Contrast"
          >
            {isDark ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-neutral-800" />}
          </button>

          {/* Hidden File Picker Input for Android File Picker */}
          <input
            ref={fileInputRef}
            type="file"
            onChange={handleDirectFileImport}
            className="hidden"
          />

          {/* Import GPX Button */}
          <button
            onClick={() => {
              if (settings.hapticFeedback) triggerHaptic('tap');
              setIsImportOpen(true);
            }}
            className={\`flex items-center gap-1 px-2.5 py-1 rounded-lg border text-[11px] font-bold transition-all active:scale-95 \${
              isDark 
                ? 'border-neutral-700 bg-neutral-900 text-neutral-200 hover:bg-neutral-800 hover:text-white' 
                : 'border-neutral-300 bg-neutral-100 text-neutral-800 hover:bg-neutral-200'
            }\`}
            title="Import GPX Customer Route"
          >
            <Upload className="w-3 h-3 text-emerald-400" />
            <span>GPX</span>
          </button>

          {/* Download Project Source ZIP Button */}
          <button
            onClick={() => setIsExportOpen(true)}
            className={\`flex items-center gap-1 px-2.5 py-1 rounded-lg border text-[11px] font-bold transition-all active:scale-95 \${
              isDark 
                ? 'border-blue-700/80 bg-blue-950/70 text-blue-300 hover:bg-blue-900 hover:text-white' 
                : 'border-blue-300 bg-blue-50 text-blue-800 hover:bg-blue-100'
            }\`}
            title="Download source code and Android APK wrapper ZIP"
          >
            <Download className="w-3 h-3 text-blue-400" />
            <span>ZIP</span>
          </button>

          {/* Stops Drawer Toggle */}
          {routeData && (
            <button
              onClick={() => setIsDrawerOpen(true)}
              className={\`p-1.5 rounded-lg border transition-colors \${
                isDark 
                  ? 'border-neutral-700 bg-neutral-900 text-neutral-200 hover:bg-neutral-800' 
                  : 'border-neutral-300 bg-neutral-100 text-neutral-800 hover:bg-neutral-200'
              }\`}
              title="View all stops list"
            >
              <ListFilter className="w-3.5 h-3.5 text-emerald-400" />
            </button>
          )}

          {/* Settings Button */}
          <button
            onClick={() => setIsSettingsOpen(true)}
            className={\`p-1.5 rounded-lg transition-colors \${
              isDark ? 'text-neutral-400 hover:text-white hover:bg-neutral-900' : 'text-neutral-600 hover:text-black hover:bg-neutral-200'
            }\`}
            title="Settings & Display options"
          >
            <SettingsIcon className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* Main Screen Container - Fitted mobile viewport without scrolling */}
      <main className="flex-1 w-full max-w-md mx-auto flex flex-col px-2.5 py-1 sm:px-3 sm:py-1.5 relative overflow-hidden">
        {/* Auto-Arrival Banner (Confirms automatic arrival without requiring manual input) */}
        {arrivalToast && (
          <div className="absolute top-4 left-4 right-4 z-30 animate-in slide-in-from-top duration-200">
            <div className="bg-emerald-500 text-black px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2 border-2 border-emerald-300">
              <CheckCircle2 className="w-4 h-4 stroke-[3] shrink-0" />
              <span className="text-xs font-black truncate">
                {arrivalToast}
              </span>
            </div>
          </div>
        )}

        {/* Undo Toast when a customer was skipped */}
        {skipToast && (
          <div className="absolute top-4 left-4 right-4 z-30 animate-in slide-in-from-top duration-200">
            <div className="bg-amber-400 text-black px-4 py-2.5 rounded-2xl shadow-2xl flex items-center justify-between border-2 border-amber-300">
              <span className="text-xs font-bold truncate max-w-[240px]">
                {skipToast.message}
              </span>
              <button
                onClick={handleUndoSkip}
                className="flex items-center gap-1 px-2.5 py-1 bg-black text-amber-300 rounded-lg text-xs font-black uppercase tracking-wider hover:bg-neutral-900 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Undo</span>
              </button>
            </div>
          </div>
        )}

        {/* Case 1: Route finished / all customers visited */}
        {isRouteFinished ? (
          <RouteCompletionView
            stops={routeData.stops}
            routeName={routeData.name}
            isDark={isDark}
            onRestart={handleResetProgress}
            onJumpToStop={handleJumpToStop}
            onLoadNewRoute={() => setIsImportOpen(true)}
          />
        ) : currentStop && routeData ? (
          /* Case 2: Active customer stop card */
          <StopCard
            stop={currentStop}
            previousStop={previousStop || undefined}
            nextStop={nextStop || undefined}
            userLocation={userLocation}
            gpsStatus={gpsStatus}
            gpsErrorMsg={gpsErrorMsg}
            distanceToCurrentFeet={distanceToCurrentFeet}
            isWithinGeofence={isWithinGeofence}
            isSharedLocationWithPrevious={isSharedLocationWithPrevious}
            isSharedLocationWithNext={isSharedLocationWithNext}
            autoArrivalStatus={autoArrivalStatus}
            currentIndex={routeData.currentIndex}
            totalStops={routeData.stops.length}
            completedCount={completedCount}
            skippedCount={skippedCount}
            settings={settings}
            onSkip={handleSkipCustomer}
            onPrevious={handlePreviousCustomer}
            onJumpToStopList={() => setIsDrawerOpen(true)}
            arrivalRadiusMeters={arrivalRadiusMeters}
            isPassedWithoutCompletion={isPassedWithoutCompletion}
            simulateApproachAndPass={simulateApproachAndPass}
            simulateApproachAndArrive={simulateApproachAndArrive}
            isSimulatingGps={isSimulatingGps}
            stopGpsSimulation={stopGpsSimulation}
          />
        ) : (
          /* Case 3: No route loaded */
          <div className="flex-1 flex flex-col items-center justify-center text-center p-6 space-y-4 my-auto">
            <div className="w-16 h-16 rounded-3xl bg-neutral-900 border border-neutral-800 flex items-center justify-center text-emerald-400">
              <Compass className="w-8 h-8" />
            </div>
            <div>
              <h2 className="text-xl font-black">No Active GPX Route</h2>
              <p className="text-xs text-neutral-400 mt-1 max-w-xs">
                Import a customer GPX file from OsmAnd or pick a built-in delivery route.
              </p>
            </div>
            <div className="space-y-2 w-full max-w-xs">
              <button
                onClick={() => setIsImportOpen(true)}
                className="w-full py-3.5 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-950/40"
              >
                <Upload className="w-4 h-4" />
                <span>Import GPX File</span>
              </button>
              <button
                onClick={() => {
                  const defaultPreset = SAMPLE_GPX_ROUTES[0];
                  const parsed = parseGPX(defaultPreset.gpxXml, defaultPreset.title);
                  handleImportSuccess(parsed.stops, parsed.routeName, \`\${defaultPreset.id}.gpx\`);
                }}
                className="w-full py-3 px-4 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-200 font-bold text-xs flex items-center justify-center gap-2 transition-all"
              >
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Load Sample Route (20 Stops)</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Import Modal */}
      <GpxImportModal
        isOpen={isImportOpen}
        isDark={isDark}
        onClose={() => setIsImportOpen(false)}
        onImportSuccess={handleImportSuccess}
      />

      {/* Route List Drawer */}
      {routeData && (
        <RouteListDrawer
          isOpen={isDrawerOpen}
          isDark={isDark}
          stops={routeData.stops}
          currentIndex={routeData.currentIndex}
          routeName={routeData.name}
          onClose={() => setIsDrawerOpen(false)}
          onSelectStop={handleJumpToStop}
          onResetRoute={handleResetProgress}
        />
      )}

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        isDark={isDark}
        settings={settings}
        onClose={() => setIsSettingsOpen(false)}
        onUpdateSettings={(newSettings) => setSettings((s) => ({ ...s, ...newSettings }))}
        onOpenImport={() => setIsImportOpen(true)}
        onResetProgress={handleResetProgress}
        onClearRoute={handleClearRoute}
        onOpenExport={() => setIsExportOpen(true)}
      />

      {/* Export / APK Modal */}
      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        isDark={isDark}
      />
    </div>
  );
}
`,lt=`import React, { useState } from 'react';
import { 
  X, 
  Download, 
  CheckCircle2, 
  Smartphone, 
  ExternalLink, 
  FileArchive, 
  Sparkles,
  ArrowRight,
  ShieldCheck,
  HelpCircle
} from 'lucide-react';
import { downloadProjectZip } from '../utils/projectExporter';
import { triggerHaptic } from '../utils/voiceAndHaptics';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  isDark: boolean;
}

export function ExportModal({ isOpen, onClose, isDark }: ExportModalProps) {
  const [downloading, setDownloading] = useState(false);
  const [downloaded, setDownloaded] = useState(false);

  if (!isOpen) return null;

  const handleDownload = async () => {
    triggerHaptic('tap');
    setDownloading(true);
    try {
      await downloadProjectZip();
      setDownloaded(true);
      triggerHaptic('complete');
    } catch (err) {
      console.error('Download failed', err);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className={\`w-full max-w-lg rounded-t-3xl sm:rounded-3xl border shadow-2xl flex flex-col max-h-[92vh] overflow-hidden \${
          isDark 
            ? 'bg-neutral-950 border-neutral-800 text-white' 
            : 'bg-white border-neutral-200 text-black'
        }\`}
      >
        {/* Header */}
        <div className={\`p-4 border-b flex items-center justify-between shrink-0 \${
          isDark ? 'border-neutral-800 bg-neutral-900/60' : 'border-neutral-200 bg-neutral-50'
        }\`}>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shrink-0 shadow-md">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black tracking-tight">Export Source Code & APK Builder</h2>
              <p className="text-xs text-neutral-400">Step 1: Download code to your Samsung S26</p>
            </div>
          </div>
          <button
            onClick={() => {
              triggerHaptic('tap');
              onClose();
            }}
            className={\`p-2 rounded-xl transition-colors \${
              isDark ? 'hover:bg-neutral-800 text-neutral-400' : 'hover:bg-neutral-100 text-neutral-600'
            }\`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* Main Download Button */}
          <div className={\`p-4 rounded-2xl border \${
            isDark ? 'bg-neutral-900/90 border-blue-900/60' : 'bg-blue-50/70 border-blue-200'
          }\`}>
            <p className="text-xs font-semibold text-neutral-400 mb-2">
              Instant 1-Tap Download to your phone:
            </p>
            <button
              onClick={handleDownload}
              disabled={downloading}
              className={\`w-full py-4 px-4 rounded-2xl font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2.5 shadow-lg active:scale-95 transition-all \${
                downloaded
                  ? 'bg-emerald-500 hover:bg-emerald-600 text-black'
                  : 'bg-blue-600 hover:bg-blue-500 text-white'
              }\`}
            >
              {downloading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Packaging Zip File...</span>
                </>
              ) : downloaded ? (
                <>
                  <CheckCircle2 className="w-5 h-5 stroke-[2.5]" />
                  <span>Downloaded! Tap to Download Again</span>
                </>
              ) : (
                <>
                  <Download className="w-5 h-5" />
                  <span>Download Complete Project (.ZIP)</span>
                </>
              )}
            </button>

            {downloaded && (
              <div className="mt-3 p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-start gap-2 text-emerald-400 text-xs">
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
                <span>
                  <strong>Saved to your phone:</strong> Check your Samsung <strong>My Files &gt; Downloads</strong> folder for <code className="bg-black/40 px-1 py-0.5 rounded font-mono">OsmAnd_Route_Companion_Source.zip</code>.
                </span>
              </div>
            )}
          </div>

          {/* Included Files info */}
          <div className={\`p-3.5 rounded-2xl border text-xs space-y-2 \${
            isDark ? 'bg-neutral-900 border-neutral-800' : 'bg-neutral-100 border-neutral-200'
          }\`}>
            <div className="flex items-center gap-2 font-bold text-neutral-300">
              <FileArchive className="w-4 h-4 text-blue-400" />
              <span>What is included in this .ZIP file:</span>
            </div>
            <ul className="space-y-1.5 text-neutral-400 pl-6 list-disc">
              <li><strong>Native Android Kotlin wrapper:</strong> Binds to OsmAnd AIDL background service</li>
              <li><strong>Full React App:</strong> Your customer cards, yellow house number, 50ft arrival, and GPX parser</li>
              <li><strong>Automated Cloud Builder:</strong> Preconfigured GitHub Action to compile the APK free with zero setup</li>
            </ul>
          </div>

          {/* Next Steps: Step 2 & Step 3 */}
          <div className="space-y-3">
            <h3 className="text-xs font-black uppercase tracking-wider text-neutral-400">
              What to do next (Takes ~3 minutes on your phone):
            </h3>

            {/* Step 2 card */}
            <div className={\`p-3.5 rounded-2xl border flex items-start gap-3 \${
              isDark ? 'bg-neutral-900/50 border-neutral-800' : 'bg-neutral-50 border-neutral-200'
            }\`}>
              <div className="w-6 h-6 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                2
              </div>
              <div className="text-xs space-y-1">
                <p className="font-bold">Upload to GitHub (Free cloud builder)</p>
                <p className="text-neutral-400">
                  Open <a href="https://github.com" target="_blank" rel="noreferrer" className="text-blue-400 underline font-semibold">github.com</a> on your Samsung S26, tap <strong>New repository</strong>, name it <code className="bg-neutral-800 px-1 py-0.5 rounded text-neutral-200">route-companion</code>, and tap <strong>Upload files</strong> to upload the zip files.
                </p>
              </div>
            </div>

            {/* Step 3 card */}
            <div className={\`p-3.5 rounded-2xl border flex items-start gap-3 \${
              isDark ? 'bg-neutral-900/50 border-neutral-800' : 'bg-neutral-50 border-neutral-200'
            }\`}>
              <div className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                3
              </div>
              <div className="text-xs space-y-1">
                <p className="font-bold">Download and Install your APK</p>
                <p className="text-neutral-400">
                  Tap the <strong>Actions</strong> tab in your repository. In 2 minutes, tap the completed build and download <code className="bg-neutral-800 px-1 py-0.5 rounded text-neutral-200">app-debug.apk</code> to your Samsung S26 to install.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className={\`p-4 border-t flex items-center justify-between shrink-0 \${
          isDark ? 'border-neutral-800 bg-neutral-950' : 'border-neutral-200 bg-white'
        }\`}>
          <div className="flex items-center gap-1.5 text-xs text-neutral-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>100% Free · No computer needed</span>
          </div>
          <button
            onClick={() => {
              triggerHaptic('tap');
              onClose();
            }}
            className={\`px-4 py-2 rounded-xl text-xs font-bold \${
              isDark ? 'bg-neutral-800 hover:bg-neutral-700 text-neutral-200' : 'bg-neutral-200 hover:bg-neutral-300 text-black'
            }\`}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
`,ut=`import React, { useState } from 'react';
import { parseGPX } from '../utils/gpxParser';
import { SAMPLE_GPX_ROUTES } from '../utils/sampleRoutes';
import { RouteStop } from '../types/route';
import { UploadCloud, FileCode, CheckCircle, AlertCircle, X, Download, Sparkles } from 'lucide-react';

interface GpxImportModalProps {
  isOpen: boolean;
  isDark: boolean;
  onClose: () => void;
  onImportSuccess: (stops: RouteStop[], routeName: string, filename: string) => void;
}

export const GpxImportModal: React.FC<GpxImportModalProps> = ({
  isOpen,
  isDark,
  onClose,
  onImportSuccess,
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'samples' | 'paste'>('upload');
  const [rawText, setRawText] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [previewStops, setPreviewStops] = useState<{ stops: RouteStop[]; routeName: string; filename: string } | null>(null);

  if (!isOpen) return null;

  const handleFileProcess = (file: File) => {
    setError(null);
    try {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const text = e.target?.result as string;
          if (!text || typeof text !== 'string') {
            throw new Error('File content is empty or unreadable.');
          }
          const cleanName = file.name.replace(/\\.[^/.]+$/, '');
          const result = parseGPX(text, cleanName);
          if (!result.stops || result.stops.length === 0) {
            throw new Error('No valid customer stops found in GPX file.');
          }
          setPreviewStops({
            stops: result.stops,
            routeName: result.routeName,
            filename: file.name,
          });
        } catch (err: any) {
          setError(err.message || 'Failed to parse GPX file.');
        }
      };
      reader.onerror = () => {
        setError('Error reading file from disk.');
      };
      reader.readAsText(file);
    } catch (err: any) {
      setError(err.message || 'Error processing file.');
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileProcess(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileProcess(e.target.files[0]);
    }
    if (e.target) {
      e.target.value = '';
    }
  };

  const handleParsePaste = () => {
    setError(null);
    try {
      if (!rawText.trim()) {
        setError('Please paste GPX XML content.');
        return;
      }
      const result = parseGPX(rawText, 'Pasted GPX Route');
      setPreviewStops({
        stops: result.stops,
        routeName: result.routeName,
        filename: 'pasted_route.gpx',
      });
    } catch (err: any) {
      setError(err.message || 'Invalid GPX content.');
    }
  };

  const handleLoadPreset = (preset: typeof SAMPLE_GPX_ROUTES[0]) => {
    setError(null);
    try {
      const result = parseGPX(preset.gpxXml, preset.title);
      setPreviewStops({
        stops: result.stops,
        routeName: result.routeName,
        filename: \`\${preset.id}.gpx\`,
      });
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleConfirmImport = () => {
    if (previewStops) {
      onImportSuccess(previewStops.stops, previewStops.routeName, previewStops.filename);
      onClose();
    }
  };

  const downloadSampleGpx = (preset: typeof SAMPLE_GPX_ROUTES[0]) => {
    const blob = new Blob([preset.gpxXml], { type: 'application/gpx+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = \`\${preset.id}.gpx\`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className={\`w-full max-w-lg rounded-3xl border shadow-2xl overflow-hidden flex flex-col max-h-[90vh] \${
          isDark ? 'bg-neutral-900 border-neutral-700 text-white' : 'bg-white border-neutral-300 text-black'
        }\`}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800">
          <div>
            <h2 className="text-lg font-black tracking-tight">Import Customer GPX Route</h2>
            <p className="text-xs text-neutral-400 mt-0.5">Exact customer waypoint sequence will be preserved</p>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-neutral-800 px-6 pt-3 gap-2 bg-neutral-950/40">
          <button
            onClick={() => { setActiveTab('samples'); setError(null); }}
            className={\`pb-2.5 px-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 \${
              activeTab === 'samples'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }\`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Sample Routes</span>
          </button>
          <button
            onClick={() => { setActiveTab('upload'); setError(null); }}
            className={\`pb-2.5 px-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 \${
              activeTab === 'upload'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }\`}
          >
            <UploadCloud className="w-3.5 h-3.5" />
            <span>Upload GPX File</span>
          </button>
          <button
            onClick={() => { setActiveTab('paste'); setError(null); }}
            className={\`pb-2.5 px-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 \${
              activeTab === 'paste'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }\`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Paste XML</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-red-950/80 border border-red-800 text-red-200 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
              <span>{error}</span>
            </div>
          )}

          {activeTab === 'samples' && (
            <div className="space-y-3">
              <p className="text-xs text-neutral-400">
                Instantly load ready-to-test customer routes, or download the GPX to import into OsmAnd:
              </p>
              {SAMPLE_GPX_ROUTES.map((preset) => (
                <div 
                  key={preset.id}
                  className={\`p-4 rounded-2xl border transition-all \${
                    previewStops?.filename === \`\${preset.id}.gpx\`
                      ? 'border-emerald-500 bg-emerald-950/20'
                      : isDark ? 'border-neutral-800 bg-neutral-950 hover:border-neutral-700' : 'border-neutral-200 bg-neutral-50 hover:border-neutral-300'
                  }\`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h3 className="font-bold text-sm text-neutral-100">{preset.title}</h3>
                      <p className="text-xs text-neutral-400 mt-1 leading-relaxed">{preset.description}</p>
                      <span className="inline-block mt-2 text-[11px] font-mono font-bold px-2 py-0.5 rounded bg-neutral-800 text-emerald-400">
                        {preset.stopCount} Sequenced Stops
                      </span>
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-neutral-800/80 flex items-center justify-between gap-2">
                    <button
                      onClick={() => handleLoadPreset(preset)}
                      className="px-3.5 py-1.5 text-xs font-bold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors"
                    >
                      Select Route
                    </button>
                    <button
                      onClick={() => downloadSampleGpx(preset)}
                      className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border border-neutral-700 text-neutral-300 hover:text-white hover:bg-neutral-800 transition-colors"
                      title="Download .gpx file to load into OsmAnd"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download GPX</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'upload' && (
            <div
              onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
              onDragLeave={() => setDragActive(false)}
              onDrop={handleDrop}
              className={\`border-2 border-dashed rounded-2xl p-8 text-center flex flex-col items-center justify-center transition-all \${
                dragActive 
                  ? 'border-emerald-400 bg-emerald-950/20' 
                  : isDark ? 'border-neutral-700 bg-neutral-950/60' : 'border-neutral-300 bg-neutral-50'
              }\`}
            >
              <UploadCloud className="w-10 h-10 text-emerald-400 mb-3" />
              <p className="font-bold text-sm mb-1">Drag and drop your GPX file here</p>
              <p className="text-xs text-neutral-400 mb-4">Supports OsmAnd waypoints, routepoints, and favorites (.gpx)</p>
              <label className="cursor-pointer px-4 py-2 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white transition-colors">
                Browse Files
                <input 
                  type="file" 
                  className="hidden" 
                  onChange={handleFileInput}
                />
              </label>
              <p className="text-[11px] text-neutral-400 mt-3 max-w-xs">
                💡 Tip: If Samsung shows &quot;No files&quot;, tap <span className="font-semibold text-neutral-200">Recent files</span> at the top, or switch to the <span className="font-semibold text-emerald-400">Paste GPX</span> tab!
              </p>
            </div>
          )}

          {activeTab === 'paste' && (
            <div className="space-y-3">
              <label className="block text-xs font-bold uppercase text-neutral-400">
                Paste GPX XML Code
              </label>
              <textarea
                value={rawText}
                onChange={(e) => setRawText(e.target.value)}
                placeholder="<?xml version='1.0' encoding='UTF-8'?>\\n<gpx version='1.1' ...>\\n  <wpt lat='...' lon='...'>\\n    <name>Customer Name</name>\\n    <desc>123 Main St</desc>\\n  </wpt>\\n</gpx>"
                rows={7}
                className="w-full rounded-xl p-3 text-xs font-mono bg-neutral-950 border border-neutral-700 text-neutral-200 focus:outline-none focus:border-emerald-400 resize-none"
              />
              <button
                onClick={handleParsePaste}
                className="w-full py-2.5 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white transition-colors"
              >
                Parse GPX Text
              </button>
            </div>
          )}

          {/* Preview of detected stops */}
          {previewStops && (
            <div className="p-4 rounded-2xl border border-emerald-500/50 bg-emerald-950/20 space-y-2">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                <CheckCircle className="w-4 h-4" />
                <span>Ready to load: {previewStops.routeName}</span>
              </div>
              <div className="text-xs text-neutral-300 space-y-1">
                <p>
                  Found <strong className="text-emerald-300">{previewStops.stops.length} stops</strong> in exact GPX order.
                </p>
                <p className="text-[11px] text-neutral-400">
                  Stop #1: <strong>{previewStops.stops[0]?.name}</strong> ({previewStops.stops[0]?.houseNumber ? \`#\${previewStops.stops[0].houseNumber} \` : ''}{previewStops.stops[0]?.streetName})
                </p>
                {previewStops.stops.length > 1 && (
                  <p className="text-[11px] text-neutral-400">
                    Final Stop #{previewStops.stops.length}: <strong>{previewStops.stops[previewStops.stops.length - 1]?.name}</strong>
                  </p>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-neutral-800 flex items-center justify-end gap-3 bg-neutral-950/40">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-xl border border-neutral-700 text-neutral-300 hover:bg-neutral-800 transition-colors"
          >
            Cancel
          </button>
          <button
            disabled={!previewStops}
            onClick={handleConfirmImport}
            className={\`px-5 py-2.5 text-xs font-extrabold rounded-xl transition-all \${
              previewStops
                ? 'bg-emerald-500 hover:bg-emerald-400 text-black shadow-lg shadow-emerald-950/50'
                : 'opacity-40 cursor-not-allowed bg-neutral-800 text-neutral-500'
            }\`}
          >
            Start Route with {previewStops?.stops.length || 0} Stops
          </button>
        </div>
      </div>
    </div>
  );
};
`,dt=`import React from 'react';
import { 
  CornerUpRight, 
  CornerUpLeft, 
  ArrowUp, 
  RotateCcw, 
  Flag, 
  GitFork, 
  Compass, 
  CircleDot,
  ArrowUpRight,
  ArrowUpLeft
} from 'lucide-react';

interface ManeuverIconProps {
  type?: string;
  modifier?: string;
  className?: string;
}

export const ManeuverIcon: React.FC<ManeuverIconProps> = ({ 
  type = 'turn', 
  modifier = 'straight',
  className = 'w-10 h-10' 
}) => {
  const mod = (modifier || '').toLowerCase();
  const t = (type || '').toLowerCase();

  if (t === 'arrive') {
    return <Flag className={className} />;
  }

  if (t === 'roundabout' || t === 'rotary') {
    return <CircleDot className={className} />;
  }

  if (t === 'fork') {
    return <GitFork className={className} />;
  }

  if (mod.includes('uturn') || mod.includes('turnaround') || mod.includes('turn around') || t === 'turnaround') {
    return <RotateCcw className={className} />;
  }

  if (mod === 'sharp right') {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M12 21V11a4 4 0 0 1 4-4h5" />
        <polyline points="18 4 21 7 18 10" />
      </svg>
    );
  }

  if (mod === 'sharp left') {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M12 21V11a4 4 0 0 0-4-4H3" />
        <polyline points="6 4 3 7 6 10" />
      </svg>
    );
  }

  if (mod === 'slight right') {
    return <ArrowUpRight className={className} strokeWidth={2.75} />;
  }

  if (mod === 'slight left') {
    return <ArrowUpLeft className={className} strokeWidth={2.75} />;
  }

  if (mod === 'right') {
    return <CornerUpRight className={className} strokeWidth={2.75} />;
  }

  if (mod === 'left') {
    return <CornerUpLeft className={className} strokeWidth={2.75} />;
  }

  if (mod === 'straight' || t === 'continue' || t === 'depart') {
    return <ArrowUp className={className} strokeWidth={2.75} />;
  }

  return <Compass className={className} strokeWidth={2.5} />;
};
`,ft=`import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { GpsLocation } from '../utils/useGpsTracker';
import { Crosshair, Navigation } from 'lucide-react';

interface RoadMapViewProps {
  userLocation: GpsLocation | null;
  destination: {
    lat: number;
    lon: number;
    name: string;
    houseNumber?: string;
    address?: string;
  };
  routeCoordinates?: [number, number][]; // [lat, lon][]
  isDark?: boolean;
}

export const RoadMapView: React.FC<RoadMapViewProps> = ({
  userLocation,
  destination,
  routeCoordinates = [],
  isDark = true,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);
  const destMarkerRef = useRef<L.Marker | null>(null);
  const routePolylineRef = useRef<L.Polyline | null>(null);

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    const initialLat = userLocation?.lat || destination.lat;
    const initialLon = userLocation?.lon || destination.lon;

    const map = L.map(mapContainerRef.current, {
      center: [initialLat, initialLon],
      zoom: 16,
      zoomControl: false,
      attributionControl: false,
    });

    // High performance OpenStreetMap standard tiles
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      className: isDark ? 'dark-map-tiles' : '',
    }).addTo(map);

    mapInstanceRef.current = map;

    // Invalidate size to ensure crisp rendering on mobile screens
    setTimeout(() => {
      map.invalidateSize();
    }, 150);

    return () => {
      map.remove();
      mapInstanceRef.current = null;
      userMarkerRef.current = null;
      destMarkerRef.current = null;
      routePolylineRef.current = null;
    };
  }, []);

  // Update Route Polyline
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (routePolylineRef.current) {
      map.removeLayer(routePolylineRef.current);
      routePolylineRef.current = null;
    }

    if (routeCoordinates && routeCoordinates.length > 1) {
      const polyline = L.polyline(routeCoordinates, {
        color: '#f59e0b', // Amber road route
        weight: 5,
        opacity: 0.9,
        lineCap: 'round',
        lineJoin: 'round',
      }).addTo(map);

      routePolylineRef.current = polyline;

      // Fit bounds to route
      try {
        map.fitBounds(polyline.getBounds(), { padding: [25, 25], maxZoom: 17 });
      } catch (e) {
        // ignore bounds calculation error if identical points
      }
    }
  }, [routeCoordinates]);

  // Update Destination Marker
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !destination || isNaN(destination.lat) || isNaN(destination.lon)) return;

    if (destMarkerRef.current) {
      destMarkerRef.current.setLatLng([destination.lat, destination.lon]);
    } else {
      const destHtml = \`
        <div style="display:flex; flex-direction:column; align-items:center; transform: translate(-50%, -100%);">
          <div style="background:#fbbf24; color:#000; font-weight:900; font-family:monospace; font-size:12px; padding:3px 7px; border-radius:8px; border:2px solid #000; box-shadow:0 4px 8px rgba(0,0,0,0.5); white-space:nowrap;">
            \${destination.houseNumber || 'STOP'}
          </div>
          <div style="width:0; height:0; border-left:6px solid transparent; border-right:6px solid transparent; border-top:8px solid #fbbf24;"></div>
        </div>
      \`;

      const destIcon = L.divIcon({
        html: destHtml,
        className: 'custom-dest-pin',
        iconSize: [40, 40],
        iconAnchor: [20, 36],
      });

      destMarkerRef.current = L.marker([destination.lat, destination.lon], { icon: destIcon }).addTo(map);
    }
  }, [destination.lat, destination.lon, destination.houseNumber]);

  // Update Driver / User Location Marker
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (userLocation && !isNaN(userLocation.lat) && !isNaN(userLocation.lon)) {
      const userLatLng: L.LatLngExpression = [userLocation.lat, userLocation.lon];

      if (userMarkerRef.current) {
        userMarkerRef.current.setLatLng(userLatLng);
      } else {
        const userHtml = \`
          <div style="position:relative; width:22px; height:22px; display:flex; align-items:center; justify-content:center;">
            <div style="position:absolute; width:100%; height:100%; border-radius:50%; background:#38bdf8; opacity:0.4; animation:ping 1.5s cubic-bezier(0,0,0.2,1) infinite;"></div>
            <div style="width:14px; height:14px; border-radius:50%; background:#0284c7; border:2.5px solid #ffffff; box-shadow:0 0 8px rgba(2,132,199,0.9);"></div>
          </div>
        \`;

        const userIcon = L.divIcon({
          html: userHtml,
          className: 'custom-user-dot',
          iconSize: [22, 22],
          iconAnchor: [11, 11],
        });

        userMarkerRef.current = L.marker(userLatLng, { icon: userIcon, zIndexOffset: 1000 }).addTo(map);
      }
    } else if (userMarkerRef.current) {
      map.removeLayer(userMarkerRef.current);
      userMarkerRef.current = null;
    }
  }, [userLocation?.lat, userLocation?.lon]);

  // Recenter handler
  const handleRecenter = () => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (userLocation && !isNaN(userLocation.lat) && !isNaN(userLocation.lon)) {
      map.setView([userLocation.lat, userLocation.lon], 17, { animate: true });
    } else if (destination && !isNaN(destination.lat) && !isNaN(destination.lon)) {
      map.setView([destination.lat, destination.lon], 17, { animate: true });
    }
  };

  const handleFitRoute = () => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (routePolylineRef.current) {
      map.fitBounds(routePolylineRef.current.getBounds(), { padding: [25, 25], maxZoom: 17 });
    } else if (userLocation && destination) {
      const bounds = L.latLngBounds(
        [userLocation.lat, userLocation.lon],
        [destination.lat, destination.lon]
      );
      map.fitBounds(bounds, { padding: [30, 30], maxZoom: 17 });
    }
  };

  return (
    <div className="relative w-full h-full min-h-[170px] max-h-[260px] rounded-2xl overflow-hidden border border-neutral-800 bg-neutral-950 shadow-inner">
      <div ref={mapContainerRef} className="w-full h-full" />

      {/* Map Action Buttons */}
      <div className="absolute bottom-2.5 right-2.5 z-[1000] flex flex-col gap-1.5">
        <button
          onClick={handleRecenter}
          className="p-2 bg-neutral-900/90 hover:bg-neutral-800 text-amber-400 rounded-xl border border-neutral-700 shadow-lg backdrop-blur-sm transition-transform active:scale-90"
          title="Center on current location"
        >
          <Navigation className="w-4 h-4" />
        </button>
        <button
          onClick={handleFitRoute}
          className="p-2 bg-neutral-900/90 hover:bg-neutral-800 text-neutral-300 rounded-xl border border-neutral-700 shadow-lg backdrop-blur-sm transition-transform active:scale-90"
          title="Fit full route to customer"
        >
          <Crosshair className="w-4 h-4" />
        </button>
      </div>

      {/* Attribution overlay badge */}
      <div className="absolute bottom-1 left-2 z-[1000] pointer-events-none text-[9px] font-mono text-neutral-400/80 bg-black/60 px-1.5 py-0.5 rounded">
        © OpenStreetMap
      </div>
    </div>
  );
};
`,pt=`import React from 'react';
import { RouteStop } from '../types/route';
import { CheckCircle2, SkipForward, RotateCcw, Download, Sparkles, Navigation } from 'lucide-react';
import { exportToGPX } from '../utils/gpxParser';

interface RouteCompletionViewProps {
  stops: RouteStop[];
  routeName: string;
  isDark: boolean;
  onRestart: () => void;
  onJumpToStop: (index: number) => void;
  onLoadNewRoute: () => void;
}

export const RouteCompletionView: React.FC<RouteCompletionViewProps> = ({
  stops,
  routeName,
  isDark,
  onRestart,
  onJumpToStop,
  onLoadNewRoute,
}) => {
  const completedCount = stops.filter((s) => s.status === 'completed').length;
  const skippedStops = stops
    .map((stop, index) => ({ stop, index }))
    .filter(({ stop }) => stop.status === 'skipped');

  const handleDownload = () => {
    const xml = exportToGPX(stops, routeName);
    const blob = new Blob([xml], { type: 'application/gpx+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = \`\${routeName.replace(/\\s+/g, '_')}_summary.gpx\`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col h-full justify-between p-4 max-w-lg mx-auto w-full text-center">
      <div className="my-auto space-y-5">
        {/* Celebration Trophy / Ring */}
        <div className="w-20 h-20 mx-auto rounded-3xl bg-emerald-500/20 border-2 border-emerald-500 flex items-center justify-center text-emerald-400 shadow-xl shadow-emerald-950/40">
          <CheckCircle2 className="w-10 h-10 stroke-[2.5]" />
        </div>

        <div>
          <span className="text-xs font-bold tracking-widest uppercase text-emerald-400">
            Route Complete
          </span>
          <h1 className="text-3xl font-black mt-1 text-white">
            All Customers Processed
          </h1>
          <p className="text-xs text-neutral-400 mt-1">
            {routeName}
          </p>
        </div>

        {/* Metric Badges */}
        <div className="grid grid-cols-2 gap-3 max-w-xs mx-auto">
          <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-center">
            <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 block">
              Completed
            </span>
            <span className="text-2xl font-black text-emerald-400 mt-0.5 block font-mono">
              {completedCount}
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-center">
            <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 block">
              Skipped
            </span>
            <span className="text-2xl font-black text-amber-400 mt-0.5 block font-mono">
              {skippedStops.length}
            </span>
          </div>
        </div>

        {/* Skipped Stops Review List */}
        {skippedStops.length > 0 ? (
          <div className="text-left bg-neutral-950 rounded-2xl border border-neutral-800 p-4 max-h-56 overflow-y-auto space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-amber-400 border-b border-neutral-800 pb-2">
              <span className="flex items-center gap-1.5">
                <SkipForward className="w-3.5 h-3.5" />
                Skipped Customers ({skippedStops.length})
              </span>
              <span className="text-[10px] text-neutral-400">Tap to Revisit</span>
            </div>

            {skippedStops.map(({ stop, index }) => (
              <div
                key={stop.id}
                onClick={() => onJumpToStop(index)}
                className="p-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 transition-colors cursor-pointer flex items-center justify-between text-xs"
              >
                <div>
                  <span className="font-bold text-neutral-200">
                    #{stop.orderIndex}. {stop.name}
                  </span>
                  <p className="text-[11px] text-neutral-400 truncate max-w-[220px]">
                    {stop.fullAddress}
                  </p>
                </div>
                <span className="text-[10px] font-bold px-2 py-1 rounded bg-amber-950 text-amber-300 border border-amber-800">
                  Re-visit
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-800/60 text-xs text-emerald-300">
            ★ Perfect run! Zero skipped customers.
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="space-y-2.5 pt-4">
        <button
          onClick={handleDownload}
          className="w-full h-12 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs flex items-center justify-center gap-2 border border-neutral-700 transition-colors"
        >
          <Download className="w-4 h-4 text-emerald-400" />
          <span>Export Final GPX Route</span>
        </button>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={onRestart}
            className="h-12 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-200 font-bold text-xs flex items-center justify-center gap-2 border border-neutral-800 transition-colors"
          >
            <RotateCcw className="w-4 h-4 text-amber-400" />
            <span>Restart Route</span>
          </button>

          <button
            onClick={onLoadNewRoute}
            className="h-12 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors"
          >
            <Sparkles className="w-4 h-4" />
            <span>Load New GPX</span>
          </button>
        </div>
      </div>
    </div>
  );
};
`,mt=`import React, { useState } from 'react';
import { RouteStop } from '../types/route';
import { exportToGPX, getStopHouseNumber } from '../utils/gpxParser';
import { 
  X, 
  Search, 
  CheckCircle, 
  SkipForward, 
  Clock, 
  Download, 
  Navigation,
  ArrowRight,
  RotateCcw
} from 'lucide-react';

interface RouteListDrawerProps {
  isOpen: boolean;
  isDark: boolean;
  stops: RouteStop[];
  currentIndex: number;
  routeName: string;
  onClose: () => void;
  onSelectStop: (index: number) => void;
  onResetRoute: () => void;
}

export const RouteListDrawer: React.FC<RouteListDrawerProps> = ({
  isOpen,
  isDark,
  stops,
  currentIndex,
  routeName,
  onClose,
  onSelectStop,
  onResetRoute,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  if (!isOpen) return null;

  const filteredStops = stops
    .map((stop, originalIndex) => ({ stop, originalIndex }))
    .filter(({ stop, originalIndex }) => {
      const q = searchTerm.toLowerCase();
      const hNum = getStopHouseNumber(stop, originalIndex);
      return (
        stop.name.toLowerCase().includes(q) ||
        stop.fullAddress.toLowerCase().includes(q) ||
        (hNum !== '—' && hNum.toLowerCase().includes(q)) ||
        String(stop.orderIndex).includes(q)
      );
    });

  const handleDownloadGpx = () => {
    const xml = exportToGPX(stops, routeName);
    const blob = new Blob([xml], { type: 'application/gpx+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = \`\${routeName.replace(/\\s+/g, '_')}_updated.gpx\`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className={\`w-full max-w-md h-full flex flex-col shadow-2xl border-l \${
          isDark ? 'bg-neutral-950 border-neutral-800 text-white' : 'bg-white border-neutral-300 text-black'
        }\`}
      >
        {/* Header */}
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
          <div>
            <h2 className="font-black text-base tracking-tight">Customer Sequence</h2>
            <p className="text-xs text-neutral-400">
              {stops.length} Total Waypoints · Preserved Order
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-3 border-b border-neutral-800 bg-neutral-900/60">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search customer, house #, or street..."
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-100 placeholder:text-neutral-500 focus:outline-none focus:border-emerald-400"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white text-xs"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Stop Items List */}
        <div className="flex-1 overflow-y-auto divide-y divide-neutral-800/60 p-2">
          {filteredStops.length === 0 ? (
            <div className="text-center py-12 text-neutral-400 text-xs">
              No customers found matching &quot;{searchTerm}&quot;
            </div>
          ) : (
            filteredStops.map(({ stop, originalIndex }) => {
              const isCurrent = originalIndex === currentIndex;
              return (
                <div
                  key={stop.id}
                  onClick={() => {
                    onSelectStop(originalIndex);
                    onClose();
                  }}
                  className={\`p-3 rounded-xl transition-all cursor-pointer flex items-center gap-3 my-1 \${
                    isCurrent
                      ? 'bg-emerald-950/40 border-2 border-emerald-500/80 shadow-md'
                      : isDark
                        ? 'hover:bg-neutral-900/80 border border-transparent'
                        : 'hover:bg-neutral-100 border border-transparent'
                  }\`}
                >
                  {/* Order Number Badge */}
                  <div 
                    className={\`w-9 h-9 rounded-xl flex items-center justify-center font-mono font-bold text-xs shrink-0 \${
                      isCurrent
                        ? 'bg-emerald-500 text-black shadow-md'
                        : stop.status === 'completed'
                          ? 'bg-neutral-800 text-emerald-400 border border-emerald-800/50'
                          : stop.status === 'skipped'
                            ? 'bg-amber-950 text-amber-400 border border-amber-800/50'
                            : 'bg-neutral-900 text-neutral-300 border border-neutral-800'
                    }\`}
                  >
                    #{stop.orderIndex}
                  </div>

                  {/* Stop Details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={\`font-bold text-sm truncate \${isCurrent ? 'text-emerald-300' : 'text-neutral-100'}\`}>
                        {stop.name}
                      </span>
                      {(() => {
                        const hNum = getStopHouseNumber(stop, originalIndex);
                        return hNum !== '—' ? (
                          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-neutral-800 text-amber-300 border border-neutral-700">
                            #{hNum}
                          </span>
                        ) : null;
                      })()}
                    </div>
                    <p className="text-xs text-neutral-400 truncate mt-0.5">
                      {stop.fullAddress}
                    </p>
                  </div>

                  {/* Status Indicator Icon */}
                  <div className="shrink-0 flex items-center gap-1.5">
                    {stop.status === 'completed' && (
                      <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400">
                        <CheckCircle className="w-4 h-4" />
                      </span>
                    )}
                    {stop.status === 'skipped' && (
                      <span className="flex items-center gap-1 text-[11px] font-semibold text-amber-400">
                        <SkipForward className="w-4 h-4" />
                      </span>
                    )}
                    {stop.status === 'pending' && !isCurrent && (
                      <span className="text-[11px] text-neutral-500">
                        <Clock className="w-3.5 h-3.5" />
                      </span>
                    )}
                    {isCurrent && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-500 text-black tracking-wider">
                        Active
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer actions */}
        <div className="p-3 border-t border-neutral-800 bg-neutral-900/60 flex items-center justify-between gap-2">
          <button
            onClick={onResetRoute}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset to Stop 1</span>
          </button>

          <button
            onClick={handleDownloadGpx}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export GPX</span>
          </button>
        </div>
      </div>
    </div>
  );
};
`,ht=`import React from 'react';
import { AppSettings } from '../types/route';
import { X, Moon, Sun, Volume2, Smartphone, Eye, Sparkles, Trash2, RotateCcw, FolderOpen } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  isDark: boolean;
  settings: AppSettings;
  onClose: () => void;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  onOpenImport: () => void;
  onResetProgress: () => void;
  onClearRoute: () => void;
  onOpenExport?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  isDark,
  settings,
  onClose,
  onUpdateSettings,
  onOpenImport,
  onResetProgress,
  onClearRoute,
  onOpenExport,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className={\`w-full max-w-md rounded-3xl border shadow-2xl overflow-hidden flex flex-col max-h-[90vh] \${
          isDark ? 'bg-neutral-900 border-neutral-700 text-white' : 'bg-white border-neutral-300 text-black'
        }\`}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800">
          <div>
            <h2 className="text-lg font-black tracking-tight">Driver & Screen Settings</h2>
            <p className="text-xs text-neutral-400 mt-0.5">Optimized for Samsung Android & OsmAnd</p>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Settings Body */}
        <div className="p-6 overflow-y-auto space-y-5">
          {/* Theme Mode: AMOLED Black vs High Contrast Day */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-2">
              Display Mode
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => onUpdateSettings({ theme: 'amoled-black' })}
                className={\`p-3.5 rounded-2xl border flex flex-col items-center justify-center gap-2 transition-all \${
                  settings.theme === 'amoled-black'
                    ? 'border-emerald-400 bg-neutral-950 text-white ring-2 ring-emerald-500/30'
                    : 'border-neutral-800 bg-neutral-950/40 text-neutral-400 hover:text-neutral-200'
                }\`}
              >
                <Moon className="w-5 h-5 text-emerald-400" />
                <span className="text-xs font-bold">AMOLED Pitch Black</span>
                <span className="text-[10px] text-neutral-400">Saves battery & high OLED contrast</span>
              </button>

              <button
                onClick={() => onUpdateSettings({ theme: 'high-contrast-day' })}
                className={\`p-3.5 rounded-2xl border flex flex-col items-center justify-center gap-2 transition-all \${
                  settings.theme === 'high-contrast-day'
                    ? 'border-emerald-400 bg-neutral-100 text-black ring-2 ring-emerald-500/30'
                    : 'border-neutral-800 bg-neutral-950/40 text-neutral-400 hover:text-neutral-200'
                }\`}
              >
                <Sun className="w-5 h-5 text-amber-500" />
                <span className="text-xs font-bold">Daylight High Contrast</span>
                <span className="text-[10px] text-neutral-400">Direct sunlight in vehicle mount</span>
              </button>
            </div>
          </div>

          {/* Screen Wake Lock */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl border border-neutral-800 bg-neutral-950/50">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-emerald-400">
                <Smartphone className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-neutral-100">Keep Screen Awake</h4>
                <p className="text-[11px] text-neutral-400">Prevents phone display from sleeping while on route</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.keepScreenAwake}
              onChange={(e) => onUpdateSettings({ keepScreenAwake: e.target.checked })}
              className="w-5 h-5 accent-emerald-500 rounded cursor-pointer"
            />
          </div>

          {/* Voice Announcements */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl border border-neutral-800 bg-neutral-950/50">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-emerald-400">
                <Volume2 className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-neutral-100">Voice Announcement</h4>
                <p className="text-[11px] text-neutral-400">Speaks next customer name & address on advance</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.voiceAnnouncement}
              onChange={(e) => onUpdateSettings({ voiceAnnouncement: e.target.checked })}
              className="w-5 h-5 accent-emerald-500 rounded cursor-pointer"
            />
          </div>

          {/* Haptic Vibration */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl border border-neutral-800 bg-neutral-950/50">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-amber-400">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-neutral-100">Haptic Vibration</h4>
                <p className="text-[11px] text-neutral-400">Tactile vibration feedback on button press</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.hapticFeedback}
              onChange={(e) => onUpdateSettings({ hapticFeedback: e.target.checked })}
              className="w-5 h-5 accent-emerald-500 rounded cursor-pointer"
            />
          </div>

          {/* Extra Large Font */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl border border-neutral-800 bg-neutral-950/50">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-blue-400">
                <Eye className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-neutral-100">Extra Large Typography</h4>
                <p className="text-[11px] text-neutral-400">Maximizes readability from distance on dash mount</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.extraLargeText}
              onChange={(e) => onUpdateSettings({ extraLargeText: e.target.checked })}
              className="w-5 h-5 accent-emerald-500 rounded cursor-pointer"
            />
          </div>

          {/* Automatic Arrival Radius (Configurable 50m / ~164ft default) */}
          <div className="p-4 rounded-2xl border border-neutral-800 bg-neutral-950/50 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-amber-400">
                  <RotateCcw className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-neutral-100">Arrival Detection Radius</h4>
                  <p className="text-[11px] text-neutral-400">Geofence distance when approaching or passing stops</p>
                </div>
              </div>
              <span className="text-xs font-mono font-bold text-amber-400">
                {settings.arrivalRadiusMeters || 50}m (~{Math.round((settings.arrivalRadiusMeters || 50) * 3.28084)} ft)
              </span>
            </div>

            <div className="grid grid-cols-5 gap-1.5 pt-1">
              {[
                { meters: 25, label: '25m', sub: '82 ft' },
                { meters: 40, label: '40m', sub: '131 ft' },
                { meters: 50, label: '50m', sub: '164 ft', rec: true },
                { meters: 75, label: '75m', sub: '246 ft' },
                { meters: 100, label: '100m', sub: '328 ft' },
              ].map((item) => {
                const isSelected = (settings.arrivalRadiusMeters || 50) === item.meters;
                return (
                  <button
                    key={item.meters}
                    type="button"
                    onClick={() => onUpdateSettings({ arrivalRadiusMeters: item.meters })}
                    className={\`py-2 px-1 rounded-xl border flex flex-col items-center justify-center transition-all \${
                      isSelected
                        ? 'border-amber-400 bg-amber-400/15 text-amber-300 font-bold ring-1 ring-amber-400/50'
                        : 'border-neutral-800 bg-neutral-900/60 text-neutral-400 hover:text-white'
                    }\`}
                  >
                    <span className="text-xs">{item.label}</span>
                    <span className="text-[9px] text-neutral-500">{item.sub}</span>
                    {item.rec && (
                      <span className="text-[8px] text-emerald-400 font-mono mt-0.5">Rec</span>
                    )}
                  </button>
                );
              })}
            </div>
            <p className="text-[10px] text-neutral-500">
              50m (~164 ft) ensures reliable arrival recognition when passing at driving speed or on wide roads.
            </p>
          </div>

          {/* Route Management Section */}
          <div className="pt-3 border-t border-neutral-800 space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-2">
              Route Management
            </label>

            <button
              onClick={() => {
                onClose();
                onOpenExport?.();
              }}
              className="w-full flex items-center justify-between p-3 rounded-xl border border-blue-800 hover:border-blue-700 bg-blue-950/40 text-xs font-bold text-blue-300 hover:text-white transition-colors"
            >
              <div className="flex items-center gap-2">
                <FolderOpen className="w-4 h-4 text-blue-400" />
                <span>Export Project Source (.ZIP)</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded bg-blue-900/60 text-blue-200 font-mono">Step 1</span>
            </button>

            <button
              onClick={() => {
                onClose();
                onOpenImport();
              }}
              className="w-full flex items-center justify-between p-3 rounded-xl border border-neutral-800 hover:border-neutral-700 bg-neutral-950/40 text-xs font-bold text-neutral-200 hover:text-white transition-colors"
            >
              <div className="flex items-center gap-2">
                <FolderOpen className="w-4 h-4 text-neutral-400" />
                <span>Import Different GPX File</span>
              </div>
              <span className="text-[10px] text-neutral-400">Browse...</span>
            </button>

            <button
              onClick={() => {
                onResetProgress();
                onClose();
              }}
              className="w-full flex items-center justify-between p-3 rounded-xl border border-neutral-800 hover:border-neutral-700 bg-neutral-950/40 text-xs font-bold text-neutral-200 hover:text-white transition-colors"
            >
              <div className="flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-amber-400" />
                <span>Reset Progress to Stop 1</span>
              </div>
              <span className="text-[10px] text-neutral-400">Keep stops</span>
            </button>

            <button
              onClick={() => {
                if (confirm('Clear current route and load fresh GPX?')) {
                  onClearRoute();
                  onClose();
                }
              }}
              className="w-full flex items-center justify-between p-3 rounded-xl border border-red-900/60 hover:border-red-800 bg-red-950/20 text-xs font-bold text-red-300 hover:text-red-200 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Trash2 className="w-4 h-4 text-red-400" />
                <span>Clear Loaded Route</span>
              </div>
              <span className="text-[10px] text-red-400/80">Delete</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-neutral-800 flex justify-end bg-neutral-950/40">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
`,K=`import React, { useState } from 'react';
import { RouteStop, AppSettings } from '../types/route';
import { TurnByTurnPanel } from './TurnByTurnPanel';
import { RoadMapView } from './RoadMapView';
import { GpsLocation } from '../utils/useGpsTracker';
import { getStopHouseNumber } from '../utils/gpxParser';
import { 
  ChevronLeft, 
  SkipForward, 
  List,
  Map
} from 'lucide-react';

interface StopCardProps {
  stop: RouteStop;
  previousStop?: RouteStop;
  nextStop?: RouteStop;
  userLocation: GpsLocation | null;
  gpsStatus: 'acquiring' | 'locked' | 'denied';
  gpsErrorMsg: string | null;
  distanceToCurrentFeet: number | null;
  isWithinGeofence: boolean;
  isSharedLocationWithPrevious: boolean;
  isSharedLocationWithNext: boolean;
  autoArrivalStatus: string;
  currentIndex: number;
  totalStops: number;
  completedCount: number;
  skippedCount: number;
  settings: AppSettings;
  onSkip: () => void;
  onPrevious: () => void;
  onJumpToStopList: () => void;
  arrivalRadiusMeters?: number;
  isPassedWithoutCompletion?: boolean;
  simulateApproachAndPass?: () => void;
  simulateApproachAndArrive?: () => void;
  isSimulatingGps?: boolean;
  stopGpsSimulation?: () => void;
}

export const StopCard: React.FC<StopCardProps> = ({
  stop,
  previousStop,
  nextStop,
  userLocation,
  gpsStatus,
  gpsErrorMsg,
  distanceToCurrentFeet,
  isWithinGeofence,
  autoArrivalStatus,
  currentIndex,
  totalStops,
  settings,
  onSkip,
  onPrevious,
  onJumpToStopList,
  arrivalRadiusMeters,
  isPassedWithoutCompletion,
  simulateApproachAndPass,
  simulateApproachAndArrive,
  isSimulatingGps,
  stopGpsSimulation,
}) => {
  const isDark = settings.theme === 'amoled-black';

  // Toggle map view on/off (defaults to map-free large-text navigation)
  const [isMapOpen, setIsMapOpen] = useState(false);
  const [routeCoordinates, setRouteCoordinates] = useState<[number, number][]>([]);

  // Extract true house number from the customer's delivery address data (never stop sequence e.g. "002")
  const displayHouseNumber = getStopHouseNumber(stop, currentIndex);

  return (
    <div className="flex flex-col h-full justify-between pb-safe select-none overflow-hidden">
      {/* 1. Turn-by-Turn Navigation Panel at the very top (compacted for S26 viewport) */}
      <div className="shrink-0">
        <TurnByTurnPanel
          currentStop={stop}
          previousStop={previousStop}
          nextStop={nextStop}
          userLocation={userLocation}
          gpsStatus={gpsStatus}
          gpsErrorMsg={gpsErrorMsg}
          distanceToCurrentFeet={distanceToCurrentFeet}
          isDark={isDark}
          arrivalRadiusMeters={arrivalRadiusMeters || settings.arrivalRadiusMeters || 50}
          isWithinGeofence={isWithinGeofence}
          autoArrivalStatus={autoArrivalStatus}
          isPassedWithoutCompletion={isPassedWithoutCompletion}
          simulateApproachAndPass={simulateApproachAndPass}
          simulateApproachAndArrive={simulateApproachAndArrive}
          isSimulatingGps={isSimulatingGps}
          stopGpsSimulation={stopGpsSimulation}
          onRouteCoordinatesUpdate={setRouteCoordinates}
          onSkipCustomer={onSkip}
          voiceAnnouncement={settings.voiceAnnouncement}
        />
      </div>

      {/* 2. Stop Number, Show Map / Hide Map Toggle, and Previous Button */}
      <div className="shrink-0 flex items-center justify-between px-1 py-0.5 mb-1 gap-2">
        <button
          onClick={onJumpToStopList}
          className="flex items-center gap-1.5 text-xs font-mono font-bold text-neutral-400 hover:text-white transition-colors"
          title="Open Stop List"
        >
          <span className="text-emerald-400">STOP {currentIndex + 1} OF {totalStops}</span>
          <List className="w-3.5 h-3.5 text-neutral-500" />
        </button>

        <div className="flex items-center gap-1.5">
          {/* Show Map / Hide Map toggle button located near the STOP 5 OF 175 area */}
          <button
            onClick={() => setIsMapOpen((prev) => !prev)}
            className={\`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-black uppercase tracking-wider transition-all active:scale-95 border \${
              isMapOpen
                ? 'bg-amber-400 text-black border-amber-300 shadow-md shadow-amber-950/40'
                : 'bg-neutral-900 hover:bg-neutral-800 text-amber-400 border-neutral-700'
            }\`}
            title={isMapOpen ? 'Hide road map' : 'Show road map'}
          >
            <Map className="w-3.5 h-3.5" />
            <span>{isMapOpen ? 'Hide Map' : 'Show Map'}</span>
          </button>

          {currentIndex > 0 && (
            <button
              onClick={onPrevious}
              className="flex items-center gap-1 text-[11px] font-semibold text-neutral-400 hover:text-white px-2 py-1 rounded-lg bg-neutral-900 border border-neutral-800 transition-colors active:scale-95"
              title="Return to previous customer"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Prev</span>
            </button>
          )}
        </div>
      </div>

      {/* 3 & 4. Main Display Area: Map Mode OR Customer Name & Large Yellow House-Number Block */}
      {isMapOpen ? (
        /* MAP MODE: Live interactive road map with compact customer header */
        <div className="flex-1 flex flex-col min-h-0 my-auto py-1 space-y-1.5">
          {/* Compact Customer & House Number Strip */}
          <div className="shrink-0 flex items-center justify-between bg-neutral-900/90 border border-neutral-800 rounded-xl px-3 py-1.5">
            <div className="min-w-0 flex-1 pr-2">
              <div className="text-sm font-black text-white truncate">{stop.name}</div>
              {stop.fullAddress && (
                <div className="text-[11px] font-semibold text-neutral-400 truncate">{stop.fullAddress}</div>
              )}
            </div>
            <div className="shrink-0 px-2.5 py-0.5 bg-amber-400 text-black font-black font-mono text-xl rounded-lg border border-amber-300 shadow">
              {displayHouseNumber}
            </div>
          </div>

          {/* Real OpenStreetMap Road Map */}
          <div className="flex-1 min-h-[160px] max-h-[250px] w-full">
            <RoadMapView
              userLocation={userLocation}
              destination={{
                lat: stop.lat,
                lon: stop.lon,
                name: stop.name,
                houseNumber: displayHouseNumber,
                address: stop.fullAddress,
              }}
              routeCoordinates={routeCoordinates}
              isDark={isDark}
            />
          </div>
        </div>
      ) : (
        /* DEFAULT MAP-FREE MODE: Large Customer Name + Large Yellow House-Number Block */
        <div className="flex-1 flex flex-col items-center justify-center my-auto py-1 text-center min-h-0">
          {/* Customer's Name in Large Text */}
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight leading-snug mb-2 px-2 max-w-md break-words line-clamp-2">
            {stop.name}
          </h1>

          {/* Yellow House-Number Block with Very Large Number */}
          <div 
            className="bg-amber-400 text-black border-2 border-amber-300 rounded-2xl px-6 py-2.5 sm:py-3 flex items-center justify-center shadow-xl min-w-[160px] max-w-[260px] transition-transform active:scale-95"
          >
            <span className="text-5xl sm:text-6xl font-black font-mono tracking-tighter leading-none">
              {displayHouseNumber}
            </span>
          </div>
        </div>
      )}

      {/* 5. Orange SKIP CUSTOMER Button at the Bottom (Tightened to fit S26 without scrolling) */}
      <div className="shrink-0 pt-1.5">
        <button
          onClick={onSkip}
          className="w-full h-12 sm:h-13 rounded-xl flex items-center justify-center gap-2 font-black text-base sm:text-lg tracking-wide uppercase bg-amber-500 hover:bg-amber-400 text-black border-2 border-amber-300 shadow-lg shadow-amber-950/40 transition-all active:scale-[0.98]"
        >
          <SkipForward className="w-5 h-5 stroke-[3]" />
          <span>Skip Customer</span>
        </button>
      </div>
    </div>
  );
};
`,q=`import React, { useState, useEffect, useRef, useCallback } from 'react';
import { RouteStop } from '../types/route';
import { GpsLocation } from '../utils/useGpsTracker';
import { 
  NavManeuver, 
  fetchOsmRoute, 
  calculateDistanceMeters, 
  calculateDistanceToPolylineMeters, 
  calculateRemainingRouteDistanceMeters,
  calculateBearing,
  formatDistance, 
  formatDuration 
} from '../utils/navigationService';
import { announceTurnaround } from '../utils/voiceAndHaptics';
import { 
  Compass, 
  Play, 
  Square, 
  RotateCcw, 
  X, 
  Info, 
  CheckCircle2, 
  Sparkles,
  CornerUpRight, 
  CornerUpLeft, 
  ArrowUp, 
  ArrowUpRight, 
  ArrowUpLeft,
  CircleDot, 
  GitFork, 
  Flag,
  Navigation
} from 'lucide-react';

function isValidCoordinate(lat: number, lon: number): boolean {
  return (
    !isNaN(lat) &&
    !isNaN(lon) &&
    lat >= -90 &&
    lat <= 90 &&
    lon >= -180 &&
    lon <= 180 &&
    !(lat === 0 && lon === 0)
  );
}

// ==========================================
// 1. Maneuver Icon Component with Prominent U-Turn / Turnaround
// ==========================================
export const ManeuverIconComponent: React.FC<{ type?: string; modifier?: string; className?: string }> = ({ 
  type = 'turn', 
  modifier = 'straight',
  className = 'w-10 h-10' 
}) => {
  const mod = (modifier || '').toLowerCase();
  const t = (type || '').toLowerCase();

  if (t === 'arrive') return <Flag className={className} />;
  if (t === 'roundabout' || t === 'rotary') return <CircleDot className={className} />;
  if (t === 'fork') return <GitFork className={className} />;
  
  // Prominent driver-grade U-turn / Turn Around symbol
  if (
    mod.includes('uturn') ||
    mod === 'uturn' ||
    mod.includes('turnaround') ||
    mod.includes('turn around') ||
    t === 'turnaround'
  ) {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M9 19V9a5 5 0 0 1 10 0v7" />
        <polyline points="6 16 9 19 12 16" />
      </svg>
    );
  }
  
  if (mod === 'sharp right') {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M12 21V11a4 4 0 0 1 4-4h5" />
        <polyline points="18 4 21 7 18 10" />
      </svg>
    );
  }
  if (mod === 'sharp left') {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M12 21V11a4 4 0 0 0-4-4H3" />
        <polyline points="6 4 3 7 6 10" />
      </svg>
    );
  }
  if (mod === 'slight right') return <ArrowUpRight className={className} strokeWidth={2.75} />;
  if (mod === 'slight left') return <ArrowUpLeft className={className} strokeWidth={2.75} />;
  if (mod === 'right') return <CornerUpRight className={className} strokeWidth={2.75} />;
  if (mod === 'left') return <CornerUpLeft className={className} strokeWidth={2.75} />;
  if (mod === 'straight' || t === 'continue' || t === 'depart') {
    return <ArrowUp className={className} strokeWidth={2.75} />;
  }
  return <Compass className={className} strokeWidth={2.5} />;
};

// ==========================================
// 2. Complete Turn-by-Turn Panel Component
// ==========================================
export interface TurnByTurnPanelProps {
  currentStop: RouteStop;
  previousStop?: RouteStop;
  nextStop?: RouteStop;
  userLocation: GpsLocation | null;
  gpsStatus: 'acquiring' | 'locked' | 'denied';
  gpsErrorMsg: string | null;
  distanceToCurrentFeet: number | null;
  isDark: boolean;
  onOpenOsmAnd?: (e: React.MouseEvent) => void;
  arrivalRadiusMeters?: number;
  isWithinGeofence?: boolean;
  autoArrivalStatus?: string;
  isPassedWithoutCompletion?: boolean;
  simulateApproachAndPass?: () => void;
  simulateApproachAndArrive?: () => void;
  isSimulatingGps?: boolean;
  stopGpsSimulation?: () => void;
  onRouteCoordinatesUpdate?: (coords: [number, number][]) => void;
  onSkipCustomer?: () => void;
  voiceAnnouncement?: boolean;
}

export const TurnByTurnPanel: React.FC<TurnByTurnPanelProps> = ({
  currentStop,
  previousStop,
  nextStop,
  userLocation,
  distanceToCurrentFeet,
  isDark,
  arrivalRadiusMeters = 50,
  isWithinGeofence = false,
  autoArrivalStatus,
  isPassedWithoutCompletion = false,
  simulateApproachAndPass,
  simulateApproachAndArrive,
  isSimulatingGps = false,
  stopGpsSimulation,
  onRouteCoordinatesUpdate,
  onSkipCustomer,
  voiceAnnouncement = true,
}) => {
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [showTestMenu, setShowTestMenu] = useState(false);

  // Live OsmAnd AIDL feed state (from Android Kotlin wrapper)
  const [aidlUpdate, setAidlUpdate] = useState<{
    maneuver: string;
    street: string;
    distanceMeters: number;
    lastReceived: number;
  } | null>(null);

  useEffect(() => {
    (window as any).onOsmAndNavUpdate = (maneuver: string, street: string, distMeters: number) => {
      setAidlUpdate({
        maneuver: maneuver || 'straight',
        street: street || '',
        distanceMeters: typeof distMeters === 'number' ? distMeters : 0,
        lastReceived: Date.now(),
      });
    };
    return () => {
      delete (window as any).onOsmAndNavUpdate;
    };
  }, []);

  const isAidlActive = Boolean(aidlUpdate && Date.now() - aidlUpdate.lastReceived < 20000);

  // Road navigation state
  const [maneuvers, setManeuvers] = useState<NavManeuver[]>([]);
  const [routeCoordinates, setRouteCoordinates] = useState<[number, number][]>([]);
  const [currentManeuverIndex, setCurrentManeuverIndex] = useState(0);
  const [distanceToTurnMeters, setDistanceToTurnMeters] = useState(0);
  const [totalDistanceMeters, setTotalDistanceMeters] = useState(0);
  const [remainingDistanceToCustomerMeters, setRemainingDistanceToCustomerMeters] = useState<number | null>(null);
  const [totalDurationSeconds, setTotalDurationSeconds] = useState(0);
  const [isRouting, setIsRouting] = useState(false);
  const [routingError, setRoutingError] = useState<string | null>(null);
  const [rerouteBadge, setRerouteBadge] = useState<string | null>(null);

  // Tracking and Debounce Refs for recalculations
  const lastRerouteTimeRef = useRef<number>(0);
  const lastReroutePosRef = useRef<{ lat: number; lon: number } | null>(null);
  const minDistanceToDestRef = useRef<number>(Infinity);
  const currentStopIdRef = useRef<string | null>(null);
  const lastSegmentIndexRef = useRef<number>(0);
  const prevGpsPosRef = useRef<{ lat: number; lon: number } | null>(null);

  // Track previous GPS position for heading estimation when hardware heading is null
  useEffect(() => {
    if (userLocation && isValidCoordinate(userLocation.lat, userLocation.lon)) {
      prevGpsPosRef.current = { lat: userLocation.lat, lon: userLocation.lon };
    }
  }, [userLocation]);

  // Determine starting point: live GPS if valid, else previous stop, else realistic approach offset
  const getStartPoint = useCallback((): { lat: number; lon: number; heading: number | null } | null => {
    if (userLocation && isValidCoordinate(userLocation.lat, userLocation.lon)) {
      let heading = userLocation.heading ?? null;
      if (heading === null && prevGpsPosRef.current) {
        heading = calculateBearing(prevGpsPosRef.current.lat, prevGpsPosRef.current.lon, userLocation.lat, userLocation.lon);
      }
      return { 
        lat: userLocation.lat, 
        lon: userLocation.lon, 
        heading 
      };
    }
    if (previousStop && isValidCoordinate(previousStop.lat, previousStop.lon)) {
      return { 
        lat: previousStop.lat, 
        lon: previousStop.lon, 
        heading: null 
      };
    }
    if (currentStop && isValidCoordinate(currentStop.lat, currentStop.lon)) {
      // 0.005 deg offset (~500m) approach vector
      return { 
        lat: currentStop.lat - 0.005, 
        lon: currentStop.lon - 0.004, 
        heading: 35 
      };
    }
    return null;
  }, [userLocation, previousStop, currentStop]);

  // Primary Road Route Fetcher
  const fetchRoute = useCallback(async (customStart?: { lat: number; lon: number; heading?: number | null }, reasonTag?: string) => {
    if (!currentStop || !isValidCoordinate(currentStop.lat, currentStop.lon)) {
      setManeuvers([]);
      setRouteCoordinates([]);
      setRemainingDistanceToCustomerMeters(null);
      return;
    }

    const start = customStart || getStartPoint();
    if (!start) return;

    setIsRouting(true);
    setRoutingError(null);

    try {
      const route = await fetchOsmRoute(
        start.lat,
        start.lon,
        currentStop.lat,
        currentStop.lon,
        currentStop.name,
        start.heading
      );

      if (route.maneuvers.length > 0) {
        setManeuvers(route.maneuvers);
        setRouteCoordinates(route.coordinates);
        if (onRouteCoordinatesUpdate) {
          onRouteCoordinatesUpdate(route.coordinates);
        }
        setCurrentManeuverIndex(0);
        lastSegmentIndexRef.current = 0;
        setTotalDistanceMeters(route.totalDistance);
        setRemainingDistanceToCustomerMeters(route.totalDistance);
        setTotalDurationSeconds(route.totalDuration);
        setDistanceToTurnMeters(route.maneuvers[0]?.distanceMeters || 0);

        lastRerouteTimeRef.current = Date.now();
        lastReroutePosRef.current = { lat: start.lat, lon: start.lon };

        if (reasonTag) {
          setRerouteBadge(reasonTag);
          setTimeout(() => setRerouteBadge(null), 5000);
        } else if (route.hasUturn) {
          setRerouteBadge('Turn Around Route Active');
          setTimeout(() => setRerouteBadge(null), 5000);
        }

        // Voice announcement for turnaround maneuver
        if (route.hasUturn && voiceAnnouncement) {
          announceTurnaround();
        }
      }
    } catch (err: any) {
      console.warn('Road routing error:', err);
      setRoutingError(err.message || 'Routing unavailable');
    } finally {
      setIsRouting(false);
    }
  }, [currentStop, getStartPoint, onRouteCoordinatesUpdate, voiceAnnouncement]);

  // Initial Route Fetch on active customer change
  useEffect(() => {
    const stopId = currentStop?.id || null;
    if (stopId !== currentStopIdRef.current) {
      currentStopIdRef.current = stopId;
      setCurrentManeuverIndex(0);
      lastSegmentIndexRef.current = 0;
      setRemainingDistanceToCustomerMeters(null);
      minDistanceToDestRef.current = Infinity;
      lastReroutePosRef.current = null;
      lastRerouteTimeRef.current = 0;
      setRerouteBadge(null);
      fetchRoute();
    }
  }, [currentStop?.id, currentStop?.lat, currentStop?.lon, fetchRoute]);

  // Real-time Vehicle Progress & Intelligent Recalculation Engine
  useEffect(() => {
    if (!userLocation || !isValidCoordinate(userLocation.lat, userLocation.lon)) return;
    if (!currentStop || !isValidCoordinate(currentStop.lat, currentStop.lon)) return;

    const now = Date.now();
    const distToDest = calculateDistanceMeters(userLocation.lat, userLocation.lon, currentStop.lat, currentStop.lon);

    // Track minimum distance seen for this destination
    if (distToDest < minDistanceToDestRef.current) {
      minDistanceToDestRef.current = distToDest;
    }

    // ========================================================
    // INTELLIGENT RECALCULATION TRIGGER
    // 1. Driver passed destination without completing stop (missed stop)
    // 2. OR driver deviated significantly (> 45m) off planned route polyline
    // ========================================================
    const timeSinceLastReroute = now - lastRerouteTimeRef.current;
    const distFromLastReroute = lastReroutePosRef.current
      ? calculateDistanceMeters(userLocation.lat, userLocation.lon, lastReroutePosRef.current.lat, lastReroutePosRef.current.lon)
      : Infinity;

    // Condition A: Missed destination (passed without arrival confirmation)
    const isPassedAddress = Boolean(
      isPassedWithoutCompletion ||
      (minDistanceToDestRef.current <= 80 && distToDest >= minDistanceToDestRef.current + 22)
    );

    // Condition B: Off-route deviation from polyline (> 45 meters)
    let isOffRoute = false;
    if (routeCoordinates.length > 1) {
      const distToPolyline = calculateDistanceToPolylineMeters(userLocation.lat, userLocation.lon, routeCoordinates);
      isOffRoute = distToPolyline > 45 && distToDest > 30;
    }

    if ((isPassedAddress || isOffRoute) && timeSinceLastReroute > 3500 && distFromLastReroute > 15 && !isRouting) {
      const reason = isPassedAddress ? 'Passed Stop · Recalculating' : 'Off-Route · Rerouting';
      minDistanceToDestRef.current = distToDest;
      let heading = userLocation.heading ?? null;
      if (heading === null && prevGpsPosRef.current) {
        heading = calculateBearing(prevGpsPosRef.current.lat, prevGpsPosRef.current.lon, userLocation.lat, userLocation.lon);
      }
      fetchRoute(
        { lat: userLocation.lat, lon: userLocation.lon, heading },
        reason
      );
      return;
    }

    // ========================================================
    // DISTANCE TO CUSTOMER COUNTDOWN (Continuous along driving route)
    // ========================================================
    if (routeCoordinates.length > 1) {
      const { remainingMeters, closestSegmentIndex } = calculateRemainingRouteDistanceMeters(
        userLocation.lat,
        userLocation.lon,
        routeCoordinates,
        lastSegmentIndexRef.current
      );
      lastSegmentIndexRef.current = closestSegmentIndex;
      setRemainingDistanceToCustomerMeters(remainingMeters);
    } else if (distanceToCurrentFeet !== null) {
      setRemainingDistanceToCustomerMeters(Math.round(distanceToCurrentFeet / 3.28084));
    } else {
      setRemainingDistanceToCustomerMeters(Math.round(distToDest));
    }

    // ========================================================
    // MANEUVER PROGRESSION ALONG ACTIVE ROUTE
    // Advance to next turn as driver approaches maneuver waypoint
    // ========================================================
    if (maneuvers.length > 0 && currentManeuverIndex < maneuvers.length) {
      const currentM = maneuvers[currentManeuverIndex];
      if (currentM) {
        const [turnLon, turnLat] = currentM.location;
        const distToWaypoint = calculateDistanceMeters(userLocation.lat, userLocation.lon, turnLat, turnLon);

        if (distToWaypoint < 25 && currentManeuverIndex < maneuvers.length - 1) {
          setCurrentManeuverIndex((idx) => idx + 1);
          const nextM = maneuvers[currentManeuverIndex + 1];
          setDistanceToTurnMeters(nextM ? nextM.distanceMeters : 0);
        } else {
          setDistanceToTurnMeters(Math.max(0, Math.round(distToWaypoint)));
        }
      }
    }
  }, [userLocation, currentStop, maneuvers, currentManeuverIndex, routeCoordinates, isPassedWithoutCompletion, isRouting, fetchRoute, distanceToCurrentFeet]);

  const currentManeuver = maneuvers[currentManeuverIndex] || null;
  const nextManeuver = maneuvers[currentManeuverIndex + 1] || null;

  // Check if active customer was passed without confirmed arrival
  const distToDest = userLocation && isValidCoordinate(userLocation.lat, userLocation.lon) && isValidCoordinate(currentStop.lat, currentStop.lon)
    ? calculateDistanceMeters(userLocation.lat, userLocation.lon, currentStop.lat, currentStop.lon)
    : Infinity;

  const isCustomerPassed = Boolean(
    isPassedWithoutCompletion ||
    (minDistanceToDestRef.current <= 80 && distToDest >= minDistanceToDestRef.current + 22)
  );

  // Check if customer is the last stop on the current road
  const isLastStopOnRoad = Boolean(
    currentStop && (
      !nextStop ||
      (currentStop.streetName && nextStop.streetName && currentStop.streetName.toLowerCase().trim() !== nextStop.streetName.toLowerCase().trim())
    )
  );

  // Check if route involves a turnaround / U-turn
  const hasTurnaroundManeuver = Boolean(
    maneuvers.some((m) => {
      const mod = (m.modifier || '').toLowerCase();
      const t = (m.type || '').toLowerCase();
      return mod.includes('uturn') || mod.includes('turnaround') || mod.includes('turn around') || t === 'turnaround';
    })
  );

  const shouldTurnAround = Boolean(
    (isCustomerPassed && (hasTurnaroundManeuver || currentManeuverIndex <= 1)) ||
    (currentManeuver?.modifier?.toLowerCase().includes('uturn')) ||
    (currentManeuver?.instruction?.includes('Turn around as soon as possible.'))
  );

  // Voice announcement trigger when turnaround is active
  useEffect(() => {
    if (shouldTurnAround && voiceAnnouncement) {
      announceTurnaround();
    }
  }, [shouldTurnAround, voiceAnnouncement]);

  const activeManeuverType = isAidlActive && aidlUpdate
    ? (aidlUpdate.maneuver.includes('roundabout') ? 'roundabout' : (aidlUpdate.maneuver.includes('uturn') || aidlUpdate.maneuver.includes('turnaround') ? 'turnaround' : 'turn'))
    : shouldTurnAround
      ? 'turnaround'
      : currentManeuver?.type || 'turn';

  const activeManeuverModifier = isAidlActive && aidlUpdate
    ? aidlUpdate.maneuver
    : shouldTurnAround
      ? 'uturn'
      : currentManeuver?.modifier || 'straight';

  const activeInstructionText = isAidlActive && aidlUpdate
    ? (aidlUpdate.maneuver.includes('uturn') || aidlUpdate.maneuver.includes('turnaround')
        ? 'Turn around as soon as possible.'
        : (aidlUpdate.street ? \`Turn onto \${aidlUpdate.street}\` : aidlUpdate.maneuver))
    : shouldTurnAround
      ? 'Turn around as soon as possible.'
      : currentManeuver?.instruction || (currentStop.streetName ? \`Proceed along route to \${currentStop.streetName}\` : 'Proceed toward customer destination');

  const activeStreetName = isAidlActive && aidlUpdate
    ? aidlUpdate.street
    : currentManeuver?.streetName || currentStop.streetName || currentStop.fullAddress || '';

  const activeDistanceToNextTurn = isAidlActive && aidlUpdate
    ? formatDistance(aidlUpdate.distanceMeters)
    : formatDistance(distanceToTurnMeters) || '0 ft';

  const hasValidCoords = isValidCoordinate(currentStop.lat, currentStop.lon);

  const arrivalZoneFeet = Math.round((arrivalRadiusMeters || 50) * 3.28084);
  const isArrived = Boolean(
    isWithinGeofence ||
    (distanceToCurrentFeet !== null && distanceToCurrentFeet <= arrivalZoneFeet)
  );

  // Prioritize active customer's delivery address distance along calculated driving route
  const displayDistanceToCustomer = isArrived
    ? '0 ft'
    : remainingDistanceToCustomerMeters !== null
      ? formatDistance(remainingDistanceToCustomerMeters)
      : distanceToCurrentFeet !== null && hasValidCoords
        ? formatDistance(distanceToCurrentFeet / 3.28084)
        : totalDistanceMeters > 0
          ? formatDistance(totalDistanceMeters)
          : '0 ft';

  // Check whether an upcoming road maneuver/turn is relevant before reaching customer
  const isFinalArrivalManeuver = !currentManeuver || currentManeuver.type === 'arrive';
  const hasUpcomingTurn = !isFinalArrivalManeuver && (currentManeuverIndex < maneuvers.length - 1 || distanceToTurnMeters > 15);

  return (
    <>
      {/* 
        Substantially Taller, Full-Width Driver-Grade Turn-by-Turn Card
        - Zero text truncation (no truncate, no nowrap, no ellipses)
        - Multi-line wrap enabled for any street name length
        - High-contrast AMOLED black & amber/orange styling
        - Legal U-turn & block rerouting support
      */}
      <div 
        className={\`w-full rounded-2xl border-2 transition-all shadow-xl relative mb-2 flex flex-col shrink-0 \${
          isArrived
            ? 'bg-emerald-950/95 border-emerald-400 text-white shadow-emerald-950/90'
            : isDark 
              ? 'bg-neutral-950 border-neutral-800 text-white shadow-neutral-950/95' 
              : 'bg-neutral-900 border-neutral-700 text-white shadow-neutral-500/40'
        }\`}
      >
        {/* Amber accent top bar */}
        <div className="w-full h-1 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-400 rounded-t-2xl" />

        {/* 1. Header Bar: Engine Source, Reroute Status & Test Drive Controls */}
        <div className="px-3 py-1 flex items-center justify-between border-b border-neutral-800/90 gap-1.5 flex-wrap">
          {/* Active Status Badge */}
          <div className="flex items-center gap-1.5">
            <span className="relative flex h-2 w-2 shrink-0">
              <span className={\`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 \${
                isAidlActive ? 'bg-emerald-400' : isSimulatingGps ? 'bg-amber-400' : 'bg-orange-400'
              }\`} />
              <span className={\`relative inline-flex rounded-full h-2 w-2 \${
                isAidlActive ? 'bg-emerald-400' : isSimulatingGps ? 'bg-amber-400' : 'bg-orange-500'
              }\`} />
            </span>
            <span className="font-mono font-bold uppercase tracking-wider text-[10px] text-neutral-300">
              {rerouteBadge
                ? rerouteBadge
                : isAidlActive 
                  ? 'OsmAnd Native AIDL' 
                  : isSimulatingGps
                    ? 'Test Simulation Active'
                    : isRouting 
                      ? 'Recalculating...' 
                      : 'OpenStreetMap Routing'}
            </span>
          </div>

          {/* Test Drive Controls */}
          <div className="flex items-center gap-1.5 relative">
            {isSimulatingGps ? (
              <button
                onClick={() => {
                  if (stopGpsSimulation) stopGpsSimulation();
                }}
                className="flex items-center gap-1 px-2.5 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-wider bg-amber-400 text-black shadow-md shadow-amber-950/60 animate-pulse transition-all active:scale-95"
                title="Pause active simulation"
              >
                <Square className="w-2.5 h-2.5 fill-current" />
                <span>Stop</span>
              </button>
            ) : (
              <div className="relative">
                <button
                  onClick={() => setShowTestMenu((v) => !v)}
                  className="flex items-center gap-1 px-2.5 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-wider bg-neutral-900 hover:bg-neutral-800 text-amber-400 border border-neutral-700 transition-all active:scale-95"
                  title="Test in-phone without driving"
                >
                  <Play className="w-2.5 h-2.5 fill-current" />
                  <span>Test Drive</span>
                </button>

                {/* Test Drive Dropdown Menu */}
                {showTestMenu && (
                  <div className="absolute right-0 top-full mt-1.5 w-52 bg-neutral-900 border border-neutral-700 rounded-xl shadow-2xl p-1.5 z-40 space-y-1 animate-in fade-in zoom-in-95 duration-150">
                    <button
                      onClick={() => {
                        setShowTestMenu(false);
                        if (simulateApproachAndArrive) {
                          simulateApproachAndArrive();
                        } else if (simulateApproachAndPass) {
                          simulateApproachAndPass();
                        }
                      }}
                      className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-bold text-white hover:bg-neutral-800 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>Approach & Stop</span>
                      </div>
                      <span className="text-[9px] text-neutral-400 uppercase font-mono">Arrival</span>
                    </button>

                    <button
                      onClick={() => {
                        setShowTestMenu(false);
                        if (simulateApproachAndPass) {
                          simulateApproachAndPass();
                        }
                      }}
                      className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-bold text-white hover:bg-neutral-800 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-1.5">
                        <RotateCcw className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>Miss Stop & Reroute</span>
                      </div>
                      <span className="text-[9px] text-amber-400 uppercase font-mono">Turn Around</span>
                    </button>
                  </div>
                )}
              </div>
            )}

            <button
              onClick={() => setShowStatusModal(true)}
              className="p-1 text-neutral-400 hover:text-white rounded hover:bg-neutral-800 transition-colors"
              title="Navigation details & instructions"
            >
              <Info className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 2. Primary Customer Guidance Section: Maneuver Arrow + Large DISTANCE TO CUSTOMER */}
        <div className="px-3 py-2 flex items-center justify-between gap-3 border-b border-neutral-800/60">
          {/* Maneuver Arrow Container */}
          <div 
            className={\`w-12 h-12 sm:w-14 sm:h-14 rounded-xl flex items-center justify-center shrink-0 border-2 shadow-lg transition-all \${
              isArrived
                ? 'bg-emerald-500 border-emerald-300 text-black shadow-emerald-500/50'
                : isAidlActive
                  ? 'bg-emerald-500/25 border-emerald-400 text-emerald-400'
                  : 'bg-amber-400 border-amber-300 text-black shadow-amber-400/20'
            }\`}
          >
            {isArrived ? (
              <CheckCircle2 className="w-8 h-8 sm:w-9 sm:h-9 stroke-[3] text-black" />
            ) : (
              <ManeuverIconComponent 
                type={activeManeuverType}
                modifier={activeManeuverModifier}
                className="w-8 h-8 sm:w-9 sm:h-9 stroke-[2.75]" 
              />
            )}
          </div>

          {/* Large Hero: DISTANCE TO CUSTOMER with secondary next turn indicator */}
          <div className="flex-1 text-right min-w-0">
            <div className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-amber-400 font-mono mb-0.5">
              {isArrived ? 'ARRIVED AT CUSTOMER' : 'DISTANCE TO CUSTOMER'}
            </div>
            <div className="font-black text-3xl sm:text-4xl font-mono text-white tracking-tight leading-none drop-shadow">
              {displayDistanceToCustomer}
            </div>

            {/* Secondary Road Maneuver Instruction when turn is relevant */}
            {!isArrived && (
              <div className="mt-1 flex items-center justify-end gap-1.5 text-xs font-mono">
                {hasUpcomingTurn ? (
                  <>
                    <span className="text-[9px] font-black uppercase tracking-wider text-black bg-amber-400 px-1.5 py-0.5 rounded shrink-0">
                      NEXT TURN
                    </span>
                    <span className="text-white font-extrabold text-[11px] sm:text-xs">
                      {activeDistanceToNextTurn}
                    </span>
                  </>
                ) : (
                  <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block animate-pulse" />
                    <span>Straight to Stop</span>
                  </span>
                )}
              </div>
            )}
          </div>
        </div>

        {/* 3. Full-Width Driving Instruction */}
        <div className="px-3 py-1.5 space-y-1">
          {/* Complete Turn Instruction Text - No truncate, wraps cleanly */}
          <h2 className="text-base sm:text-lg font-black text-amber-300 tracking-tight leading-snug whitespace-normal break-words">
            {activeInstructionText}
          </h2>

          {/* Road / Street Name Pill */}
          {activeStreetName && (
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-neutral-900 border border-neutral-700/80 text-white font-bold text-xs max-w-full whitespace-normal break-words">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
              <span className="break-words">Road: {activeStreetName}</span>
            </div>
          )}
        </div>

        {/* Missed Last Stop Guidance Banner */}
        {isCustomerPassed && isLastStopOnRoad && !isArrived && (
          <div className="mx-3 my-1 px-3 py-1.5 rounded-xl bg-amber-500/15 border border-amber-400/40 text-amber-300 text-[11px] font-bold flex items-center justify-between gap-2">
            <span>Customer is last stop on road · Turn around as soon as possible, or tap Skip to continue</span>
            {onSkipCustomer && (
              <button 
                onClick={onSkipCustomer} 
                className="shrink-0 px-2 py-0.5 bg-amber-400 text-black rounded-lg text-[10px] font-black uppercase tracking-wider hover:bg-amber-300 active:scale-95 transition-all shadow"
              >
                Skip
              </button>
            )}
          </div>
        )}

        {/* 4. Upcoming Next Turn Preview Strip ("THEN" Maneuver) */}
        {nextManeuver && !isArrived && (
          <div className="px-3 py-1 bg-neutral-900/95 border-t border-neutral-800 rounded-b-2xl flex items-center gap-2 text-xs font-semibold text-neutral-300 whitespace-normal break-words">
            <span className="text-[9px] font-black uppercase tracking-wider text-black bg-amber-400 px-1.5 py-0.5 rounded shrink-0">
              THEN
            </span>
            <div className="w-4 h-4 flex items-center justify-center shrink-0 text-amber-400">
              <ManeuverIconComponent 
                type={nextManeuver.type}
                modifier={nextManeuver.modifier}
                className="w-3.5 h-3.5 stroke-[2.5]" 
              />
            </div>
            <div className="flex-1 min-w-0 whitespace-normal break-words text-neutral-200 text-xs">
              <span className="font-mono text-amber-400 font-bold">In {formatDistance(nextManeuver.distanceMeters)}:</span>{' '}
              <span>{nextManeuver.instruction}</span>
            </div>
          </div>
        )}

        {/* 5. Geofence Arrival Banner */}
        {isArrived && (
          <div className="p-2 bg-emerald-500 text-black font-black text-xs text-center tracking-wide uppercase rounded-b-2xl flex items-center justify-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 stroke-[3]" />
            <span>ARRIVED WITHIN {arrivalZoneFeet} FT GEOFENCE</span>
          </div>
        )}

        {/* Routing Error Notice */}
        {routingError && (
          <div className="px-4 py-2 bg-red-950/80 border-t border-red-900 text-xs text-red-300 flex items-center justify-between">
            <span>Routing server: {routingError}</span>
            <button
              onClick={() => fetchRoute()}
              className="underline text-red-200 flex items-center gap-1 font-bold"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Retry
            </button>
          </div>
        )}
      </div>

      {/* Navigation Architecture & In-Phone Testing Guide Modal */}
      {showStatusModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-3xl border border-neutral-700 bg-neutral-900 text-white shadow-2xl p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-orange-600 flex items-center justify-center text-white shrink-0">
                  <Compass className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-black text-base">True Road Navigation</h3>
                  <p className="text-xs text-neutral-400">Intelligent Rerouting & Legal Maneuvers</p>
                </div>
              </div>
              <button
                onClick={() => setShowStatusModal(false)}
                className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs text-neutral-300">
              <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="font-bold text-amber-400 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" />
                  <span>Legal Maneuvers & Missed Destinations</span>
                </div>
                <p>
                  Calculates genuine OpenStreetMap driving routes with exact road names, turn angles, and step distances.
                </p>
                <ul className="list-disc pl-4 space-y-1 text-neutral-400">
                  <li><strong>Turnaround Guidance:</strong> When turning around is the appropriate way to return to the customer, the app instructs &quot;Turn around as soon as possible.&quot;.</li>
                  <li><strong>Around the Block:</strong> If a turnaround is restricted by road dividers or one-way rules, the app routes you around the block via legal side streets.</li>
                  <li><strong>Last Stop on Road:</strong> If the customer is the last stop on the road and you pass it, the app guides you to turn around while keeping the active customer until arrival or manual skip.</li>
                  <li><strong>No Accidental Advance:</strong> Passing an address without stopping does not mark the customer complete; it keeps the customer active and recalculates the return route.</li>
                </ul>
              </div>

              <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="font-bold text-amber-300">How to Test on Android:</div>
                <ol className="list-decimal pl-4 space-y-1.5 text-neutral-400">
                  <li>Tap <strong>Test Drive</strong> in the navigation header.</li>
                  <li>Select <strong>Approach & Stop</strong> to verify confirmed arrival and automatic stop advancement.</li>
                  <li>Select <strong>Miss Stop & Reroute</strong> to simulate driving past without stopping. Watch the app keep the active customer and instantly recalculate a legal return route.</li>
                  <li>While driving on the road, the app automatically tracks your real-time GPS position.</li>
                </ol>
              </div>
            </div>

            <button
              onClick={() => setShowStatusModal(false)}
              className="w-full mt-5 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-sm transition-all"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
};
`,gt=`@import "tailwindcss";

@layer utilities {
  .pb-safe {
    padding-bottom: max(0.75rem, env(safe-area-inset-bottom, 0.75rem));
  }
  .pt-safe {
    padding-top: max(0.5rem, env(safe-area-inset-top, 0.5rem));
  }
}

:root {
  color-scheme: dark;
  font-family: 'Plus Jakarta Sans', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

/* Prevent accidental pull-to-refresh on Android when swiping cards in truck mount */
body {
  overscroll-behavior-y: contain;
  touch-action: manipulation;
}

/* High-contrast AMOLED Dark styling for OpenStreetMap tiles */
.dark-map-tiles {
  filter: brightness(0.7) invert(0.92) contrast(1.4) hue-rotate(185deg) saturate(0.4);
}
`,_t=`import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(<App />);
`,vt=`export type StopStatus = 'pending' | 'completed' | 'skipped';

export interface RouteStop {
  id: string;
  orderIndex: number; // 1-based exact sequence from GPX
  name: string;
  houseNumber: string;
  fullAddress: string;
  streetName: string;
  lat: number;
  lon: number;
  desc?: string;
  cmt?: string;
  notes?: string;
  status: StopStatus;
  statusTimestamp?: number;
  skipReason?: string;
}

export interface RouteData {
  id: string;
  name: string;
  filename: string;
  stops: RouteStop[];
  currentIndex: number; // 0-based index into stops array
  importedAt: number;
  lastUpdated: number;
}

export interface AppSettings {
  theme: 'amoled-black' | 'high-contrast-day';
  voiceAnnouncement: boolean;
  hapticFeedback: boolean;
  keepScreenAwake: boolean;
  extraLargeText: boolean;
  arrivalRadiusMeters?: number; // Configurable arrival radius in meters (default 50m / ~164ft)
}

`,yt=`import { RouteStop } from '../types/route';

/**
 * Cleanly extracts the house or building number from an address string.
 * Supports:
 * - Simple numbers: "123 Main St" -> "123"
 * - Letter suffixes: "123A Main St" -> "123A"
 * - Hyphenated / sub-numbers: "1402-B Willow Creek Rd", "45/2 Birchwood" -> "1402-B", "45/2"
 * - Strips route/stop sequence prefixes like "002 - 123 Main St", "Stop 2: 123 Main St"
 * - Handles suite/unit before or after: "Suite 100, 500 S 6th St" -> "500"
 * Returns empty string if no valid house number is found.
 */
export function extractHouseNumber(addressText: string | undefined | null): string {
  if (!addressText) return '';
  let text = addressText.trim();
  if (!text) return '';

  // 1. Ignore coordinate-only or unavailable location placeholders
  if (/^location\\s*\\(?/i.test(text) || /^lat/i.test(text) || text.toLowerCase() === 'location unavailable') {
    return '';
  }

  // 2. Strip leading stop-sequence indicators like "002 - ", "Stop 002: ", "Stop 2 - ", "#002 - "
  // Do NOT strip non-zero-padded hyphenated house numbers like "1402-B" or "12-A"
  text = text.replace(/^(?:stop\\s*#?\\d+\\s*[-:–—]\\s*|#?0+\\d+\\s*[-:–—]\\s*)/i, '').trim();

  // 3. Strip leading "Unit/Apt/Suite" if it precedes the street address:
  // e.g., "Apt 4B, 123 Foster ville Road" -> "123 Foster ville Road"
  const unitPrefixMatch = text.match(/^(?:apt\\.?|apartment|unit|suite|ste\\.?|room|rm\\.?)\\s*#?[a-z0-9-]+\\s*,\\s*(.+)$/i);
  if (unitPrefixMatch) {
    text = unitPrefixMatch[1].trim();
  }

  // 4. Primary: Match house number at the beginning of address (most common and reliable):
  // e.g. "123 Foster ville Road", "#123 Foster ville Road", "123A Main St", "1402-B Willow Creek Rd"
  const leadingMatch = text.match(/^(?:#|no\\.?\\s*)?(\\d+[A-Za-z]?(?:[-\\/][A-Za-z0-9]+)?)\\s+([A-Za-z0-9#])/i);
  if (leadingMatch) {
    // Verify it is not a zero-padded stop sequence that survived stripping (like "002")
    if (!/^0+\\d+$/.test(leadingMatch[1])) {
      return leadingMatch[1];
    }
  }

  // 5. Look for house number preceding street name / street suffix indicators:
  // e.g. "500 S 6th St", "Suite 100, 500 S 6th St"
  const streetWithNumMatch = text.match(/(?:^|[,\\s])(?:#|no\\.?\\s*)?(\\d+[A-Za-z]?(?:[-\\/][A-Za-z0-9]+)?)\\s+(?:[NSEW]\\.?\\s+)?([A-Za-z0-9\\s]+?\\s+(?:st|street|rd|road|ave|avenue|ln|lane|dr|drive|blvd|boulevard|way|ct|court|cir|circle|pl|place|ter|terrace|pkwy|parkway))\\b/i);
  if (streetWithNumMatch) {
    if (!/^0+\\d+$/.test(streetWithNumMatch[1])) {
      return streetWithNumMatch[1];
    }
  }

  // 6. Generic pattern: any standalone number with optional letter suffix at start of string
  const startNumMatch = text.match(/^(?:#|no\\.?\\s*)?(\\d+[A-Za-z]?(?:[-\\/][A-Za-z0-9]+)?)\\b/i);
  if (startNumMatch && !/^0+\\d+$/.test(startNumMatch[1])) {
    return startNumMatch[1];
  }

  return '';
}

/**
 * Resolves the genuine house number for a RouteStop.
 * Prioritizes the customer's delivery address data (fullAddress, desc, cmt, address).
 * Explicitly rejects stop sequence numbers (such as "002" or orderIndex).
 * Returns '—' as a fallback if no valid house number is identifiable.
 */
export function getStopHouseNumber(stop: RouteStop | null | undefined, currentIndex?: number): string {
  if (!stop) return '—';

  // 1. Try extracting from delivery address sources first (the true source of truth)
  const addressSources = [
    stop.fullAddress,
    stop.desc,
    stop.cmt,
    stop.streetName,
    stop.notes,
  ];

  for (const source of addressSources) {
    if (source) {
      const extracted = extractHouseNumber(source);
      if (extracted) {
        return extracted;
      }
    }
  }

  // 2. If stop.houseNumber was previously set, verify it isn't just a stop sequence number
  if (stop.houseNumber && stop.houseNumber.trim()) {
    const candidate = stop.houseNumber.trim();
    const isStopSequence = 
      /^0+\\d+$/.test(candidate) || // leading zeros e.g. "001", "002"
      (stop.orderIndex && candidate === String(stop.orderIndex)) ||
      (currentIndex !== undefined && candidate === String(currentIndex + 1));

    if (!isStopSequence) {
      return candidate;
    }
  }

  // 3. Check customer name only if it contains a street address pattern
  // e.g. "123 Foster ville Road"
  if (stop.name) {
    const extractedFromName = extractHouseNumber(stop.name);
    if (extractedFromName) {
      const isStopSequence = 
        /^0+\\d+$/.test(extractedFromName) ||
        (stop.orderIndex && extractedFromName === String(stop.orderIndex)) ||
        (currentIndex !== undefined && extractedFromName === String(currentIndex + 1));
      if (!isStopSequence) {
        return extractedFromName;
      }
    }
  }

  // 4. Fallback when address has no identifiable house number
  return '—';
}

/**
 * Extracts a house/building number and street from an address or text string
 */
export function extractAddressComponents(text: string): { houseNumber: string; streetName: string; fullAddress: string } {
  const clean = (text || '').trim();
  if (!clean) {
    return { houseNumber: '', streetName: '', fullAddress: '' };
  }

  // If this text is coordinate-only or location placeholder, return empty house number
  if (/^location\\s*\\(?/i.test(clean) || clean.toLowerCase() === 'location unavailable') {
    return { houseNumber: '', streetName: clean, fullAddress: clean };
  }

  // Strip route/stop ordering prefix if present (e.g., "002 - ", "Stop 2: ", "#002 - ")
  let addressText = clean.replace(/^(?:stop\\s*#?\\d+\\s*[-:–—]\\s*|#?0+\\d+\\s*[-:–—]\\s*)/i, '').trim();

  // Strip leading Unit/Apt/Suite if it precedes the address:
  // e.g., "Apt 4B, 123 Foster ville Road" -> "123 Foster ville Road"
  const unitPrefixMatch = addressText.match(/^(?:apt\\.?|apartment|unit|suite|ste\\.?|room|rm\\.?)\\s*#?[a-z0-9-]+\\s*,\\s*(.+)$/i);
  if (unitPrefixMatch) {
    addressText = unitPrefixMatch[1].trim();
  }

  const houseNumber = extractHouseNumber(addressText);

  let streetName = addressText;
  if (houseNumber) {
    const index = addressText.indexOf(houseNumber);
    if (index !== -1) {
      const afterHouse = addressText.slice(index + houseNumber.length).trim();
      const commaIndex = afterHouse.indexOf(',');
      if (commaIndex !== -1) {
        streetName = afterHouse.slice(0, commaIndex).trim();
      } else {
        streetName = afterHouse;
      }
    }
  }

  return {
    houseNumber,
    streetName: streetName || clean,
    fullAddress: clean,
  };
}

/**
 * Validates latitude and longitude values
 */
export function isValidCoordinate(lat: number, lon: number): boolean {
  return (
    !isNaN(lat) &&
    !isNaN(lon) &&
    lat >= -90 &&
    lat <= 90 &&
    lon >= -180 &&
    lon <= 180 &&
    !(lat === 0 && lon === 0)
  );
}

/**
 * Helper to get text content of a tag or namespaced tag safely from XML element
 */
function getTagText(parent: Element, tagName: string): string {
  // 1. Direct getElementsByTagName (e.g. 'name', 'desc', 'cmt')
  const el = parent.getElementsByTagName(tagName)[0];
  if (el?.textContent && el.textContent.trim()) {
    return el.textContent.trim();
  }

  // 2. Namespaced or child matches (e.g. 'osmand:housenumber', 'addr:housenumber')
  const children = Array.from(parent.children);
  for (const child of children) {
    if (child.localName === tagName || child.nodeName.endsWith(\`:\${tagName}\`)) {
      if (child.textContent?.trim()) return child.textContent.trim();
    }
    // Inspect inside <extensions>
    for (const sub of Array.from(child.children)) {
      if (sub.localName === tagName || sub.nodeName.endsWith(\`:\${tagName}\`)) {
        if (sub.textContent?.trim()) return sub.textContent.trim();
      }
    }
  }

  return '';
}

/**
 * Parses raw GPX XML and extracts customer stops in the exact order they appear in the file.
 * Safely handles OsmAnd marker extensions, custom namespaces, and distinguishes route sequence numbers from house numbers.
 */
export function parseGPX(gpxContent: string, routeNameDefault = 'Imported Route'): { stops: RouteStop[]; routeName: string } {
  const cleanedContent = (gpxContent || '').replace(/^\\uFEFF/, '').trim();
  if (!cleanedContent) {
    throw new Error('File content is empty.');
  }

  let xmlDoc: Document;
  if (typeof DOMParser !== 'undefined') {
    const parser = new DOMParser();
    xmlDoc = parser.parseFromString(cleanedContent, 'text/xml');
  } else {
    throw new Error('DOMParser unavailable in current runtime');
  }

  // Check for XML parsererror
  const parserError = xmlDoc.getElementsByTagName('parsererror')[0];
  if (parserError) {
    throw new Error('Invalid GPX/XML format. Please verify the file contains valid route/waypoint XML.');
  }

  // Extract route/metadata name if present
  let routeName = routeNameDefault;
  const metaEl = xmlDoc.getElementsByTagName('metadata')[0];
  const metaName = metaEl ? getTagText(metaEl, 'name') : '';
  const gpxName = getTagText(xmlDoc.documentElement, 'name');
  if (metaName) {
    routeName = metaName;
  } else if (gpxName) {
    routeName = gpxName;
  }

  // Collect points in exact file order.
  let pointElements = Array.from(xmlDoc.getElementsByTagName('wpt'));
  if (pointElements.length === 0) {
    pointElements = Array.from(xmlDoc.getElementsByTagName('rtept'));
  }
  if (pointElements.length === 0) {
    pointElements = Array.from(xmlDoc.getElementsByTagName('trkpt'));
  }

  if (pointElements.length === 0) {
    throw new Error('No customer waypoints (<wpt> or <rtept>) found in this GPX file.');
  }

  const stops: RouteStop[] = [];

  pointElements.forEach((pt, index) => {
    // 1. Coordinates parsing & validation
    const latStr = pt.getAttribute('lat');
    const lonStr = pt.getAttribute('lon');
    const parsedLat = latStr ? parseFloat(latStr) : NaN;
    const parsedLon = lonStr ? parseFloat(lonStr) : NaN;

    const hasValidCoords = isValidCoordinate(parsedLat, parsedLon);
    const finalLat = hasValidCoords ? parsedLat : 0;
    const finalLon = hasValidCoords ? parsedLon : 0;

    // 2. Text fields parsing
    const rawName = getTagText(pt, 'name');
    const rawDesc = getTagText(pt, 'desc');
    const rawCmt = getTagText(pt, 'cmt');
    const rawAddress = getTagText(pt, 'address');
    const osmandHouseNum = getTagText(pt, 'housenumber');
    const osmandStreet = getTagText(pt, 'street');

    // 3. Disambiguate customer name, stop sequence, and delivery address:
    let customerName = rawName || \`Customer #\${index + 1}\`;
    let addressCandidate = rawAddress || rawDesc || rawCmt;
    let potentialAddressFromName = '';

    // If rawName has a sequence prefix like "002 - Marcus Vance" or "002 - 123 Foster ville Road":
    if (rawName.includes(' - ') || rawName.includes(' – ')) {
      const parts = rawName.split(/\\s*[-–]\\s*/);
      if (parts.length >= 2) {
        // First part is a stop sequence (e.g. "001", "002", "Stop 1", "#2"):
        if (/^(?:stop\\s*)?#?\\d+$/i.test(parts[0].trim())) {
          customerName = parts.slice(1).join(' - ').trim();
          // If the remaining part is an address (e.g. "123 Foster ville Road")
          if (/^\\d+[A-Za-z]?\\s+[A-Za-z]/.test(customerName)) {
            potentialAddressFromName = customerName;
          }
        } else if (/^(?:stop\\s*)?#?\\d+$/i.test(parts[parts.length - 1].trim())) {
          // Trailing stop sequence e.g. "Marcus Vance - 002"
          customerName = parts.slice(0, parts.length - 1).join(' - ').trim();
        }
      }
    } else if (/^#?0*\\d+$/.test(rawName.trim())) {
      // Name is just a sequence number e.g. "002"
      const num = parseInt(rawName.trim().replace('#', ''), 10);
      customerName = \`Customer #\${num || (index + 1)}\`;
    }

    if (!addressCandidate && potentialAddressFromName) {
      addressCandidate = potentialAddressFromName;
    }

    // Fallback if no addressCandidate exists
    if (!addressCandidate) {
      addressCandidate = hasValidCoords
        ? \`Location (\${finalLat.toFixed(5)}, \${finalLon.toFixed(5)})\`
        : 'Location unavailable';
    }

    // 4. Extract genuine house number and street from the delivery address:
    const { houseNumber: parsedHouseNumber, streetName: parsedStreet, fullAddress } = extractAddressComponents(addressCandidate);
    
    // Explicit OsmAnd housenumber tag check (reject if it's a zero-padded stop sequence)
    let finalHouseNumber = parsedHouseNumber;
    if (!finalHouseNumber && osmandHouseNum && !/^0+\\d+$/.test(osmandHouseNum.trim())) {
      finalHouseNumber = osmandHouseNum.trim();
    }

    // If still not found and customerName has a street address pattern
    if (!finalHouseNumber && customerName) {
      const nameExtracted = extractAddressComponents(customerName);
      if (nameExtracted.houseNumber && !/^0+\\d+$/.test(nameExtracted.houseNumber)) {
        finalHouseNumber = nameExtracted.houseNumber;
      }
    }

    const finalStreetName = osmandStreet || parsedStreet || '';

    stops.push({
      id: \`stop-\${index + 1}-\${Date.now().toString(36)}-\${Math.random().toString(36).substring(2, 6)}\`,
      orderIndex: index + 1,
      name: customerName,
      houseNumber: finalHouseNumber,
      fullAddress: fullAddress,
      streetName: finalStreetName,
      lat: finalLat,
      lon: finalLon,
      desc: rawDesc || undefined,
      cmt: rawCmt || undefined,
      status: 'pending',
    });
  });

  return { stops, routeName };
}

/**
 * Generates valid GPX XML from RouteStop array (for export/OsmAnd companion download)
 */
export function exportToGPX(stops: RouteStop[], routeName = 'Customer Route'): string {
  const gpxHeader = \`<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="OsmAnd Route Companion" xmlns="http://www.topografix.com/GPX/1/1" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.topografix.com/GPX/1/1 http://www.topografix.com/GPX/1/1/gpx.xsd">
  <metadata>
    <name>\${escapeXml(routeName)}</name>
    <desc>Customer route stops in sequential order</desc>
    <time>\${new Date().toISOString()}</time>
  </metadata>
\`;

  const waypoints = stops.map((stop) => {
    return \`  <wpt lat="\${stop.lat}" lon="\${stop.lon}">
    <name>\${escapeXml(stop.name)}</name>
    <desc>\${escapeXml(stop.fullAddress)}</desc>
    <cmt>\${escapeXml(\`House #\${stop.houseNumber || 'N/A'} - Status: \${stop.status}\`)}</cmt>
  </wpt>\`;
  }).join('\\n');

  const gpxFooter = \`\\n</gpx>\`;
  return gpxHeader + waypoints + gpxFooter;
}

function escapeXml(unsafe: string): string {
  return (unsafe || '').replace(/[<>&'"]/g, (c) => {
    switch (c) {
      case '<': return '&lt;';
      case '>': return '&gt;';
      case '&': return '&amp;';
      case '\\'': return '&apos;';
      case '"': return '&quot;';
      default: return c;
    }
  });
}
`,J=`/**
 * Turn-by-Turn Navigation & Real-time GPS Service
 * Uses device GPS hardware and OpenStreetMap (OSRM) routing engine
 * Supports legal maneuver restrictions, U-turns, block rerouting, and off-route polyline tracking.
 */

export interface NavManeuver {
  type: string; // 'turn', 'depart', 'arrive', 'continue', 'fork', 'roundabout', etc.
  modifier?: string; // 'left', 'right', 'slight left', 'slight right', 'sharp left', 'sharp right', 'straight', 'uturn'
  instruction: string; // "Turn right onto Maple Grove Ave" or "Turn around as soon as possible."
  streetName: string;
  distanceMeters: number;
  location: [number, number]; // [lon, lat]
}

export interface NavigationState {
  currentManeuver: NavManeuver | null;
  distanceToManeuverMeters: number;
  totalDistanceToDestinationMeters: number;
  estimatedTimeSeconds: number;
  gpsActive: boolean;
  gpsAccuracyMeters: number | null;
  currentSpeedMph: number | null;
  currentHeading: number | null;
  lastUpdated: number;
  source: 'osm-live' | 'gps-direct' | 'simulated';
  error: string | null;
}

/**
 * Calculates distance in meters between two lat/lon points using the Haversine formula
 */
export function calculateDistanceMeters(lat1: number, lon1: number, lat2: number, lon2: number): number {
  if (
    isNaN(lat1) || isNaN(lon1) || isNaN(lat2) || isNaN(lon2) ||
    (lat1 === 0 && lon1 === 0) || (lat2 === 0 && lon2 === 0)
  ) {
    return Infinity;
  }
  const R = 6371000; // Earth's radius in meters
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) *
      Math.cos(lat2 * (Math.PI / 180)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Calculates distance in meters from a point to the nearest line segment in a GeoJSON polyline [lon, lat][]
 * Used for detecting off-route deviations when a driver misses a turn or leaves the planned road.
 */
export function calculateDistanceToPolylineMeters(
  pointLat: number,
  pointLon: number,
  coordinates: [number, number][]
): number {
  if (!coordinates || coordinates.length < 2) return Infinity;

  const mPerDegLat = 111132.92;
  const mPerDegLon = 111412.84 * Math.cos((pointLat * Math.PI) / 180);

  let minDistance = Infinity;

  for (let i = 0; i < coordinates.length - 1; i++) {
    const [lon1, lat1] = coordinates[i];
    const [lon2, lat2] = coordinates[i + 1];

    const px = (pointLon - lon1) * mPerDegLon;
    const py = (pointLat - lat1) * mPerDegLat;
    const sx = (lon2 - lon1) * mPerDegLon;
    const sy = (lat2 - lat1) * mPerDegLat;
    const lenSq = sx * sx + sy * sy;

    let d: number;
    if (lenSq === 0) {
      d = Math.sqrt(px * px + py * py);
    } else {
      const t = Math.max(0, Math.min(1, (px * sx + py * sy) / lenSq));
      const projX = t * sx;
      const projY = t * sy;
      const dx = px - projX;
      const dy = py - projY;
      d = Math.sqrt(dx * dx + dy * dy);
    }

    if (d < minDistance) {
      minDistance = d;
    }
  }

  return minDistance;
}

/**
 * Calculates remaining driving route distance in meters from the user's current GPS position
 * to the destination along the planned route coordinates polyline.
 * Continuously counts down as the vehicle advances along each road segment.
 */
export function calculateRemainingRouteDistanceMeters(
  pointLat: number,
  pointLon: number,
  coordinates: [number, number][],
  minSegmentIndex = 0
): { remainingMeters: number; closestSegmentIndex: number } {
  if (!coordinates || coordinates.length === 0) {
    return { remainingMeters: 0, closestSegmentIndex: 0 };
  }
  if (coordinates.length === 1) {
    const dist = calculateDistanceMeters(pointLat, pointLon, coordinates[0][1], coordinates[0][0]);
    return { remainingMeters: dist, closestSegmentIndex: 0 };
  }

  const mPerDegLat = 111132.92;
  const mPerDegLon = 111412.84 * Math.cos((pointLat * Math.PI) / 180);

  let bestSegmentIndex = Math.max(0, Math.min(minSegmentIndex, coordinates.length - 2));
  let minPerpDistanceSq = Infinity;
  let bestT = 0;

  // Search forward from previous segment progress (with a small look-back window for GPS jitter)
  const startIndex = Math.max(0, minSegmentIndex - 2);
  for (let i = startIndex; i < coordinates.length - 1; i++) {
    const [lon1, lat1] = coordinates[i];
    const [lon2, lat2] = coordinates[i + 1];

    const px = (pointLon - lon1) * mPerDegLon;
    const py = (pointLat - lat1) * mPerDegLat;
    const sx = (lon2 - lon1) * mPerDegLon;
    const sy = (lat2 - lat1) * mPerDegLat;
    const lenSq = sx * sx + sy * sy;

    if (lenSq === 0) continue;

    const t = Math.max(0, Math.min(1, (px * sx + py * sy) / lenSq));
    const projX = t * sx;
    const projY = t * sy;
    const dx = px - projX;
    const dy = py - projY;
    const distSq = dx * dx + dy * dy;

    if (distSq < minPerpDistanceSq) {
      minPerpDistanceSq = distSq;
      bestSegmentIndex = i;
      bestT = t;
    }
  }

  // 1. Remaining length on current segment from projected vehicle position to segment end
  const [bLon1, bLat1] = coordinates[bestSegmentIndex];
  const [bLon2, bLat2] = coordinates[bestSegmentIndex + 1];
  const currentSegDist = calculateDistanceMeters(bLat1, bLon1, bLat2, bLon2);
  let remainingMeters = Math.max(0, (1 - bestT) * currentSegDist);

  // 2. Sum length of all subsequent segments along the route
  for (let j = bestSegmentIndex + 1; j < coordinates.length - 1; j++) {
    remainingMeters += calculateDistanceMeters(
      coordinates[j][1],
      coordinates[j][0],
      coordinates[j + 1][1],
      coordinates[j + 1][0]
    );
  }

  return {
    remainingMeters: Math.max(0, Math.round(remainingMeters)),
    closestSegmentIndex: bestSegmentIndex,
  };
}

/**
 * Calculates compass bearing from point 1 to point 2 (0 - 360 degrees)
 */
export function calculateBearing(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const y = Math.sin((lon2 - lon1) * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180));
  const x =
    Math.cos(lat1 * (Math.PI / 180)) * Math.sin(lat2 * (Math.PI / 180)) -
    Math.sin(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * Math.cos((lon2 - lon1) * (Math.PI / 180));
  const brng = (Math.atan2(y, x) * 180) / Math.PI;
  return (brng + 360) % 360;
}

/**
 * Convert bearing degrees to cardinal direction name
 */
export function bearingToDirection(bearing: number): string {
  const directions = ['North', 'Northeast', 'East', 'Southeast', 'South', 'Southwest', 'West', 'Northwest'];
  const index = Math.round(bearing / 45) % 8;
  return directions[index];
}

/**
 * Format distance in feet and miles (or meters/km) for rapid driver glanceability
 */
export function formatDistance(meters: number, useMetric = false): string {
  if (isNaN(meters) || meters < 0) return '0 ft';

  if (useMetric) {
    if (meters < 1000) {
      return \`\${Math.round(meters)} m\`;
    }
    return \`\${(meters / 1000).toFixed(1)} km\`;
  }

  // Imperial (US) standard for in-vehicle navigation
  const feet = meters * 3.28084;
  if (feet < 1000) {
    if (feet > 200) {
      return \`\${Math.round(feet / 50) * 50} ft\`;
    }
    return \`\${Math.max(10, Math.round(feet / 10) * 10)} ft\`;
  }

  const miles = feet / 5280;
  if (miles < 10) {
    return \`\${miles.toFixed(1)} mi\`;
  }
  return \`\${Math.round(miles)} mi\`;
}

/**
 * Format estimated travel duration in minutes and hours
 */
export function formatDuration(seconds: number): string {
  if (isNaN(seconds) || seconds <= 0) return '1 min';
  const mins = Math.round(seconds / 60);
  if (mins < 60) {
    return \`\${Math.max(1, mins)} min\`;
  }
  const hours = Math.floor(mins / 60);
  const remMins = mins % 60;
  return remMins > 0 ? \`\${hours}h \${remMins}m\` : \`\${hours}h\`;
}

/**
 * Generates natural driver maneuver instructions from OSRM step.
 * Accurately formats U-turn instructions without fabricating them.
 */
export function buildInstructionText(type: string, modifier: string | undefined, streetName: string, destinationName: string): string {
  const street = streetName && streetName.trim() ? streetName.trim() : '';
  const mod = (modifier || '').toLowerCase();
  const t = (type || '').toLowerCase();

  if (t === 'arrive') {
    return destinationName ? \`Arrive at \${destinationName}\` : 'Arrive at destination';
  }
  if (t === 'depart') {
    return street ? \`Head out onto \${street}\` : 'Head toward destination';
  }
  if (t === 'merge') {
    return mod.includes('left')
      ? (street ? \`Merge left onto \${street}\` : 'Merge left')
      : (street ? \`Merge right onto \${street}\` : 'Merge right');
  }
  if (t === 'on ramp' || t === 'off ramp' || t === 'ramp') {
    return street ? \`Take ramp onto \${street}\` : 'Take ramp';
  }
  if (t === 'fork') {
    return mod.includes('left')
      ? (street ? \`Keep left at fork onto \${street}\` : 'Keep left at fork')
      : (street ? \`Keep right at fork onto \${street}\` : 'Keep right at fork');
  }
  if (t === 'roundabout' || t === 'rotary') {
    return street ? \`Enter roundabout toward \${street}\` : 'Enter roundabout';
  }
  if (t === 'end of road') {
    return mod.includes('left')
      ? (street ? \`Turn left at end onto \${street}\` : 'Turn left at end of road')
      : (street ? \`Turn right at end onto \${street}\` : 'Turn right at end of road');
  }

  // Turnaround maneuvers evaluated by the routing engine
  // Preferred exact wording: "Turn around as soon as possible."
  if (
    mod.includes('uturn') ||
    mod === 'uturn' ||
    mod.includes('turnaround') ||
    mod.includes('turn around') ||
    t === 'turnaround'
  ) {
    return 'Turn around as soon as possible.';
  }

  switch (mod) {
    case 'left':
      return street ? \`Turn left onto \${street}\` : 'Turn left';
    case 'right':
      return street ? \`Turn right onto \${street}\` : 'Turn right';
    case 'slight left':
      return street ? \`Bear slightly left onto \${street}\` : 'Bear slightly left';
    case 'slight right':
      return street ? \`Bear slightly right onto \${street}\` : 'Bear slightly right';
    case 'sharp left':
      return street ? \`Make a sharp left onto \${street}\` : 'Sharp left';
    case 'sharp right':
      return street ? \`Make a sharp right onto \${street}\` : 'Sharp right';
    case 'straight':
      return street ? \`Continue straight on \${street}\` : 'Continue straight';
    default:
      if (t === 'continue' || t === 'new name') {
        return street ? \`Continue onto \${street}\` : 'Continue straight';
      }
      return street ? \`Proceed onto \${street}\` : 'Proceed along route';
  }
}

/**
 * Fetches real turn-by-turn driving route steps from OpenStreetMap OSRM routing engine.
 * Supports start bearings for moving vehicle travel direction to ensure legal U-turns
 * vs routing around blocks.
 */
export async function fetchOsmRoute(
  startLat: number,
  startLon: number,
  destLat: number,
  destLon: number,
  destName: string,
  startBearing?: number | null
): Promise<{
  maneuvers: NavManeuver[];
  totalDistance: number;
  totalDuration: number;
  coordinates: [number, number][];
  hasUturn: boolean;
}> {
  const hasBearing = typeof startBearing === 'number' && !isNaN(startBearing) && startBearing >= 0 && startBearing <= 360;
  
  // Base OSRM URL with turn steps, detailed geometries, and continue_straight=false for flexible maneuvers
  const baseUrl = \`https://router.project-osrm.org/route/v1/driving/\${startLon},\${startLat};\${destLon},\${destLat}?steps=true&overview=full&geometries=geojson&continue_straight=false\`;
  
  // Helper to fetch and parse
  const executeQuery = async (queryUrl: string) => {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 7000);
    try {
      const response = await fetch(queryUrl, { signal: controller.signal });
      clearTimeout(timeoutId);
      if (!response.ok) {
        throw new Error(\`Routing server HTTP \${response.status}\`);
      }
      const data = await response.json();
      return data;
    } catch (err: any) {
      clearTimeout(timeoutId);
      throw err;
    }
  };

  let data: any = null;

  // 1. Try with start travel heading constraint if available
  if (hasBearing) {
    try {
      const bearingUrl = \`\${baseUrl}&bearings=\${Math.round(startBearing)},60;\`;
      const result = await executeQuery(bearingUrl);
      if (result.code === 'Ok' && result.routes && result.routes.length > 0) {
        data = result;
      }
    } catch (err) {
      // Fall through to unconstrained query
    }
  }

  // 2. Unconstrained fallback if bearing query failed or was not provided
  if (!data) {
    data = await executeQuery(baseUrl);
  }

  if (data.code !== 'Ok' || !data.routes || data.routes.length === 0) {
    throw new Error('No driving route found between coordinates');
  }

  const route = data.routes[0];
  const leg = route.legs?.[0];
  const steps = leg?.steps || [];
  const coordinates: [number, number][] = route.geometry?.coordinates || [];

  let hasUturn = false;

  const maneuvers: NavManeuver[] = steps.map((s: any) => {
    const type = s.maneuver?.type || 'turn';
    const modifier = s.maneuver?.modifier;
    const streetName = s.name || '';
    const instruction = buildInstructionText(type, modifier, streetName, destName);
    const location: [number, number] = s.maneuver?.location || [destLon, destLat];

    if (modifier && modifier.toLowerCase().includes('uturn')) {
      hasUturn = true;
    }

    return {
      type,
      modifier,
      instruction,
      streetName,
      distanceMeters: s.distance || 0,
      location,
    };
  });

  return {
    maneuvers,
    totalDistance: route.distance || 0,
    totalDuration: route.duration || 0,
    coordinates,
    hasUturn,
  };
}
`,bt=`export interface SampleRoutePreset {
  id: string;
  title: string;
  description: string;
  stopCount: number;
  gpxXml: string;
}

export const SAMPLE_GPX_ROUTES: SampleRoutePreset[] = [
  {
    id: 'residential-route-springfield',
    title: 'North Springfield Residential Route (20 Stops)',
    description: 'Sequenced customer stops for residential service with distinct house numbers & notes',
    stopCount: 20,
    gpxXml: \`<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="OsmAnd Route Companion" xmlns="http://www.topografix.com/GPX/1/1">
  <metadata>
    <name>North Springfield Residential Route</name>
    <desc>Customer collection and service route in sequence</desc>
  </metadata>
  <wpt lat="39.7990" lon="-89.6438">
    <name>Eleanor &amp; Frank Davies</name>
    <desc>104 Maple Grove Ave, Springfield, IL 62702</desc>
    <cmt>Side gate accessible, watch for golden retriever</cmt>
  </wpt>
  <wpt lat="39.8005" lon="-89.6450">
    <name>Marcus Vance</name>
    <desc>112 Maple Grove Ave, Springfield, IL 62702</desc>
    <cmt>Bin beside garage, ring bell if blocked</cmt>
  </wpt>
  <wpt lat="39.8018" lon="-89.6462">
    <name>Sophia Ramirez</name>
    <desc>128 Maple Grove Ave, Springfield, IL 62702</desc>
    <cmt>Curbside pickup requested</cmt>
  </wpt>
  <wpt lat="39.8035" lon="-89.6480">
    <name>Dr. Arthur Pendelton</name>
    <desc>215 Willow Creek Rd, Springfield, IL 62702</desc>
    <cmt>Long gravel driveway, turn around at circle</cmt>
  </wpt>
  <wpt lat="39.8049" lon="-89.6495">
    <name>Elena Rostova</name>
    <desc>229 Willow Creek Rd, Springfield, IL 62702</desc>
    <cmt>House number on stone mailbox</cmt>
  </wpt>
  <wpt lat="39.8062" lon="-89.6512">
    <name>Jackson &amp; Maya Miller</name>
    <desc>241 Willow Creek Rd, Springfield, IL 62702</desc>
    <cmt>Yellow house on corner</cmt>
  </wpt>
  <wpt lat="39.8080" lon="-89.6530">
    <name>Robert K. Sterling</name>
    <desc>304 Sycamore Lane, Springfield, IL 62702</desc>
    <cmt>Back alley approach preferred</cmt>
  </wpt>
  <wpt lat="39.8095" lon="-89.6548">
    <name>Hannah &amp; Liam Chen</name>
    <desc>318 Sycamore Lane, Springfield, IL 62702</desc>
    <cmt>Ring doorbell after stop</cmt>
  </wpt>
  <wpt lat="39.8110" lon="-89.6565">
    <name>George Henderson</name>
    <desc>330 Sycamore Lane, Springfield, IL 62702</desc>
    <cmt>Code for gate #4421</cmt>
  </wpt>
  <wpt lat="39.8125" lon="-89.6582">
    <name>Patricia &amp; Carl Kowalski</name>
    <desc>402 Birchwood Court, Springfield, IL 62702</desc>
    <cmt>Cul-de-sac house at end on left</cmt>
  </wpt>
  <wpt lat="39.8138" lon="-89.6601">
    <name>Devon Washington</name>
    <desc>415 Birchwood Court, Springfield, IL 62702</desc>
    <cmt>Leave invoice in mailbox slot</cmt>
  </wpt>
  <wpt lat="39.8152" lon="-89.6618">
    <name>Chloe &amp; Noah Bennett</name>
    <desc>520 Cedar Crest Way, Springfield, IL 62702</desc>
    <cmt>Red brick house with circular portico</cmt>
  </wpt>
  <wpt lat="39.8168" lon="-89.6635">
    <name>Samuel Ortiz</name>
    <desc>534 Cedar Crest Way, Springfield, IL 62702</desc>
    <cmt>Customer works from home, quiet approach</cmt>
  </wpt>
  <wpt lat="39.8182" lon="-89.6652">
    <name>Miriam Goldstein</name>
    <desc>601 Pine Needle Drive, Springfield, IL 62702</desc>
    <cmt>Keycard box next to service door</cmt>
  </wpt>
  <wpt lat="39.8198" lon="-89.6670">
    <name>Thomas &amp; Valerie Reed</name>
    <desc>615 Pine Needle Drive, Springfield, IL 62702</desc>
    <cmt>House number illuminated on porch column</cmt>
  </wpt>
  <wpt lat="39.8215" lon="-89.6690">
    <name>Amina Al-Mansoor</name>
    <desc>722 Juniper Park Blvd, Springfield, IL 62702</desc>
    <cmt>Corner lot with white vinyl fence</cmt>
  </wpt>
  <wpt lat="39.8230" lon="-89.6708">
    <name>Kenneth O'Connor</name>
    <desc>736 Juniper Park Blvd, Springfield, IL 62702</desc>
    <cmt>Please close latch securely</cmt>
  </wpt>
  <wpt lat="39.8248" lon="-89.6725">
    <name>Zoe &amp; Lucas Taylor</name>
    <desc>802 Hawthorn Ridge, Springfield, IL 62702</desc>
    <cmt>Call before arrival if gate locked</cmt>
  </wpt>
  <wpt lat="39.8265" lon="-89.6742">
    <name>Geraldine Brooks</name>
    <desc>818 Hawthorn Ridge, Springfield, IL 62702</desc>
    <cmt>Elderly resident, curbside staging</cmt>
  </wpt>
  <wpt lat="39.8280" lon="-89.6760">
    <name>Victor &amp; Beatrice Moreno</name>
    <desc>834 Hawthorn Ridge, Springfield, IL 62702</desc>
    <cmt>Final customer on morning route block</cmt>
  </wpt>
</gpx>\`,
  },
  {
    id: 'commercial-route-metro',
    title: 'Metro Commercial Route (10 Stops)',
    description: 'Commercial facilities, clinics, and businesses with suite numbers',
    stopCount: 10,
    gpxXml: \`<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="OsmAnd Route Companion" xmlns="http://www.topografix.com/GPX/1/1">
  <metadata>
    <name>Metro Commercial Route</name>
    <desc>Commercial client sequence</desc>
  </metadata>
  <wpt lat="39.7810" lon="-89.6500">
    <name>Apex Medical Labs - Suite 100</name>
    <desc>500 S 6th St, Springfield, IL 62701</desc>
    <cmt>Rear loading dock entrance, press buzzer B</cmt>
  </wpt>
  <wpt lat="39.7835" lon="-89.6520">
    <name>Capitol City Bakery</name>
    <desc>412 E Monroe St, Springfield, IL 62701</desc>
    <cmt>Service alley between 4th &amp; 5th</cmt>
  </wpt>
  <wpt lat="39.7860" lon="-89.6540">
    <name>Heritage Law Offices</name>
    <desc>620 E Adams St, Suite 300, Springfield, IL 62701</desc>
    <cmt>Elevator access to 3rd floor</cmt>
  </wpt>
  <wpt lat="39.7890" lon="-89.6570">
    <name>Lincoln Park Dental Clinic</name>
    <desc>805 N 9th St, Springfield, IL 62702</desc>
    <cmt>Staff entrance on north side</cmt>
  </wpt>
  <wpt lat="39.7920" lon="-89.6600">
    <name>Prairie State Veterinary</name>
    <desc>1120 N Walnut St, Springfield, IL 62702</desc>
    <cmt>Doorbell labeled Delivery/Service</cmt>
  </wpt>
  <wpt lat="39.7950" lon="-89.6630">
    <name>Oak Crest Senior Living</name>
    <desc>1400 W Washington St, Springfield, IL 62702</desc>
    <cmt>Check in at security desk Building A</cmt>
  </wpt>
  <wpt lat="39.7980" lon="-89.6660">
    <name>Green Valley Nursery</name>
    <desc>1850 W Jefferson St, Springfield, IL 62702</desc>
    <cmt>Drive through main gravel yard to warehouse</cmt>
  </wpt>
  <wpt lat="39.8010" lon="-89.6690">
    <name>Westside Auto Diagnostics</name>
    <desc>2204 W Monroe St, Springfield, IL 62704</desc>
    <cmt>Bay 3 entrance, ask for Sal</cmt>
  </wpt>
  <wpt lat="39.8040" lon="-89.6720">
    <name>Midwest Fitness Center</name>
    <desc>2600 S MacArthur Blvd, Springfield, IL 62704</desc>
    <cmt>South equipment dock</cmt>
  </wpt>
  <wpt lat="39.8070" lon="-89.6750">
    <name>Chatham Community Bank</name>
    <desc>3100 S 6th St, Springfield, IL 62703</desc>
    <cmt>Authorized personnel entry only</cmt>
  </wpt>
</gpx>\`,
  },
];
`,xt=`import { useState, useEffect, useRef, useCallback } from 'react';
import { RouteStop } from '../types/route';
import { calculateDistanceMeters, calculateBearing } from './navigationService';
import { triggerHaptic } from './voiceAndHaptics';

export interface GpsLocation {
  lat: number;
  lon: number;
  accuracy: number;
  speed: number | null; // mph
  heading: number | null;
  timestamp: number;
}

export interface UseGpsTrackerReturn {
  location: GpsLocation | null;
  gpsStatus: 'acquiring' | 'locked' | 'denied';
  gpsErrorMsg: string | null;
  distanceToCurrentMeters: number | null;
  distanceToCurrentFeet: number | null;
  isWithinGeofence: boolean;
  isSharedLocationWithPrevious: boolean;
  isSharedLocationWithNext: boolean;
  autoArrivalStatus: string;
  arrivalRadiusMeters: number;
  isPassedWithoutCompletion: boolean;
  simulateApproachAndPass: () => void;
  simulateApproachAndArrive: () => void;
  isSimulatingGps: boolean;
  stopGpsSimulation: () => void;
}

// Configurable constants and safeguards
export const DEFAULT_ARRIVAL_RADIUS_METERS = 50.0; // ~164 feet
const MAX_ACCURACY_THRESHOLD_METERS = 40.0; // Filter out inaccurate GPS drift
const COOLDOWN_MS = 5000; // Minimum time between auto-advances (5 seconds)
const PASSING_DISTANCE_INCREASE_METERS = 18.0; // Distance must expand by 18m from closest point to confirm vehicle passed

/**
 * Validate latitude and longitude coordinates
 */
export function isValidCoordinate(lat: number, lon: number): boolean {
  return (
    !isNaN(lat) &&
    !isNaN(lon) &&
    lat >= -90 &&
    lat <= 90 &&
    lon >= -180 &&
    lon <= 180 &&
    !(lat === 0 && lon === 0)
  );
}

/**
 * Calculates whether the straight line path between two consecutive GPS fixes
 * passed within radiusMeters of destination coordinates.
 */
export function checkSegmentPassesPoint(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
  destLat: number,
  destLon: number,
  radiusMeters: number
): { passed: boolean; minDistance: number; t: number } {
  const latRad = (destLat * Math.PI) / 180;
  const cosLat = Math.cos(latRad);
  const mPerDegLat = 111132.92;
  const mPerDegLon = 111412.84 * cosLat;

  const x1 = (lon1 - destLon) * mPerDegLon;
  const y1 = (lat1 - destLat) * mPerDegLat;
  const x2 = (lon2 - destLon) * mPerDegLon;
  const y2 = (lat2 - destLat) * mPerDegLat;

  const dx = x2 - x1;
  const dy = y2 - y1;
  const lenSq = dx * dx + dy * dy;

  if (lenSq === 0) {
    const d = Math.sqrt(x1 * x1 + y1 * y1);
    return { passed: d <= radiusMeters, minDistance: d, t: 0 };
  }

  const t = -(x1 * dx + y1 * dy) / lenSq;

  if (t > 0 && t < 1) {
    const projX = x1 + t * dx;
    const projY = y1 + t * dy;
    const minDistance = Math.sqrt(projX * projX + projY * projY);
    return { passed: minDistance <= radiusMeters, minDistance, t };
  }

  const d1 = Math.sqrt(x1 * x1 + y1 * y1);
  const d2 = Math.sqrt(x2 * x2 + y2 * y2);
  const minDistance = Math.min(d1, d2);
  return { passed: minDistance <= radiusMeters, minDistance, t };
}

export function useGpsTracker(
  currentStop: RouteStop | null,
  previousStop: RouteStop | null,
  nextStop: RouteStop | null,
  onAutoAdvance: () => void,
  arrivalRadiusMeters: number = DEFAULT_ARRIVAL_RADIUS_METERS,
  roadRemainingMeters?: number | null
): UseGpsTrackerReturn {
  const [location, setLocation] = useState<GpsLocation | null>(null);
  const [gpsStatus, setGpsStatus] = useState<'acquiring' | 'locked' | 'denied'>('acquiring');
  const [gpsErrorMsg, setGpsErrorMsg] = useState<string | null>(null);
  const [arrivalStateDesc, setArrivalStateDesc] = useState<string>('Monitoring GPS');
  const [isPassedWithoutCompletion, setIsPassedWithoutCompletion] = useState<boolean>(false);

  // Simulation state for phone/desktop indoor testing
  const [isSimulatingGps, setIsSimulatingGps] = useState(false);
  const simIntervalRef = useRef<number | null>(null);

  // Safeguard & Tracking Refs
  const minDistanceSeenRef = useRef<number>(Infinity);
  const enteredArrivalZoneRef = useRef<boolean>(false);
  const consecutiveInsideCountRef = useRef<number>(0);
  const lastLocationRef = useRef<GpsLocation | null>(null);
  const lastAdvanceTimestampRef = useRef<number>(0);
  const lastAdvancedStopIdRef = useRef<string | null>(null);
  const isAdvancingRef = useRef<boolean>(false);
  const departurePendingRef = useRef<boolean>(false);
  const activeStopIdRef = useRef<string | null>(null);

  // Keep stable refs to latest props to prevent watchPosition re-binding
  const currentStopRef = useRef(currentStop);
  currentStopRef.current = currentStop;

  const previousStopRef = useRef(previousStop);
  previousStopRef.current = previousStop;

  const nextStopRef = useRef(nextStop);
  nextStopRef.current = nextStop;

  const onAutoAdvanceRef = useRef(onAutoAdvance);
  onAutoAdvanceRef.current = onAutoAdvance;

  const arrivalRadiusRef = useRef(arrivalRadiusMeters);
  arrivalRadiusRef.current = arrivalRadiusMeters;

  const roadRemainingMetersRef = useRef(roadRemainingMeters);
  roadRemainingMetersRef.current = roadRemainingMeters;

  // Shared location check (within 18m of previous/next stop)
  const isSharedLocationWithPrevious = Boolean(
    currentStop &&
    previousStop &&
    isValidCoordinate(currentStop.lat, currentStop.lon) &&
    isValidCoordinate(previousStop.lat, previousStop.lon) &&
    calculateDistanceMeters(currentStop.lat, currentStop.lon, previousStop.lat, previousStop.lon) < 18
  );

  const isSharedLocationWithNext = Boolean(
    currentStop &&
    nextStop &&
    isValidCoordinate(currentStop.lat, currentStop.lon) &&
    isValidCoordinate(nextStop.lat, nextStop.lon) &&
    calculateDistanceMeters(currentStop.lat, currentStop.lon, nextStop.lat, nextStop.lon) < 18
  );

  const isSharedLocationWithPreviousRef = useRef(isSharedLocationWithPrevious);
  isSharedLocationWithPreviousRef.current = isSharedLocationWithPrevious;

  // Reset tracking state whenever the active customer changes
  useEffect(() => {
    const newStopId = currentStop?.id || null;
    if (newStopId !== activeStopIdRef.current) {
      activeStopIdRef.current = newStopId;
      minDistanceSeenRef.current = Infinity;
      enteredArrivalZoneRef.current = false;
      consecutiveInsideCountRef.current = 0;
      isAdvancingRef.current = false;
      setIsPassedWithoutCompletion(false);

      // If driver is currently inside arrival radius of the NEW stop at activation,
      // require departure/movement or dwell cooldown before allowing auto-advance.
      if (
        location &&
        currentStop &&
        isValidCoordinate(currentStop.lat, currentStop.lon)
      ) {
        const d = calculateDistanceMeters(location.lat, location.lon, currentStop.lat, currentStop.lon);
        if (d <= arrivalRadiusRef.current) {
          departurePendingRef.current = true;
        } else {
          departurePendingRef.current = false;
        }
      } else {
        departurePendingRef.current = false;
      }
    }
  }, [currentStop?.id]);

  /**
   * Core Arrival & Missed Stop Decision Engine
   * Evaluates current GPS location against verified coordinates of currentStop.
   * Enforces reliable arrival confirmation: does NOT auto-complete if driver merely drives past without stopping.
   */
  const processLocationUpdate = useCallback((currentLoc: GpsLocation) => {
    const activeStop = currentStopRef.current;
    if (!activeStop) {
      setArrivalStateDesc('No Active Route');
      return;
    }

    // 1. Verify Destination Coordinates
    if (!isValidCoordinate(activeStop.lat, activeStop.lon)) {
      setArrivalStateDesc('Invalid Destination Coordinates (Manual Skip)');
      return;
    }

    // 2. Filter out poor accuracy readings (e.g. initial tower jump > 40m)
    if (currentLoc.accuracy > MAX_ACCURACY_THRESHOLD_METERS) {
      setArrivalStateDesc(\`GPS Accuracy Low (±\${Math.round(currentLoc.accuracy * 3.28084)} ft)\`);
      return;
    }

    const radius = arrivalRadiusRef.current;
    const distToDestination = calculateDistanceMeters(
      currentLoc.lat,
      currentLoc.lon,
      activeStop.lat,
      activeStop.lon
    );

    // Track minimum distance seen for this active stop
    if (distToDestination < minDistanceSeenRef.current) {
      minDistanceSeenRef.current = distToDestination;
    }

    const prevLoc = lastLocationRef.current;
    const now = Date.now();

    // 3. Prevent immediate cascade / double advance
    if (isAdvancingRef.current) return;
    if (now - lastAdvanceTimestampRef.current < COOLDOWN_MS) return;
    if (lastAdvancedStopIdRef.current === activeStop.id) return;

    // 4. Shared Location Safeguard (Multi-unit building or shared entrance)
    if (isSharedLocationWithPreviousRef.current && lastAdvancedStopIdRef.current === previousStopRef.current?.id) {
      setArrivalStateDesc('Shared Address · Tap Skip when done');
      return;
    }

    // 5. Departure Latch
    if (departurePendingRef.current) {
      if (distToDestination > radius * 1.1) {
        departurePendingRef.current = false;
      } else if (now - lastAdvanceTimestampRef.current > 8000 && !isSharedLocationWithPreviousRef.current) {
        departurePendingRef.current = false;
      } else {
        setArrivalStateDesc('Departing Previous Stop...');
        return;
      }
    }

    // 6. Parallel Road Rejection
    const roadDist = roadRemainingMetersRef.current;
    if (roadDist !== undefined && roadDist !== null && roadDist > Math.max(radius * 2.2, 120)) {
      setArrivalStateDesc(\`Parallel Road / Route Distance \${Math.round(roadDist * 3.28084)} ft\`);
      return;
    }

    let isReliablyArrived = false;
    let arrivalReason = '';

    // ========================================================
    // CRITERION 1: RELIABLY CONFIRMED ARRIVAL
    // Driver reached the stop AND slowed down / stopped or dwelled,
    // OR parked within very close range (<= 15 meters)
    // ========================================================
    if (distToDestination <= radius) {
      enteredArrivalZoneRef.current = true;
      consecutiveInsideCountRef.current += 1;

      // Delivery driver has slowed down / stopped to deliver package
      const isStoppedOrCrawling = currentLoc.speed !== null && currentLoc.speed <= 5.0;
      const isVeryClose = distToDestination <= 15.0; // 50 feet curbside/driveway

      if (isStoppedOrCrawling || consecutiveInsideCountRef.current >= 2 || isVeryClose) {
        isReliablyArrived = true;
        arrivalReason = \`Reached destination (\${Math.round(distToDestination * 3.28084)} ft)\`;
      } else {
        setArrivalStateDesc(\`In Arrival Zone (\${Math.round(distToDestination * 3.28084)} ft)\`);
      }
    } else {
      consecutiveInsideCountRef.current = 0;
    }

    // ========================================================
    // CRITERION 2: MISSED DESTINATION / PASSED WITHOUT COMPLETION
    // Driver drove past the destination without stopping to deliver!
    // We DO NOT mark completed. Instead, we signal for route recalculation!
    // ========================================================
    if (!isReliablyArrived && minDistanceSeenRef.current <= radius * 1.6) {
      // Distance was close to customer, and is now expanding by at least 18 meters
      const isExpanding = distToDestination >= minDistanceSeenRef.current + PASSING_DISTANCE_INCREASE_METERS;
      const isMovingAway = prevLoc ? distToDestination > calculateDistanceMeters(prevLoc.lat, prevLoc.lon, activeStop.lat, activeStop.lon) : false;

      // Check heading: points away from destination
      const bearingToDest = calculateBearing(currentLoc.lat, currentLoc.lon, activeStop.lat, activeStop.lon);
      let headingPointsAway = false;
      if (currentLoc.heading !== null) {
        const diff = Math.abs(currentLoc.heading - bearingToDest);
        const normalizedDiff = diff > 180 ? 360 - diff : diff;
        headingPointsAway = normalizedDiff > 75;
      }

      if (isExpanding && (isMovingAway || headingPointsAway)) {
        // Vehicle passed the customer without stopping!
        setIsPassedWithoutCompletion(true);
        setArrivalStateDesc(\`Missed stop (\${Math.round(distToDestination * 3.28084)} ft) · Recalculating...\`);
        lastLocationRef.current = currentLoc;
        return;
      }
    }

    // ========================================================
    // EXECUTE CONFIRMED ARRIVAL
    // ========================================================
    if (isReliablyArrived) {
      isAdvancingRef.current = true;
      lastAdvanceTimestampRef.current = now;
      lastAdvancedStopIdRef.current = activeStop.id;
      enteredArrivalZoneRef.current = false;
      consecutiveInsideCountRef.current = 0;
      minDistanceSeenRef.current = Infinity;
      setIsPassedWithoutCompletion(false);

      setArrivalStateDesc(\`Arrived: \${arrivalReason}\`);
      triggerHaptic('complete');
      onAutoAdvanceRef.current();
      return;
    }

    // Normal navigation progress tracking
    if (!enteredArrivalZoneRef.current) {
      const feet = Math.round(distToDestination * 3.28084);
      setArrivalStateDesc(\`\${feet} ft to customer (Zone: \${Math.round(radius * 3.28084)} ft)\`);
    }

    lastLocationRef.current = currentLoc;
  }, []);

  // Mount native Android GPS watcher
  useEffect(() => {
    if (typeof window === 'undefined' || !('geolocation' in navigator)) {
      setGpsStatus('denied');
      setGpsErrorMsg('GPS hardware not supported by this browser.');
      return;
    }

    setGpsStatus('acquiring');

    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        if (isSimulatingGps) return;

        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;
        const accuracy = pos.coords.accuracy || 8;
        const speed = pos.coords.speed !== null && pos.coords.speed >= 0
          ? Math.round(pos.coords.speed * 2.23694)
          : null;
        const heading = pos.coords.heading !== null && !isNaN(pos.coords.heading)
          ? pos.coords.heading
          : null;

        const currentLoc: GpsLocation = {
          lat,
          lon,
          accuracy,
          speed,
          heading,
          timestamp: pos.timestamp || Date.now(),
        };

        setLocation(currentLoc);
        setGpsStatus('locked');
        setGpsErrorMsg(null);

        processLocationUpdate(currentLoc);
      },
      (err) => {
        if (isSimulatingGps) return;
        setGpsStatus('denied');
        setGpsErrorMsg(err.message || 'GPS hardware access denied.');
      },
      {
        enableHighAccuracy: true,
        maximumAge: 1000,
        timeout: 10000,
      }
    );

    return () => {
      try {
        navigator.geolocation.clearWatch(watchId);
      } catch (e) {}
    };
  }, [processLocationUpdate, isSimulatingGps]);

  // Clean up any running simulation on unmount
  useEffect(() => {
    return () => {
      if (simIntervalRef.current) {
        window.clearInterval(simIntervalRef.current);
      }
    };
  }, []);

  /**
   * Interactive Simulator 1: Approach, stop at address, confirm arrival, and advance.
   */
  const simulateApproachAndArrive = useCallback(() => {
    const activeStop = currentStopRef.current;
    if (!activeStop || !isValidCoordinate(activeStop.lat, activeStop.lon)) return;

    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    setIsSimulatingGps(true);
    setGpsStatus('locked');
    setGpsErrorMsg(null);
    setIsPassedWithoutCompletion(false);

    const latMeters = 111132.92;
    const destLat = activeStop.lat;
    const destLon = activeStop.lon;

    // Approaching: -120m -> -60m -> -20m (inside zone) -> 0m (stopped at curbside)
    const waypoints = [
      { offset: -120, speed: 25 },
      { offset: -70, speed: 18 },
      { offset: -25, speed: 8 },
      { offset: 0, speed: 0 }, // Stopped at customer
      { offset: 0, speed: 0 }, // Dwell at customer -> confirms arrival
    ];
    let step = 0;

    simIntervalRef.current = window.setInterval(() => {
      if (step >= waypoints.length) {
        if (simIntervalRef.current) {
          window.clearInterval(simIntervalRef.current);
          simIntervalRef.current = null;
        }
        setIsSimulatingGps(false);
        return;
      }

      const wp = waypoints[step];
      const simLat = destLat + (wp.offset / latMeters);
      const simLon = destLon;

      const simLoc: GpsLocation = {
        lat: simLat,
        lon: simLon,
        accuracy: 3,
        speed: wp.speed,
        heading: 0,
        timestamp: Date.now(),
      };

      setLocation(simLoc);
      processLocationUpdate(simLoc);

      step += 1;
    }, 1100);
  }, [processLocationUpdate]);

  /**
   * Interactive Simulator 2: Approach, DRIVE PAST at 25 mph without stopping,
   * triggers live OSRM route recalculation (legal U-turn or around the block)!
   */
  const simulateApproachAndPass = useCallback(() => {
    const activeStop = currentStopRef.current;
    if (!activeStop || !isValidCoordinate(activeStop.lat, activeStop.lon)) return;

    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    setIsSimulatingGps(true);
    setGpsStatus('locked');
    setGpsErrorMsg(null);

    const latMeters = 111132.92;
    const destLat = activeStop.lat;
    const destLon = activeStop.lon;

    // Passes from -100m south to +80m north without slowing down
    const waypoints = [
      { offset: -100, speed: 25 },
      { offset: -45, speed: 25 },
      { offset: 0, speed: 25 }, // Driven directly past
      { offset: 45, speed: 25 }, // Missed address, continuing down street
      { offset: 90, speed: 25 }, // Recalculation active
    ];
    let step = 0;

    simIntervalRef.current = window.setInterval(() => {
      if (step >= waypoints.length) {
        if (simIntervalRef.current) {
          window.clearInterval(simIntervalRef.current);
          simIntervalRef.current = null;
        }
        setIsSimulatingGps(false);
        return;
      }

      const wp = waypoints[step];
      const simLat = destLat + (wp.offset / latMeters);
      const simLon = destLon + (12 / (latMeters * Math.cos(destLat * Math.PI / 180)));

      const simLoc: GpsLocation = {
        lat: simLat,
        lon: simLon,
        accuracy: 4,
        speed: wp.speed,
        heading: 0, // Traveling North away from destination
        timestamp: Date.now(),
      };

      setLocation(simLoc);
      processLocationUpdate(simLoc);

      step += 1;
    }, 1200);
  }, [processLocationUpdate]);

  const stopGpsSimulation = useCallback(() => {
    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }
    setIsSimulatingGps(false);
  }, []);

  // Calculated reactive metrics for UI display
  let distanceToCurrentMeters: number | null = null;
  let distanceToCurrentFeet: number | null = null;
  let isWithinGeofence = false;

  if (location && currentStop && isValidCoordinate(currentStop.lat, currentStop.lon)) {
    distanceToCurrentMeters = calculateDistanceMeters(location.lat, location.lon, currentStop.lat, currentStop.lon);
    distanceToCurrentFeet = Math.round(distanceToCurrentMeters * 3.28084);
    isWithinGeofence = distanceToCurrentMeters <= arrivalRadiusMeters;
  }

  let finalArrivalStatus = arrivalStateDesc;
  if (gpsStatus === 'denied') {
    finalArrivalStatus = 'GPS Disabled';
  } else if (gpsStatus === 'acquiring') {
    finalArrivalStatus = 'Acquiring Satellites...';
  } else if (isPassedWithoutCompletion) {
    finalArrivalStatus = \`Passed stop (\${distanceToCurrentFeet} ft) · Recalculating...\`;
  } else if (isSimulatingGps) {
    finalArrivalStatus = \`Simulating Road Progress (\${distanceToCurrentFeet} ft)\`;
  } else if (isWithinGeofence) {
    finalArrivalStatus = isSharedLocationWithPrevious
      ? 'Shared Address · Tap Skip when done'
      : \`In Zone (\${distanceToCurrentFeet} ft / \${Math.round(arrivalRadiusMeters * 3.28084)} ft)\`;
  }

  return {
    location,
    gpsStatus,
    gpsErrorMsg,
    distanceToCurrentMeters,
    distanceToCurrentFeet,
    isWithinGeofence,
    isSharedLocationWithPrevious,
    isSharedLocationWithNext,
    autoArrivalStatus: finalArrivalStatus,
    arrivalRadiusMeters,
    isPassedWithoutCompletion,
    simulateApproachAndPass,
    simulateApproachAndArrive,
    isSimulatingGps,
    stopGpsSimulation,
  };
}
`,St=`import { useState, useEffect, useRef, useCallback } from 'react';
import { RouteStop } from '../types/route';
import { GpsLocation } from './useGpsTracker';
import { 
  NavManeuver, 
  fetchOsmRoute, 
  calculateDistanceMeters, 
  calculateDistanceToPolylineMeters,
  formatDistance, 
  formatDuration 
} from './navigationService';
import { isValidCoordinate } from './gpxParser';

export interface RoadNavigationState {
  currentManeuver: NavManeuver | null;
  nextManeuver: NavManeuver | null;
  maneuverIndex: number;
  totalManeuvers: number;
  distanceToTurnMeters: number;
  distanceToTurnFormatted: string;
  totalDistanceMeters: number;
  totalDistanceFormatted: string;
  totalDurationSeconds: number;
  totalDurationFormatted: string;
  isRouting: boolean;
  routingError: string | null;
  hasUturn: boolean;
  isSimulating: boolean;
  toggleSimulation: () => void;
  restartRoute: () => void;
  recalculate: () => void;
}

export function useRoadNavigation(
  currentStop: RouteStop | null,
  previousStop?: RouteStop,
  userLocation: GpsLocation | null = null,
  gpsStatus: 'acquiring' | 'locked' | 'denied' = 'acquiring'
): RoadNavigationState {
  const [maneuvers, setManeuvers] = useState<NavManeuver[]>([]);
  const [routeCoordinates, setRouteCoordinates] = useState<[number, number][]>([]);
  const [currentManeuverIndex, setCurrentManeuverIndex] = useState(0);
  const [distanceToTurnMeters, setDistanceToTurnMeters] = useState(0);
  const [totalDistanceMeters, setTotalDistanceMeters] = useState(0);
  const [totalDurationSeconds, setTotalDurationSeconds] = useState(0);
  const [isRouting, setIsRouting] = useState(false);
  const [routingError, setRoutingError] = useState<string | null>(null);
  const [hasUturn, setHasUturn] = useState<boolean>(false);

  // Simulation mode
  const [isSimulating, setIsSimulating] = useState(false);
  const simulationRef = useRef<number | null>(null);
  const simProgressRef = useRef(0);

  const lastRoutedCoords = useRef<{
    startLat: number;
    startLon: number;
    destLat: number;
    destLon: number;
  } | null>(null);

  const lastRerouteTimestamp = useRef<number>(0);

  // Determine starting point: live GPS if valid, else previous stop, else realistic offset
  const getStartPoint = useCallback((): { lat: number; lon: number; heading: number | null } | null => {
    if (userLocation && isValidCoordinate(userLocation.lat, userLocation.lon)) {
      return { 
        lat: userLocation.lat, 
        lon: userLocation.lon, 
        heading: userLocation.heading ?? null 
      };
    }
    if (previousStop && isValidCoordinate(previousStop.lat, previousStop.lon)) {
      return { 
        lat: previousStop.lat, 
        lon: previousStop.lon, 
        heading: null 
      };
    }
    if (currentStop && isValidCoordinate(currentStop.lat, currentStop.lon)) {
      return { 
        lat: currentStop.lat - 0.005, 
        lon: currentStop.lon - 0.004, 
        heading: 45 
      };
    }
    return null;
  }, [userLocation, previousStop, currentStop]);

  // Fetch actual OSRM road route
  const fetchRoute = useCallback(async (forced = false) => {
    if (!currentStop || !isValidCoordinate(currentStop.lat, currentStop.lon)) {
      setManeuvers([]);
      setRouteCoordinates([]);
      return;
    }

    const start = getStartPoint();
    if (!start) return;

    if (!forced && lastRoutedCoords.current) {
      const distStart = calculateDistanceMeters(
        start.lat, start.lon,
        lastRoutedCoords.current.startLat, lastRoutedCoords.current.startLon
      );
      const distDest = calculateDistanceMeters(
        currentStop.lat, currentStop.lon,
        lastRoutedCoords.current.destLat, lastRoutedCoords.current.destLon
      );
      if (distStart < 50 && distDest < 20 && maneuvers.length > 0) {
        return;
      }
    }

    setIsRouting(true);
    setRoutingError(null);

    try {
      const route = await fetchOsmRoute(
        start.lat,
        start.lon,
        currentStop.lat,
        currentStop.lon,
        currentStop.name,
        start.heading
      );

      if (route.maneuvers.length > 0) {
        setManeuvers(route.maneuvers);
        setRouteCoordinates(route.coordinates);
        setCurrentManeuverIndex(0);
        setTotalDistanceMeters(route.totalDistance);
        setTotalDurationSeconds(route.totalDuration);
        setDistanceToTurnMeters(route.maneuvers[0]?.distanceMeters || 0);
        setHasUturn(route.hasUturn);

        lastRoutedCoords.current = {
          startLat: start.lat,
          startLon: start.lon,
          destLat: currentStop.lat,
          destLon: currentStop.lon,
        };
        lastRerouteTimestamp.current = Date.now();
      }
    } catch (err: any) {
      console.warn('Road routing error:', err);
      setRoutingError(err.message || 'Routing unavailable');
    } finally {
      setIsRouting(false);
    }
  }, [currentStop, getStartPoint, maneuvers.length]);

  // Initial route fetch on stop change
  useEffect(() => {
    simProgressRef.current = 0;
    setCurrentManeuverIndex(0);
    lastRoutedCoords.current = null;
    fetchRoute();
  }, [currentStop?.id, currentStop?.lat, currentStop?.lon]);

  // Live vehicle progress update and off-route recalculation
  useEffect(() => {
    if (isSimulating || maneuvers.length === 0 || !userLocation) return;

    const currentM = maneuvers[currentManeuverIndex];
    if (!currentM) return;

    // Check if off-route from polyline (> 45m away)
    const now = Date.now();
    if (routeCoordinates.length > 1 && now - lastRerouteTimestamp.current > 4000) {
      const distToPolyline = calculateDistanceToPolylineMeters(userLocation.lat, userLocation.lon, routeCoordinates);
      if (distToPolyline > 45) {
        fetchRoute(true);
        return;
      }
    }

    // Calculate real distance to current maneuver waypoint
    const [turnLon, turnLat] = currentM.location;
    const distToManeuver = calculateDistanceMeters(userLocation.lat, userLocation.lon, turnLat, turnLon);

    // If within 25 meters (80 ft) of turn point, advance to next maneuver
    if (distToManeuver < 25 && currentManeuverIndex < maneuvers.length - 1) {
      setCurrentManeuverIndex((idx) => idx + 1);
      const nextM = maneuvers[currentManeuverIndex + 1];
      setDistanceToTurnMeters(nextM ? nextM.distanceMeters : 0);
    } else {
      setDistanceToTurnMeters(Math.max(0, Math.round(distToManeuver)));
    }
  }, [userLocation, maneuvers, currentManeuverIndex, isSimulating, routeCoordinates, fetchRoute]);

  // Simulation timer
  useEffect(() => {
    if (!isSimulating || maneuvers.length === 0) {
      if (simulationRef.current) {
        window.clearInterval(simulationRef.current);
        simulationRef.current = null;
      }
      return;
    }

    let currentDist = maneuvers[currentManeuverIndex]?.distanceMeters || 300;
    setDistanceToTurnMeters(currentDist);

    simulationRef.current = window.setInterval(() => {
      currentDist -= 20;
      if (currentDist <= 20) {
        setCurrentManeuverIndex((prev) => {
          if (prev >= maneuvers.length - 1) {
            setIsSimulating(false);
            return prev;
          }
          const nextIdx = prev + 1;
          currentDist = maneuvers[nextIdx]?.distanceMeters || 200;
          return nextIdx;
        });
      }
      setDistanceToTurnMeters(Math.max(10, currentDist));
      setTotalDistanceMeters((tot) => Math.max(0, tot - 20));
      setTotalDurationSeconds((dur) => Math.max(0, dur - 1.5));
    }, 800);

    return () => {
      if (simulationRef.current) {
        window.clearInterval(simulationRef.current);
      }
    };
  }, [isSimulating, maneuvers, currentManeuverIndex]);

  const toggleSimulation = useCallback(() => {
    setIsSimulating((s) => !s);
  }, []);

  const restartRoute = useCallback(() => {
    simProgressRef.current = 0;
    setCurrentManeuverIndex(0);
    if (maneuvers.length > 0) {
      setDistanceToTurnMeters(maneuvers[0].distanceMeters);
    }
  }, [maneuvers]);

  const recalculate = useCallback(() => {
    fetchRoute(true);
  }, [fetchRoute]);

  const currentM = maneuvers[currentManeuverIndex] || null;
  const nextM = maneuvers[currentManeuverIndex + 1] || null;

  return {
    currentManeuver: currentM,
    nextManeuver: nextM,
    maneuverIndex: currentManeuverIndex,
    totalManeuvers: maneuvers.length,
    distanceToTurnMeters,
    distanceToTurnFormatted: formatDistance(distanceToTurnMeters),
    totalDistanceMeters,
    totalDistanceFormatted: formatDistance(totalDistanceMeters),
    totalDurationSeconds,
    totalDurationFormatted: formatDuration(totalDurationSeconds),
    isRouting,
    routingError,
    hasUturn,
    isSimulating,
    toggleSimulation,
    restartRoute,
    recalculate,
  };
}
`,Ct=`/**
 * Tactile haptic feedback for Samsung Android devices and browsers
 */
export function triggerHaptic(type: 'tap' | 'skip' | 'next' | 'undo' | 'complete' = 'tap') {
  if (typeof window === 'undefined') return;

  // 1. Prefer native Android Bridge if running inside Android APK wrapper
  try {
    const androidBridge = (window as any).AndroidBridge;
    if (androidBridge && typeof androidBridge.vibrate === 'function') {
      androidBridge.vibrate(type);
      return;
    }
  } catch (err) {
    // Non-blocking
  }

  // 2. Web browser fallback with navigator.vibrate
  if (!('vibrate' in navigator)) return;

  try {
    switch (type) {
      case 'skip':
        navigator.vibrate([60, 40, 80]);
        break;
      case 'next':
        navigator.vibrate(45);
        break;
      case 'undo':
        navigator.vibrate([30, 30, 30]);
        break;
      case 'complete':
        navigator.vibrate([100, 50, 100, 50, 150]);
        break;
      case 'tap':
      default:
        navigator.vibrate(30);
        break;
    }
  } catch (err) {
    // Graceful fallback
  }
}

/**
 * Text-to-speech announcement for hands-free driving
 */
export function announceStop(customerName: string, houseNumber: string, streetName: string) {
  if (typeof window === 'undefined') return;

  let text = \`Next customer: \${customerName}.\`;
  if (houseNumber) {
    text += \` Number \${houseNumber}, \${streetName || ''}\`;
  }

  // 1. Prefer native Android Bridge TTS (never blocks main thread)
  try {
    const androidBridge = (window as any).AndroidBridge;
    if (androidBridge && typeof androidBridge.speak === 'function') {
      androidBridge.speak(text);
      return;
    }
  } catch (err) {
    // Non-blocking
  }

  // 2. Web browser fallback with SpeechSynthesis (only when not inside Android wrapper)
  if (!('speechSynthesis' in window)) return;

  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.05;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;
    window.speechSynthesis.speak(utterance);
  } catch (err) {
    // Non-blocking
  }
}

/**
 * Voice guidance for missed stops and turnaround maneuvers
 * Preferred exact wording: "Turn around as soon as possible."
 */
let lastTurnaroundSpokenTime = 0;

export function announceTurnaround() {
  if (typeof window === 'undefined') return;

  const now = Date.now();
  // Prevent repeating more than once every 12 seconds
  if (now - lastTurnaroundSpokenTime < 12000) return;
  lastTurnaroundSpokenTime = now;

  const text = 'Turn around as soon as possible.';

  // 1. Prefer native Android Bridge TTS
  try {
    const androidBridge = (window as any).AndroidBridge;
    if (androidBridge && typeof androidBridge.speak === 'function') {
      androidBridge.speak(text);
      return;
    }
  } catch (err) {
    // Non-blocking
  }

  // 2. Web browser fallback
  if (!('speechSynthesis' in window)) return;
  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.05;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;
    window.speechSynthesis.speak(utterance);
  } catch (err) {
    // Non-blocking
  }
}

/**
 * Screen WakeLock manager to prevent screen from dimming/sleeping on phone mount
 */
let wakeLockSentinel: any = null;

export async function requestWakeLock(): Promise<boolean> {
  if (typeof window === 'undefined') return false;

  // If in Android native app, FLAG_KEEP_SCREEN_ON is already set on the Window
  if ((window as any).AndroidBridge) {
    return true;
  }

  if (!('wakeLock' in navigator)) {
    return false;
  }
  try {
    wakeLockSentinel = await (navigator as any).wakeLock.request('screen');
    wakeLockSentinel.addEventListener('release', () => {
      wakeLockSentinel = null;
    });
    return true;
  } catch (err) {
    return false;
  }
}

export function releaseWakeLock() {
  if (wakeLockSentinel) {
    try {
      wakeLockSentinel.release();
    } catch (e) {
      // ignore
    }
    wakeLockSentinel = null;
  }
}

/**
 * Generate navigation URIs for OsmAnd and standard Android map handlers
 */
export function getNavigationLinks(lat: number, lon: number, label: string) {
  const encodedLabel = encodeURIComponent(label || 'Customer Stop');
  
  // Standard geo URI (will open OsmAnd or default Android map app)
  const geoUri = \`geo:\${lat},\${lon}?q=\${lat},\${lon}(\${encodedLabel})\`;
  
  // OsmAnd direct intent URI
  const osmandUri = \`osmand.navigation:q=\${lat},\${lon}\`;
  
  // Google Maps fallback web link
  const gmapsUrl = \`https://www.google.com/maps/dir/?api=1&destination=\${lat},\${lon}\`;

  return { geoUri, osmandUri, gmapsUrl };
}
`,wt=`{
  "compilerOptions": {
    "target": "ES2022",
    "experimentalDecorators": true,
    "useDefineForClassFields": false,
    "module": "ESNext",
    "types": ["vite/client"],
    "lib": [
      "ES2022",
      "DOM",
      "DOM.Iterable"
    ],
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "isolatedModules": true,
    "moduleDetection": "force",
    "allowJs": true,
    "jsx": "react-jsx",
    "paths": {
      "@/*": [
        "./*"
      ]
    },
    "allowImportingTsExtensions": true,
    "noEmit": true
  }
}
`,Tt=`import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    base: './',
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
`,Et=c(o(((e,t)=>{(function(n){typeof e==`object`&&t!==void 0?t.exports=n():typeof define==`function`&&define.amd?define([],n):(typeof window<`u`?window:typeof global<`u`?global:typeof self<`u`?self:this).JSZip=n()})(function(){return function e(t,n,r){function i(o,s){if(!n[o]){if(!t[o]){var c=typeof l==`function`&&l;if(!s&&c)return c(o,!0);if(a)return a(o,!0);var u=Error(`Cannot find module '`+o+`'`);throw u.code=`MODULE_NOT_FOUND`,u}var d=n[o]={exports:{}};t[o][0].call(d.exports,function(e){var n=t[o][1][e];return i(n||e)},d,d.exports,e,t,n,r)}return n[o].exports}for(var a=typeof l==`function`&&l,o=0;o<r.length;o++)i(r[o]);return i}({1:[function(e,t,n){var r=e(`./utils`),i=e(`./support`),a=`ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=`;n.encode=function(e){for(var t,n,i,o,s,c,l,u=[],d=0,f=e.length,p=f,m=r.getTypeOf(e)!==`string`;d<e.length;)p=f-d,i=m?(t=e[d++],n=d<f?e[d++]:0,d<f?e[d++]:0):(t=e.charCodeAt(d++),n=d<f?e.charCodeAt(d++):0,d<f?e.charCodeAt(d++):0),o=t>>2,s=(3&t)<<4|n>>4,c=1<p?(15&n)<<2|i>>6:64,l=2<p?63&i:64,u.push(a.charAt(o)+a.charAt(s)+a.charAt(c)+a.charAt(l));return u.join(``)},n.decode=function(e){var t,n,r,o,s,c,l=0,u=0,d=`data:`;if(e.substr(0,d.length)===d)throw Error(`Invalid base64 input, it looks like a data url.`);var f,p=3*(e=e.replace(/[^A-Za-z0-9+/=]/g,``)).length/4;if(e.charAt(e.length-1)===a.charAt(64)&&p--,e.charAt(e.length-2)===a.charAt(64)&&p--,p%1!=0)throw Error(`Invalid base64 input, bad content length.`);for(f=i.uint8array?new Uint8Array(0|p):Array(0|p);l<e.length;)t=a.indexOf(e.charAt(l++))<<2|(o=a.indexOf(e.charAt(l++)))>>4,n=(15&o)<<4|(s=a.indexOf(e.charAt(l++)))>>2,r=(3&s)<<6|(c=a.indexOf(e.charAt(l++))),f[u++]=t,s!==64&&(f[u++]=n),c!==64&&(f[u++]=r);return f}},{"./support":30,"./utils":32}],2:[function(e,t,n){var r=e(`./external`),i=e(`./stream/DataWorker`),a=e(`./stream/Crc32Probe`),o=e(`./stream/DataLengthProbe`);function s(e,t,n,r,i){this.compressedSize=e,this.uncompressedSize=t,this.crc32=n,this.compression=r,this.compressedContent=i}s.prototype={getContentWorker:function(){var e=new i(r.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new o(`data_length`)),t=this;return e.on(`end`,function(){if(this.streamInfo.data_length!==t.uncompressedSize)throw Error(`Bug : uncompressed data size mismatch`)}),e},getCompressedWorker:function(){return new i(r.Promise.resolve(this.compressedContent)).withStreamInfo(`compressedSize`,this.compressedSize).withStreamInfo(`uncompressedSize`,this.uncompressedSize).withStreamInfo(`crc32`,this.crc32).withStreamInfo(`compression`,this.compression)}},s.createWorkerFrom=function(e,t,n){return e.pipe(new a).pipe(new o(`uncompressedSize`)).pipe(t.compressWorker(n)).pipe(new o(`compressedSize`)).withStreamInfo(`compression`,t)},t.exports=s},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(e,t,n){var r=e(`./stream/GenericWorker`);n.STORE={magic:`\0\0`,compressWorker:function(){return new r(`STORE compression`)},uncompressWorker:function(){return new r(`STORE decompression`)}},n.DEFLATE=e(`./flate`)},{"./flate":7,"./stream/GenericWorker":28}],4:[function(e,t,n){var r=e(`./utils`),i=function(){for(var e,t=[],n=0;n<256;n++){e=n;for(var r=0;r<8;r++)e=1&e?3988292384^e>>>1:e>>>1;t[n]=e}return t}();t.exports=function(e,t){return e!==void 0&&e.length?r.getTypeOf(e)===`string`?function(e,t,n,r){var a=i,o=r+n;e^=-1;for(var s=r;s<o;s++)e=e>>>8^a[255&(e^t.charCodeAt(s))];return-1^e}(0|t,e,e.length,0):function(e,t,n,r){var a=i,o=r+n;e^=-1;for(var s=r;s<o;s++)e=e>>>8^a[255&(e^t[s])];return-1^e}(0|t,e,e.length,0):0}},{"./utils":32}],5:[function(e,t,n){n.base64=!1,n.binary=!1,n.dir=!1,n.createFolders=!0,n.date=null,n.compression=null,n.compressionOptions=null,n.comment=null,n.unixPermissions=null,n.dosPermissions=null},{}],6:[function(e,t,n){var r=null;r=typeof Promise<`u`?Promise:e(`lie`),t.exports={Promise:r}},{lie:37}],7:[function(e,t,n){var r=typeof Uint8Array<`u`&&typeof Uint16Array<`u`&&typeof Uint32Array<`u`,i=e(`pako`),a=e(`./utils`),o=e(`./stream/GenericWorker`),s=r?`uint8array`:`array`;function c(e,t){o.call(this,`FlateWorker/`+e),this._pako=null,this._pakoAction=e,this._pakoOptions=t,this.meta={}}n.magic=`\b\0`,a.inherits(c,o),c.prototype.processChunk=function(e){this.meta=e.meta,this._pako===null&&this._createPako(),this._pako.push(a.transformTo(s,e.data),!1)},c.prototype.flush=function(){o.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},c.prototype.cleanUp=function(){o.prototype.cleanUp.call(this),this._pako=null},c.prototype._createPako=function(){this._pako=new i[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var e=this;this._pako.onData=function(t){e.push({data:t,meta:e.meta})}},n.compressWorker=function(e){return new c(`Deflate`,e)},n.uncompressWorker=function(){return new c(`Inflate`,{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(e,t,n){function r(e,t){var n,r=``;for(n=0;n<t;n++)r+=String.fromCharCode(255&e),e>>>=8;return r}function i(e,t,n,i,o,u){var d,f,p=e.file,m=e.compression,h=u!==s.utf8encode,g=a.transformTo(`string`,u(p.name)),_=a.transformTo(`string`,s.utf8encode(p.name)),v=p.comment,y=a.transformTo(`string`,u(v)),b=a.transformTo(`string`,s.utf8encode(v)),x=_.length!==p.name.length,S=b.length!==v.length,C=``,w=``,T=``,E=p.dir,D=p.date,O={crc32:0,compressedSize:0,uncompressedSize:0};t&&!n||(O.crc32=e.crc32,O.compressedSize=e.compressedSize,O.uncompressedSize=e.uncompressedSize);var k=0;t&&(k|=8),h||!x&&!S||(k|=2048);var A=0,j=0;E&&(A|=16),o===`UNIX`?(j=798,A|=function(e,t){var n=e;return e||(n=t?16893:33204),(65535&n)<<16}(p.unixPermissions,E)):(j=20,A|=function(e){return 63&(e||0)}(p.dosPermissions)),d=D.getUTCHours(),d<<=6,d|=D.getUTCMinutes(),d<<=5,d|=D.getUTCSeconds()/2,f=D.getUTCFullYear()-1980,f<<=4,f|=D.getUTCMonth()+1,f<<=5,f|=D.getUTCDate(),x&&(w=r(1,1)+r(c(g),4)+_,C+=`up`+r(w.length,2)+w),S&&(T=r(1,1)+r(c(y),4)+b,C+=`uc`+r(T.length,2)+T);var M=``;return M+=`
\0`,M+=r(k,2),M+=m.magic,M+=r(d,2),M+=r(f,2),M+=r(O.crc32,4),M+=r(O.compressedSize,4),M+=r(O.uncompressedSize,4),M+=r(g.length,2),M+=r(C.length,2),{fileRecord:l.LOCAL_FILE_HEADER+M+g+C,dirRecord:l.CENTRAL_FILE_HEADER+r(j,2)+M+r(y.length,2)+`\0\0\0\0`+r(A,4)+r(i,4)+g+C+y}}var a=e(`../utils`),o=e(`../stream/GenericWorker`),s=e(`../utf8`),c=e(`../crc32`),l=e(`../signature`);function u(e,t,n,r){o.call(this,`ZipFileWorker`),this.bytesWritten=0,this.zipComment=t,this.zipPlatform=n,this.encodeFileName=r,this.streamFiles=e,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}a.inherits(u,o),u.prototype.push=function(e){var t=e.meta.percent||0,n=this.entriesCount,r=this._sources.length;this.accumulate?this.contentBuffer.push(e):(this.bytesWritten+=e.data.length,o.prototype.push.call(this,{data:e.data,meta:{currentFile:this.currentFile,percent:n?(t+100*(n-r-1))/n:100}}))},u.prototype.openedSource=function(e){this.currentSourceOffset=this.bytesWritten,this.currentFile=e.file.name;var t=this.streamFiles&&!e.file.dir;if(t){var n=i(e,t,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:n.fileRecord,meta:{percent:0}})}else this.accumulate=!0},u.prototype.closedSource=function(e){this.accumulate=!1;var t=this.streamFiles&&!e.file.dir,n=i(e,t,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(n.dirRecord),t)this.push({data:function(e){return l.DATA_DESCRIPTOR+r(e.crc32,4)+r(e.compressedSize,4)+r(e.uncompressedSize,4)}(e),meta:{percent:100}});else for(this.push({data:n.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},u.prototype.flush=function(){for(var e=this.bytesWritten,t=0;t<this.dirRecords.length;t++)this.push({data:this.dirRecords[t],meta:{percent:100}});var n=this.bytesWritten-e,i=function(e,t,n,i,o){var s=a.transformTo(`string`,o(i));return l.CENTRAL_DIRECTORY_END+`\0\0\0\0`+r(e,2)+r(e,2)+r(t,4)+r(n,4)+r(s.length,2)+s}(this.dirRecords.length,n,e,this.zipComment,this.encodeFileName);this.push({data:i,meta:{percent:100}})},u.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},u.prototype.registerPrevious=function(e){this._sources.push(e);var t=this;return e.on(`data`,function(e){t.processChunk(e)}),e.on(`end`,function(){t.closedSource(t.previous.streamInfo),t._sources.length?t.prepareNextSource():t.end()}),e.on(`error`,function(e){t.error(e)}),this},u.prototype.resume=function(){return!!o.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},u.prototype.error=function(e){var t=this._sources;if(!o.prototype.error.call(this,e))return!1;for(var n=0;n<t.length;n++)try{t[n].error(e)}catch{}return!0},u.prototype.lock=function(){o.prototype.lock.call(this);for(var e=this._sources,t=0;t<e.length;t++)e[t].lock()},t.exports=u},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(e,t,n){var r=e(`../compressions`),i=e(`./ZipFileWorker`);n.generateWorker=function(e,t,n){var a=new i(t.streamFiles,n,t.platform,t.encodeFileName),o=0;try{e.forEach(function(e,n){o++;var i=function(e,t){var n=e||t,i=r[n];if(!i)throw Error(n+` is not a valid compression method !`);return i}(n.options.compression,t.compression),s=n.options.compressionOptions||t.compressionOptions||{},c=n.dir,l=n.date;n._compressWorker(i,s).withStreamInfo(`file`,{name:e,dir:c,date:l,comment:n.comment||``,unixPermissions:n.unixPermissions,dosPermissions:n.dosPermissions}).pipe(a)}),a.entriesCount=o}catch(e){a.error(e)}return a}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(e,t,n){function r(){if(!(this instanceof r))return new r;if(arguments.length)throw Error(`The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.`);this.files=Object.create(null),this.comment=null,this.root=``,this.clone=function(){var e=new r;for(var t in this)typeof this[t]!=`function`&&(e[t]=this[t]);return e}}(r.prototype=e(`./object`)).loadAsync=e(`./load`),r.support=e(`./support`),r.defaults=e(`./defaults`),r.version=`3.10.2`,r.loadAsync=function(e,t){return new r().loadAsync(e,t)},r.external=e(`./external`),t.exports=r},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(e,t,n){var r=e(`./utils`),i=e(`./external`),a=e(`./utf8`),o=e(`./zipEntries`),s=e(`./stream/Crc32Probe`),c=e(`./nodejsUtils`);function l(e){return new i.Promise(function(t,n){var r=e.decompressed.getContentWorker().pipe(new s);r.on(`error`,function(e){n(e)}).on(`end`,function(){r.streamInfo.crc32===e.decompressed.crc32?t():n(Error(`Corrupted zip : CRC32 mismatch`))}).resume()})}t.exports=function(e,t){var n=this;return t=r.extend(t||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:a.utf8decode}),c.isNode&&c.isStream(e)?i.Promise.reject(Error(`JSZip can't accept a stream when loading a zip file.`)):r.prepareContent(`the loaded zip file`,e,!0,t.optimizedBinaryString,t.base64).then(function(e){var n=new o(t);return n.load(e),n}).then(function(e){var n=[i.Promise.resolve(e)],r=e.files;if(t.checkCRC32)for(var a=0;a<r.length;a++)n.push(l(r[a]));return i.Promise.all(n)}).then(function(e){for(var i=e.shift(),a=i.files,o=0;o<a.length;o++){var s=a[o],c=s.fileNameStr,l=r.resolve(s.fileNameStr);n.file(l,s.decompressed,{binary:!0,optimizedBinaryString:!0,date:s.date,dir:s.dir,comment:s.fileCommentStr.length?s.fileCommentStr:null,unixPermissions:s.unixPermissions,dosPermissions:s.dosPermissions,createFolders:t.createFolders}),s.dir||(n.file(l).unsafeOriginalName=c)}return i.zipComment.length&&(n.comment=i.zipComment),n})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(e,t,n){var r=e(`../utils`),i=e(`../stream/GenericWorker`);function a(e,t){i.call(this,`Nodejs stream input adapter for `+e),this._upstreamEnded=!1,this._bindStream(t)}r.inherits(a,i),a.prototype._bindStream=function(e){var t=this;(this._stream=e).pause(),e.on(`data`,function(e){t.push({data:e,meta:{percent:0}})}).on(`error`,function(e){t.isPaused?this.generatedError=e:t.error(e)}).on(`end`,function(){t.isPaused?t._upstreamEnded=!0:t.end()})},a.prototype.pause=function(){return!!i.prototype.pause.call(this)&&(this._stream.pause(),!0)},a.prototype.resume=function(){return!!i.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},t.exports=a},{"../stream/GenericWorker":28,"../utils":32}],13:[function(e,t,n){var r=e(`readable-stream`).Readable;function i(e,t,n){r.call(this,t),this._helper=e;var i=this;e.on(`data`,function(e,t){i.push(e)||i._helper.pause(),n&&n(t)}).on(`error`,function(e){i.emit(`error`,e)}).on(`end`,function(){i.push(null)})}e(`../utils`).inherits(i,r),i.prototype._read=function(){this._helper.resume()},t.exports=i},{"../utils":32,"readable-stream":16}],14:[function(e,t,n){t.exports={isNode:typeof Buffer<`u`,newBufferFrom:function(e,t){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(e,t);if(typeof e==`number`)throw Error(`The "data" argument must not be a number`);return new Buffer(e,t)},allocBuffer:function(e){if(Buffer.alloc)return Buffer.alloc(e);var t=new Buffer(e);return t.fill(0),t},isBuffer:function(e){return Buffer.isBuffer(e)},isStream:function(e){return e&&typeof e.on==`function`&&typeof e.pause==`function`&&typeof e.resume==`function`}}},{}],15:[function(e,t,n){function r(e,t,n){var r,i=a.getTypeOf(t),s=a.extend(n||{},c);s.date=s.date||new Date,s.compression!==null&&(s.compression=s.compression.toUpperCase()),typeof s.unixPermissions==`string`&&(s.unixPermissions=parseInt(s.unixPermissions,8)),s.unixPermissions&&16384&s.unixPermissions&&(s.dir=!0),s.dosPermissions&&16&s.dosPermissions&&(s.dir=!0),s.dir&&(e=h(e)),s.createFolders&&(r=m(e))&&g.call(this,r,!0);var d=i===`string`&&!1===s.binary&&!1===s.base64;n&&n.binary!==void 0||(s.binary=!d),(t instanceof l&&t.uncompressedSize===0||s.dir||!t||t.length===0)&&(s.base64=!1,s.binary=!0,t=``,s.compression=`STORE`,i=`string`);var _=null;_=t instanceof l||t instanceof o?t:f.isNode&&f.isStream(t)?new p(e,t):a.prepareContent(e,t,s.binary,s.optimizedBinaryString,s.base64);var v=new u(e,_,s);this.files[e]=v}var i=e(`./utf8`),a=e(`./utils`),o=e(`./stream/GenericWorker`),s=e(`./stream/StreamHelper`),c=e(`./defaults`),l=e(`./compressedObject`),u=e(`./zipObject`),d=e(`./generate`),f=e(`./nodejsUtils`),p=e(`./nodejs/NodejsStreamInputAdapter`),m=function(e){e.slice(-1)===`/`&&(e=e.substring(0,e.length-1));var t=e.lastIndexOf(`/`);return 0<t?e.substring(0,t):``},h=function(e){return e.slice(-1)!==`/`&&(e+=`/`),e},g=function(e,t){return t=t===void 0?c.createFolders:t,e=h(e),this.files[e]||r.call(this,e,null,{dir:!0,createFolders:t}),this.files[e]};function _(e){return Object.prototype.toString.call(e)===`[object RegExp]`}t.exports={load:function(){throw Error(`This method has been removed in JSZip 3.0, please check the upgrade guide.`)},forEach:function(e){var t,n,r;for(t in this.files)r=this.files[t],(n=t.slice(this.root.length,t.length))&&t.slice(0,this.root.length)===this.root&&e(n,r)},filter:function(e){var t=[];return this.forEach(function(n,r){e(n,r)&&t.push(r)}),t},file:function(e,t,n){if(arguments.length!==1)return e=this.root+e,r.call(this,e,t,n),this;if(_(e)){var i=e;return this.filter(function(e,t){return!t.dir&&i.test(e)})}var a=this.files[this.root+e];return a&&!a.dir?a:null},folder:function(e){if(!e)return this;if(_(e))return this.filter(function(t,n){return n.dir&&e.test(t)});var t=this.root+e,n=g.call(this,t),r=this.clone();return r.root=n.name,r},remove:function(e){e=this.root+e;var t=this.files[e];if(t||=(e.slice(-1)!==`/`&&(e+=`/`),this.files[e]),t&&!t.dir)delete this.files[e];else for(var n=this.filter(function(t,n){return n.name.slice(0,e.length)===e}),r=0;r<n.length;r++)delete this.files[n[r].name];return this},generate:function(){throw Error(`This method has been removed in JSZip 3.0, please check the upgrade guide.`)},generateInternalStream:function(e){var t,n={};try{if((n=a.extend(e||{},{streamFiles:!1,compression:`STORE`,compressionOptions:null,type:``,platform:`DOS`,comment:null,mimeType:`application/zip`,encodeFileName:i.utf8encode})).type=n.type.toLowerCase(),n.compression=n.compression.toUpperCase(),n.type===`binarystring`&&(n.type=`string`),!n.type)throw Error(`No output type specified.`);a.checkSupport(n.type),n.platform!==`darwin`&&n.platform!==`freebsd`&&n.platform!==`linux`&&n.platform!==`sunos`||(n.platform=`UNIX`),n.platform===`win32`&&(n.platform=`DOS`);var r=n.comment||this.comment||``;t=d.generateWorker(this,n,r)}catch(e){(t=new o(`error`)).error(e)}return new s(t,n.type||`string`,n.mimeType)},generateAsync:function(e,t){return this.generateInternalStream(e).accumulate(t)},generateNodeStream:function(e,t){return(e||={}).type||(e.type=`nodebuffer`),this.generateInternalStream(e).toNodejsStream(t)}}},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(e,t,n){t.exports=e(`stream`)},{stream:void 0}],17:[function(e,t,n){var r=e(`./DataReader`);function i(e){r.call(this,e);for(var t=0;t<this.data.length;t++)e[t]=255&e[t]}e(`../utils`).inherits(i,r),i.prototype.byteAt=function(e){return this.data[this.zero+e]},i.prototype.lastIndexOfSignature=function(e){for(var t=e.charCodeAt(0),n=e.charCodeAt(1),r=e.charCodeAt(2),i=e.charCodeAt(3),a=this.length-4;0<=a;--a)if(this.data[a]===t&&this.data[a+1]===n&&this.data[a+2]===r&&this.data[a+3]===i)return a-this.zero;return-1},i.prototype.readAndCheckSignature=function(e){var t=e.charCodeAt(0),n=e.charCodeAt(1),r=e.charCodeAt(2),i=e.charCodeAt(3),a=this.readData(4);return t===a[0]&&n===a[1]&&r===a[2]&&i===a[3]},i.prototype.readData=function(e){if(this.checkOffset(e),e===0)return[];var t=this.data.slice(this.zero+this.index,this.zero+this.index+e);return this.index+=e,t},t.exports=i},{"../utils":32,"./DataReader":18}],18:[function(e,t,n){var r=e(`../utils`);function i(e){this.data=e,this.length=e.length,this.index=0,this.zero=0}i.prototype={checkOffset:function(e){this.checkIndex(this.index+e)},checkIndex:function(e){if(this.length<this.zero+e||e<0)throw Error(`End of data reached (data length = `+this.length+`, asked index = `+e+`). Corrupted zip ?`)},setIndex:function(e){this.checkIndex(e),this.index=e},skip:function(e){this.setIndex(this.index+e)},byteAt:function(){},readInt:function(e){var t,n=0;for(this.checkOffset(e),t=this.index+e-1;t>=this.index;t--)n=(n<<8)+this.byteAt(t);return this.index+=e,n},readString:function(e){return r.transformTo(`string`,this.readData(e))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var e=this.readInt(4);return new Date(Date.UTC(1980+(e>>25&127),(e>>21&15)-1,e>>16&31,e>>11&31,e>>5&63,(31&e)<<1))}},t.exports=i},{"../utils":32}],19:[function(e,t,n){var r=e(`./Uint8ArrayReader`);function i(e){r.call(this,e)}e(`../utils`).inherits(i,r),i.prototype.readData=function(e){this.checkOffset(e);var t=this.data.slice(this.zero+this.index,this.zero+this.index+e);return this.index+=e,t},t.exports=i},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(e,t,n){var r=e(`./DataReader`);function i(e){r.call(this,e)}e(`../utils`).inherits(i,r),i.prototype.byteAt=function(e){return this.data.charCodeAt(this.zero+e)},i.prototype.lastIndexOfSignature=function(e){return this.data.lastIndexOf(e)-this.zero},i.prototype.readAndCheckSignature=function(e){return e===this.readData(4)},i.prototype.readData=function(e){this.checkOffset(e);var t=this.data.slice(this.zero+this.index,this.zero+this.index+e);return this.index+=e,t},t.exports=i},{"../utils":32,"./DataReader":18}],21:[function(e,t,n){var r=e(`./ArrayReader`);function i(e){r.call(this,e)}e(`../utils`).inherits(i,r),i.prototype.readData=function(e){if(this.checkOffset(e),e===0)return new Uint8Array;var t=this.data.subarray(this.zero+this.index,this.zero+this.index+e);return this.index+=e,t},t.exports=i},{"../utils":32,"./ArrayReader":17}],22:[function(e,t,n){var r=e(`../utils`),i=e(`../support`),a=e(`./ArrayReader`),o=e(`./StringReader`),s=e(`./NodeBufferReader`),c=e(`./Uint8ArrayReader`);t.exports=function(e){var t=r.getTypeOf(e);return r.checkSupport(t),t!==`string`||i.uint8array?t===`nodebuffer`?new s(e):i.uint8array?new c(r.transformTo(`uint8array`,e)):new a(r.transformTo(`array`,e)):new o(e)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(e,t,n){n.LOCAL_FILE_HEADER=`PK`,n.CENTRAL_FILE_HEADER=`PK`,n.CENTRAL_DIRECTORY_END=`PK`,n.ZIP64_CENTRAL_DIRECTORY_LOCATOR=`PK\x07`,n.ZIP64_CENTRAL_DIRECTORY_END=`PK`,n.DATA_DESCRIPTOR=`PK\x07\b`},{}],24:[function(e,t,n){var r=e(`./GenericWorker`),i=e(`../utils`);function a(e){r.call(this,`ConvertWorker to `+e),this.destType=e}i.inherits(a,r),a.prototype.processChunk=function(e){this.push({data:i.transformTo(this.destType,e.data),meta:e.meta})},t.exports=a},{"../utils":32,"./GenericWorker":28}],25:[function(e,t,n){var r=e(`./GenericWorker`),i=e(`../crc32`);function a(){r.call(this,`Crc32Probe`),this.withStreamInfo(`crc32`,0)}e(`../utils`).inherits(a,r),a.prototype.processChunk=function(e){this.streamInfo.crc32=i(e.data,this.streamInfo.crc32||0),this.push(e)},t.exports=a},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(e,t,n){var r=e(`../utils`),i=e(`./GenericWorker`);function a(e){i.call(this,`DataLengthProbe for `+e),this.propName=e,this.withStreamInfo(e,0)}r.inherits(a,i),a.prototype.processChunk=function(e){if(e){var t=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=t+e.data.length}i.prototype.processChunk.call(this,e)},t.exports=a},{"../utils":32,"./GenericWorker":28}],27:[function(e,t,n){var r=e(`../utils`),i=e(`./GenericWorker`);function a(e){i.call(this,`DataWorker`);var t=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type=``,this._tickScheduled=!1,e.then(function(e){t.dataIsReady=!0,t.data=e,t.max=e&&e.length||0,t.type=r.getTypeOf(e),t.isPaused||t._tickAndRepeat()},function(e){t.error(e)})}r.inherits(a,i),a.prototype.cleanUp=function(){i.prototype.cleanUp.call(this),this.data=null},a.prototype.resume=function(){return!!i.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,r.delay(this._tickAndRepeat,[],this)),!0)},a.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(r.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},a.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var e=null,t=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case`string`:e=this.data.substring(this.index,t);break;case`uint8array`:e=this.data.subarray(this.index,t);break;case`array`:case`nodebuffer`:e=this.data.slice(this.index,t)}return this.index=t,this.push({data:e,meta:{percent:this.max?this.index/this.max*100:0}})},t.exports=a},{"../utils":32,"./GenericWorker":28}],28:[function(e,t,n){function r(e){this.name=e||`default`,this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}r.prototype={push:function(e){this.emit(`data`,e)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit(`end`),this.cleanUp(),this.isFinished=!0}catch(e){this.emit(`error`,e)}return!0},error:function(e){return!this.isFinished&&(this.isPaused?this.generatedError=e:(this.isFinished=!0,this.emit(`error`,e),this.previous&&this.previous.error(e),this.cleanUp()),!0)},on:function(e,t){return this._listeners[e].push(t),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(e,t){if(this._listeners[e])for(var n=0;n<this._listeners[e].length;n++)this._listeners[e][n].call(this,t)},pipe:function(e){return e.registerPrevious(this)},registerPrevious:function(e){if(this.isLocked)throw Error(`The stream '`+this+`' has already been used.`);this.streamInfo=e.streamInfo,this.mergeStreamInfo(),this.previous=e;var t=this;return e.on(`data`,function(e){t.processChunk(e)}),e.on(`end`,function(){t.end()}),e.on(`error`,function(e){t.error(e)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var e=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),e=!0),this.previous&&this.previous.resume(),!e},flush:function(){},processChunk:function(e){this.push(e)},withStreamInfo:function(e,t){return this.extraStreamInfo[e]=t,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var e in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,e)&&(this.streamInfo[e]=this.extraStreamInfo[e])},lock:function(){if(this.isLocked)throw Error(`The stream '`+this+`' has already been used.`);this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var e=`Worker `+this.name;return this.previous?this.previous+` -> `+e:e}},t.exports=r},{}],29:[function(e,t,n){var r=e(`../utils`),i=e(`./ConvertWorker`),a=e(`./GenericWorker`),o=e(`../base64`),s=e(`../support`),c=e(`../external`),l=null;if(s.nodestream)try{l=e(`../nodejs/NodejsStreamOutputAdapter`)}catch{}function u(e,t){return new c.Promise(function(n,i){var a=[],s=e._internalType,c=e._outputType,l=e._mimeType;e.on(`data`,function(e,n){a.push(e),t&&t(n)}).on(`error`,function(e){a=[],i(e)}).on(`end`,function(){try{n(function(e,t,n){switch(e){case`blob`:return r.newBlob(r.transformTo(`arraybuffer`,t),n);case`base64`:return o.encode(t);default:return r.transformTo(e,t)}}(c,function(e,t){var n,r=0,i=null,a=0;for(n=0;n<t.length;n++)a+=t[n].length;switch(e){case`string`:return t.join(``);case`array`:return Array.prototype.concat.apply([],t);case`uint8array`:for(i=new Uint8Array(a),n=0;n<t.length;n++)i.set(t[n],r),r+=t[n].length;return i;case`nodebuffer`:return Buffer.concat(t);default:throw Error(`concat : unsupported type '`+e+`'`)}}(s,a),l))}catch(e){i(e)}a=[]}).resume()})}function d(e,t,n){var o=t;switch(t){case`blob`:case`arraybuffer`:o=`uint8array`;break;case`base64`:o=`string`}try{this._internalType=o,this._outputType=t,this._mimeType=n,r.checkSupport(o),this._worker=e.pipe(new i(o)),e.lock()}catch(e){this._worker=new a(`error`),this._worker.error(e)}}d.prototype={accumulate:function(e){return u(this,e)},on:function(e,t){var n=this;return e===`data`?this._worker.on(e,function(e){t.call(n,e.data,e.meta)}):this._worker.on(e,function(){r.delay(t,arguments,n)}),this},resume:function(){return r.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(e){if(r.checkSupport(`nodestream`),this._outputType!==`nodebuffer`)throw Error(this._outputType+` is not supported by this method`);return new l(this,{objectMode:this._outputType!==`nodebuffer`},e)}},t.exports=d},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(e,t,n){if(n.base64=!0,n.array=!0,n.string=!0,n.arraybuffer=typeof ArrayBuffer<`u`&&typeof Uint8Array<`u`,n.nodebuffer=typeof Buffer<`u`,n.uint8array=typeof Uint8Array<`u`,typeof ArrayBuffer>`u`)n.blob=!1;else{var r=new ArrayBuffer(0);try{n.blob=new Blob([r],{type:`application/zip`}).size===0}catch{try{var i=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);i.append(r),n.blob=i.getBlob(`application/zip`).size===0}catch{n.blob=!1}}}try{n.nodestream=!!e(`readable-stream`).Readable}catch{n.nodestream=!1}},{"readable-stream":16}],31:[function(e,t,n){for(var r=e(`./utils`),i=e(`./support`),a=e(`./nodejsUtils`),o=e(`./stream/GenericWorker`),s=Array(256),c=0;c<256;c++)s[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;s[254]=s[254]=1;function l(){o.call(this,`utf-8 decode`),this.leftOver=null}function u(){o.call(this,`utf-8 encode`)}n.utf8encode=function(e){return i.nodebuffer?a.newBufferFrom(e,`utf-8`):function(e){var t,n,r,a,o,s=e.length,c=0;for(a=0;a<s;a++)(64512&(n=e.charCodeAt(a)))==55296&&a+1<s&&(64512&(r=e.charCodeAt(a+1)))==56320&&(n=65536+(n-55296<<10)+(r-56320),a++),c+=n<128?1:n<2048?2:n<65536?3:4;for(t=i.uint8array?new Uint8Array(c):Array(c),a=o=0;o<c;a++)(64512&(n=e.charCodeAt(a)))==55296&&a+1<s&&(64512&(r=e.charCodeAt(a+1)))==56320&&(n=65536+(n-55296<<10)+(r-56320),a++),n<128?t[o++]=n:(n<2048?t[o++]=192|n>>>6:(n<65536?t[o++]=224|n>>>12:(t[o++]=240|n>>>18,t[o++]=128|n>>>12&63),t[o++]=128|n>>>6&63),t[o++]=128|63&n);return t}(e)},n.utf8decode=function(e){return i.nodebuffer?r.transformTo(`nodebuffer`,e).toString(`utf-8`):function(e){var t,n,i,a,o=e.length,c=Array(2*o);for(t=n=0;t<o;)if((i=e[t++])<128)c[n++]=i;else if(4<(a=s[i]))c[n++]=65533,t+=a-1;else{for(i&=a===2?31:a===3?15:7;1<a&&t<o;)i=i<<6|63&e[t++],a--;1<a?c[n++]=65533:i<65536?c[n++]=i:(i-=65536,c[n++]=55296|i>>10&1023,c[n++]=56320|1023&i)}return c.length!==n&&(c.subarray?c=c.subarray(0,n):c.length=n),r.applyFromCharCode(c)}(e=r.transformTo(i.uint8array?`uint8array`:`array`,e))},r.inherits(l,o),l.prototype.processChunk=function(e){var t=r.transformTo(i.uint8array?`uint8array`:`array`,e.data);if(this.leftOver&&this.leftOver.length){if(i.uint8array){var a=t;(t=new Uint8Array(a.length+this.leftOver.length)).set(this.leftOver,0),t.set(a,this.leftOver.length)}else t=this.leftOver.concat(t);this.leftOver=null}var o=function(e,t){var n;for((t||=e.length)>e.length&&(t=e.length),n=t-1;0<=n&&(192&e[n])==128;)n--;return n<0||n===0?t:n+s[e[n]]>t?n:t}(t),c=t;o!==t.length&&(i.uint8array?(c=t.subarray(0,o),this.leftOver=t.subarray(o,t.length)):(c=t.slice(0,o),this.leftOver=t.slice(o,t.length))),this.push({data:n.utf8decode(c),meta:e.meta})},l.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:n.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},n.Utf8DecodeWorker=l,r.inherits(u,o),u.prototype.processChunk=function(e){this.push({data:n.utf8encode(e.data),meta:e.meta})},n.Utf8EncodeWorker=u},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(e,t,n){var r=e(`./support`),i=e(`./base64`),a=e(`./nodejsUtils`),o=e(`./external`);function s(e){return e}function c(e,t){for(var n=0;n<e.length;++n)t[n]=255&e.charCodeAt(n);return t}e(`setimmediate`),n.newBlob=function(e,t){n.checkSupport(`blob`);try{return new Blob([e],{type:t})}catch{try{var r=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return r.append(e),r.getBlob(t)}catch{throw Error(`Bug : can't construct the Blob.`)}}};var l={stringifyByChunk:function(e,t,n){var r=[],i=0,a=e.length;if(a<=n)return String.fromCharCode.apply(null,e);for(;i<a;)t===`array`||t===`nodebuffer`?r.push(String.fromCharCode.apply(null,e.slice(i,Math.min(i+n,a)))):r.push(String.fromCharCode.apply(null,e.subarray(i,Math.min(i+n,a)))),i+=n;return r.join(``)},stringifyByChar:function(e){for(var t=``,n=0;n<e.length;n++)t+=String.fromCharCode(e[n]);return t},applyCanBeUsed:{uint8array:function(){try{return r.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}}(),nodebuffer:function(){try{return r.nodebuffer&&String.fromCharCode.apply(null,a.allocBuffer(1)).length===1}catch{return!1}}()}};function u(e){var t=65536,r=n.getTypeOf(e),i=!0;if(r===`uint8array`?i=l.applyCanBeUsed.uint8array:r===`nodebuffer`&&(i=l.applyCanBeUsed.nodebuffer),i)for(;1<t;)try{return l.stringifyByChunk(e,r,t)}catch{t=Math.floor(t/2)}return l.stringifyByChar(e)}function d(e,t){for(var n=0;n<e.length;n++)t[n]=e[n];return t}n.applyFromCharCode=u;var f={};f.string={string:s,array:function(e){return c(e,Array(e.length))},arraybuffer:function(e){return f.string.uint8array(e).buffer},uint8array:function(e){return c(e,new Uint8Array(e.length))},nodebuffer:function(e){return c(e,a.allocBuffer(e.length))}},f.array={string:u,array:s,arraybuffer:function(e){return new Uint8Array(e).buffer},uint8array:function(e){return new Uint8Array(e)},nodebuffer:function(e){return a.newBufferFrom(e)}},f.arraybuffer={string:function(e){return u(new Uint8Array(e))},array:function(e){return d(new Uint8Array(e),Array(e.byteLength))},arraybuffer:s,uint8array:function(e){return new Uint8Array(e)},nodebuffer:function(e){return a.newBufferFrom(new Uint8Array(e))}},f.uint8array={string:u,array:function(e){return d(e,Array(e.length))},arraybuffer:function(e){return e.buffer},uint8array:s,nodebuffer:function(e){return a.newBufferFrom(e)}},f.nodebuffer={string:u,array:function(e){return d(e,Array(e.length))},arraybuffer:function(e){return f.nodebuffer.uint8array(e).buffer},uint8array:function(e){return d(e,new Uint8Array(e.length))},nodebuffer:s},n.transformTo=function(e,t){return t||=``,e?(n.checkSupport(e),f[n.getTypeOf(t)][e](t)):t},n.resolve=function(e){for(var t=e.split(`/`),n=[],r=0;r<t.length;r++){var i=t[r];i===`.`||i===``&&r!==0&&r!==t.length-1||(i===`..`?n.pop():n.push(i))}return n.join(`/`)},n.getTypeOf=function(e){if(typeof e==`string`)return`string`;var t=Object.prototype.toString.call(e);return t===`[object Array]`?`array`:r.nodebuffer&&a.isBuffer(e)?`nodebuffer`:r.uint8array&&t===`[object Uint8Array]`?`uint8array`:r.arraybuffer&&t===`[object ArrayBuffer]`?`arraybuffer`:void 0},n.checkSupport=function(e){if(!r[e.toLowerCase()])throw Error(e+` is not supported by this platform`)},n.MAX_VALUE_16BITS=65535,n.MAX_VALUE_32BITS=-1,n.pretty=function(e){var t,n,r=``;for(n=0;n<(e||``).length;n++)r+=`\\x`+((t=e.charCodeAt(n))<16?`0`:``)+t.toString(16).toUpperCase();return r},n.delay=function(e,t,n){setImmediate(function(){e.apply(n||null,t||[])})},n.inherits=function(e,t){function n(){}n.prototype=t.prototype,e.prototype=new n},n.extend=function(){var e,t,n={};for(e=0;e<arguments.length;e++)for(t in arguments[e])Object.prototype.hasOwnProperty.call(arguments[e],t)&&n[t]===void 0&&(n[t]=arguments[e][t]);return n},n.prepareContent=function(e,t,a,s,l){return o.Promise.resolve(t).then(function(t){return r.blob&&(t instanceof Blob||[`[object File]`,`[object Blob]`].indexOf(Object.prototype.toString.call(t))!==-1)?Blob.prototype.arrayBuffer===void 0?typeof FileReader<`u`?new o.Promise(function(e,n){var r=new FileReader;r.onload=function(t){e(t.target.result)},r.onerror=function(e){n(e.target.error)},r.readAsArrayBuffer(t)}):o.Promise.reject(Error(e+` is a Blob, but we have no way of reading it.`)):t.arrayBuffer():t}).then(function(t){var u=n.getTypeOf(t);return u?(u===`arraybuffer`?t=n.transformTo(`uint8array`,t):u===`string`&&(l?t=i.decode(t):a&&!0!==s&&(t=function(e){return c(e,r.uint8array?new Uint8Array(e.length):Array(e.length))}(t))),t):o.Promise.reject(Error(`Can't read the data of '`+e+`'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?`))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(e,t,n){var r=e(`./reader/readerFor`),i=e(`./utils`),a=e(`./signature`),o=e(`./zipEntry`),s=e(`./support`);function c(e){this.files=[],this.loadOptions=e}c.prototype={checkSignature:function(e){if(!this.reader.readAndCheckSignature(e)){this.reader.index-=4;var t=this.reader.readString(4);throw Error(`Corrupted zip or bug: unexpected signature (`+i.pretty(t)+`, expected `+i.pretty(e)+`)`)}},isSignature:function(e,t){var n=this.reader.index;this.reader.setIndex(e);var r=this.reader.readString(4)===t;return this.reader.setIndex(n),r},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var e=this.reader.readData(this.zipCommentLength),t=s.uint8array?`uint8array`:`array`,n=i.transformTo(t,e);this.zipComment=this.loadOptions.decodeFileName(n)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var e,t,n,r=this.zip64EndOfCentralSize-44;0<r;)e=this.reader.readInt(2),t=this.reader.readInt(4),n=this.reader.readData(t),this.zip64ExtensibleData[e]={id:e,length:t,value:n}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw Error(`Multi-volumes zip are not supported`)},readLocalFiles:function(){for(var e=0,t;e<this.files.length;e++)t=this.files[e],this.reader.setIndex(t.localHeaderOffset),this.checkSignature(a.LOCAL_FILE_HEADER),t.readLocalPart(this.reader),t.handleUTF8(),t.processAttributes()},readCentralDir:function(){var e;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(a.CENTRAL_FILE_HEADER);)(e=new o({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(e);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw Error(`Corrupted zip or bug: expected `+this.centralDirRecords+` records in central dir, got `+this.files.length)},readEndOfCentral:function(){var e=this.reader.lastIndexOfSignature(a.CENTRAL_DIRECTORY_END);if(e<0)throw this.isSignature(0,a.LOCAL_FILE_HEADER)?Error(`Corrupted zip: can't find end of central directory`):Error(`Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html`);this.reader.setIndex(e);var t=e;if(this.checkSignature(a.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===i.MAX_VALUE_16BITS||this.diskWithCentralDirStart===i.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===i.MAX_VALUE_16BITS||this.centralDirRecords===i.MAX_VALUE_16BITS||this.centralDirSize===i.MAX_VALUE_32BITS||this.centralDirOffset===i.MAX_VALUE_32BITS){if(this.zip64=!0,(e=this.reader.lastIndexOfSignature(a.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw Error(`Corrupted zip: can't find the ZIP64 end of central directory locator`);if(this.reader.setIndex(e),this.checkSignature(a.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,a.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(a.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw Error(`Corrupted zip: can't find the ZIP64 end of central directory`);this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(a.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var n=this.centralDirOffset+this.centralDirSize;this.zip64&&(n+=20,n+=12+this.zip64EndOfCentralSize);var r=t-n;if(0<r)this.isSignature(t,a.CENTRAL_FILE_HEADER)||(this.reader.zero=r);else if(r<0)throw Error(`Corrupted zip: missing `+Math.abs(r)+` bytes.`)},prepareReader:function(e){this.reader=r(e)},load:function(e){this.prepareReader(e),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},t.exports=c},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(e,t,n){var r=e(`./reader/readerFor`),i=e(`./utils`),a=e(`./compressedObject`),o=e(`./crc32`),s=e(`./utf8`),c=e(`./compressions`),l=e(`./support`);function u(e,t){this.options=e,this.loadOptions=t}u.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(e){var t,n;if(e.skip(22),this.fileNameLength=e.readInt(2),n=e.readInt(2),this.fileName=e.readData(this.fileNameLength),e.skip(n),this.compressedSize===-1||this.uncompressedSize===-1)throw Error(`Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)`);if((t=function(e){for(var t in c)if(Object.prototype.hasOwnProperty.call(c,t)&&c[t].magic===e)return c[t];return null}(this.compressionMethod))===null)throw Error(`Corrupted zip : compression `+i.pretty(this.compressionMethod)+` unknown (inner file : `+i.transformTo(`string`,this.fileName)+`)`);this.decompressed=new a(this.compressedSize,this.uncompressedSize,this.crc32,t,e.readData(this.compressedSize))},readCentralPart:function(e){this.versionMadeBy=e.readInt(2),e.skip(2),this.bitFlag=e.readInt(2),this.compressionMethod=e.readString(2),this.date=e.readDate(),this.crc32=e.readInt(4),this.compressedSize=e.readInt(4),this.uncompressedSize=e.readInt(4);var t=e.readInt(2);if(this.extraFieldsLength=e.readInt(2),this.fileCommentLength=e.readInt(2),this.diskNumberStart=e.readInt(2),this.internalFileAttributes=e.readInt(2),this.externalFileAttributes=e.readInt(4),this.localHeaderOffset=e.readInt(4),this.isEncrypted())throw Error(`Encrypted zip are not supported`);e.skip(t),this.readExtraFields(e),this.parseZIP64ExtraField(e),this.fileComment=e.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var e=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),e==0&&(this.dosPermissions=63&this.externalFileAttributes),e==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!==`/`||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var e=r(this.extraFields[1].value);this.uncompressedSize===i.MAX_VALUE_32BITS&&(this.uncompressedSize=e.readInt(8)),this.compressedSize===i.MAX_VALUE_32BITS&&(this.compressedSize=e.readInt(8)),this.localHeaderOffset===i.MAX_VALUE_32BITS&&(this.localHeaderOffset=e.readInt(8)),this.diskNumberStart===i.MAX_VALUE_32BITS&&(this.diskNumberStart=e.readInt(4))}},readExtraFields:function(e){var t,n,r,i=e.index+this.extraFieldsLength;for(this.extraFields||={};e.index+4<i;)t=e.readInt(2),n=e.readInt(2),r=e.readData(n),this.extraFields[t]={id:t,length:n,value:r};e.setIndex(i)},handleUTF8:function(){var e=l.uint8array?`uint8array`:`array`;if(this.useUTF8())this.fileNameStr=s.utf8decode(this.fileName),this.fileCommentStr=s.utf8decode(this.fileComment);else{var t=this.findExtraFieldUnicodePath();if(t!==null)this.fileNameStr=t;else{var n=i.transformTo(e,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(n)}var r=this.findExtraFieldUnicodeComment();if(r!==null)this.fileCommentStr=r;else{var a=i.transformTo(e,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(a)}}},findExtraFieldUnicodePath:function(){var e=this.extraFields[28789];if(e){var t=r(e.value);return t.readInt(1)===1&&o(this.fileName)===t.readInt(4)?s.utf8decode(t.readData(e.length-5)):null}return null},findExtraFieldUnicodeComment:function(){var e=this.extraFields[25461];if(e){var t=r(e.value);return t.readInt(1)===1&&o(this.fileComment)===t.readInt(4)?s.utf8decode(t.readData(e.length-5)):null}return null}},t.exports=u},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(e,t,n){function r(e,t,n){this.name=e,this.dir=n.dir,this.date=n.date,this.comment=n.comment,this.unixPermissions=n.unixPermissions,this.dosPermissions=n.dosPermissions,this._data=t,this._dataBinary=n.binary,this.options={compression:n.compression,compressionOptions:n.compressionOptions}}var i=e(`./stream/StreamHelper`),a=e(`./stream/DataWorker`),o=e(`./utf8`),s=e(`./compressedObject`),c=e(`./stream/GenericWorker`);r.prototype={internalStream:function(e){var t=null,n=`string`;try{if(!e)throw Error(`No output type specified.`);var r=(n=e.toLowerCase())===`string`||n===`text`;n!==`binarystring`&&n!==`text`||(n=`string`),t=this._decompressWorker();var a=!this._dataBinary;a&&!r&&(t=t.pipe(new o.Utf8EncodeWorker)),!a&&r&&(t=t.pipe(new o.Utf8DecodeWorker))}catch(e){(t=new c(`error`)).error(e)}return new i(t,n,``)},async:function(e,t){return this.internalStream(e).accumulate(t)},nodeStream:function(e,t){return this.internalStream(e||`nodebuffer`).toNodejsStream(t)},_compressWorker:function(e,t){if(this._data instanceof s&&this._data.compression.magic===e.magic)return this._data.getCompressedWorker();var n=this._decompressWorker();return this._dataBinary||(n=n.pipe(new o.Utf8EncodeWorker)),s.createWorkerFrom(n,e,t)},_decompressWorker:function(){return this._data instanceof s?this._data.getContentWorker():this._data instanceof c?this._data:new a(this._data)}};for(var l=[`asText`,`asBinary`,`asNodeBuffer`,`asUint8Array`,`asArrayBuffer`],u=function(){throw Error(`This method has been removed in JSZip 3.0, please check the upgrade guide.`)},d=0;d<l.length;d++)r.prototype[l[d]]=u;t.exports=r},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(e,t,n){(function(e){var n,r,i=e.MutationObserver||e.WebKitMutationObserver;if(i){var a=0,o=new i(u),s=e.document.createTextNode(``);o.observe(s,{characterData:!0}),n=function(){s.data=a=++a%2}}else if(e.setImmediate||e.MessageChannel===void 0)n=`document`in e&&`onreadystatechange`in e.document.createElement(`script`)?function(){var t=e.document.createElement(`script`);t.onreadystatechange=function(){u(),t.onreadystatechange=null,t.parentNode.removeChild(t),t=null},e.document.documentElement.appendChild(t)}:function(){setTimeout(u,0)};else{var c=new e.MessageChannel;c.port1.onmessage=u,n=function(){c.port2.postMessage(0)}}var l=[];function u(){var e,t;r=!0;for(var n=l.length;n;){for(t=l,l=[],e=-1;++e<n;)t[e]();n=l.length}r=!1}t.exports=function(e){l.push(e)!==1||r||n()}}).call(this,typeof global<`u`?global:typeof self<`u`?self:typeof window<`u`?window:{})},{}],37:[function(e,t,n){var r=e(`immediate`);function i(){}var a={},o=[`REJECTED`],s=[`FULFILLED`],c=[`PENDING`];function l(e){if(typeof e!=`function`)throw TypeError(`resolver must be a function`);this.state=c,this.queue=[],this.outcome=void 0,e!==i&&p(this,e)}function u(e,t,n){this.promise=e,typeof t==`function`&&(this.onFulfilled=t,this.callFulfilled=this.otherCallFulfilled),typeof n==`function`&&(this.onRejected=n,this.callRejected=this.otherCallRejected)}function d(e,t,n){r(function(){var r;try{r=t(n)}catch(t){return a.reject(e,t)}r===e?a.reject(e,TypeError(`Cannot resolve promise with itself`)):a.resolve(e,r)})}function f(e){var t=e&&e.then;if(e&&(typeof e==`object`||typeof e==`function`)&&typeof t==`function`)return function(){t.apply(e,arguments)}}function p(e,t){var n=!1;function r(t){n||(n=!0,a.reject(e,t))}function i(t){n||(n=!0,a.resolve(e,t))}var o=m(function(){t(i,r)});o.status===`error`&&r(o.value)}function m(e,t){var n={};try{n.value=e(t),n.status=`success`}catch(e){n.status=`error`,n.value=e}return n}(t.exports=l).prototype.finally=function(e){if(typeof e!=`function`)return this;var t=this.constructor;return this.then(function(n){return t.resolve(e()).then(function(){return n})},function(n){return t.resolve(e()).then(function(){throw n})})},l.prototype.catch=function(e){return this.then(null,e)},l.prototype.then=function(e,t){if(typeof e!=`function`&&this.state===s||typeof t!=`function`&&this.state===o)return this;var n=new this.constructor(i);return this.state===c?this.queue.push(new u(n,e,t)):d(n,this.state===s?e:t,this.outcome),n},u.prototype.callFulfilled=function(e){a.resolve(this.promise,e)},u.prototype.otherCallFulfilled=function(e){d(this.promise,this.onFulfilled,e)},u.prototype.callRejected=function(e){a.reject(this.promise,e)},u.prototype.otherCallRejected=function(e){d(this.promise,this.onRejected,e)},a.resolve=function(e,t){var n=m(f,t);if(n.status===`error`)return a.reject(e,n.value);var r=n.value;if(r)p(e,r);else{e.state=s,e.outcome=t;for(var i=-1,o=e.queue.length;++i<o;)e.queue[i].callFulfilled(t)}return e},a.reject=function(e,t){e.state=o,e.outcome=t;for(var n=-1,r=e.queue.length;++n<r;)e.queue[n].callRejected(t);return e},l.resolve=function(e){return e instanceof this?e:a.resolve(new this(i),e)},l.reject=function(e){var t=new this(i);return a.reject(t,e)},l.all=function(e){var t=this;if(Object.prototype.toString.call(e)!==`[object Array]`)return this.reject(TypeError(`must be an array`));var n=e.length,r=!1;if(!n)return this.resolve([]);for(var o=Array(n),s=0,c=-1,l=new this(i);++c<n;)u(e[c],c);return l;function u(e,i){t.resolve(e).then(function(e){o[i]=e,++s!==n||r||(r=!0,a.resolve(l,o))},function(e){r||(r=!0,a.reject(l,e))})}},l.race=function(e){var t=this;if(Object.prototype.toString.call(e)!==`[object Array]`)return this.reject(TypeError(`must be an array`));var n=e.length,r=!1;if(!n)return this.resolve([]);for(var o=-1,s=new this(i);++o<n;)c=e[o],t.resolve(c).then(function(e){r||(r=!0,a.resolve(s,e))},function(e){r||(r=!0,a.reject(s,e))});var c;return s}},{immediate:36}],38:[function(e,t,n){var r={};(0,e(`./lib/utils/common`).assign)(r,e(`./lib/deflate`),e(`./lib/inflate`),e(`./lib/zlib/constants`)),t.exports=r},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(e,t,n){var r=e(`./zlib/deflate`),i=e(`./utils/common`),a=e(`./utils/strings`),o=e(`./zlib/messages`),s=e(`./zlib/zstream`),c=Object.prototype.toString,l=0,u=-1,d=0,f=8;function p(e){if(!(this instanceof p))return new p(e);this.options=i.assign({level:u,method:f,chunkSize:16384,windowBits:15,memLevel:8,strategy:d,to:``},e||{});var t=this.options;t.raw&&0<t.windowBits?t.windowBits=-t.windowBits:t.gzip&&0<t.windowBits&&t.windowBits<16&&(t.windowBits+=16),this.err=0,this.msg=``,this.ended=!1,this.chunks=[],this.strm=new s,this.strm.avail_out=0;var n=r.deflateInit2(this.strm,t.level,t.method,t.windowBits,t.memLevel,t.strategy);if(n!==l)throw Error(o[n]);if(t.header&&r.deflateSetHeader(this.strm,t.header),t.dictionary){var m=typeof t.dictionary==`string`?a.string2buf(t.dictionary):c.call(t.dictionary)===`[object ArrayBuffer]`?new Uint8Array(t.dictionary):t.dictionary;if((n=r.deflateSetDictionary(this.strm,m))!==l)throw Error(o[n]);this._dict_set=!0}}function m(e,t){var n=new p(t);if(n.push(e,!0),n.err)throw n.msg||o[n.err];return n.result}p.prototype.push=function(e,t){var n,o,s=this.strm,u=this.options.chunkSize;if(this.ended)return!1;o=t===~~t?t:!0===t?4:0,s.input=typeof e==`string`?a.string2buf(e):c.call(e)===`[object ArrayBuffer]`?new Uint8Array(e):e,s.next_in=0,s.avail_in=s.input.length;do{if(s.avail_out===0&&(s.output=new i.Buf8(u),s.next_out=0,s.avail_out=u),(n=r.deflate(s,o))!==1&&n!==l)return this.onEnd(n),!(this.ended=!0);s.avail_out!==0&&(s.avail_in!==0||o!==4&&o!==2)||(this.options.to===`string`?this.onData(a.buf2binstring(i.shrinkBuf(s.output,s.next_out))):this.onData(i.shrinkBuf(s.output,s.next_out)))}while((0<s.avail_in||s.avail_out===0)&&n!==1);return o===4?(n=r.deflateEnd(this.strm),this.onEnd(n),this.ended=!0,n===l):o!==2||(this.onEnd(l),!(s.avail_out=0))},p.prototype.onData=function(e){this.chunks.push(e)},p.prototype.onEnd=function(e){e===l&&(this.result=this.options.to===`string`?this.chunks.join(``):i.flattenChunks(this.chunks)),this.chunks=[],this.err=e,this.msg=this.strm.msg},n.Deflate=p,n.deflate=m,n.deflateRaw=function(e,t){return(t||={}).raw=!0,m(e,t)},n.gzip=function(e,t){return(t||={}).gzip=!0,m(e,t)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(e,t,n){var r=e(`./zlib/inflate`),i=e(`./utils/common`),a=e(`./utils/strings`),o=e(`./zlib/constants`),s=e(`./zlib/messages`),c=e(`./zlib/zstream`),l=e(`./zlib/gzheader`),u=Object.prototype.toString;function d(e){if(!(this instanceof d))return new d(e);this.options=i.assign({chunkSize:16384,windowBits:0,to:``},e||{});var t=this.options;t.raw&&0<=t.windowBits&&t.windowBits<16&&(t.windowBits=-t.windowBits,t.windowBits===0&&(t.windowBits=-15)),!(0<=t.windowBits&&t.windowBits<16)||e&&e.windowBits||(t.windowBits+=32),15<t.windowBits&&t.windowBits<48&&!(15&t.windowBits)&&(t.windowBits|=15),this.err=0,this.msg=``,this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var n=r.inflateInit2(this.strm,t.windowBits);if(n!==o.Z_OK)throw Error(s[n]);this.header=new l,r.inflateGetHeader(this.strm,this.header)}function f(e,t){var n=new d(t);if(n.push(e,!0),n.err)throw n.msg||s[n.err];return n.result}d.prototype.push=function(e,t){var n,s,c,l,d,f,p=this.strm,m=this.options.chunkSize,h=this.options.dictionary,g=!1;if(this.ended)return!1;s=t===~~t?t:!0===t?o.Z_FINISH:o.Z_NO_FLUSH,p.input=typeof e==`string`?a.binstring2buf(e):u.call(e)===`[object ArrayBuffer]`?new Uint8Array(e):e,p.next_in=0,p.avail_in=p.input.length;do{if(p.avail_out===0&&(p.output=new i.Buf8(m),p.next_out=0,p.avail_out=m),(n=r.inflate(p,o.Z_NO_FLUSH))===o.Z_NEED_DICT&&h&&(f=typeof h==`string`?a.string2buf(h):u.call(h)===`[object ArrayBuffer]`?new Uint8Array(h):h,n=r.inflateSetDictionary(this.strm,f)),n===o.Z_BUF_ERROR&&!0===g&&(n=o.Z_OK,g=!1),n!==o.Z_STREAM_END&&n!==o.Z_OK)return this.onEnd(n),!(this.ended=!0);p.next_out&&(p.avail_out!==0&&n!==o.Z_STREAM_END&&(p.avail_in!==0||s!==o.Z_FINISH&&s!==o.Z_SYNC_FLUSH)||(this.options.to===`string`?(c=a.utf8border(p.output,p.next_out),l=p.next_out-c,d=a.buf2string(p.output,c),p.next_out=l,p.avail_out=m-l,l&&i.arraySet(p.output,p.output,c,l,0),this.onData(d)):this.onData(i.shrinkBuf(p.output,p.next_out)))),p.avail_in===0&&p.avail_out===0&&(g=!0)}while((0<p.avail_in||p.avail_out===0)&&n!==o.Z_STREAM_END);return n===o.Z_STREAM_END&&(s=o.Z_FINISH),s===o.Z_FINISH?(n=r.inflateEnd(this.strm),this.onEnd(n),this.ended=!0,n===o.Z_OK):s!==o.Z_SYNC_FLUSH||(this.onEnd(o.Z_OK),!(p.avail_out=0))},d.prototype.onData=function(e){this.chunks.push(e)},d.prototype.onEnd=function(e){e===o.Z_OK&&(this.result=this.options.to===`string`?this.chunks.join(``):i.flattenChunks(this.chunks)),this.chunks=[],this.err=e,this.msg=this.strm.msg},n.Inflate=d,n.inflate=f,n.inflateRaw=function(e,t){return(t||={}).raw=!0,f(e,t)},n.ungzip=f},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(e,t,n){var r=typeof Uint8Array<`u`&&typeof Uint16Array<`u`&&typeof Int32Array<`u`;n.assign=function(e){for(var t=Array.prototype.slice.call(arguments,1);t.length;){var n=t.shift();if(n){if(typeof n!=`object`)throw TypeError(n+`must be non-object`);for(var r in n)n.hasOwnProperty(r)&&(e[r]=n[r])}}return e},n.shrinkBuf=function(e,t){return e.length===t?e:e.subarray?e.subarray(0,t):(e.length=t,e)};var i={arraySet:function(e,t,n,r,i){if(t.subarray&&e.subarray)e.set(t.subarray(n,n+r),i);else for(var a=0;a<r;a++)e[i+a]=t[n+a]},flattenChunks:function(e){for(var t=r=0,n=e.length,r,i,a,o;t<n;t++)r+=e[t].length;for(o=new Uint8Array(r),t=i=0,n=e.length;t<n;t++)a=e[t],o.set(a,i),i+=a.length;return o}},a={arraySet:function(e,t,n,r,i){for(var a=0;a<r;a++)e[i+a]=t[n+a]},flattenChunks:function(e){return[].concat.apply([],e)}};n.setTyped=function(e){e?(n.Buf8=Uint8Array,n.Buf16=Uint16Array,n.Buf32=Int32Array,n.assign(n,i)):(n.Buf8=Array,n.Buf16=Array,n.Buf32=Array,n.assign(n,a))},n.setTyped(r)},{}],42:[function(e,t,n){var r=e(`./common`),i=!0,a=!0;try{String.fromCharCode.apply(null,[0])}catch{i=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{a=!1}for(var o=new r.Buf8(256),s=0;s<256;s++)o[s]=252<=s?6:248<=s?5:240<=s?4:224<=s?3:192<=s?2:1;function c(e,t){if(t<65537&&(e.subarray&&a||!e.subarray&&i))return String.fromCharCode.apply(null,r.shrinkBuf(e,t));for(var n=``,o=0;o<t;o++)n+=String.fromCharCode(e[o]);return n}o[254]=o[254]=1,n.string2buf=function(e){var t,n,i,a,o,s=e.length,c=0;for(a=0;a<s;a++)(64512&(n=e.charCodeAt(a)))==55296&&a+1<s&&(64512&(i=e.charCodeAt(a+1)))==56320&&(n=65536+(n-55296<<10)+(i-56320),a++),c+=n<128?1:n<2048?2:n<65536?3:4;for(t=new r.Buf8(c),a=o=0;o<c;a++)(64512&(n=e.charCodeAt(a)))==55296&&a+1<s&&(64512&(i=e.charCodeAt(a+1)))==56320&&(n=65536+(n-55296<<10)+(i-56320),a++),n<128?t[o++]=n:(n<2048?t[o++]=192|n>>>6:(n<65536?t[o++]=224|n>>>12:(t[o++]=240|n>>>18,t[o++]=128|n>>>12&63),t[o++]=128|n>>>6&63),t[o++]=128|63&n);return t},n.buf2binstring=function(e){return c(e,e.length)},n.binstring2buf=function(e){for(var t=new r.Buf8(e.length),n=0,i=t.length;n<i;n++)t[n]=e.charCodeAt(n);return t},n.buf2string=function(e,t){var n,r,i,a,s=t||e.length,l=Array(2*s);for(n=r=0;n<s;)if((i=e[n++])<128)l[r++]=i;else if(4<(a=o[i]))l[r++]=65533,n+=a-1;else{for(i&=a===2?31:a===3?15:7;1<a&&n<s;)i=i<<6|63&e[n++],a--;1<a?l[r++]=65533:i<65536?l[r++]=i:(i-=65536,l[r++]=55296|i>>10&1023,l[r++]=56320|1023&i)}return c(l,r)},n.utf8border=function(e,t){var n;for((t||=e.length)>e.length&&(t=e.length),n=t-1;0<=n&&(192&e[n])==128;)n--;return n<0||n===0?t:n+o[e[n]]>t?n:t}},{"./common":41}],43:[function(e,t,n){t.exports=function(e,t,n,r){for(var i=65535&e,a=e>>>16&65535,o=0;n!==0;){for(n-=o=2e3<n?2e3:n;a=a+(i=i+t[r++]|0)|0,--o;);i%=65521,a%=65521}return i|a<<16}},{}],44:[function(e,t,n){t.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(e,t,n){var r=function(){for(var e,t=[],n=0;n<256;n++){e=n;for(var r=0;r<8;r++)e=1&e?3988292384^e>>>1:e>>>1;t[n]=e}return t}();t.exports=function(e,t,n,i){var a=r,o=i+n;e^=-1;for(var s=i;s<o;s++)e=e>>>8^a[255&(e^t[s])];return-1^e}},{}],46:[function(e,t,n){var r,i=e(`../utils/common`),a=e(`./trees`),o=e(`./adler32`),s=e(`./crc32`),c=e(`./messages`),l=0,u=4,d=0,f=-2,p=-1,m=4,h=2,g=8,_=9,v=286,y=30,b=19,x=2*v+1,S=15,C=3,w=258,T=w+C+1,E=42,D=113,O=1,k=2,A=3,j=4;function M(e,t){return e.msg=c[t],t}function ee(e){return(e<<1)-(4<e?9:0)}function N(e){for(var t=e.length;0<=--t;)e[t]=0}function P(e){var t=e.state,n=t.pending;n>e.avail_out&&(n=e.avail_out),n!==0&&(i.arraySet(e.output,t.pending_buf,t.pending_out,n,e.next_out),e.next_out+=n,t.pending_out+=n,e.total_out+=n,e.avail_out-=n,t.pending-=n,t.pending===0&&(t.pending_out=0))}function F(e,t){a._tr_flush_block(e,0<=e.block_start?e.block_start:-1,e.strstart-e.block_start,t),e.block_start=e.strstart,P(e.strm)}function I(e,t){e.pending_buf[e.pending++]=t}function R(e,t){e.pending_buf[e.pending++]=t>>>8&255,e.pending_buf[e.pending++]=255&t}function z(e,t){var n,r,i=e.max_chain_length,a=e.strstart,o=e.prev_length,s=e.nice_match,c=e.strstart>e.w_size-T?e.strstart-(e.w_size-T):0,l=e.window,u=e.w_mask,d=e.prev,f=e.strstart+w,p=l[a+o-1],m=l[a+o];e.prev_length>=e.good_match&&(i>>=2),s>e.lookahead&&(s=e.lookahead);do if(l[(n=t)+o]===m&&l[n+o-1]===p&&l[n]===l[a]&&l[++n]===l[a+1]){a+=2,n++;do;while(l[++a]===l[++n]&&l[++a]===l[++n]&&l[++a]===l[++n]&&l[++a]===l[++n]&&l[++a]===l[++n]&&l[++a]===l[++n]&&l[++a]===l[++n]&&l[++a]===l[++n]&&a<f);if(r=w-(f-a),a=f-w,o<r){if(e.match_start=t,s<=(o=r))break;p=l[a+o-1],m=l[a+o]}}while((t=d[t&u])>c&&--i!=0);return o<=e.lookahead?o:e.lookahead}function B(e){var t,n,r,a,c,l,u,d,f,p,m=e.w_size;do{if(a=e.window_size-e.lookahead-e.strstart,e.strstart>=m+(m-T)){for(i.arraySet(e.window,e.window,m,m,0),e.match_start-=m,e.strstart-=m,e.block_start-=m,t=n=e.hash_size;r=e.head[--t],e.head[t]=m<=r?r-m:0,--n;);for(t=n=m;r=e.prev[--t],e.prev[t]=m<=r?r-m:0,--n;);a+=m}if(e.strm.avail_in===0)break;if(l=e.strm,u=e.window,d=e.strstart+e.lookahead,f=a,p=void 0,p=l.avail_in,f<p&&(p=f),n=p===0?0:(l.avail_in-=p,i.arraySet(u,l.input,l.next_in,p,d),l.state.wrap===1?l.adler=o(l.adler,u,p,d):l.state.wrap===2&&(l.adler=s(l.adler,u,p,d)),l.next_in+=p,l.total_in+=p,p),e.lookahead+=n,e.lookahead+e.insert>=C)for(c=e.strstart-e.insert,e.ins_h=e.window[c],e.ins_h=(e.ins_h<<e.hash_shift^e.window[c+1])&e.hash_mask;e.insert&&(e.ins_h=(e.ins_h<<e.hash_shift^e.window[c+C-1])&e.hash_mask,e.prev[c&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=c,c++,e.insert--,!(e.lookahead+e.insert<C)););}while(e.lookahead<T&&e.strm.avail_in!==0)}function te(e,t){for(var n,r;;){if(e.lookahead<T){if(B(e),e.lookahead<T&&t===l)return O;if(e.lookahead===0)break}if(n=0,e.lookahead>=C&&(e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+C-1])&e.hash_mask,n=e.prev[e.strstart&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=e.strstart),n!==0&&e.strstart-n<=e.w_size-T&&(e.match_length=z(e,n)),e.match_length>=C){if(r=a._tr_tally(e,e.strstart-e.match_start,e.match_length-C),e.lookahead-=e.match_length,e.match_length<=e.max_lazy_match&&e.lookahead>=C){for(e.match_length--;e.strstart++,e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+C-1])&e.hash_mask,n=e.prev[e.strstart&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=e.strstart,--e.match_length!=0;);e.strstart++}else e.strstart+=e.match_length,e.match_length=0,e.ins_h=e.window[e.strstart],e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+1])&e.hash_mask}else r=a._tr_tally(e,0,e.window[e.strstart]),e.lookahead--,e.strstart++;if(r&&(F(e,!1),e.strm.avail_out===0))return O}return e.insert=e.strstart<C-1?e.strstart:C-1,t===u?(F(e,!0),e.strm.avail_out===0?A:j):e.last_lit&&(F(e,!1),e.strm.avail_out===0)?O:k}function ne(e,t){for(var n,r,i;;){if(e.lookahead<T){if(B(e),e.lookahead<T&&t===l)return O;if(e.lookahead===0)break}if(n=0,e.lookahead>=C&&(e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+C-1])&e.hash_mask,n=e.prev[e.strstart&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=e.strstart),e.prev_length=e.match_length,e.prev_match=e.match_start,e.match_length=C-1,n!==0&&e.prev_length<e.max_lazy_match&&e.strstart-n<=e.w_size-T&&(e.match_length=z(e,n),e.match_length<=5&&(e.strategy===1||e.match_length===C&&4096<e.strstart-e.match_start)&&(e.match_length=C-1)),e.prev_length>=C&&e.match_length<=e.prev_length){for(i=e.strstart+e.lookahead-C,r=a._tr_tally(e,e.strstart-1-e.prev_match,e.prev_length-C),e.lookahead-=e.prev_length-1,e.prev_length-=2;++e.strstart<=i&&(e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+C-1])&e.hash_mask,n=e.prev[e.strstart&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=e.strstart),--e.prev_length!=0;);if(e.match_available=0,e.match_length=C-1,e.strstart++,r&&(F(e,!1),e.strm.avail_out===0))return O}else if(e.match_available){if((r=a._tr_tally(e,0,e.window[e.strstart-1]))&&F(e,!1),e.strstart++,e.lookahead--,e.strm.avail_out===0)return O}else e.match_available=1,e.strstart++,e.lookahead--}return e.match_available&&=(r=a._tr_tally(e,0,e.window[e.strstart-1]),0),e.insert=e.strstart<C-1?e.strstart:C-1,t===u?(F(e,!0),e.strm.avail_out===0?A:j):e.last_lit&&(F(e,!1),e.strm.avail_out===0)?O:k}function re(e,t,n,r,i){this.good_length=e,this.max_lazy=t,this.nice_length=n,this.max_chain=r,this.func=i}function ie(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=g,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new i.Buf16(2*x),this.dyn_dtree=new i.Buf16(2*(2*y+1)),this.bl_tree=new i.Buf16(2*(2*b+1)),N(this.dyn_ltree),N(this.dyn_dtree),N(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new i.Buf16(S+1),this.heap=new i.Buf16(2*v+1),N(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new i.Buf16(2*v+1),N(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ae(e){var t;return e&&e.state?(e.total_in=e.total_out=0,e.data_type=h,(t=e.state).pending=0,t.pending_out=0,t.wrap<0&&(t.wrap=-t.wrap),t.status=t.wrap?E:D,e.adler=t.wrap===2?0:1,t.last_flush=l,a._tr_init(t),d):M(e,f)}function oe(e){var t=ae(e);return t===d&&function(e){e.window_size=2*e.w_size,N(e.head),e.max_lazy_match=r[e.level].max_lazy,e.good_match=r[e.level].good_length,e.nice_match=r[e.level].nice_length,e.max_chain_length=r[e.level].max_chain,e.strstart=0,e.block_start=0,e.lookahead=0,e.insert=0,e.match_length=e.prev_length=C-1,e.match_available=0,e.ins_h=0}(e.state),t}function se(e,t,n,r,a,o){if(!e)return f;var s=1;if(t===p&&(t=6),r<0?(s=0,r=-r):15<r&&(s=2,r-=16),a<1||_<a||n!==g||r<8||15<r||t<0||9<t||o<0||m<o)return M(e,f);r===8&&(r=9);var c=new ie;return(e.state=c).strm=e,c.wrap=s,c.gzhead=null,c.w_bits=r,c.w_size=1<<c.w_bits,c.w_mask=c.w_size-1,c.hash_bits=a+7,c.hash_size=1<<c.hash_bits,c.hash_mask=c.hash_size-1,c.hash_shift=~~((c.hash_bits+C-1)/C),c.window=new i.Buf8(2*c.w_size),c.head=new i.Buf16(c.hash_size),c.prev=new i.Buf16(c.w_size),c.lit_bufsize=1<<a+6,c.pending_buf_size=4*c.lit_bufsize,c.pending_buf=new i.Buf8(c.pending_buf_size),c.d_buf=1*c.lit_bufsize,c.l_buf=3*c.lit_bufsize,c.level=t,c.strategy=o,c.method=n,oe(e)}r=[new re(0,0,0,0,function(e,t){var n=65535;for(n>e.pending_buf_size-5&&(n=e.pending_buf_size-5);;){if(e.lookahead<=1){if(B(e),e.lookahead===0&&t===l)return O;if(e.lookahead===0)break}e.strstart+=e.lookahead,e.lookahead=0;var r=e.block_start+n;if((e.strstart===0||e.strstart>=r)&&(e.lookahead=e.strstart-r,e.strstart=r,F(e,!1),e.strm.avail_out===0)||e.strstart-e.block_start>=e.w_size-T&&(F(e,!1),e.strm.avail_out===0))return O}return e.insert=0,t===u?(F(e,!0),e.strm.avail_out===0?A:j):(e.strstart>e.block_start&&(F(e,!1),e.strm.avail_out),O)}),new re(4,4,8,4,te),new re(4,5,16,8,te),new re(4,6,32,32,te),new re(4,4,16,16,ne),new re(8,16,32,32,ne),new re(8,16,128,128,ne),new re(8,32,128,256,ne),new re(32,128,258,1024,ne),new re(32,258,258,4096,ne)],n.deflateInit=function(e,t){return se(e,t,g,15,8,0)},n.deflateInit2=se,n.deflateReset=oe,n.deflateResetKeep=ae,n.deflateSetHeader=function(e,t){return e&&e.state&&e.state.wrap===2?(e.state.gzhead=t,d):f},n.deflate=function(e,t){var n,i,o,c;if(!e||!e.state||5<t||t<0)return e?M(e,f):f;if(i=e.state,!e.output||!e.input&&e.avail_in!==0||i.status===666&&t!==u)return M(e,e.avail_out===0?-5:f);if(i.strm=e,n=i.last_flush,i.last_flush=t,i.status===E){if(i.wrap===2)e.adler=0,I(i,31),I(i,139),I(i,8),i.gzhead?(I(i,+!!i.gzhead.text+(i.gzhead.hcrc?2:0)+(i.gzhead.extra?4:0)+(i.gzhead.name?8:0)+(i.gzhead.comment?16:0)),I(i,255&i.gzhead.time),I(i,i.gzhead.time>>8&255),I(i,i.gzhead.time>>16&255),I(i,i.gzhead.time>>24&255),I(i,i.level===9?2:2<=i.strategy||i.level<2?4:0),I(i,255&i.gzhead.os),i.gzhead.extra&&i.gzhead.extra.length&&(I(i,255&i.gzhead.extra.length),I(i,i.gzhead.extra.length>>8&255)),i.gzhead.hcrc&&(e.adler=s(e.adler,i.pending_buf,i.pending,0)),i.gzindex=0,i.status=69):(I(i,0),I(i,0),I(i,0),I(i,0),I(i,0),I(i,i.level===9?2:2<=i.strategy||i.level<2?4:0),I(i,3),i.status=D);else{var p=g+(i.w_bits-8<<4)<<8;p|=(2<=i.strategy||i.level<2?0:i.level<6?1:i.level===6?2:3)<<6,i.strstart!==0&&(p|=32),p+=31-p%31,i.status=D,R(i,p),i.strstart!==0&&(R(i,e.adler>>>16),R(i,65535&e.adler)),e.adler=1}}if(i.status===69){if(i.gzhead.extra){for(o=i.pending;i.gzindex<(65535&i.gzhead.extra.length)&&(i.pending!==i.pending_buf_size||(i.gzhead.hcrc&&i.pending>o&&(e.adler=s(e.adler,i.pending_buf,i.pending-o,o)),P(e),o=i.pending,i.pending!==i.pending_buf_size));)I(i,255&i.gzhead.extra[i.gzindex]),i.gzindex++;i.gzhead.hcrc&&i.pending>o&&(e.adler=s(e.adler,i.pending_buf,i.pending-o,o)),i.gzindex===i.gzhead.extra.length&&(i.gzindex=0,i.status=73)}else i.status=73}if(i.status===73){if(i.gzhead.name){o=i.pending;do{if(i.pending===i.pending_buf_size&&(i.gzhead.hcrc&&i.pending>o&&(e.adler=s(e.adler,i.pending_buf,i.pending-o,o)),P(e),o=i.pending,i.pending===i.pending_buf_size)){c=1;break}c=i.gzindex<i.gzhead.name.length?255&i.gzhead.name.charCodeAt(i.gzindex++):0,I(i,c)}while(c!==0);i.gzhead.hcrc&&i.pending>o&&(e.adler=s(e.adler,i.pending_buf,i.pending-o,o)),c===0&&(i.gzindex=0,i.status=91)}else i.status=91}if(i.status===91){if(i.gzhead.comment){o=i.pending;do{if(i.pending===i.pending_buf_size&&(i.gzhead.hcrc&&i.pending>o&&(e.adler=s(e.adler,i.pending_buf,i.pending-o,o)),P(e),o=i.pending,i.pending===i.pending_buf_size)){c=1;break}c=i.gzindex<i.gzhead.comment.length?255&i.gzhead.comment.charCodeAt(i.gzindex++):0,I(i,c)}while(c!==0);i.gzhead.hcrc&&i.pending>o&&(e.adler=s(e.adler,i.pending_buf,i.pending-o,o)),c===0&&(i.status=103)}else i.status=103}if(i.status===103&&(i.gzhead.hcrc?(i.pending+2>i.pending_buf_size&&P(e),i.pending+2<=i.pending_buf_size&&(I(i,255&e.adler),I(i,e.adler>>8&255),e.adler=0,i.status=D)):i.status=D),i.pending!==0){if(P(e),e.avail_out===0)return i.last_flush=-1,d}else if(e.avail_in===0&&ee(t)<=ee(n)&&t!==u)return M(e,-5);if(i.status===666&&e.avail_in!==0)return M(e,-5);if(e.avail_in!==0||i.lookahead!==0||t!==l&&i.status!==666){var m=i.strategy===2?function(e,t){for(var n;;){if(e.lookahead===0&&(B(e),e.lookahead===0)){if(t===l)return O;break}if(e.match_length=0,n=a._tr_tally(e,0,e.window[e.strstart]),e.lookahead--,e.strstart++,n&&(F(e,!1),e.strm.avail_out===0))return O}return e.insert=0,t===u?(F(e,!0),e.strm.avail_out===0?A:j):e.last_lit&&(F(e,!1),e.strm.avail_out===0)?O:k}(i,t):i.strategy===3?function(e,t){for(var n,r,i,o,s=e.window;;){if(e.lookahead<=w){if(B(e),e.lookahead<=w&&t===l)return O;if(e.lookahead===0)break}if(e.match_length=0,e.lookahead>=C&&0<e.strstart&&(r=s[i=e.strstart-1])===s[++i]&&r===s[++i]&&r===s[++i]){o=e.strstart+w;do;while(r===s[++i]&&r===s[++i]&&r===s[++i]&&r===s[++i]&&r===s[++i]&&r===s[++i]&&r===s[++i]&&r===s[++i]&&i<o);e.match_length=w-(o-i),e.match_length>e.lookahead&&(e.match_length=e.lookahead)}if(e.match_length>=C?(n=a._tr_tally(e,1,e.match_length-C),e.lookahead-=e.match_length,e.strstart+=e.match_length,e.match_length=0):(n=a._tr_tally(e,0,e.window[e.strstart]),e.lookahead--,e.strstart++),n&&(F(e,!1),e.strm.avail_out===0))return O}return e.insert=0,t===u?(F(e,!0),e.strm.avail_out===0?A:j):e.last_lit&&(F(e,!1),e.strm.avail_out===0)?O:k}(i,t):r[i.level].func(i,t);if(m!==A&&m!==j||(i.status=666),m===O||m===A)return e.avail_out===0&&(i.last_flush=-1),d;if(m===k&&(t===1?a._tr_align(i):t!==5&&(a._tr_stored_block(i,0,0,!1),t===3&&(N(i.head),i.lookahead===0&&(i.strstart=0,i.block_start=0,i.insert=0))),P(e),e.avail_out===0))return i.last_flush=-1,d}return t===u?i.wrap<=0?1:(i.wrap===2?(I(i,255&e.adler),I(i,e.adler>>8&255),I(i,e.adler>>16&255),I(i,e.adler>>24&255),I(i,255&e.total_in),I(i,e.total_in>>8&255),I(i,e.total_in>>16&255),I(i,e.total_in>>24&255)):(R(i,e.adler>>>16),R(i,65535&e.adler)),P(e),0<i.wrap&&(i.wrap=-i.wrap),i.pending===0?1:d):d},n.deflateEnd=function(e){var t;return e&&e.state?(t=e.state.status)!==E&&t!==69&&t!==73&&t!==91&&t!==103&&t!==D&&t!==666?M(e,f):(e.state=null,t===D?M(e,-3):d):f},n.deflateSetDictionary=function(e,t){var n,r,a,s,c,l,u,p,m=t.length;if(!e||!e.state||(s=(n=e.state).wrap)===2||s===1&&n.status!==E||n.lookahead)return f;for(s===1&&(e.adler=o(e.adler,t,m,0)),n.wrap=0,m>=n.w_size&&(s===0&&(N(n.head),n.strstart=0,n.block_start=0,n.insert=0),p=new i.Buf8(n.w_size),i.arraySet(p,t,m-n.w_size,n.w_size,0),t=p,m=n.w_size),c=e.avail_in,l=e.next_in,u=e.input,e.avail_in=m,e.next_in=0,e.input=t,B(n);n.lookahead>=C;){for(r=n.strstart,a=n.lookahead-(C-1);n.ins_h=(n.ins_h<<n.hash_shift^n.window[r+C-1])&n.hash_mask,n.prev[r&n.w_mask]=n.head[n.ins_h],n.head[n.ins_h]=r,r++,--a;);n.strstart=r,n.lookahead=C-1,B(n)}return n.strstart+=n.lookahead,n.block_start=n.strstart,n.insert=n.lookahead,n.lookahead=0,n.match_length=n.prev_length=C-1,n.match_available=0,e.next_in=l,e.input=u,e.avail_in=c,n.wrap=s,d},n.deflateInfo=`pako deflate (from Nodeca project)`},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(e,t,n){t.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name=``,this.comment=``,this.hcrc=0,this.done=!1}},{}],48:[function(e,t,n){t.exports=function(e,t){var n=e.state,r=e.next_in,i,a,o,s,c,l,u,d,f,p,m,h,g,_,v,y,b,x,S,C,w,T=e.input,E;i=r+(e.avail_in-5),a=e.next_out,E=e.output,o=a-(t-e.avail_out),s=a+(e.avail_out-257),c=n.dmax,l=n.wsize,u=n.whave,d=n.wnext,f=n.window,p=n.hold,m=n.bits,h=n.lencode,g=n.distcode,_=(1<<n.lenbits)-1,v=(1<<n.distbits)-1;e:do{m<15&&(p+=T[r++]<<m,m+=8,p+=T[r++]<<m,m+=8),y=h[p&_];t:for(;;){if(p>>>=b=y>>>24,m-=b,(b=y>>>16&255)==0)E[a++]=65535&y;else{if(!(16&b)){if(!(64&b)){y=h[(65535&y)+(p&(1<<b)-1)];continue t}if(32&b){n.mode=12;break e}e.msg=`invalid literal/length code`,n.mode=30;break e}x=65535&y,(b&=15)&&(m<b&&(p+=T[r++]<<m,m+=8),x+=p&(1<<b)-1,p>>>=b,m-=b),m<15&&(p+=T[r++]<<m,m+=8,p+=T[r++]<<m,m+=8),y=g[p&v];r:for(;;){if(p>>>=b=y>>>24,m-=b,!(16&(b=y>>>16&255))){if(!(64&b)){y=g[(65535&y)+(p&(1<<b)-1)];continue r}e.msg=`invalid distance code`,n.mode=30;break e}if(S=65535&y,m<(b&=15)&&(p+=T[r++]<<m,(m+=8)<b&&(p+=T[r++]<<m,m+=8)),c<(S+=p&(1<<b)-1)){e.msg=`invalid distance too far back`,n.mode=30;break e}if(p>>>=b,m-=b,(b=a-o)<S){if(u<(b=S-b)&&n.sane){e.msg=`invalid distance too far back`,n.mode=30;break e}if(w=f,(C=0)===d){if(C+=l-b,b<x){for(x-=b;E[a++]=f[C++],--b;);C=a-S,w=E}}else if(d<b){if(C+=l+d-b,(b-=d)<x){for(x-=b;E[a++]=f[C++],--b;);if(C=0,d<x){for(x-=b=d;E[a++]=f[C++],--b;);C=a-S,w=E}}}else if(C+=d-b,b<x){for(x-=b;E[a++]=f[C++],--b;);C=a-S,w=E}for(;2<x;)E[a++]=w[C++],E[a++]=w[C++],E[a++]=w[C++],x-=3;x&&(E[a++]=w[C++],1<x&&(E[a++]=w[C++]))}else{for(C=a-S;E[a++]=E[C++],E[a++]=E[C++],E[a++]=E[C++],2<(x-=3););x&&(E[a++]=E[C++],1<x&&(E[a++]=E[C++]))}break}}break}}while(r<i&&a<s);r-=x=m>>3,p&=(1<<(m-=x<<3))-1,e.next_in=r,e.next_out=a,e.avail_in=r<i?i-r+5:5-(r-i),e.avail_out=a<s?s-a+257:257-(a-s),n.hold=p,n.bits=m}},{}],49:[function(e,t,n){var r=e(`../utils/common`),i=e(`./adler32`),a=e(`./crc32`),o=e(`./inffast`),s=e(`./inftrees`),c=1,l=2,u=0,d=-2,f=1,p=852,m=592;function h(e){return(e>>>24&255)+(e>>>8&65280)+((65280&e)<<8)+((255&e)<<24)}function g(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new r.Buf16(320),this.work=new r.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function _(e){var t;return e&&e.state?(t=e.state,e.total_in=e.total_out=t.total=0,e.msg=``,t.wrap&&(e.adler=1&t.wrap),t.mode=f,t.last=0,t.havedict=0,t.dmax=32768,t.head=null,t.hold=0,t.bits=0,t.lencode=t.lendyn=new r.Buf32(p),t.distcode=t.distdyn=new r.Buf32(m),t.sane=1,t.back=-1,u):d}function v(e){var t;return e&&e.state?((t=e.state).wsize=0,t.whave=0,t.wnext=0,_(e)):d}function y(e,t){var n,r;return e&&e.state?(r=e.state,t<0?(n=0,t=-t):(n=1+(t>>4),t<48&&(t&=15)),t&&(t<8||15<t)?d:(r.window!==null&&r.wbits!==t&&(r.window=null),r.wrap=n,r.wbits=t,v(e))):d}function b(e,t){var n,r;return e?(r=new g,(e.state=r).window=null,(n=y(e,t))!==u&&(e.state=null),n):d}var x,S,C=!0;function w(e){if(C){var t;for(x=new r.Buf32(512),S=new r.Buf32(32),t=0;t<144;)e.lens[t++]=8;for(;t<256;)e.lens[t++]=9;for(;t<280;)e.lens[t++]=7;for(;t<288;)e.lens[t++]=8;for(s(c,e.lens,0,288,x,0,e.work,{bits:9}),t=0;t<32;)e.lens[t++]=5;s(l,e.lens,0,32,S,0,e.work,{bits:5}),C=!1}e.lencode=x,e.lenbits=9,e.distcode=S,e.distbits=5}function T(e,t,n,i){var a,o=e.state;return o.window===null&&(o.wsize=1<<o.wbits,o.wnext=0,o.whave=0,o.window=new r.Buf8(o.wsize)),i>=o.wsize?(r.arraySet(o.window,t,n-o.wsize,o.wsize,0),o.wnext=0,o.whave=o.wsize):(i<(a=o.wsize-o.wnext)&&(a=i),r.arraySet(o.window,t,n-i,a,o.wnext),(i-=a)?(r.arraySet(o.window,t,n-i,i,0),o.wnext=i,o.whave=o.wsize):(o.wnext+=a,o.wnext===o.wsize&&(o.wnext=0),o.whave<o.wsize&&(o.whave+=a))),0}n.inflateReset=v,n.inflateReset2=y,n.inflateResetKeep=_,n.inflateInit=function(e){return b(e,15)},n.inflateInit2=b,n.inflate=function(e,t){var n,p,m,g,_,v,y,b,x,S,C,E,D,O,k,A,j,M,ee,N,P,F,I,R,z=0,B=new r.Buf8(4),te=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!e||!e.state||!e.output||!e.input&&e.avail_in!==0)return d;(n=e.state).mode===12&&(n.mode=13),_=e.next_out,m=e.output,y=e.avail_out,g=e.next_in,p=e.input,v=e.avail_in,b=n.hold,x=n.bits,S=v,C=y,F=u;e:for(;;)switch(n.mode){case f:if(n.wrap===0){n.mode=13;break}for(;x<16;){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}if(2&n.wrap&&b===35615){B[n.check=0]=255&b,B[1]=b>>>8&255,n.check=a(n.check,B,2,0),x=b=0,n.mode=2;break}if(n.flags=0,n.head&&(n.head.done=!1),!(1&n.wrap)||(((255&b)<<8)+(b>>8))%31){e.msg=`incorrect header check`,n.mode=30;break}if((15&b)!=8){e.msg=`unknown compression method`,n.mode=30;break}if(x-=4,P=8+(15&(b>>>=4)),n.wbits===0)n.wbits=P;else if(P>n.wbits){e.msg=`invalid window size`,n.mode=30;break}n.dmax=1<<P,e.adler=n.check=1,n.mode=512&b?10:12,x=b=0;break;case 2:for(;x<16;){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}if(n.flags=b,(255&n.flags)!=8){e.msg=`unknown compression method`,n.mode=30;break}if(57344&n.flags){e.msg=`unknown header flags set`,n.mode=30;break}n.head&&(n.head.text=b>>8&1),512&n.flags&&(B[0]=255&b,B[1]=b>>>8&255,n.check=a(n.check,B,2,0)),x=b=0,n.mode=3;case 3:for(;x<32;){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}n.head&&(n.head.time=b),512&n.flags&&(B[0]=255&b,B[1]=b>>>8&255,B[2]=b>>>16&255,B[3]=b>>>24&255,n.check=a(n.check,B,4,0)),x=b=0,n.mode=4;case 4:for(;x<16;){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}n.head&&(n.head.xflags=255&b,n.head.os=b>>8),512&n.flags&&(B[0]=255&b,B[1]=b>>>8&255,n.check=a(n.check,B,2,0)),x=b=0,n.mode=5;case 5:if(1024&n.flags){for(;x<16;){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}n.length=b,n.head&&(n.head.extra_len=b),512&n.flags&&(B[0]=255&b,B[1]=b>>>8&255,n.check=a(n.check,B,2,0)),x=b=0}else n.head&&(n.head.extra=null);n.mode=6;case 6:if(1024&n.flags&&(v<(E=n.length)&&(E=v),E&&(n.head&&(P=n.head.extra_len-n.length,n.head.extra||(n.head.extra=Array(n.head.extra_len)),r.arraySet(n.head.extra,p,g,E,P)),512&n.flags&&(n.check=a(n.check,p,E,g)),v-=E,g+=E,n.length-=E),n.length))break e;n.length=0,n.mode=7;case 7:if(2048&n.flags){if(v===0)break e;for(E=0;P=p[g+E++],n.head&&P&&n.length<65536&&(n.head.name+=String.fromCharCode(P)),P&&E<v;);if(512&n.flags&&(n.check=a(n.check,p,E,g)),v-=E,g+=E,P)break e}else n.head&&(n.head.name=null);n.length=0,n.mode=8;case 8:if(4096&n.flags){if(v===0)break e;for(E=0;P=p[g+E++],n.head&&P&&n.length<65536&&(n.head.comment+=String.fromCharCode(P)),P&&E<v;);if(512&n.flags&&(n.check=a(n.check,p,E,g)),v-=E,g+=E,P)break e}else n.head&&(n.head.comment=null);n.mode=9;case 9:if(512&n.flags){for(;x<16;){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}if(b!==(65535&n.check)){e.msg=`header crc mismatch`,n.mode=30;break}x=b=0}n.head&&(n.head.hcrc=n.flags>>9&1,n.head.done=!0),e.adler=n.check=0,n.mode=12;break;case 10:for(;x<32;){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}e.adler=n.check=h(b),x=b=0,n.mode=11;case 11:if(n.havedict===0)return e.next_out=_,e.avail_out=y,e.next_in=g,e.avail_in=v,n.hold=b,n.bits=x,2;e.adler=n.check=1,n.mode=12;case 12:if(t===5||t===6)break e;case 13:if(n.last){b>>>=7&x,x-=7&x,n.mode=27;break}for(;x<3;){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}switch(n.last=1&b,--x,3&(b>>>=1)){case 0:n.mode=14;break;case 1:if(w(n),n.mode=20,t!==6)break;b>>>=2,x-=2;break e;case 2:n.mode=17;break;case 3:e.msg=`invalid block type`,n.mode=30}b>>>=2,x-=2;break;case 14:for(b>>>=7&x,x-=7&x;x<32;){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}if((65535&b)!=(b>>>16^65535)){e.msg=`invalid stored block lengths`,n.mode=30;break}if(n.length=65535&b,x=b=0,n.mode=15,t===6)break e;case 15:n.mode=16;case 16:if(E=n.length){if(v<E&&(E=v),y<E&&(E=y),E===0)break e;r.arraySet(m,p,g,E,_),v-=E,g+=E,y-=E,_+=E,n.length-=E;break}n.mode=12;break;case 17:for(;x<14;){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}if(n.nlen=257+(31&b),b>>>=5,x-=5,n.ndist=1+(31&b),b>>>=5,x-=5,n.ncode=4+(15&b),b>>>=4,x-=4,286<n.nlen||30<n.ndist){e.msg=`too many length or distance symbols`,n.mode=30;break}n.have=0,n.mode=18;case 18:for(;n.have<n.ncode;){for(;x<3;){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}n.lens[te[n.have++]]=7&b,b>>>=3,x-=3}for(;n.have<19;)n.lens[te[n.have++]]=0;if(n.lencode=n.lendyn,n.lenbits=7,I={bits:n.lenbits},F=s(0,n.lens,0,19,n.lencode,0,n.work,I),n.lenbits=I.bits,F){e.msg=`invalid code lengths set`,n.mode=30;break}n.have=0,n.mode=19;case 19:for(;n.have<n.nlen+n.ndist;){for(;A=(z=n.lencode[b&(1<<n.lenbits)-1])>>>16&255,j=65535&z,!((k=z>>>24)<=x);){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}if(j<16)b>>>=k,x-=k,n.lens[n.have++]=j;else{if(j===16){for(R=k+2;x<R;){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}if(b>>>=k,x-=k,n.have===0){e.msg=`invalid bit length repeat`,n.mode=30;break}P=n.lens[n.have-1],E=3+(3&b),b>>>=2,x-=2}else if(j===17){for(R=k+3;x<R;){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}x-=k,P=0,E=3+(7&(b>>>=k)),b>>>=3,x-=3}else{for(R=k+7;x<R;){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}x-=k,P=0,E=11+(127&(b>>>=k)),b>>>=7,x-=7}if(n.have+E>n.nlen+n.ndist){e.msg=`invalid bit length repeat`,n.mode=30;break}for(;E--;)n.lens[n.have++]=P}}if(n.mode===30)break;if(n.lens[256]===0){e.msg=`invalid code -- missing end-of-block`,n.mode=30;break}if(n.lenbits=9,I={bits:n.lenbits},F=s(c,n.lens,0,n.nlen,n.lencode,0,n.work,I),n.lenbits=I.bits,F){e.msg=`invalid literal/lengths set`,n.mode=30;break}if(n.distbits=6,n.distcode=n.distdyn,I={bits:n.distbits},F=s(l,n.lens,n.nlen,n.ndist,n.distcode,0,n.work,I),n.distbits=I.bits,F){e.msg=`invalid distances set`,n.mode=30;break}if(n.mode=20,t===6)break e;case 20:n.mode=21;case 21:if(6<=v&&258<=y){e.next_out=_,e.avail_out=y,e.next_in=g,e.avail_in=v,n.hold=b,n.bits=x,o(e,C),_=e.next_out,m=e.output,y=e.avail_out,g=e.next_in,p=e.input,v=e.avail_in,b=n.hold,x=n.bits,n.mode===12&&(n.back=-1);break}for(n.back=0;A=(z=n.lencode[b&(1<<n.lenbits)-1])>>>16&255,j=65535&z,!((k=z>>>24)<=x);){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}if(A&&!(240&A)){for(M=k,ee=A,N=j;A=(z=n.lencode[N+((b&(1<<M+ee)-1)>>M)])>>>16&255,j=65535&z,!(M+(k=z>>>24)<=x);){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}b>>>=M,x-=M,n.back+=M}if(b>>>=k,x-=k,n.back+=k,n.length=j,A===0){n.mode=26;break}if(32&A){n.back=-1,n.mode=12;break}if(64&A){e.msg=`invalid literal/length code`,n.mode=30;break}n.extra=15&A,n.mode=22;case 22:if(n.extra){for(R=n.extra;x<R;){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}n.length+=b&(1<<n.extra)-1,b>>>=n.extra,x-=n.extra,n.back+=n.extra}n.was=n.length,n.mode=23;case 23:for(;A=(z=n.distcode[b&(1<<n.distbits)-1])>>>16&255,j=65535&z,!((k=z>>>24)<=x);){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}if(!(240&A)){for(M=k,ee=A,N=j;A=(z=n.distcode[N+((b&(1<<M+ee)-1)>>M)])>>>16&255,j=65535&z,!(M+(k=z>>>24)<=x);){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}b>>>=M,x-=M,n.back+=M}if(b>>>=k,x-=k,n.back+=k,64&A){e.msg=`invalid distance code`,n.mode=30;break}n.offset=j,n.extra=15&A,n.mode=24;case 24:if(n.extra){for(R=n.extra;x<R;){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}n.offset+=b&(1<<n.extra)-1,b>>>=n.extra,x-=n.extra,n.back+=n.extra}if(n.offset>n.dmax){e.msg=`invalid distance too far back`,n.mode=30;break}n.mode=25;case 25:if(y===0)break e;if(E=C-y,n.offset>E){if((E=n.offset-E)>n.whave&&n.sane){e.msg=`invalid distance too far back`,n.mode=30;break}D=E>n.wnext?(E-=n.wnext,n.wsize-E):n.wnext-E,E>n.length&&(E=n.length),O=n.window}else O=m,D=_-n.offset,E=n.length;for(y<E&&(E=y),y-=E,n.length-=E;m[_++]=O[D++],--E;);n.length===0&&(n.mode=21);break;case 26:if(y===0)break e;m[_++]=n.length,y--,n.mode=21;break;case 27:if(n.wrap){for(;x<32;){if(v===0)break e;v--,b|=p[g++]<<x,x+=8}if(C-=y,e.total_out+=C,n.total+=C,C&&(e.adler=n.check=n.flags?a(n.check,m,C,_-C):i(n.check,m,C,_-C)),C=y,(n.flags?b:h(b))!==n.check){e.msg=`incorrect data check`,n.mode=30;break}x=b=0}n.mode=28;case 28:if(n.wrap&&n.flags){for(;x<32;){if(v===0)break e;v--,b+=p[g++]<<x,x+=8}if(b!==(0|n.total)){e.msg=`incorrect length check`,n.mode=30;break}x=b=0}n.mode=29;case 29:F=1;break e;case 30:F=-3;break e;case 31:return-4;default:return d}return e.next_out=_,e.avail_out=y,e.next_in=g,e.avail_in=v,n.hold=b,n.bits=x,(n.wsize||C!==e.avail_out&&n.mode<30&&(n.mode<27||t!==4))&&T(e,e.output,e.next_out,C-e.avail_out)?(n.mode=31,-4):(S-=e.avail_in,C-=e.avail_out,e.total_in+=S,e.total_out+=C,n.total+=C,n.wrap&&C&&(e.adler=n.check=n.flags?a(n.check,m,C,e.next_out-C):i(n.check,m,C,e.next_out-C)),e.data_type=n.bits+(n.last?64:0)+(n.mode===12?128:0)+(n.mode===20||n.mode===15?256:0),(S==0&&C===0||t===4)&&F===u&&(F=-5),F)},n.inflateEnd=function(e){if(!e||!e.state)return d;var t=e.state;return t.window&&=null,e.state=null,u},n.inflateGetHeader=function(e,t){var n;return e&&e.state&&2&(n=e.state).wrap?((n.head=t).done=!1,u):d},n.inflateSetDictionary=function(e,t){var n,r=t.length;return e&&e.state?(n=e.state).wrap!==0&&n.mode!==11?d:n.mode===11&&i(1,t,r,0)!==n.check?-3:T(e,t,r,r)?(n.mode=31,-4):(n.havedict=1,u):d},n.inflateInfo=`pako inflate (from Nodeca project)`},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(e,t,n){var r=e(`../utils/common`),i=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],a=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],o=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],s=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];t.exports=function(e,t,n,c,l,u,d,f){var p,m,h,g,_,v,y,b,x,S=f.bits,C=0,w=0,T=0,E=0,D=0,O=0,k=0,A=0,j=0,M=0,ee=null,N=0,P=new r.Buf16(16),F=new r.Buf16(16),I=null,R=0;for(C=0;C<=15;C++)P[C]=0;for(w=0;w<c;w++)P[t[n+w]]++;for(D=S,E=15;1<=E&&P[E]===0;E--);if(E<D&&(D=E),E===0)return l[u++]=20971520,l[u++]=20971520,f.bits=1,0;for(T=1;T<E&&P[T]===0;T++);for(D<T&&(D=T),C=A=1;C<=15;C++)if(A<<=1,(A-=P[C])<0)return-1;if(0<A&&(e===0||E!==1))return-1;for(F[1]=0,C=1;C<15;C++)F[C+1]=F[C]+P[C];for(w=0;w<c;w++)t[n+w]!==0&&(d[F[t[n+w]]++]=w);if(v=e===0?(ee=I=d,19):e===1?(ee=i,N-=257,I=a,R-=257,256):(ee=o,I=s,-1),C=T,_=u,k=w=M=0,h=-1,g=(j=1<<(O=D))-1,e===1&&852<j||e===2&&592<j)return 1;for(;;){for(y=C-k,x=d[w]<v?(b=0,d[w]):d[w]>v?(b=I[R+d[w]],ee[N+d[w]]):(b=96,0),p=1<<C-k,T=m=1<<O;l[_+(M>>k)+(m-=p)]=y<<24|b<<16|x,m!==0;);for(p=1<<C-1;M&p;)p>>=1;if(p===0?M=0:(M&=p-1,M+=p),w++,--P[C]==0){if(C===E)break;C=t[n+d[w]]}if(D<C&&(M&g)!==h){for(k===0&&(k=D),_+=T,A=1<<(O=C-k);O+k<E&&!((A-=P[O+k])<=0);)O++,A<<=1;if(j+=1<<O,e===1&&852<j||e===2&&592<j)return 1;l[h=M&g]=D<<24|O<<16|_-u}}return M!==0&&(l[_+M]=C-k<<24|4194304),f.bits=D,0}},{"../utils/common":41}],51:[function(e,t,n){t.exports={2:`need dictionary`,1:`stream end`,0:``,"-1":`file error`,"-2":`stream error`,"-3":`data error`,"-4":`insufficient memory`,"-5":`buffer error`,"-6":`incompatible version`}},{}],52:[function(e,t,n){var r=e(`../utils/common`),i=0,a=1;function o(e){for(var t=e.length;0<=--t;)e[t]=0}var s=0,c=29,l=256,u=l+1+c,d=30,f=19,p=2*u+1,m=15,h=16,g=7,_=256,v=16,y=17,b=18,x=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],S=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],C=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],w=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],T=Array(2*(u+2));o(T);var E=Array(2*d);o(E);var D=Array(512);o(D);var O=Array(256);o(O);var k=Array(c);o(k);var A,j,M,ee=Array(d);function N(e,t,n,r,i){this.static_tree=e,this.extra_bits=t,this.extra_base=n,this.elems=r,this.max_length=i,this.has_stree=e&&e.length}function P(e,t){this.dyn_tree=e,this.max_code=0,this.stat_desc=t}function F(e){return e<256?D[e]:D[256+(e>>>7)]}function I(e,t){e.pending_buf[e.pending++]=255&t,e.pending_buf[e.pending++]=t>>>8&255}function R(e,t,n){e.bi_valid>h-n?(e.bi_buf|=t<<e.bi_valid&65535,I(e,e.bi_buf),e.bi_buf=t>>h-e.bi_valid,e.bi_valid+=n-h):(e.bi_buf|=t<<e.bi_valid&65535,e.bi_valid+=n)}function z(e,t,n){R(e,n[2*t],n[2*t+1])}function B(e,t){for(var n=0;n|=1&e,e>>>=1,n<<=1,0<--t;);return n>>>1}function te(e,t,n){var r,i,a=Array(m+1),o=0;for(r=1;r<=m;r++)a[r]=o=o+n[r-1]<<1;for(i=0;i<=t;i++){var s=e[2*i+1];s!==0&&(e[2*i]=B(a[s]++,s))}}function ne(e){for(var t=0;t<u;t++)e.dyn_ltree[2*t]=0;for(t=0;t<d;t++)e.dyn_dtree[2*t]=0;for(t=0;t<f;t++)e.bl_tree[2*t]=0;e.dyn_ltree[2*_]=1,e.opt_len=e.static_len=0,e.last_lit=e.matches=0}function re(e){8<e.bi_valid?I(e,e.bi_buf):0<e.bi_valid&&(e.pending_buf[e.pending++]=e.bi_buf),e.bi_buf=0,e.bi_valid=0}function ie(e,t,n,r){var i=2*t,a=2*n;return e[i]<e[a]||e[i]===e[a]&&r[t]<=r[n]}function ae(e,t,n){for(var r=e.heap[n],i=n<<1;i<=e.heap_len&&(i<e.heap_len&&ie(t,e.heap[i+1],e.heap[i],e.depth)&&i++,!ie(t,r,e.heap[i],e.depth));)e.heap[n]=e.heap[i],n=i,i<<=1;e.heap[n]=r}function oe(e,t,n){var r,i,a,o,s=0;if(e.last_lit!==0)for(;r=e.pending_buf[e.d_buf+2*s]<<8|e.pending_buf[e.d_buf+2*s+1],i=e.pending_buf[e.l_buf+s],s++,r===0?z(e,i,t):(z(e,(a=O[i])+l+1,t),(o=x[a])!==0&&R(e,i-=k[a],o),z(e,a=F(--r),n),(o=S[a])!==0&&R(e,r-=ee[a],o)),s<e.last_lit;);z(e,_,t)}function se(e,t){var n,r,i,a=t.dyn_tree,o=t.stat_desc.static_tree,s=t.stat_desc.has_stree,c=t.stat_desc.elems,l=-1;for(e.heap_len=0,e.heap_max=p,n=0;n<c;n++)a[2*n]===0?a[2*n+1]=0:(e.heap[++e.heap_len]=l=n,e.depth[n]=0);for(;e.heap_len<2;)a[2*(i=e.heap[++e.heap_len]=l<2?++l:0)]=1,e.depth[i]=0,e.opt_len--,s&&(e.static_len-=o[2*i+1]);for(t.max_code=l,n=e.heap_len>>1;1<=n;n--)ae(e,a,n);for(i=c;n=e.heap[1],e.heap[1]=e.heap[e.heap_len--],ae(e,a,1),r=e.heap[1],e.heap[--e.heap_max]=n,e.heap[--e.heap_max]=r,a[2*i]=a[2*n]+a[2*r],e.depth[i]=(e.depth[n]>=e.depth[r]?e.depth[n]:e.depth[r])+1,a[2*n+1]=a[2*r+1]=i,e.heap[1]=i++,ae(e,a,1),2<=e.heap_len;);e.heap[--e.heap_max]=e.heap[1],function(e,t){var n,r,i,a,o,s,c=t.dyn_tree,l=t.max_code,u=t.stat_desc.static_tree,d=t.stat_desc.has_stree,f=t.stat_desc.extra_bits,h=t.stat_desc.extra_base,g=t.stat_desc.max_length,_=0;for(a=0;a<=m;a++)e.bl_count[a]=0;for(c[2*e.heap[e.heap_max]+1]=0,n=e.heap_max+1;n<p;n++)g<(a=c[2*c[2*(r=e.heap[n])+1]+1]+1)&&(a=g,_++),c[2*r+1]=a,l<r||(e.bl_count[a]++,o=0,h<=r&&(o=f[r-h]),s=c[2*r],e.opt_len+=s*(a+o),d&&(e.static_len+=s*(u[2*r+1]+o)));if(_!==0){do{for(a=g-1;e.bl_count[a]===0;)a--;e.bl_count[a]--,e.bl_count[a+1]+=2,e.bl_count[g]--,_-=2}while(0<_);for(a=g;a!==0;a--)for(r=e.bl_count[a];r!==0;)l<(i=e.heap[--n])||(c[2*i+1]!==a&&(e.opt_len+=(a-c[2*i+1])*c[2*i],c[2*i+1]=a),r--)}}(e,t),te(a,l,e.bl_count)}function ce(e,t,n){var r,i,a=-1,o=t[1],s=0,c=7,l=4;for(o===0&&(c=138,l=3),t[2*(n+1)+1]=65535,r=0;r<=n;r++)i=o,o=t[2*(r+1)+1],++s<c&&i===o||(s<l?e.bl_tree[2*i]+=s:i===0?s<=10?e.bl_tree[2*y]++:e.bl_tree[2*b]++:(i!==a&&e.bl_tree[2*i]++,e.bl_tree[2*v]++),a=i,l=(s=0)===o?(c=138,3):i===o?(c=6,3):(c=7,4))}function le(e,t,n){var r,i,a=-1,o=t[1],s=0,c=7,l=4;for(o===0&&(c=138,l=3),r=0;r<=n;r++)if(i=o,o=t[2*(r+1)+1],!(++s<c&&i===o)){if(s<l)for(;z(e,i,e.bl_tree),--s!=0;);else i===0?s<=10?(z(e,y,e.bl_tree),R(e,s-3,3)):(z(e,b,e.bl_tree),R(e,s-11,7)):(i!==a&&(z(e,i,e.bl_tree),s--),z(e,v,e.bl_tree),R(e,s-3,2));a=i,l=(s=0)===o?(c=138,3):i===o?(c=6,3):(c=7,4)}}o(ee);var V=!1;function H(e,t,n,i){R(e,(s<<1)+ +!!i,3),function(e,t,n,i){re(e),I(e,n),I(e,~n),r.arraySet(e.pending_buf,e.window,t,n,e.pending),e.pending+=n}(e,t,n,!0)}n._tr_init=function(e){V||=(function(){var e,t,n,r,i,a=Array(m+1);for(r=n=0;r<c-1;r++)for(k[r]=n,e=0;e<1<<x[r];e++)O[n++]=r;for(O[n-1]=r,r=i=0;r<16;r++)for(ee[r]=i,e=0;e<1<<S[r];e++)D[i++]=r;for(i>>=7;r<d;r++)for(ee[r]=i<<7,e=0;e<1<<S[r]-7;e++)D[256+i++]=r;for(t=0;t<=m;t++)a[t]=0;for(e=0;e<=143;)T[2*e+1]=8,e++,a[8]++;for(;e<=255;)T[2*e+1]=9,e++,a[9]++;for(;e<=279;)T[2*e+1]=7,e++,a[7]++;for(;e<=287;)T[2*e+1]=8,e++,a[8]++;for(te(T,u+1,a),e=0;e<d;e++)E[2*e+1]=5,E[2*e]=B(e,5);A=new N(T,x,l+1,u,m),j=new N(E,S,0,d,m),M=new N([],C,0,f,g)}(),!0),e.l_desc=new P(e.dyn_ltree,A),e.d_desc=new P(e.dyn_dtree,j),e.bl_desc=new P(e.bl_tree,M),e.bi_buf=0,e.bi_valid=0,ne(e)},n._tr_stored_block=H,n._tr_flush_block=function(e,t,n,r){var o,s,c=0;0<e.level?(e.strm.data_type===2&&(e.strm.data_type=function(e){var t,n=4093624447;for(t=0;t<=31;t++,n>>>=1)if(1&n&&e.dyn_ltree[2*t]!==0)return i;if(e.dyn_ltree[18]!==0||e.dyn_ltree[20]!==0||e.dyn_ltree[26]!==0)return a;for(t=32;t<l;t++)if(e.dyn_ltree[2*t]!==0)return a;return i}(e)),se(e,e.l_desc),se(e,e.d_desc),c=function(e){var t;for(ce(e,e.dyn_ltree,e.l_desc.max_code),ce(e,e.dyn_dtree,e.d_desc.max_code),se(e,e.bl_desc),t=f-1;3<=t&&e.bl_tree[2*w[t]+1]===0;t--);return e.opt_len+=3*(t+1)+5+5+4,t}(e),o=e.opt_len+3+7>>>3,(s=e.static_len+3+7>>>3)<=o&&(o=s)):o=s=n+5,n+4<=o&&t!==-1?H(e,t,n,r):e.strategy===4||s===o?(R(e,2+ +!!r,3),oe(e,T,E)):(R(e,4+ +!!r,3),function(e,t,n,r){var i;for(R(e,t-257,5),R(e,n-1,5),R(e,r-4,4),i=0;i<r;i++)R(e,e.bl_tree[2*w[i]+1],3);le(e,e.dyn_ltree,t-1),le(e,e.dyn_dtree,n-1)}(e,e.l_desc.max_code+1,e.d_desc.max_code+1,c+1),oe(e,e.dyn_ltree,e.dyn_dtree)),ne(e),r&&re(e)},n._tr_tally=function(e,t,n){return e.pending_buf[e.d_buf+2*e.last_lit]=t>>>8&255,e.pending_buf[e.d_buf+2*e.last_lit+1]=255&t,e.pending_buf[e.l_buf+e.last_lit]=255&n,e.last_lit++,t===0?e.dyn_ltree[2*n]++:(e.matches++,t--,e.dyn_ltree[2*(O[n]+l+1)]++,e.dyn_dtree[2*F(t)]++),e.last_lit===e.lit_bufsize-1},n._tr_align=function(e){R(e,2,3),z(e,_,T),function(e){e.bi_valid===16?(I(e,e.bi_buf),e.bi_buf=0,e.bi_valid=0):8<=e.bi_valid&&(e.pending_buf[e.pending++]=255&e.bi_buf,e.bi_buf>>=8,e.bi_valid-=8)}(e)}},{"../utils/common":41}],53:[function(e,t,n){t.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg=``,this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(e,t,n){(function(e){(function(e,t){if(!e.setImmediate){var n,r,i,a,o=1,s={},c=!1,l=e.document,u=Object.getPrototypeOf&&Object.getPrototypeOf(e);u=u&&u.setTimeout?u:e,n={}.toString.call(e.process)===`[object process]`?function(e){process.nextTick(function(){f(e)})}:function(){if(e.postMessage&&!e.importScripts){var t=!0,n=e.onmessage;return e.onmessage=function(){t=!1},e.postMessage(``,`*`),e.onmessage=n,t}}()?(a=`setImmediate$`+Math.random()+`$`,e.addEventListener?e.addEventListener(`message`,p,!1):e.attachEvent(`onmessage`,p),function(t){e.postMessage(a+t,`*`)}):e.MessageChannel?((i=new MessageChannel).port1.onmessage=function(e){f(e.data)},function(e){i.port2.postMessage(e)}):l&&`onreadystatechange`in l.createElement(`script`)?(r=l.documentElement,function(e){var t=l.createElement(`script`);t.onreadystatechange=function(){f(e),t.onreadystatechange=null,r.removeChild(t),t=null},r.appendChild(t)}):function(e){setTimeout(f,0,e)},u.setImmediate=function(e){typeof e!=`function`&&(e=Function(``+e));for(var t=Array(arguments.length-1),r=0;r<t.length;r++)t[r]=arguments[r+1];return s[o]={callback:e,args:t},n(o),o++},u.clearImmediate=d}function d(e){delete s[e]}function f(e){if(c)setTimeout(f,0,e);else{var n=s[e];if(n){c=!0;try{(function(e){var n=e.callback,r=e.args;switch(r.length){case 0:n();break;case 1:n(r[0]);break;case 2:n(r[0],r[1]);break;case 3:n(r[0],r[1],r[2]);break;default:n.apply(t,r)}})(n)}finally{d(e),c=!1}}}}function p(t){t.source===e&&typeof t.data==`string`&&t.data.indexOf(a)===0&&f(+t.data.slice(a.length))}})(typeof self>`u`?e===void 0?this:e:self)}).call(this,typeof global<`u`?global:typeof self<`u`?self:typeof window<`u`?window:{})},{}]},{},[10])(10)})}))(),1),Y=`pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

rootProject.name = "RouteCompanion"
include(":app")
`,Dt=`plugins {
    id("com.android.application") version "8.2.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
}
`,Ot=`plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.routecompanion.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.routecompanion.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "1.0.2"
    }


    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.webkit:webkit:1.10.0")
}
`,kt=`<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <!-- Android 11+ package visibility to query and bind to OsmAnd services -->
    <queries>
        <package android:name="net.osmand" />
        <package android:name="net.osmand.plus" />
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="osmand.navigation" />
        </intent>
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="geo" />
        </intent>
    </queries>

    <application
        android:allowBackup="true"
        android:icon="@android:drawable/ic_dialog_map"
        android:label="@string/app_name"
        android:roundIcon="@android:drawable/ic_dialog_map"
        android:supportsRtl="true"
        android:theme="@style/Theme.AppCompat.NoActionBar">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`,At=`<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">Route Companion</string>
</resources>
`,jt=`# Proguard rules for Route Companion
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
`,Mt=`android.useAndroidX=true
android.nonTransitiveRClass=true
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
`,Nt=`package com.routecompanion.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.WindowManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private lateinit var osmandBridge: OsmAndNavigationBridge
    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        try {
            val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            fileUploadCallback?.onReceiveValue(uris)
        } catch (e: Exception) {
            Log.e(TAG, "Error in file picker result", e)
            fileUploadCallback?.onReceiveValue(null)
        } finally {
            fileUploadCallback = null
        }
    }

    companion object {
        private const val LOCATION_PERMISSION_REQUEST = 1001
        private const val TAG = "RouteCompanion"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        try {
            tts = TextToSpeech(this, this)
        } catch (e: Exception) {
            Log.w(TAG, "TTS init error", e)
        }

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        WebView.setWebContentsDebuggingEnabled(true)

        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                setGeolocationEnabled(true)
                allowFileAccess = true
                allowContentAccess = true
                allowFileAccessFromFileURLs = true
                allowUniversalAccessFromFileURLs = true
                cacheMode = WebSettings.LOAD_DEFAULT
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            }

            webChromeClient = object : WebChromeClient() {
                override fun onGeolocationPermissionsShowPrompt(
                    origin: String?,
                    callback: GeolocationPermissions.Callback?
                ) {
                    callback?.invoke(origin, true, true)
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    fileUploadCallback?.onReceiveValue(null)
                    fileUploadCallback = filePathCallback

                    val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }

                    try {
                        filePickerLauncher.launch(Intent.createChooser(intent, "Select GPX File"))
                        return true
                    } catch (e: Exception) {
                        Log.e(TAG, "Cannot launch file picker", e)
                        fileUploadCallback?.onReceiveValue(null)
                        fileUploadCallback = null
                        return false
                    }
                }
            }

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView,
                    request: WebResourceRequest
                ): WebResourceResponse? {
                    val res = assetLoader.shouldInterceptRequest(request.url)
                    return res ?: super.shouldInterceptRequest(view, request)
                }

                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean {
                    val url = request.url.toString()
                    if (url.startsWith("https://appassets.androidplatform.net/")) {
                        return false
                    }
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, request.url).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        startActivity(intent)
                    } catch (e: Exception) {
                        Log.w(TAG, "Cannot open external intent: $url", e)
                    }
                    return true
                }
            }

            addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        }

        setContentView(webView)
        checkLocationPermission()

        osmandBridge = OsmAndNavigationBridge(this) { maneuver, street, distanceMeters ->
            runOnUiThread {
                val safeManeuver = maneuver.replace("'", "\\\\'")
                val safeStreet = street.replace("'", "\\\\'")
                val js = "window.onOsmAndNavUpdate && window.onOsmAndNavUpdate('$safeManeuver', '$safeStreet', $distanceMeters);"
                webView.evaluateJavascript(js, null)
            }
        }
        osmandBridge.start()

        webView.loadUrl("https://appassets.androidplatform.net/assets/dist/index.html")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            isTtsReady = true
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun isAndroidApp(): Boolean = true

        @JavascriptInterface
        fun vibrate(type: String) {
            try {
                val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val manager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                    manager.defaultVibrator
                } else {
                    @Suppress("DEPRECATION")
                    getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val effect = when (type) {
                        "skip" -> VibrationEffect.createWaveform(longArrayOf(0, 50, 40, 70), -1)
                        "complete" -> VibrationEffect.createWaveform(longArrayOf(0, 80, 50, 100), -1)
                        "undo" -> VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE)
                        else -> VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE)
                    }
                    vibrator.vibrate(effect)
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(40)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Vibrate error", e)
            }
        }

        @JavascriptInterface
        fun speak(text: String) {
            if (isTtsReady && tts != null) {
                try {
                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "route_tts")
                } catch (e: Exception) {
                    Log.w(TAG, "TTS speak error", e)
                }
            }
        }

        @JavascriptInterface
        fun openOsmAnd(lat: Double, lon: Double) {
            runOnUiThread {
                try {
                    val osmandIntent = Intent(Intent.ACTION_VIEW, Uri.parse("osmand.navigation:q=$lat,$lon")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(osmandIntent)
                } catch (e: Exception) {
                    try {
                        val geoIntent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon(Customer)")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        startActivity(geoIntent)
                    } catch (err: Exception) {
                        Log.w(TAG, "Cannot launch navigation intent", err)
                    }
                }
            }
        }
    }

    private fun checkLocationPermission() {
        val permissions = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        val needed = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), LOCATION_PERMISSION_REQUEST)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        osmandBridge.stop()
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {}
    }
}
`,Pt=`package com.routecompanion.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.util.Log
import androidx.core.content.ContextCompat

/**
 * Listens for OsmAnd turn-by-turn navigation broadcasts and relays them to WebView
 */
class OsmAndNavigationBridge(
    private val context: Context,
    private val onUpdate: (maneuver: String, street: String, distanceMeters: Int) -> Unit
) {
    private val navBroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent?.action == "net.osmand.NAVIGATION_INFO") {
                val maneuver = intent.getStringExtra("NEXT_MANEUVER_TYPE") ?: "straight"
                val street = intent.getStringExtra("NEXT_STREET_NAME") ?: ""
                val dist = intent.getIntExtra("DISTANCE_TO_NEXT", 0)
                onUpdate(maneuver, street, dist)
            }
        }
    }

    fun start() {
        val filter = IntentFilter("net.osmand.NAVIGATION_INFO")
        try {
            ContextCompat.registerReceiver(
                context,
                navBroadcastReceiver,
                filter,
                ContextCompat.RECEIVER_EXPORTED
            )
        } catch (e: Exception) {
            try {
                context.registerReceiver(navBroadcastReceiver, filter)
            } catch (err: Exception) {
                Log.w("OsmAndBridge", "Could not register receiver", err)
            }
        }
    }

    fun stop() {
        try {
            context.unregisterReceiver(navBroadcastReceiver)
        } catch (e: Exception) {
            Log.w("OsmAndBridge", "Error unregistering receiver", e)
        }
    }
}
`,Ft=`name: Build Android APK

on:
  push:
    branches: [ "main", "master" ]
  workflow_dispatch:

jobs:
  build:
    name: Build & Package APK
    runs-on: ubuntu-latest

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Extract Project ZIP (if unextracted)
        run: |
          if [ ! -d "src" ]; then
            LATEST_ZIP=$(ls -t *.zip 2>/dev/null | head -n 1)
            if [ -n "$LATEST_ZIP" ] && [ -f "$LATEST_ZIP" ]; then
              echo "Extracting latest archive: $LATEST_ZIP"
              unzip -o "$LATEST_ZIP"
              echo "Source unzipped successfully!"
            fi
          fi

      - name: Set up Java JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Set up Node.js 20
        uses: actions/setup-node@v4
        with:
          node-version: '20'

      - name: Force All-Files Picker
        run: |
          sed -i 's/accept="[^"]*"/accept=""/g' src/components/GpxImportModal.tsx 2>/dev/null || true
          sed -i 's/accept="[^"]*"/accept=""/g' src/App.tsx 2>/dev/null || true
          sed -i 's/fileChooserParams?.createIntent()/null/g' android/app/src/main/java/com/routecompanion/app/MainActivity.kt 2>/dev/null || true

      - name: Build Web Application
        run: |
          npm install --legacy-peer-deps
          npm run build
          mkdir -p android/app/src/main/assets/dist
          cp -r dist/* android/app/src/main/assets/
          cp -r dist/* android/app/src/main/assets/dist/

      - name: Ensure Android Structure & Config
        run: |
          mkdir -p android/app/src/main/res/values
          touch android/app/proguard-rules.pro
          printf '<?xml version="1.0" encoding="utf-8"?>\\n<resources>\\n    <string name="app_name">Route Companion</string>\\n</resources>\\n' > android/app/src/main/res/values/strings.xml
          echo "sdk.dir=$ANDROID_HOME" > android/local.properties

      - name: Setup Gradle
        uses: gradle/actions/setup-gradle@v3
        with:
          gradle-version: 8.5
          cache-disabled: true

      - name: Build Android APK
        working-directory: ./android
        run: |
          set +e
          gradle assembleDebug -x lint -x test --no-daemon --stacktrace 2>&1 | tee build.log
          STATUS=\${PIPESTATUS[0]}
          if [ $STATUS -ne 0 ]; then
            echo "### ❌ Build Failed Log Summary" >> $GITHUB_STEP_SUMMARY
            echo '\`\`\`text' >> $GITHUB_STEP_SUMMARY
            tail -n 100 build.log >> $GITHUB_STEP_SUMMARY
            echo '\`\`\`' >> $GITHUB_STEP_SUMMARY
            exit $STATUS
          else
            echo "### ✅ Android APK Built Successfully!" >> $GITHUB_STEP_SUMMARY
          fi

      - name: Upload Build Log Artifact
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: gradle-build-log
          path: android/build.log

      - name: Upload Ready-to-Install APK
        if: success()
        uses: actions/upload-artifact@v4
        with:
          name: OsmAnd-Route-Companion-APK
          path: android/app/build/outputs/apk/debug/*.apk
          retention-days: 14
`,It=`# OsmAnd Route Companion (Android APK Source)

This package contains the complete source code and native Android wrapper for **OsmAnd Route Companion**.

## How to Build the APK on your Samsung Galaxy S26:

1. In your GitHub repository (\`route-companion\`), ensure \`.github/workflows/build.yml\` is present.
2. The GitHub Action will automatically run and compile the APK in ~2 minutes!
3. Go to the **Actions** tab on your GitHub repository.
4. Tap the workflow run, scroll down to **Artifacts**, and download **OsmAnd-Route-Companion-APK**.
5. In Samsung **My Files > Downloads**, tap \`app-debug.apk\` to install.
`,Lt=Object.assign({"/EXPORT_AND_BUILD_GUIDE.md":at,"/index.html":ot,"/package.json":st,"/src/App.tsx":ct,"/src/components/ExportModal.tsx":lt,"/src/components/GpxImportModal.tsx":ut,"/src/components/ManeuverIcon.tsx":dt,"/src/components/RoadMapView.tsx":ft,"/src/components/RouteCompletionView.tsx":pt,"/src/components/RouteListDrawer.tsx":mt,"/src/components/SettingsModal.tsx":ht,"/src/components/StopCard.tsx":K,"/src/components/TurnByTurnPanel.tsx":q,"/src/index.css":gt,"/src/main.tsx":_t,"/src/types/route.ts":vt,"/src/utils/gpxParser.ts":yt,"/src/utils/navigationService.ts":J,"/src/utils/sampleRoutes.ts":bt,"/src/utils/useGpsTracker.ts":xt,"/src/utils/useRoadNavigation.ts":St,"/src/utils/voiceAndHaptics.ts":Ct,"/tsconfig.json":wt,"/vite.config.ts":Tt});async function Rt(){try{let e=await fetch(`/OsmAnd_Route_Companion_Source.zip?v=${Date.now()}`);if(e.ok){let t=await e.blob();if(t.size>1e5){let e=URL.createObjectURL(t),n=document.createElement(`a`);n.href=e,n.download=`OsmAnd_Route_Companion_Source.zip`,document.body.appendChild(n),n.click(),setTimeout(()=>{document.body.removeChild(n),URL.revokeObjectURL(e)},2e3);return}}}catch(e){console.warn(`Prebuilt zip fetch failed, generating dynamically in-browser:`,e)}let e=new Et.default;for(let[t,n]of Object.entries(Lt)){let r=t.startsWith(`/`)?t.slice(1):t;typeof n==`string`&&e.file(r,n)}e.file(`android/settings.gradle.kts`,Y),e.file(`android/build.gradle.kts`,Dt),e.file(`android/app/build.gradle.kts`,Ot),e.file(`android/gradle.properties`,Mt),e.file(`android/app/proguard-rules.pro`,jt),e.file(`android/app/src/main/AndroidManifest.xml`,kt),e.file(`android/app/src/main/res/values/strings.xml`,At),e.file(`android/app/src/main/java/com/routecompanion/app/MainActivity.kt`,Nt),e.file(`android/app/src/main/java/com/routecompanion/app/OsmAndNavigationBridge.kt`,Pt),e.file(`.github/workflows/build.yml`,Ft),e.file(`.github/workflows/build-apk.yml`,Ft),e.file(`README.md`,It);let t=await e.generateAsync({type:`blob`,compression:`DEFLATE`,compressionOptions:{level:6}}),n=URL.createObjectURL(t),r=document.createElement(`a`);r.href=n,r.download=`OsmAnd_Route_Companion_Source.zip`,document.body.appendChild(r),r.click(),setTimeout(()=>{document.body.removeChild(r),URL.revokeObjectURL(n)},2e3)}function zt({isOpen:e,onClose:t,isDark:n}){let[r,i]=(0,v.useState)(!1),[a,o]=(0,v.useState)(!1);return e?(0,G.jsx)(`div`,{className:`fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200`,children:(0,G.jsxs)(`div`,{className:`w-full max-w-lg rounded-t-3xl sm:rounded-3xl border shadow-2xl flex flex-col max-h-[92vh] overflow-hidden ${n?`bg-neutral-950 border-neutral-800 text-white`:`bg-white border-neutral-200 text-black`}`,children:[(0,G.jsxs)(`div`,{className:`p-4 border-b flex items-center justify-between shrink-0 ${n?`border-neutral-800 bg-neutral-900/60`:`border-neutral-200 bg-neutral-50`}`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-2.5`,children:[(0,G.jsx)(`div`,{className:`w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shrink-0 shadow-md`,children:(0,G.jsx)(Se,{className:`w-5 h-5`})}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h2`,{className:`text-base font-black tracking-tight`,children:`Export Source Code & APK Builder`}),(0,G.jsx)(`p`,{className:`text-xs text-neutral-400`,children:`Step 1: Download code to your Samsung S26`})]})]}),(0,G.jsx)(`button`,{onClick:()=>{k(`tap`),t()},className:`p-2 rounded-xl transition-colors ${n?`hover:bg-neutral-800 text-neutral-400`:`hover:bg-neutral-100 text-neutral-600`}`,children:(0,G.jsx)(qe,{className:`w-5 h-5`})})]}),(0,G.jsxs)(`div`,{className:`p-4 sm:p-5 overflow-y-auto space-y-4`,children:[(0,G.jsxs)(`div`,{className:`p-4 rounded-2xl border ${n?`bg-neutral-900/90 border-blue-900/60`:`bg-blue-50/70 border-blue-200`}`,children:[(0,G.jsx)(`p`,{className:`text-xs font-semibold text-neutral-400 mb-2`,children:`Instant 1-Tap Download to your phone:`}),(0,G.jsx)(`button`,{onClick:async()=>{k(`tap`),i(!0);try{await Rt(),o(!0),k(`complete`)}catch(e){console.error(`Download failed`,e)}finally{i(!1)}},disabled:r,className:`w-full py-4 px-4 rounded-2xl font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2.5 shadow-lg active:scale-95 transition-all ${a?`bg-emerald-500 hover:bg-emerald-600 text-black`:`bg-blue-600 hover:bg-blue-500 text-white`}`,children:r?(0,G.jsxs)(G.Fragment,{children:[(0,G.jsx)(`div`,{className:`w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin`}),(0,G.jsx)(`span`,{children:`Packaging Zip File...`})]}):a?(0,G.jsxs)(G.Fragment,{children:[(0,G.jsx)(me,{className:`w-5 h-5 stroke-[2.5]`}),(0,G.jsx)(`span`,{children:`Downloaded! Tap to Download Again`})]}):(0,G.jsxs)(G.Fragment,{children:[(0,G.jsx)(Se,{className:`w-5 h-5`}),(0,G.jsx)(`span`,{children:`Download Complete Project (.ZIP)`})]})}),a&&(0,G.jsxs)(`div`,{className:`mt-3 p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-start gap-2 text-emerald-400 text-xs`,children:[(0,G.jsx)(me,{className:`w-4 h-4 shrink-0 mt-0.5 text-emerald-400`}),(0,G.jsxs)(`span`,{children:[(0,G.jsx)(`strong`,{children:`Saved to your phone:`}),` Check your Samsung `,(0,G.jsx)(`strong`,{children:`My Files > Downloads`}),` folder for `,(0,G.jsx)(`code`,{className:`bg-black/40 px-1 py-0.5 rounded font-mono`,children:`OsmAnd_Route_Companion_Source.zip`}),`.`]})]})]}),(0,G.jsxs)(`div`,{className:`p-3.5 rounded-2xl border text-xs space-y-2 ${n?`bg-neutral-900 border-neutral-800`:`bg-neutral-100 border-neutral-200`}`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-2 font-bold text-neutral-300`,children:[(0,G.jsx)(we,{className:`w-4 h-4 text-blue-400`}),(0,G.jsx)(`span`,{children:`What is included in this .ZIP file:`})]}),(0,G.jsxs)(`ul`,{className:`space-y-1.5 text-neutral-400 pl-6 list-disc`,children:[(0,G.jsxs)(`li`,{children:[(0,G.jsx)(`strong`,{children:`Native Android Kotlin wrapper:`}),` Binds to OsmAnd AIDL background service`]}),(0,G.jsxs)(`li`,{children:[(0,G.jsx)(`strong`,{children:`Full React App:`}),` Your customer cards, yellow house number, 50ft arrival, and GPX parser`]}),(0,G.jsxs)(`li`,{children:[(0,G.jsx)(`strong`,{children:`Automated Cloud Builder:`}),` Preconfigured GitHub Action to compile the APK free with zero setup`]})]})]}),(0,G.jsxs)(`div`,{className:`space-y-3`,children:[(0,G.jsx)(`h3`,{className:`text-xs font-black uppercase tracking-wider text-neutral-400`,children:`What to do next (Takes ~3 minutes on your phone):`}),(0,G.jsxs)(`div`,{className:`p-3.5 rounded-2xl border flex items-start gap-3 ${n?`bg-neutral-900/50 border-neutral-800`:`bg-neutral-50 border-neutral-200`}`,children:[(0,G.jsx)(`div`,{className:`w-6 h-6 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5`,children:`2`}),(0,G.jsxs)(`div`,{className:`text-xs space-y-1`,children:[(0,G.jsx)(`p`,{className:`font-bold`,children:`Upload to GitHub (Free cloud builder)`}),(0,G.jsxs)(`p`,{className:`text-neutral-400`,children:[`Open `,(0,G.jsx)(`a`,{href:`https://github.com`,target:`_blank`,rel:`noreferrer`,className:`text-blue-400 underline font-semibold`,children:`github.com`}),` on your Samsung S26, tap `,(0,G.jsx)(`strong`,{children:`New repository`}),`, name it `,(0,G.jsx)(`code`,{className:`bg-neutral-800 px-1 py-0.5 rounded text-neutral-200`,children:`route-companion`}),`, and tap `,(0,G.jsx)(`strong`,{children:`Upload files`}),` to upload the zip files.`]})]})]}),(0,G.jsxs)(`div`,{className:`p-3.5 rounded-2xl border flex items-start gap-3 ${n?`bg-neutral-900/50 border-neutral-800`:`bg-neutral-50 border-neutral-200`}`,children:[(0,G.jsx)(`div`,{className:`w-6 h-6 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5`,children:`3`}),(0,G.jsxs)(`div`,{className:`text-xs space-y-1`,children:[(0,G.jsx)(`p`,{className:`font-bold`,children:`Download and Install your APK`}),(0,G.jsxs)(`p`,{className:`text-neutral-400`,children:[`Tap the `,(0,G.jsx)(`strong`,{children:`Actions`}),` tab in your repository. In 2 minutes, tap the completed build and download `,(0,G.jsx)(`code`,{className:`bg-neutral-800 px-1 py-0.5 rounded text-neutral-200`,children:`app-debug.apk`}),` to your Samsung S26 to install.`]})]})]})]})]}),(0,G.jsxs)(`div`,{className:`p-4 border-t flex items-center justify-between shrink-0 ${n?`border-neutral-800 bg-neutral-950`:`border-neutral-200 bg-white`}`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-1.5 text-xs text-neutral-400`,children:[(0,G.jsx)(ze,{className:`w-4 h-4 text-emerald-400`}),(0,G.jsx)(`span`,{children:`100% Free · No computer needed`})]}),(0,G.jsx)(`button`,{onClick:()=>{k(`tap`),t()},className:`px-4 py-2 rounded-xl text-xs font-bold ${n?`bg-neutral-800 hover:bg-neutral-700 text-neutral-200`:`bg-neutral-200 hover:bg-neutral-300 text-black`}`,children:`Close`})]})]})}):null}var Bt=40,X=5e3,Vt=18;function Ht(e,t){return!isNaN(e)&&!isNaN(t)&&e>=-90&&e<=90&&t>=-180&&t<=180&&(e!==0||t!==0)}function Ut(e,t,n,r,i=50,a){let[o,s]=(0,v.useState)(null),[c,l]=(0,v.useState)(`acquiring`),[u,d]=(0,v.useState)(null),[f,p]=(0,v.useState)(`Monitoring GPS`),[m,h]=(0,v.useState)(!1),[g,_]=(0,v.useState)(!1),y=(0,v.useRef)(null),b=(0,v.useRef)(1/0),x=(0,v.useRef)(!1),S=(0,v.useRef)(0),C=(0,v.useRef)(null),w=(0,v.useRef)(0),T=(0,v.useRef)(null),E=(0,v.useRef)(!1),D=(0,v.useRef)(!1),O=(0,v.useRef)(null),A=(0,v.useRef)(e);A.current=e;let j=(0,v.useRef)(t);j.current=t;let M=(0,v.useRef)(n);M.current=n;let ee=(0,v.useRef)(r);ee.current=r;let N=(0,v.useRef)(i);N.current=i;let P=(0,v.useRef)(a);P.current=a;let I=!!(e&&t&&Ht(e.lat,e.lon)&&Ht(t.lat,t.lon)&&F(e.lat,e.lon,t.lat,t.lon)<18),R=!!(e&&n&&Ht(e.lat,e.lon)&&Ht(n.lat,n.lon)&&F(e.lat,e.lon,n.lat,n.lon)<18),B=(0,v.useRef)(I);B.current=I,(0,v.useEffect)(()=>{let t=e?.id||null;t!==O.current&&(O.current=t,b.current=1/0,x.current=!1,S.current=0,E.current=!1,h(!1),o&&e&&Ht(e.lat,e.lon)&&F(o.lat,o.lon,e.lat,e.lon)<=N.current?D.current=!0:D.current=!1)},[e?.id]);let te=(0,v.useCallback)(e=>{let t=A.current;if(!t){p(`No Active Route`);return}if(!Ht(t.lat,t.lon)){p(`Invalid Destination Coordinates (Manual Skip)`);return}if(e.accuracy>Bt){p(`GPS Accuracy Low (±${Math.round(e.accuracy*3.28084)} ft)`);return}let n=N.current,r=F(e.lat,e.lon,t.lat,t.lon);r<b.current&&(b.current=r);let i=C.current,a=Date.now();if(E.current||a-w.current<X||T.current===t.id)return;if(B.current&&T.current===j.current?.id){p(`Shared Address · Tap Skip when done`);return}if(D.current){if(r>n*1.1)D.current=!1;else if(a-w.current>8e3&&!B.current)D.current=!1;else{p(`Departing Previous Stop...`);return}}let o=P.current;if(o!=null&&o>Math.max(n*2.2,120)){p(`Parallel Road / Route Distance ${Math.round(o*3.28084)} ft`);return}let s=!1,c=``;if(r<=n){x.current=!0,S.current+=1;let t=e.speed!==null&&e.speed<=5,n=r<=15;t||S.current>=2||n?(s=!0,c=`Reached destination (${Math.round(r*3.28084)} ft)`):p(`In Arrival Zone (${Math.round(r*3.28084)} ft)`)}else S.current=0;if(!s&&b.current<=n*1.6){let n=r>=b.current+Vt,a=i?r>F(i.lat,i.lon,t.lat,t.lon):!1,o=z(e.lat,e.lon,t.lat,t.lon),s=!1;if(e.heading!==null){let t=Math.abs(e.heading-o);s=(t>180?360-t:t)>75}if(n&&(a||s)){h(!0),p(`Missed stop (${Math.round(r*3.28084)} ft) · Recalculating...`),C.current=e;return}}if(s)E.current=!0,w.current=a,T.current=t.id,x.current=!1,S.current=0,b.current=1/0,h(!1),p(`Arrived: ${c}`),k(`complete`),ee.current();else{if(!x.current){let e=Math.round(r*3.28084);p(`${e} ft to customer (Zone: ${Math.round(n*3.28084)} ft)`)}C.current=e}},[]);(0,v.useEffect)(()=>{if(typeof window>`u`||!(`geolocation`in navigator)){l(`denied`),d(`GPS hardware not supported by this browser.`);return}l(`acquiring`);let e=navigator.geolocation.watchPosition(e=>{if(g)return;let t={lat:e.coords.latitude,lon:e.coords.longitude,accuracy:e.coords.accuracy||8,speed:e.coords.speed!==null&&e.coords.speed>=0?Math.round(e.coords.speed*2.23694):null,heading:e.coords.heading!==null&&!isNaN(e.coords.heading)?e.coords.heading:null,timestamp:e.timestamp||Date.now()};s(t),l(`locked`),d(null),te(t)},e=>{g||(l(`denied`),d(e.message||`GPS hardware access denied.`))},{enableHighAccuracy:!0,maximumAge:1e3,timeout:1e4});return()=>{try{navigator.geolocation.clearWatch(e)}catch{}}},[te,g]),(0,v.useEffect)(()=>()=>{y.current&&window.clearInterval(y.current)},[]);let ne=(0,v.useCallback)(()=>{let e=A.current;if(!e||!Ht(e.lat,e.lon))return;y.current&&=(window.clearInterval(y.current),null),_(!0),l(`locked`),d(null),h(!1);let t=e.lat,n=e.lon,r=[{offset:-120,speed:25},{offset:-70,speed:18},{offset:-25,speed:8},{offset:0,speed:0},{offset:0,speed:0}],i=0;y.current=window.setInterval(()=>{if(i>=r.length){y.current&&=(window.clearInterval(y.current),null),_(!1);return}let e=r[i],a={lat:t+e.offset/111132.92,lon:n,accuracy:3,speed:e.speed,heading:0,timestamp:Date.now()};s(a),te(a),i+=1},1100)},[te]),re=(0,v.useCallback)(()=>{let e=A.current;if(!e||!Ht(e.lat,e.lon))return;y.current&&=(window.clearInterval(y.current),null),_(!0),l(`locked`),d(null);let t=111132.92,n=e.lat,r=e.lon,i=[{offset:-100,speed:25},{offset:-45,speed:25},{offset:0,speed:25},{offset:45,speed:25},{offset:90,speed:25}],a=0;y.current=window.setInterval(()=>{if(a>=i.length){y.current&&=(window.clearInterval(y.current),null),_(!1);return}let e=i[a],o={lat:n+e.offset/t,lon:r+12/(t*Math.cos(n*Math.PI/180)),accuracy:4,speed:e.speed,heading:0,timestamp:Date.now()};s(o),te(o),a+=1},1200)},[te]),ie=(0,v.useCallback)(()=>{y.current&&=(window.clearInterval(y.current),null),_(!1)},[]),ae=null,oe=null,se=!1;o&&e&&Ht(e.lat,e.lon)&&(ae=F(o.lat,o.lon,e.lat,e.lon),oe=Math.round(ae*3.28084),se=ae<=i);let ce=f;return c===`denied`?ce=`GPS Disabled`:c===`acquiring`?ce=`Acquiring Satellites...`:m?ce=`Passed stop (${oe} ft) · Recalculating...`:g?ce=`Simulating Road Progress (${oe} ft)`:se&&(ce=I?`Shared Address · Tap Skip when done`:`In Zone (${oe} ft / ${Math.round(i*3.28084)} ft)`),{location:o,gpsStatus:c,gpsErrorMsg:u,distanceToCurrentMeters:ae,distanceToCurrentFeet:oe,isWithinGeofence:se,isSharedLocationWithPrevious:I,isSharedLocationWithNext:R,autoArrivalStatus:ce,arrivalRadiusMeters:i,isPassedWithoutCompletion:m,simulateApproachAndPass:re,simulateApproachAndArrive:ne,isSimulatingGps:g,stopGpsSimulation:ie}}var Wt=`osmand_route_assistant_v1`,Gt=`osmand_route_assistant_settings_v1`,Kt={theme:`amoled-black`,voiceAnnouncement:!1,hapticFeedback:!0,keepScreenAwake:!0,extraLargeText:!1,arrivalRadiusMeters:50};function qt(){let[e,t]=(0,v.useState)(()=>{try{let e=localStorage.getItem(Gt);if(e)return{...Kt,...JSON.parse(e)}}catch{}return Kt}),[n,r]=(0,v.useState)(()=>{try{let e=localStorage.getItem(Wt);if(e){let t=JSON.parse(e);if(t&&Array.isArray(t.stops)&&t.stops.length>0){let e=t.stops.map((e,t)=>{let n=x(e,t);return{...e,houseNumber:n===`—`?e.houseNumber&&!/^0+\d+$/.test(e.houseNumber)?e.houseNumber:``:n}});return{...t,stops:e}}}}catch{}try{let e=O[0],t=T(e.gpxXml,e.title);return{id:e.id,name:t.routeName,filename:`${e.id}.gpx`,stops:t.stops,currentIndex:0,importedAt:Date.now(),lastUpdated:Date.now()}}catch{return null}}),[i,a]=(0,v.useState)(!1),[o,s]=(0,v.useState)(!1),[c,l]=(0,v.useState)(!1),[u,d]=(0,v.useState)(!1),[f,p]=(0,v.useState)(null),[m,h]=(0,v.useState)(null),g=(0,v.useRef)(null),_=async t=>{let n=t.target.files?.[0];if(n)try{let{stops:t,routeName:i}=T(await n.text(),n.name.replace(/\.[^/.]+$/,``));if(t.length===0)throw Error(`No waypoints found in the selected GPX file.`);e.hapticFeedback&&k(`complete`);let a={id:`route-${Date.now().toString(36)}`,name:i||n.name,filename:n.name,stops:t,currentIndex:0,importedAt:Date.now(),lastUpdated:Date.now()};r(a);try{localStorage.setItem(Wt,JSON.stringify(a))}catch(e){console.error(`Storage error`,e)}h(`Imported ${n.name} (${t.length} stops)`),setTimeout(()=>h(null),4e3)}catch(e){h(e.message||`Failed to read or parse GPX file.`),setTimeout(()=>h(null),4e3)}finally{t.target&&(t.target.value=``)}};(0,v.useEffect)(()=>{if(n)try{localStorage.setItem(Wt,JSON.stringify(n))}catch(e){console.error(`Failed to save route to localStorage`,e)}else localStorage.removeItem(Wt)},[n]),(0,v.useEffect)(()=>{try{localStorage.setItem(Gt,JSON.stringify(e))}catch(e){console.error(`Failed to save settings`,e)}},[e]),(0,v.useEffect)(()=>(e.keepScreenAwake?N():P(),()=>{P()}),[e.keepScreenAwake]);let y=(0,v.useRef)(!0);(0,v.useEffect)(()=>{if(y.current)y.current=!1;else if(e.voiceAnnouncement&&n&&n.stops[n.currentIndex]){let e=n.stops[n.currentIndex],t=x(e,n.currentIndex);A(e.name,t===`—`?``:t,e.streetName)}},[n?.currentIndex,e.voiceAnnouncement]);let b=e.theme===`amoled-black`,S=()=>{if(!n)return;e.hapticFeedback&&k(`complete`);let t=n.stops[n.currentIndex];r(e=>{if(!e)return null;let t=e.currentIndex+1,n=[...e.stops];return n[e.currentIndex]&&(n[e.currentIndex]={...n[e.currentIndex],status:`completed`,statusTimestamp:Date.now()}),{...e,stops:n,currentIndex:t,lastUpdated:Date.now()}}),t&&(h(`Auto-Arrived: #${t.orderIndex} ${t.name}`),setTimeout(()=>{h(null)},3500))},C=()=>{if(!n)return;e.hapticFeedback&&k(`skip`);let t=n.stops[n.currentIndex],i=n.currentIndex;r(e=>{if(!e)return null;let t=e.currentIndex+1,n=[...e.stops];return n[e.currentIndex]&&(n[e.currentIndex]={...n[e.currentIndex],status:`skipped`,statusTimestamp:Date.now()}),{...e,stops:n,currentIndex:t,lastUpdated:Date.now()}}),t&&(p({message:`Skipped: #${t.orderIndex} ${t.name}`,previousIndex:i}),setTimeout(()=>{p(null)},4e3))},w=()=>{!n||n.currentIndex<=0||(e.hapticFeedback&&k(`undo`),r(e=>e?{...e,currentIndex:e.currentIndex-1,lastUpdated:Date.now()}:null))},E=()=>{if(!f||!n)return;e.hapticFeedback&&k(`undo`);let t=f.previousIndex;r(e=>{if(!e)return null;let n=[...e.stops];return n[t]&&(n[t]={...n[t],status:`pending`}),{...e,stops:n,currentIndex:t,lastUpdated:Date.now()}}),p(null)},D=t=>{n&&(e.hapticFeedback&&k(`tap`),r(e=>e?{...e,currentIndex:Math.max(0,Math.min(t,e.stops.length)),lastUpdated:Date.now()}:null))},j=()=>{n&&(e.hapticFeedback&&k(`tap`),r(e=>{if(!e)return null;let t=e.stops.map(e=>({...e,status:`pending`,statusTimestamp:void 0}));return{...e,stops:t,currentIndex:0,lastUpdated:Date.now()}}))},M=(t,n,i)=>{e.hapticFeedback&&k(`tap`);let a={id:`route-${Date.now().toString(36)}`,name:n,filename:i,stops:t,currentIndex:0,importedAt:Date.now(),lastUpdated:Date.now()};r(a)},ee=()=>{r(null)},F=n&&n.currentIndex<n.stops.length?n.stops[n.currentIndex]:null,I=n&&n.currentIndex>0?n.stops[n.currentIndex-1]:null,R=n&&n.currentIndex<n.stops.length-1?n.stops[n.currentIndex+1]:null,{location:z,gpsStatus:B,gpsErrorMsg:te,distanceToCurrentFeet:ne,isWithinGeofence:re,isSharedLocationWithPrevious:ie,isSharedLocationWithNext:ae,autoArrivalStatus:oe,arrivalRadiusMeters:se,isPassedWithoutCompletion:ce,simulateApproachAndPass:le,simulateApproachAndArrive:V,isSimulatingGps:H,stopGpsSimulation:U}=Ut(F,I,R,S,e.arrivalRadiusMeters||50),ue=n&&n.currentIndex>=n.stops.length,de=n?n.stops.filter(e=>e.status===`completed`).length:0,fe=n?n.stops.filter(e=>e.status===`skipped`).length:0;return(0,G.jsxs)(`div`,{className:`h-dvh max-h-dvh w-full overflow-hidden flex flex-col font-sans transition-colors duration-150 ${b?`bg-black text-white`:`bg-white text-black`}`,children:[(0,G.jsxs)(`header`,{className:`w-full shrink-0 border-b px-3 py-1.5 flex items-center justify-between z-20 ${b?`bg-neutral-950/95 border-neutral-800`:`bg-neutral-50/95 border-neutral-200`}`,children:[(0,G.jsxs)(`div`,{className:`flex items-center gap-2 min-w-0`,children:[(0,G.jsx)(`div`,{className:`w-7 h-7 rounded-lg bg-orange-600 flex items-center justify-center text-white shrink-0 shadow-sm`,children:(0,G.jsx)(ve,{className:`w-4 h-4`})}),(0,G.jsxs)(`div`,{className:`min-w-0`,children:[(0,G.jsx)(`div`,{className:`flex items-center gap-1.5`,children:(0,G.jsx)(`span`,{className:`font-black text-xs sm:text-sm tracking-tight truncate`,children:`OsmAnd Companion`})}),n&&(0,G.jsxs)(`p`,{className:`text-[10px] text-neutral-400 truncate`,children:[n.name,` (`,n.stops.length,` stops)`]})]})]}),(0,G.jsxs)(`div`,{className:`flex items-center gap-1 shrink-0`,children:[(0,G.jsx)(`button`,{onClick:()=>t(e=>({...e,theme:e.theme===`amoled-black`?`high-contrast-day`:`amoled-black`})),className:`p-1.5 rounded-lg transition-colors ${b?`text-neutral-300 hover:text-white hover:bg-neutral-900`:`text-neutral-700 hover:text-black hover:bg-neutral-200`}`,title:`Toggle AMOLED Black / Daylight High-Contrast`,children:b?(0,G.jsx)(We,{className:`w-3.5 h-3.5 text-amber-400`}):(0,G.jsx)(Ne,{className:`w-3.5 h-3.5 text-neutral-800`})}),(0,G.jsx)(`input`,{ref:g,type:`file`,onChange:_,className:`hidden`}),(0,G.jsxs)(`button`,{onClick:()=>{e.hapticFeedback&&k(`tap`),a(!0)},className:`flex items-center gap-1 px-2.5 py-1 rounded-lg border text-[11px] font-bold transition-all active:scale-95 ${b?`border-neutral-700 bg-neutral-900 text-neutral-200 hover:bg-neutral-800 hover:text-white`:`border-neutral-300 bg-neutral-100 text-neutral-800 hover:bg-neutral-200`}`,title:`Import GPX Customer Route`,children:[(0,G.jsx)(W,{className:`w-3 h-3 text-emerald-400`}),(0,G.jsx)(`span`,{children:`GPX`})]}),(0,G.jsxs)(`button`,{onClick:()=>d(!0),className:`flex items-center gap-1 px-2.5 py-1 rounded-lg border text-[11px] font-bold transition-all active:scale-95 ${b?`border-blue-700/80 bg-blue-950/70 text-blue-300 hover:bg-blue-900 hover:text-white`:`border-blue-300 bg-blue-50 text-blue-800 hover:bg-blue-100`}`,title:`Download source code and Android APK wrapper ZIP`,children:[(0,G.jsx)(Se,{className:`w-3 h-3 text-blue-400`}),(0,G.jsx)(`span`,{children:`ZIP`})]}),n&&(0,G.jsx)(`button`,{onClick:()=>s(!0),className:`p-1.5 rounded-lg border transition-colors ${b?`border-neutral-700 bg-neutral-900 text-neutral-200 hover:bg-neutral-800`:`border-neutral-300 bg-neutral-100 text-neutral-800 hover:bg-neutral-200`}`,title:`View all stops list`,children:(0,G.jsx)(Ae,{className:`w-3.5 h-3.5 text-emerald-400`})}),(0,G.jsx)(`button`,{onClick:()=>l(!0),className:`p-1.5 rounded-lg transition-colors ${b?`text-neutral-400 hover:text-white hover:bg-neutral-900`:`text-neutral-600 hover:text-black hover:bg-neutral-200`}`,title:`Settings & Display options`,children:(0,G.jsx)(Re,{className:`w-3.5 h-3.5`})})]})]}),(0,G.jsxs)(`main`,{className:`flex-1 w-full max-w-md mx-auto flex flex-col px-2.5 py-1 sm:px-3 sm:py-1.5 relative overflow-hidden`,children:[m&&(0,G.jsx)(`div`,{className:`absolute top-4 left-4 right-4 z-30 animate-in slide-in-from-top duration-200`,children:(0,G.jsxs)(`div`,{className:`bg-emerald-500 text-black px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2 border-2 border-emerald-300`,children:[(0,G.jsx)(me,{className:`w-4 h-4 stroke-[3] shrink-0`}),(0,G.jsx)(`span`,{className:`text-xs font-black truncate`,children:m})]})}),f&&(0,G.jsx)(`div`,{className:`absolute top-4 left-4 right-4 z-30 animate-in slide-in-from-top duration-200`,children:(0,G.jsxs)(`div`,{className:`bg-amber-400 text-black px-4 py-2.5 rounded-2xl shadow-2xl flex items-center justify-between border-2 border-amber-300`,children:[(0,G.jsx)(`span`,{className:`text-xs font-bold truncate max-w-[240px]`,children:f.message}),(0,G.jsxs)(`button`,{onClick:E,className:`flex items-center gap-1 px-2.5 py-1 bg-black text-amber-300 rounded-lg text-xs font-black uppercase tracking-wider hover:bg-neutral-900 transition-colors`,children:[(0,G.jsx)(Ie,{className:`w-3.5 h-3.5`}),(0,G.jsx)(`span`,{children:`Undo`})]})]})}),ue?(0,G.jsx)(it,{stops:n.stops,routeName:n.name,isDark:b,onRestart:j,onJumpToStop:D,onLoadNewRoute:()=>a(!0)}):F&&n?(0,G.jsx)(et,{stop:F,previousStop:I||void 0,nextStop:R||void 0,userLocation:z,gpsStatus:B,gpsErrorMsg:te,distanceToCurrentFeet:ne,isWithinGeofence:re,isSharedLocationWithPrevious:ie,isSharedLocationWithNext:ae,autoArrivalStatus:oe,currentIndex:n.currentIndex,totalStops:n.stops.length,completedCount:de,skippedCount:fe,settings:e,onSkip:C,onPrevious:w,onJumpToStopList:()=>s(!0),arrivalRadiusMeters:se,isPassedWithoutCompletion:ce,simulateApproachAndPass:le,simulateApproachAndArrive:V,isSimulatingGps:H,stopGpsSimulation:U}):(0,G.jsxs)(`div`,{className:`flex-1 flex flex-col items-center justify-center text-center p-6 space-y-4 my-auto`,children:[(0,G.jsx)(`div`,{className:`w-16 h-16 rounded-3xl bg-neutral-900 border border-neutral-800 flex items-center justify-center text-emerald-400`,children:(0,G.jsx)(ve,{className:`w-8 h-8`})}),(0,G.jsxs)(`div`,{children:[(0,G.jsx)(`h2`,{className:`text-xl font-black`,children:`No Active GPX Route`}),(0,G.jsx)(`p`,{className:`text-xs text-neutral-400 mt-1 max-w-xs`,children:`Import a customer GPX file from OsmAnd or pick a built-in delivery route.`})]}),(0,G.jsxs)(`div`,{className:`space-y-2 w-full max-w-xs`,children:[(0,G.jsxs)(`button`,{onClick:()=>a(!0),className:`w-full py-3.5 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-950/40`,children:[(0,G.jsx)(W,{className:`w-4 h-4`}),(0,G.jsx)(`span`,{children:`Import GPX File`})]}),(0,G.jsxs)(`button`,{onClick:()=>{let e=O[0],t=T(e.gpxXml,e.title);M(t.stops,t.routeName,`${e.id}.gpx`)},className:`w-full py-3 px-4 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-200 font-bold text-xs flex items-center justify-center gap-2 transition-all`,children:[(0,G.jsx)(He,{className:`w-4 h-4 text-emerald-400`}),(0,G.jsx)(`span`,{children:`Load Sample Route (20 Stops)`})]})]})]})]}),(0,G.jsx)(tt,{isOpen:i,isDark:b,onClose:()=>a(!1),onImportSuccess:M}),n&&(0,G.jsx)(nt,{isOpen:o,isDark:b,stops:n.stops,currentIndex:n.currentIndex,routeName:n.name,onClose:()=>s(!1),onSelectStop:D,onResetRoute:j}),(0,G.jsx)(rt,{isOpen:c,isDark:b,settings:e,onClose:()=>l(!1),onUpdateSettings:e=>t(t=>({...t,...e})),onOpenImport:()=>a(!0),onResetProgress:j,onClearRoute:ee,onOpenExport:()=>d(!0)}),(0,G.jsx)(zt,{isOpen:u,onClose:()=>d(!1),isDark:b})]})}(0,y.createRoot)(document.getElementById(`root`)).render((0,G.jsx)(qt,{}));