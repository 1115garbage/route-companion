import React, { useState, useEffect } from 'react';
import { RouteStop } from '../types/route';
import { GpsLocation } from '../utils/useGpsTracker';
import { 
  calculateBearing, 
  bearingToDirection, 
  formatDistance 
} from '../utils/navigationService';
import { isValidCoordinate } from '../utils/gpxParser';
import { ManeuverIcon } from './ManeuverIcon';
import { 
  Navigation, 
  Compass, 
  Info, 
  AlertTriangle,
  ExternalLink,
  X,
  Radio,
  CheckCircle2,
  Smartphone
} from 'lucide-react';

interface TurnByTurnPanelProps {
  currentStop: RouteStop;
  previousStop?: RouteStop;
  userLocation: GpsLocation | null;
  gpsStatus: 'acquiring' | 'locked' | 'denied';
  gpsErrorMsg: string | null;
  distanceToCurrentFeet: number | null;
  isDark: boolean;
  onOpenOsmAnd: (e: React.MouseEvent) => void;
}

export const TurnByTurnPanel: React.FC<TurnByTurnPanelProps> = ({
  currentStop,
  userLocation,
  gpsStatus,
  gpsErrorMsg,
  distanceToCurrentFeet,
  isDark,
  onOpenOsmAnd,
}) => {
  const [showStatusModal, setShowStatusModal] = useState(false);

  // Live OsmAnd AIDL feed state (received from Android Kotlin wrapper via window.onOsmAndNavUpdate)
  const [aidlUpdate, setAidlUpdate] = useState<{
    maneuver: string;
    street: string;
    distanceMeters: number;
    lastReceived: number;
  } | null>(null);

  // Hook into native Android WebView evaluation
  useEffect(() => {
    (window as any).onOsmAndNavUpdate = (maneuver: string, street: string, distMeters: number) => {
      setAidlUpdate({
        maneuver: maneuver || 'straight',
        street: street || '',
        distanceMeters: typeof distMeters === 'number' ? distMeters : 0,
        lastReceived: Date.now(),
      });
    };

    return () => {
      delete (window as any).onOsmAndNavUpdate;
    };
  }, []);

  const hasValidCoords = isValidCoordinate(currentStop.lat, currentStop.lon);

  // Check if live AIDL data was received recently (within 20 seconds)
  const isAidlActive = Boolean(aidlUpdate && Date.now() - aidlUpdate.lastReceived < 20000);

  // Compute real compass bearing from live GPS to customer coordinates
  let bearing: number | null = null;
  let directionName = '';
  if (userLocation && hasValidCoords) {
    bearing = calculateBearing(userLocation.lat, userLocation.lon, currentStop.lat, currentStop.lon);
    directionName = bearingToDirection(bearing);
  }

  // Format real distance from live GPS hardware to customer stop
  const distanceFormatted = distanceToCurrentFeet !== null && hasValidCoords
    ? formatDistance(distanceToCurrentFeet / 3.28084)
    : null;

  return (
    <>
      {/* Turn-by-Turn Panel - Minimal, high-contrast, next maneuver and distance */}
      <div 
        className={`w-full rounded-2xl border mb-2 p-3 transition-all shadow-lg ${
          isDark 
            ? 'bg-neutral-950 border-neutral-800 text-white shadow-neutral-950/80' 
            : 'bg-neutral-50 border-neutral-300 text-black shadow-neutral-300/60'
        }`}
      >
        <div className="flex items-center gap-3">
          {/* Maneuver Icon or Bearing Compass */}
          <div 
            className={`w-13 h-13 rounded-2xl flex items-center justify-center shrink-0 border-2 transition-transform ${
              isAidlActive
                ? 'bg-emerald-500/20 border-emerald-400 text-emerald-400'
                : isDark 
                  ? 'bg-orange-500/15 border-orange-400 text-orange-400 shadow-md shadow-orange-950/40' 
                  : 'bg-orange-100 border-orange-500 text-orange-600'
            }`}
          >
            {isAidlActive && aidlUpdate ? (
              <ManeuverIcon 
                type={aidlUpdate.maneuver.includes('roundabout') ? 'roundabout' : 'turn'}
                modifier={aidlUpdate.maneuver}
                className="w-7 h-7 stroke-[2.75]" 
              />
            ) : bearing !== null ? (
              <div 
                className="transition-transform duration-500 flex items-center justify-center"
                style={{ transform: `rotate(${Math.round(bearing)}deg)` }}
                title={`Bearing: ${Math.round(bearing)}° (${directionName})`}
              >
                <Navigation className="w-7 h-7 fill-current stroke-[2]" />
              </div>
            ) : (
              <Compass className="w-7 h-7 stroke-[2.25]" />
            )}
          </div>

          {/* Maneuver / Navigation Status */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 mb-0.5">
              <span className={`text-[10px] font-black uppercase tracking-wider ${
                isAidlActive ? 'text-emerald-400' : 'text-orange-400'
              }`}>
                {isAidlActive ? 'OsmAnd Live AIDL' : 'OsmAnd Navigation'}
              </span>
              <span className={`inline-block w-1.5 h-1.5 rounded-full ${
                isAidlActive ? 'bg-emerald-400 animate-pulse' : gpsStatus === 'locked' ? 'bg-emerald-400' : 'bg-amber-400'
              }`} />
            </div>

            <h2 className="font-bold text-sm leading-snug truncate text-neutral-100">
              {isAidlActive && aidlUpdate ? (
                aidlUpdate.street ? `Onto ${aidlUpdate.street}` : aidlUpdate.maneuver
              ) : !hasValidCoords ? (
                <span className="text-amber-400">No coordinates in GPX</span>
              ) : directionName ? (
                `Head ${directionName} to Customer`
              ) : (
                'Follow OsmAnd Route'
              )}
            </h2>

            <p className="text-[11px] text-neutral-400 truncate mt-0.5">
              {isAidlActive ? 'Live updates from OsmAnd' : 'Turns handled in OsmAnd app'}
            </p>
          </div>

          {/* Distance Display */}
          <div className="shrink-0 text-right">
            {isAidlActive && aidlUpdate ? (
              <>
                <div className="font-black text-2xl font-mono text-emerald-400 tracking-tight leading-none">
                  {formatDistance(aidlUpdate.distanceMeters)}
                </div>
                <div className="text-[10px] text-neutral-400 font-mono mt-0.5">
                  to turn
                </div>
              </>
            ) : distanceFormatted ? (
              <>
                <div className="font-black text-2xl font-mono text-white tracking-tight leading-none">
                  {distanceFormatted}
                </div>
                <div className="text-[10px] text-neutral-400 font-mono mt-0.5">
                  to stop
                </div>
              </>
            ) : (
              <div className="text-right">
                <span className="text-xs font-mono text-neutral-400 block">
                  {gpsStatus === 'acquiring' ? 'GPS...' : '—'}
                </span>
                <span className="text-[10px] text-neutral-400 font-mono">
                  distance
                </span>
              </div>
            )}

            {/* Integration info modal trigger */}
            <button
              onClick={() => setShowStatusModal(true)}
              className="inline-flex items-center gap-0.5 text-[10px] text-neutral-400 hover:text-white mt-1 underline decoration-dotted"
              title="View OsmAnd integration architecture & APK setup"
            >
              <span>{isAidlActive ? 'active' : 'status'}</span>
            </button>
          </div>
        </div>

        {/* GPS Permission Warning if Denied */}
        {gpsStatus === 'denied' && (
          <div className="mt-2 p-2 rounded-xl bg-amber-950/60 border border-amber-800 text-[11px] text-amber-200">
            <span>Location access disabled. Enable device GPS in browser settings for live distance updates.</span>
          </div>
        )}
      </div>

      {/* OsmAnd Technical Architecture & APK Guide Modal */}
      {showStatusModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
          <div 
            className={`w-full max-w-md rounded-3xl border shadow-2xl p-6 ${
              isDark ? 'bg-neutral-900 border-neutral-700 text-white' : 'bg-white border-neutral-300 text-black'
            }`}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-orange-600 flex items-center justify-center text-white shrink-0">
                  <Compass className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-black text-base">OsmAnd AIDL & APK Guide</h3>
                  <p className="text-xs text-neutral-400">Architecture for Samsung Galaxy S26</p>
                </div>
              </div>
              <button 
                onClick={() => setShowStatusModal(false)}
                className="p-1.5 rounded-lg text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-neutral-300 leading-relaxed max-h-[60vh] overflow-y-auto pr-1">
              {/* Status Banner */}
              <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full ${isAidlActive ? 'bg-emerald-400' : 'bg-amber-400'}`} />
                  <strong className={isAidlActive ? 'text-emerald-400' : 'text-amber-400'}>
                    {isAidlActive ? 'Native OsmAnd AIDL Connected' : 'Running in Web Browser Mode'}
                  </strong>
                </div>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  {isAidlActive 
                    ? 'Receiving real-time turn instructions directly from OsmAnd background service via Android AIDL.'
                    : 'Browsers are isolated from Android AIDL by OS security. The app uses direct GPS hardware for 50-ft arrivals and launches OsmAnd for full navigation.'}
                </p>
              </div>

              {/* Native APK Wrapper Summary */}
              <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
                <span className="font-bold text-white block">Step-by-Step APK Build on Samsung S26:</span>
                <ol className="list-decimal pl-4 space-y-1.5 text-neutral-300 text-[11px]">
                  <li>
                    <strong>Export Source Code</strong>: Tap <strong>Export Project</strong> in AI Studio (or three dots menu) to download the complete codebase ZIP.
                  </li>
                  <li>
                    <strong>Upload to Free GitHub</strong>: Create a free repository on GitHub from your Samsung browser and upload the project files.
                  </li>
                  <li>
                    <strong>Cloud Build (Free)</strong>: The included <code>.github/workflows/build-apk.yml</code> builds the Android APK automatically using free cloud runners.
                  </li>
                  <li>
                    <strong>Install on S26</strong>: Download <code>app-debug.apk</code> directly from GitHub Actions, tap it in Samsung My Files, and install!
                  </li>
                </ol>
              </div>

              {/* Working Features in Both Modes */}
              <div className="p-3.5 rounded-2xl bg-neutral-950 border border-emerald-800/60 space-y-1.5">
                <span className="font-bold text-emerald-400 block">All Features 100% Preserved:</span>
                <ul className="list-disc pl-4 space-y-1 text-neutral-300 text-[11px]">
                  <li>GPX customer import with exact stop order preservation</li>
                  <li>Large customer name and massive yellow house-number block</li>
                  <li>50-ft automatic arrival advance with drift safeguards</li>
                  <li>Orange Skip Customer button as the primary driver action</li>
                  <li>Single-tap OsmAnd destination navigation with preserved position</li>
                </ul>
              </div>
            </div>

            <div className="mt-5 pt-4 border-t border-neutral-800 flex items-center justify-between gap-2">
              <button
                onClick={(e) => {
                  setShowStatusModal(false);
                  onOpenOsmAnd(e);
                }}
                className="px-4 py-2 text-xs font-bold rounded-xl bg-orange-600 hover:bg-orange-500 text-white flex items-center gap-1.5 transition-colors"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Launch OsmAnd</span>
              </button>

              <button
                onClick={() => setShowStatusModal(false)}
                className="px-4 py-2 text-xs font-bold rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
