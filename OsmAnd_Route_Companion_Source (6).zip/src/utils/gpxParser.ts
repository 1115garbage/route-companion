import { RouteStop } from '../types/route';

/**
 * Extracts a house/building number and street from an address or text string
 */
export function extractAddressComponents(text: string): { houseNumber: string; streetName: string; fullAddress: string } {
  const clean = (text || '').trim();
  if (!clean) {
    return { houseNumber: '', streetName: '', fullAddress: '' };
  }

  // Common house number patterns: "123", "123A", "1402-B", "45/2", "#104", "Unit 12"
  const houseNumRegex = /(?:^|\b)(?:#|No\.?\s*|Unit\s*)?(\d+[A-Za-z]?(?:[-\/]\d+[A-Za-z]?)?)\b/;
  const match = clean.match(houseNumRegex);
  const houseNumber = match ? match[1] : '';

  let streetName = clean;
  if (match && match.index !== undefined) {
    const afterHouse = clean.slice(match.index + match[0].length).trim();
    const commaIndex = afterHouse.indexOf(',');
    if (commaIndex !== -1) {
      streetName = afterHouse.slice(0, commaIndex).trim();
    } else {
      streetName = afterHouse;
    }
  }

  return {
    houseNumber,
    streetName: streetName || clean,
    fullAddress: clean,
  };
}

/**
 * Validates latitude and longitude values
 */
export function isValidCoordinate(lat: number, lon: number): boolean {
  return (
    !isNaN(lat) &&
    !isNaN(lon) &&
    lat >= -90 &&
    lat <= 90 &&
    lon >= -180 &&
    lon <= 180 &&
    !(lat === 0 && lon === 0)
  );
}

/**
 * Helper to get text content of a tag or namespaced tag safely from XML element
 */
function getTagText(parent: Element, tagName: string): string {
  // 1. Direct getElementsByTagName (e.g. 'name', 'desc', 'cmt')
  const el = parent.getElementsByTagName(tagName)[0];
  if (el?.textContent && el.textContent.trim()) {
    return el.textContent.trim();
  }

  // 2. Namespaced or child matches (e.g. 'osmand:housenumber', 'addr:housenumber')
  const children = Array.from(parent.children);
  for (const child of children) {
    if (child.localName === tagName || child.nodeName.endsWith(`:${tagName}`)) {
      if (child.textContent?.trim()) return child.textContent.trim();
    }
    // Inspect inside <extensions>
    for (const sub of Array.from(child.children)) {
      if (sub.localName === tagName || sub.nodeName.endsWith(`:${tagName}`)) {
        if (sub.textContent?.trim()) return sub.textContent.trim();
      }
    }
  }

  return '';
}

/**
 * Parses raw GPX XML and extracts customer stops in the exact order they appear in the file.
 * Safely handles OsmAnd marker extensions, custom namespaces, and missing/invalid coordinates.
 */
export function parseGPX(gpxContent: string, routeNameDefault = 'Imported Route'): { stops: RouteStop[]; routeName: string } {
  // Safe XML parsing in browser environment
  let xmlDoc: Document;
  if (typeof DOMParser !== 'undefined') {
    const parser = new DOMParser();
    xmlDoc = parser.parseFromString(gpxContent, 'text/xml');
  } else {
    throw new Error('DOMParser unavailable in current runtime');
  }

  // Check for XML parsererror
  const parserError = xmlDoc.getElementsByTagName('parsererror')[0];
  if (parserError) {
    throw new Error('Invalid GPX/XML format. Please verify the file contents.');
  }

  // Extract route/metadata name if present
  let routeName = routeNameDefault;
  const metaEl = xmlDoc.getElementsByTagName('metadata')[0];
  const metaName = metaEl ? getTagText(metaEl, 'name') : '';
  const gpxName = getTagText(xmlDoc.documentElement, 'name');
  if (metaName) {
    routeName = metaName;
  } else if (gpxName) {
    routeName = gpxName;
  }

  // Collect points in exact file order.
  // Waypoints (<wpt>) are standard for OsmAnd markers & favorites.
  // Fallback to route points (<rtept>) or track points (<trkpt>) if no <wpt>.
  let pointElements = Array.from(xmlDoc.getElementsByTagName('wpt'));
  if (pointElements.length === 0) {
    pointElements = Array.from(xmlDoc.getElementsByTagName('rtept'));
  }
  if (pointElements.length === 0) {
    pointElements = Array.from(xmlDoc.getElementsByTagName('trkpt'));
  }

  if (pointElements.length === 0) {
    throw new Error('No customer waypoints (<wpt> or <rtept>) found in this GPX file.');
  }

  const stops: RouteStop[] = [];

  pointElements.forEach((pt, index) => {
    // 1. Coordinates parsing & validation
    const latStr = pt.getAttribute('lat');
    const lonStr = pt.getAttribute('lon');
    const parsedLat = latStr ? parseFloat(latStr) : NaN;
    const parsedLon = lonStr ? parseFloat(lonStr) : NaN;

    const hasValidCoords = isValidCoordinate(parsedLat, parsedLon);
    const finalLat = hasValidCoords ? parsedLat : 0;
    const finalLon = hasValidCoords ? parsedLon : 0;

    // 2. Text fields parsing
    const rawName = getTagText(pt, 'name');
    const rawDesc = getTagText(pt, 'desc');
    const rawCmt = getTagText(pt, 'cmt');
    const rawAddress = getTagText(pt, 'address');
    const osmandHouseNum = getTagText(pt, 'housenumber');
    const osmandStreet = getTagText(pt, 'street');

    // 3. Name & House Number Disambiguation
    let customerName = rawName || `Customer #${index + 1}`;
    let houseNumber = osmandHouseNum || '';
    let addressCandidate = rawAddress || rawDesc || rawCmt;

    // Pattern A: Name contains "104 - Customer Name" or "Customer Name - 104"
    if (rawName.includes(' - ') || rawName.includes(' – ')) {
      const parts = rawName.split(/\s*[-–]\s*/);
      if (parts.length >= 2) {
        if (/^\d+[A-Za-z]?$/.test(parts[0].trim())) {
          houseNumber = houseNumber || parts[0].trim();
          customerName = parts.slice(1).join(' - ').trim();
        } else if (/^\d+[A-Za-z]?$/.test(parts[parts.length - 1].trim())) {
          houseNumber = houseNumber || parts[parts.length - 1].trim();
          customerName = parts.slice(0, parts.length - 1).join(' - ').trim();
        } else if (/\d+/.test(parts[0]) && !/\d+/.test(parts[1])) {
          addressCandidate = addressCandidate || parts[0];
          customerName = parts[1];
        } else if (/\d+/.test(parts[1]) && !/\d+/.test(parts[0])) {
          addressCandidate = addressCandidate || parts[1];
          customerName = parts[0];
        }
      }
    }

    // Pattern B: Name is just a number (e.g. "104" or "#104")
    const pureNumberMatch = customerName.match(/^#?(\d+[A-Za-z]?)$/);
    if (pureNumberMatch) {
      houseNumber = houseNumber || pureNumberMatch[1];
      customerName = `Customer #${pureNumberMatch[1]}`;
    }

    // Pattern C: Name starts with house number like "104 Maple Grove"
    if (!houseNumber) {
      const leadingHouseMatch = customerName.match(/^(\d+[A-Za-z]?)\s+(.+)$/);
      if (leadingHouseMatch) {
        houseNumber = leadingHouseMatch[1];
      }
    }

    // Pattern D: Extract house number from addressCandidate or cmt/desc if still not found
    if (!houseNumber && addressCandidate) {
      const extracted = extractAddressComponents(addressCandidate);
      if (extracted.houseNumber) {
        houseNumber = extracted.houseNumber;
      }
    }

    // Fallback if no addressCandidate exists
    if (!addressCandidate) {
      addressCandidate = hasValidCoords
        ? `Location (${finalLat.toFixed(5)}, ${finalLon.toFixed(5)})`
        : 'Location unavailable';
    }

    const { streetName: parsedStreet, fullAddress } = extractAddressComponents(addressCandidate);
    const finalStreetName = osmandStreet || parsedStreet || '';

    stops.push({
      id: `stop-${index + 1}-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      orderIndex: index + 1,
      name: customerName,
      houseNumber: houseNumber,
      fullAddress: fullAddress,
      streetName: finalStreetName,
      lat: finalLat,
      lon: finalLon,
      desc: rawDesc || undefined,
      cmt: rawCmt || undefined,
      status: 'pending',
    });
  });

  return { stops, routeName };
}

/**
 * Generates valid GPX XML from RouteStop array (for export/OsmAnd companion download)
 */
export function exportToGPX(stops: RouteStop[], routeName = 'Customer Route'): string {
  const gpxHeader = `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="OsmAnd Route Companion" xmlns="http://www.topografix.com/GPX/1/1" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.topografix.com/GPX/1/1 http://www.topografix.com/GPX/1/1/gpx.xsd">
  <metadata>
    <name>${escapeXml(routeName)}</name>
    <desc>Customer route stops in sequential order</desc>
    <time>${new Date().toISOString()}</time>
  </metadata>
`;

  const waypoints = stops.map((stop) => {
    return `  <wpt lat="${stop.lat}" lon="${stop.lon}">
    <name>${escapeXml(stop.name)}</name>
    <desc>${escapeXml(stop.fullAddress)}</desc>
    <cmt>${escapeXml(`House #${stop.houseNumber || 'N/A'} - Status: ${stop.status}`)}</cmt>
  </wpt>`;
  }).join('\n');

  const gpxFooter = `\n</gpx>`;
  return gpxHeader + waypoints + gpxFooter;
}

function escapeXml(unsafe: string): string {
  return (unsafe || '').replace(/[<>&'"]/g, (c) => {
    switch (c) {
      case '<': return '&lt;';
      case '>': return '&gt;';
      case '&': return '&amp;';
      case '\'': return '&apos;';
      case '"': return '&quot;';
      default: return c;
    }
  });
}
