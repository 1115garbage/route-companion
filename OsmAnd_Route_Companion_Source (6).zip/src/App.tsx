/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { RouteData, RouteStop, AppSettings } from './types/route';
import { parseGPX } from './utils/gpxParser';
import { SAMPLE_GPX_ROUTES } from './utils/sampleRoutes';
import { triggerHaptic, announceStop, requestWakeLock, releaseWakeLock } from './utils/voiceAndHaptics';
import { StopCard } from './components/StopCard';
import { GpxImportModal } from './components/GpxImportModal';
import { RouteListDrawer } from './components/RouteListDrawer';
import { SettingsModal } from './components/SettingsModal';
import { RouteCompletionView } from './components/RouteCompletionView';
import { ExportModal } from './components/ExportModal';
import { useGpsTracker } from './utils/useGpsTracker';
import { 
  Compass, 
  Settings as SettingsIcon, 
  ListFilter, 
  Upload, 
  Download,
  RotateCcw,
  Sparkles,
  Sun,
  Moon,
  CheckCircle2
} from 'lucide-react';

const STORAGE_KEY = 'osmand_route_assistant_v1';
const SETTINGS_KEY = 'osmand_route_assistant_settings_v1';

const DEFAULT_SETTINGS: AppSettings = {
  theme: 'amoled-black',
  voiceAnnouncement: false,
  hapticFeedback: true,
  keepScreenAwake: true,
  extraLargeText: false,
};

export default function App() {
  // Load settings from localStorage
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(SETTINGS_KEY);
      if (saved) {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
      }
    } catch (e) {
      // fallback
    }
    return DEFAULT_SETTINGS;
  });

  // Load route data from localStorage or initialize with sample route
  const [routeData, setRouteData] = useState<RouteData | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && Array.isArray(parsed.stops) && parsed.stops.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      // fallback
    }

    // Default: initialize with first sample route so app is immediately usable
    try {
      const defaultPreset = SAMPLE_GPX_ROUTES[0];
      const parsed = parseGPX(defaultPreset.gpxXml, defaultPreset.title);
      return {
        id: defaultPreset.id,
        name: parsed.routeName,
        filename: `${defaultPreset.id}.gpx`,
        stops: parsed.stops,
        currentIndex: 0,
        importedAt: Date.now(),
        lastUpdated: Date.now(),
      };
    } catch (e) {
      return null;
    }
  });

  // Modals & Drawers state
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [skipToast, setSkipToast] = useState<{ message: string; previousIndex: number } | null>(null);
  const [arrivalToast, setArrivalToast] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Direct Android file picker import handler
  const handleDirectFileImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const cleanFileName = file.name.replace(/\.[^/.]+$/, '');
      const { stops, routeName } = parseGPX(text, cleanFileName);

      if (stops.length === 0) {
        throw new Error('No waypoints found in the selected GPX file.');
      }

      if (settings.hapticFeedback) triggerHaptic('complete');

      // Replace sample customers with the imported customers
      const newRoute: RouteData = {
        id: `route-${Date.now().toString(36)}`,
        name: routeName || file.name,
        filename: file.name,
        stops: stops, // exact file order preserved
        currentIndex: 0,
        importedAt: Date.now(),
        lastUpdated: Date.now(),
      };

      setRouteData(newRoute);
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(newRoute));
      } catch (err) {
        console.error('Storage error', err);
      }

      setArrivalToast(`Imported ${file.name} (${stops.length} stops)`);
      setTimeout(() => setArrivalToast(null), 4000);
    } catch (err: any) {
      setArrivalToast(err.message || 'Failed to read or parse GPX file.');
      setTimeout(() => setArrivalToast(null), 4000);
    } finally {
      if (e.target) {
        e.target.value = '';
      }
    }
  };

  // Sync route data to localStorage whenever it changes
  useEffect(() => {
    if (routeData) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(routeData));
      } catch (e) {
        console.error('Failed to save route to localStorage', e);
      }
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
  }, [routeData]);

  // Sync settings to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch (e) {
      console.error('Failed to save settings', e);
    }
  }, [settings]);

  // Handle Screen WakeLock
  useEffect(() => {
    if (settings.keepScreenAwake) {
      requestWakeLock();
    } else {
      releaseWakeLock();
    }

    return () => {
      releaseWakeLock();
    };
  }, [settings.keepScreenAwake]);

  // Voice announcement on customer stop change
  const isFirstMount = useRef(true);
  useEffect(() => {
    if (isFirstMount.current) {
      isFirstMount.current = false;
      return;
    }
    if (settings.voiceAnnouncement && routeData && routeData.stops[routeData.currentIndex]) {
      const current = routeData.stops[routeData.currentIndex];
      announceStop(current.name, current.houseNumber, current.streetName);
    }
  }, [routeData?.currentIndex, settings.voiceAnnouncement]);

  const isDark = settings.theme === 'amoled-black';

  // Automatic GPS Arrival Advance (within ~50 feet / 15m)
  const handleAutoArrive = () => {
    if (!routeData) return;
    if (settings.hapticFeedback) triggerHaptic('complete');

    const arrivedStop = routeData.stops[routeData.currentIndex];

    setRouteData((prev) => {
      if (!prev) return null;
      const nextIndex = prev.currentIndex + 1;
      const updatedStops = [...prev.stops];

      // Mark current stop as completed
      if (updatedStops[prev.currentIndex]) {
        updatedStops[prev.currentIndex] = {
          ...updatedStops[prev.currentIndex],
          status: 'completed',
          statusTimestamp: Date.now(),
        };
      }

      return {
        ...prev,
        stops: updatedStops,
        currentIndex: nextIndex,
        lastUpdated: Date.now(),
      };
    });

    if (arrivedStop) {
      setArrivalToast(`Auto-Arrived: #${arrivedStop.orderIndex} ${arrivedStop.name}`);
      setTimeout(() => {
        setArrivalToast(null);
      }, 3500);
    }
  };

  // Skip Customer Immediately
  const handleSkipCustomer = () => {
    if (!routeData) return;
    if (settings.hapticFeedback) triggerHaptic('skip');

    const skippedStop = routeData.stops[routeData.currentIndex];
    const prevIdx = routeData.currentIndex;

    setRouteData((prev) => {
      if (!prev) return null;
      const nextIndex = prev.currentIndex + 1;
      const updatedStops = [...prev.stops];

      if (updatedStops[prev.currentIndex]) {
        updatedStops[prev.currentIndex] = {
          ...updatedStops[prev.currentIndex],
          status: 'skipped',
          statusTimestamp: Date.now(),
        };
      }

      return {
        ...prev,
        stops: updatedStops,
        currentIndex: nextIndex,
        lastUpdated: Date.now(),
      };
    });

    // Show temporary Undo toast
    if (skippedStop) {
      setSkipToast({
        message: `Skipped: #${skippedStop.orderIndex} ${skippedStop.name}`,
        previousIndex: prevIdx,
      });
      setTimeout(() => {
        setSkipToast(null);
      }, 4000);
    }
  };

  // Return to Previous Customer
  const handlePreviousCustomer = () => {
    if (!routeData || routeData.currentIndex <= 0) return;
    if (settings.hapticFeedback) triggerHaptic('undo');

    setRouteData((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        currentIndex: prev.currentIndex - 1,
        lastUpdated: Date.now(),
      };
    });
  };

  // Undo accidental skip from toast
  const handleUndoSkip = () => {
    if (!skipToast || !routeData) return;
    if (settings.hapticFeedback) triggerHaptic('undo');

    const restoreIndex = skipToast.previousIndex;
    setRouteData((prev) => {
      if (!prev) return null;
      const updatedStops = [...prev.stops];
      if (updatedStops[restoreIndex]) {
        updatedStops[restoreIndex] = {
          ...updatedStops[restoreIndex],
          status: 'pending',
        };
      }
      return {
        ...prev,
        stops: updatedStops,
        currentIndex: restoreIndex,
        lastUpdated: Date.now(),
      };
    });
    setSkipToast(null);
  };

  // Jump to specific stop from list
  const handleJumpToStop = (index: number) => {
    if (!routeData) return;
    if (settings.hapticFeedback) triggerHaptic('tap');

    setRouteData((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        currentIndex: Math.max(0, Math.min(index, prev.stops.length)),
        lastUpdated: Date.now(),
      };
    });
  };

  // Reset route progress to Stop 1
  const handleResetProgress = () => {
    if (!routeData) return;
    if (settings.hapticFeedback) triggerHaptic('tap');

    setRouteData((prev) => {
      if (!prev) return null;
      const resetStops = prev.stops.map((s) => ({
        ...s,
        status: 'pending' as const,
        statusTimestamp: undefined,
      }));
      return {
        ...prev,
        stops: resetStops,
        currentIndex: 0,
        lastUpdated: Date.now(),
      };
    });
  };

  // Handle successful import of new GPX
  const handleImportSuccess = (stops: RouteStop[], routeName: string, filename: string) => {
    if (settings.hapticFeedback) triggerHaptic('tap');
    const newRoute: RouteData = {
      id: `route-${Date.now().toString(36)}`,
      name: routeName,
      filename,
      stops,
      currentIndex: 0,
      importedAt: Date.now(),
      lastUpdated: Date.now(),
    };
    setRouteData(newRoute);
  };

  // Clear current route
  const handleClearRoute = () => {
    setRouteData(null);
  };

  const currentStop = routeData && routeData.currentIndex < routeData.stops.length
    ? routeData.stops[routeData.currentIndex]
    : null;

  const previousStop = routeData && routeData.currentIndex > 0
    ? routeData.stops[routeData.currentIndex - 1]
    : null;

  const nextStop = routeData && routeData.currentIndex < routeData.stops.length - 1
    ? routeData.stops[routeData.currentIndex + 1]
    : null;

  // Real GPS hardware tracking & 50-foot automatic arrival engine with safeguards
  const {
    location: userLocation,
    gpsStatus,
    gpsErrorMsg,
    distanceToCurrentFeet,
    isWithinGeofence,
    isSharedLocationWithPrevious,
    isSharedLocationWithNext,
    autoArrivalStatus,
  } = useGpsTracker(currentStop, previousStop, nextStop, handleAutoArrive);

  const isRouteFinished = routeData && routeData.currentIndex >= routeData.stops.length;

  const completedCount = routeData ? routeData.stops.filter((s) => s.status === 'completed').length : 0;
  const skippedCount = routeData ? routeData.stops.filter((s) => s.status === 'skipped').length : 0;

  return (
    <div 
      className={`min-h-screen w-full flex flex-col font-sans transition-colors duration-150 ${
        isDark 
          ? 'bg-black text-white' 
          : 'bg-white text-black'
      }`}
    >
      {/* Top Application Bar - Designed for Samsung One UI status ergonomics */}
      <header 
        className={`w-full shrink-0 border-b px-4 py-2.5 flex items-center justify-between z-20 ${
          isDark 
            ? 'bg-neutral-950/95 border-neutral-800' 
            : 'bg-neutral-50/95 border-neutral-200'
        }`}
      >
        {/* Brand & OsmAnd Companion Tag */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-xl bg-orange-600 flex items-center justify-center text-white shrink-0 shadow-sm">
            <Compass className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="font-black text-sm tracking-tight truncate">
                OsmAnd Route Companion
              </span>
              <span className="hidden sm:inline-block text-[10px] font-mono px-1.5 py-0.2 rounded bg-neutral-800 text-emerald-400 border border-neutral-700">
                Samsung Android
              </span>
            </div>
            {routeData && (
              <p className="text-[11px] text-neutral-400 truncate">
                {routeData.name} ({routeData.stops.length} stops)
              </p>
            )}
          </div>
        </div>

        {/* Top Actions: Theme, Stops List, Settings, Import */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Quick theme toggle */}
          <button
            onClick={() => setSettings((s) => ({ ...s, theme: s.theme === 'amoled-black' ? 'high-contrast-day' : 'amoled-black' }))}
            className={`p-2 rounded-xl transition-colors ${
              isDark ? 'text-neutral-300 hover:text-white hover:bg-neutral-900' : 'text-neutral-700 hover:text-black hover:bg-neutral-200'
            }`}
            title="Toggle AMOLED Black / Daylight High-Contrast"
          >
            {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-neutral-800" />}
          </button>

          {/* Hidden File Picker Input for Android File Picker */}
          <input
            ref={fileInputRef}
            type="file"
            accept=".gpx,.xml,application/gpx+xml,text/xml"
            onChange={handleDirectFileImport}
            className="hidden"
          />

          {/* Import GPX Button */}
          <button
            onClick={() => {
              if (settings.hapticFeedback) triggerHaptic('tap');
              setIsImportOpen(true);
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all active:scale-95 ${
              isDark 
                ? 'border-neutral-700 bg-neutral-900 text-neutral-200 hover:bg-neutral-800 hover:text-white' 
                : 'border-neutral-300 bg-neutral-100 text-neutral-800 hover:bg-neutral-200'
            }`}
            title="Import GPX Customer Route"
          >
            <Upload className="w-3.5 h-3.5 text-emerald-400" />
            <span>Import GPX</span>
          </button>

          {/* Download Project Source ZIP Button */}
          <button
            onClick={() => setIsExportOpen(true)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all active:scale-95 ${
              isDark 
                ? 'border-blue-700/80 bg-blue-950/70 text-blue-300 hover:bg-blue-900 hover:text-white' 
                : 'border-blue-300 bg-blue-50 text-blue-800 hover:bg-blue-100'
            }`}
            title="Download source code and Android APK wrapper ZIP"
          >
            <Download className="w-3.5 h-3.5 text-blue-400" />
            <span>Download ZIP</span>
          </button>

          {/* Stops Drawer Toggle */}
          {routeData && (
            <button
              onClick={() => setIsDrawerOpen(true)}
              className={`p-2 rounded-xl border transition-colors ${
                isDark 
                  ? 'border-neutral-700 bg-neutral-900 text-neutral-200 hover:bg-neutral-800' 
                  : 'border-neutral-300 bg-neutral-100 text-neutral-800 hover:bg-neutral-200'
              }`}
              title="View all stops list"
            >
              <ListFilter className="w-4 h-4 text-emerald-400" />
            </button>
          )}

          {/* Settings Button */}
          <button
            onClick={() => setIsSettingsOpen(true)}
            className={`p-2 rounded-xl transition-colors ${
              isDark ? 'text-neutral-400 hover:text-white hover:bg-neutral-900' : 'text-neutral-600 hover:text-black hover:bg-neutral-200'
            }`}
            title="Settings & Display options"
          >
            <SettingsIcon className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Screen Container - Centered mobile viewport layout */}
      <main className="flex-1 w-full max-w-lg mx-auto flex flex-col p-4 relative overflow-hidden">
        {/* Auto-Arrival Banner (Confirms automatic arrival without requiring manual input) */}
        {arrivalToast && (
          <div className="absolute top-4 left-4 right-4 z-30 animate-in slide-in-from-top duration-200">
            <div className="bg-emerald-500 text-black px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2 border-2 border-emerald-300">
              <CheckCircle2 className="w-4 h-4 stroke-[3] shrink-0" />
              <span className="text-xs font-black truncate">
                {arrivalToast}
              </span>
            </div>
          </div>
        )}

        {/* Undo Toast when a customer was skipped */}
        {skipToast && (
          <div className="absolute top-4 left-4 right-4 z-30 animate-in slide-in-from-top duration-200">
            <div className="bg-amber-400 text-black px-4 py-2.5 rounded-2xl shadow-2xl flex items-center justify-between border-2 border-amber-300">
              <span className="text-xs font-bold truncate max-w-[240px]">
                {skipToast.message}
              </span>
              <button
                onClick={handleUndoSkip}
                className="flex items-center gap-1 px-2.5 py-1 bg-black text-amber-300 rounded-lg text-xs font-black uppercase tracking-wider hover:bg-neutral-900 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Undo</span>
              </button>
            </div>
          </div>
        )}

        {/* Case 1: Route finished / all customers visited */}
        {isRouteFinished ? (
          <RouteCompletionView
            stops={routeData.stops}
            routeName={routeData.name}
            isDark={isDark}
            onRestart={handleResetProgress}
            onJumpToStop={handleJumpToStop}
            onLoadNewRoute={() => setIsImportOpen(true)}
          />
        ) : currentStop && routeData ? (
          /* Case 2: Active customer stop card */
          <StopCard
            stop={currentStop}
            previousStop={previousStop || undefined}
            nextStop={nextStop || undefined}
            userLocation={userLocation}
            gpsStatus={gpsStatus}
            gpsErrorMsg={gpsErrorMsg}
            distanceToCurrentFeet={distanceToCurrentFeet}
            isWithinGeofence={isWithinGeofence}
            isSharedLocationWithPrevious={isSharedLocationWithPrevious}
            isSharedLocationWithNext={isSharedLocationWithNext}
            autoArrivalStatus={autoArrivalStatus}
            currentIndex={routeData.currentIndex}
            totalStops={routeData.stops.length}
            completedCount={completedCount}
            skippedCount={skippedCount}
            settings={settings}
            onSkip={handleSkipCustomer}
            onPrevious={handlePreviousCustomer}
            onJumpToStopList={() => setIsDrawerOpen(true)}
          />
        ) : (
          /* Case 3: No route loaded */
          <div className="flex-1 flex flex-col items-center justify-center text-center p-6 space-y-4 my-auto">
            <div className="w-16 h-16 rounded-3xl bg-neutral-900 border border-neutral-800 flex items-center justify-center text-emerald-400">
              <Compass className="w-8 h-8" />
            </div>
            <div>
              <h2 className="text-xl font-black">No Active GPX Route</h2>
              <p className="text-xs text-neutral-400 mt-1 max-w-xs">
                Import a customer GPX file from OsmAnd or pick a built-in delivery route.
              </p>
            </div>
            <div className="space-y-2 w-full max-w-xs">
              <button
                onClick={() => setIsImportOpen(true)}
                className="w-full py-3.5 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-950/40"
              >
                <Upload className="w-4 h-4" />
                <span>Import GPX File</span>
              </button>
              <button
                onClick={() => {
                  const defaultPreset = SAMPLE_GPX_ROUTES[0];
                  const parsed = parseGPX(defaultPreset.gpxXml, defaultPreset.title);
                  handleImportSuccess(parsed.stops, parsed.routeName, `${defaultPreset.id}.gpx`);
                }}
                className="w-full py-3 px-4 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-200 font-bold text-xs flex items-center justify-center gap-2 transition-all"
              >
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Load Sample Route (20 Stops)</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Import Modal */}
      <GpxImportModal
        isOpen={isImportOpen}
        isDark={isDark}
        onClose={() => setIsImportOpen(false)}
        onImportSuccess={handleImportSuccess}
      />

      {/* Route List Drawer */}
      {routeData && (
        <RouteListDrawer
          isOpen={isDrawerOpen}
          isDark={isDark}
          stops={routeData.stops}
          currentIndex={routeData.currentIndex}
          routeName={routeData.name}
          onClose={() => setIsDrawerOpen(false)}
          onSelectStop={handleJumpToStop}
          onResetRoute={handleResetProgress}
        />
      )}

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        isDark={isDark}
        settings={settings}
        onClose={() => setIsSettingsOpen(false)}
        onUpdateSettings={(newSettings) => setSettings((s) => ({ ...s, ...newSettings }))}
        onOpenImport={() => setIsImportOpen(true)}
        onResetProgress={handleResetProgress}
        onClearRoute={handleClearRoute}
        onOpenExport={() => setIsExportOpen(true)}
      />

      {/* Export / APK Modal */}
      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        isDark={isDark}
      />
    </div>
  );
}
