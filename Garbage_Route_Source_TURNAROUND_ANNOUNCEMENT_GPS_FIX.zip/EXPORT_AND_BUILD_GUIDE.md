# Garbage Route: Build & Installation Guide for Android

This guide explains how to build and install **Garbage Route** as a native Android APK, and how to resolve false video/gallery files.

---

## 1. Quick Fix for the 7 Video Files & 33 Gallery Images

### Why did Samsung show 7 videos and 33 photos?
- When you extracted `Garbage_Route_Source.zip` directly on your Samsung phone into `Downloads/Garbage_Route_Source (1)`:
  - Android One UI treats TypeScript files ending with `.ts` as **MPEG-2 Transport Stream video files**. That is why the 7 files in `src/utils` (`gpxParser.ts`, `useGpsTracker.ts`, `voiceAndHaptics.ts`, etc.) showed up in your video player with purple play icons.
  - Samsung Gallery scanned all folders in `Downloads` and added the 33 launcher icon and asset `.png` files to your photo gallery.

### How to clean them up right now:
1. Open the Samsung **My Files** app on your phone.
2. Go to **Downloads**.
3. Select and **Delete** any extracted folders named `Garbage_Route_Source`, `Garbage_Route_Source (1)`, or `OsmAnd_Route_Companion_Source`.
4. The 7 video entries and 33 gallery photos will immediately disappear from your phone!
5. In this new update, **`.nomedia`** protection files have been added to all source folders. If you ever extract the archive again, Android MediaStore will ignore all `.ts` and `.png` files completely.

---

## 2. How to Build Your APK with GitHub Actions (No Extraction Needed on Phone)

You do **NOT** need to extract the zip file on your phone! GitHub Actions automatically extracts the archive and compiles the native APK in the cloud.

### Step-by-Step Build:
1. **Download the updated source archive**:
   - In the web app, tap **Export Android Source ZIP** to download `Garbage_Route_Source.zip`.
2. **Upload directly to your GitHub repository** (`1115garbage/route-companion`):
   - Open GitHub in your phone's browser or computer.
   - Tap **Add file** > **Upload files**.
   - Select the `Garbage_Route_Source.zip` file directly (do NOT unzip it first).
   - Tap **Commit changes**.
3. **Automatic Cloud Build**:
   - Tap the **Actions** tab on your GitHub repository.
   - You will see the **Build Android APK** workflow start running automatically.
   - It will finish in ~1.5 to 2 minutes with a green checkmark.
4. **Download & Install the APK**:
   - Tap the completed workflow run.
   - Scroll down to the **Artifacts** section at the bottom.
   - Tap **Garbage-Route-APK** to download the zip containing `app-debug.apk`.
   - Open **My Files > Downloads**, tap `app-debug.apk`, and tap **Install** (or **Update**).

---

## 3. What Was Fixed in This Build

- **GitHub Actions Build Failure Fixed**:
  - Automatically accepts Android SDK 34 licenses via license hashes and sdkmanager fallback.
  - Upgraded to Node.js 22 and Gradle 8.5.
  - Stripped duplicate and bloated archive copies from the Android asset pipeline so the compiler never crashes with `exit code 1`.
  - Bumped app `versionCode` to `7` and `versionName` to `1.0.6` so phone updates install seamlessly over existing installations without conflicts.
- **Customer Information Display Decoupled from Navigation State**:
  - Customer name and yellow house number stay pinned on screen while stopped at the curb.
  - Display advances ONLY upon confirmed physical departure (vehicle speed >= 3.5 mph for 3 consecutive GPS readings and displaced > 20 meters from stop).
  - Premature display jump on missing or invalid coordinates eliminated.
- **Media Indexing Suppressed**:
  - Embedded `.nomedia` files in all 17 subfolders so Android MediaStore never treats `.ts` code as video or app icons as gallery pictures.
- **Navigation & Arrival Precision Preserved**:
  - Consecutive stops at the same address (such as Stops 22 & 23) advance cleanly in proper sequence without false turnaround alerts or skipped customers.
  - Full-speed approaches and road-end turnarounds are calculated using route direction and road geometry.
  - Preserved the 600-foot advance warning for standard turns.


Latest update: restored the explicit spoken “Turn around as soon as possible” announcement when the active road-navigation maneuver is a U-turn. The existing route maneuver selection and automatic turnaround behavior are preserved. This source update still requires a successful GitHub Actions build and device test.
