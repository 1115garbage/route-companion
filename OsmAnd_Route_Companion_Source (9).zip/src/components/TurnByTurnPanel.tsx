import React, { useState, useEffect, useRef, useCallback } from 'react';
import { RouteStop } from '../types/route';
import { GpsLocation } from '../utils/useGpsTracker';
import { 
  Compass, 
  Play, 
  Square, 
  RotateCcw, 
  X, 
  Info, 
  CheckCircle2, 
  Sparkles,
  CornerUpRight, 
  CornerUpLeft, 
  ArrowUp, 
  ArrowUpRight, 
  ArrowUpLeft,
  CircleDot, 
  GitFork, 
  Flag 
} from 'lucide-react';

// ==========================================
// 1. Types & Data Contracts
// ==========================================
export interface NavManeuver {
  type: string;
  modifier?: string;
  instruction: string;
  streetName: string;
  distanceMeters: number;
  location: [number, number]; // [lon, lat]
}

// ==========================================
// 2. Math & Distance Helpers
// ==========================================
function isValidCoordinate(lat: number, lon: number): boolean {
  return (
    !isNaN(lat) &&
    !isNaN(lon) &&
    lat >= -90 &&
    lat <= 90 &&
    lon >= -180 &&
    lon <= 180 &&
    !(lat === 0 && lon === 0)
  );
}

function calculateDistanceMeters(lat1: number, lon1: number, lat2: number, lon2: number): number {
  if (
    isNaN(lat1) || isNaN(lon1) || isNaN(lat2) || isNaN(lon2) ||
    (lat1 === 0 && lon1 === 0) || (lat2 === 0 && lon2 === 0)
  ) {
    return Infinity;
  }
  const R = 6371000;
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) *
      Math.cos(lat2 * (Math.PI / 180)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function formatDistance(meters: number): string {
  if (isNaN(meters) || meters < 0) return '0 ft';
  const feet = meters * 3.28084;
  if (feet < 1000) {
    if (feet > 200) {
      return `${Math.round(feet / 50) * 50} ft`;
    }
    return `${Math.max(10, Math.round(feet / 10) * 10)} ft`;
  }
  const miles = feet / 5280;
  if (miles < 10) {
    return `${miles.toFixed(1)} mi`;
  }
  return `${Math.round(miles)} mi`;
}

function formatDuration(seconds: number): string {
  if (isNaN(seconds) || seconds <= 0) return '1 min';
  const mins = Math.round(seconds / 60);
  if (mins < 60) return `${Math.max(1, mins)} min`;
  const hours = Math.floor(mins / 60);
  const remMins = mins % 60;
  return remMins > 0 ? `${hours}h ${remMins}m` : `${hours}h`;
}

// ==========================================
// 3. Genuine Road Instruction Generator
// ==========================================
function buildInstructionText(type: string, modifier: string | undefined, streetName: string, destinationName: string): string {
  const street = streetName && streetName.trim() ? streetName.trim() : '';
  const mod = (modifier || '').toLowerCase();
  const t = (type || '').toLowerCase();

  if (t === 'arrive') {
    return destinationName ? `Arrive at ${destinationName}` : 'Arrive at destination';
  }
  if (t === 'depart') {
    return street ? `Head out onto ${street}` : 'Head toward destination';
  }
  if (t === 'merge') {
    return mod.includes('left')
      ? (street ? `Merge left onto ${street}` : 'Merge left')
      : (street ? `Merge right onto ${street}` : 'Merge right');
  }
  if (t === 'on ramp' || t === 'off ramp' || t === 'ramp') {
    return street ? `Take ramp onto ${street}` : 'Take ramp';
  }
  if (t === 'fork') {
    return mod.includes('left')
      ? (street ? `Keep left at fork onto ${street}` : 'Keep left at fork')
      : (street ? `Keep right at fork onto ${street}` : 'Keep right at fork');
  }
  if (t === 'roundabout' || t === 'rotary') {
    return street ? `Enter roundabout toward ${street}` : 'Enter roundabout';
  }
  if (t === 'end of road') {
    return mod.includes('left')
      ? (street ? `Turn left at end onto ${street}` : 'Turn left at end of road')
      : (street ? `Turn right at end onto ${street}` : 'Turn right at end of road');
  }

  switch (mod) {
    case 'left':
      return street ? `Turn left onto ${street}` : 'Turn left';
    case 'right':
      return street ? `Turn right onto ${street}` : 'Turn right';
    case 'slight left':
      return street ? `Bear slightly left onto ${street}` : 'Bear slightly left';
    case 'slight right':
      return street ? `Bear slightly right onto ${street}` : 'Bear slightly right';
    case 'sharp left':
      return street ? `Make a sharp left onto ${street}` : 'Sharp left';
    case 'sharp right':
      return street ? `Make a sharp right onto ${street}` : 'Sharp right';
    case 'uturn':
      return street ? `Make a U-turn onto ${street}` : 'Make a U-turn';
    case 'straight':
      return street ? `Continue straight on ${street}` : 'Continue straight';
    default:
      if (t === 'continue' || t === 'new name') {
        return street ? `Continue onto ${street}` : 'Continue straight';
      }
      return street ? `Proceed onto ${street}` : 'Proceed along route';
  }
}

// ==========================================
// 4. OpenStreetMap (OSRM) Road Routing Engine
// ==========================================
async function fetchOsmRoute(
  startLat: number,
  startLon: number,
  destLat: number,
  destLon: number,
  destName: string
): Promise<{ maneuvers: NavManeuver[]; totalDistance: number; totalDuration: number }> {
  // Free, public OpenStreetMap road-network routing machine
  const url = `https://router.project-osrm.org/route/v1/driving/${startLon},${startLat};${destLon},${destLat}?steps=true&overview=full&geometries=geojson`;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 7000);

  try {
    const response = await fetch(url, { signal: controller.signal });
    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`Routing server returned HTTP ${response.status}`);
    }

    const data = await response.json();
    if (data.code !== 'Ok' || !data.routes || data.routes.length === 0) {
      throw new Error('No driving route found between coordinates');
    }

    const route = data.routes[0];
    const leg = route.legs?.[0];
    const steps = leg?.steps || [];

    const maneuvers: NavManeuver[] = steps.map((s: any) => {
      const type = s.maneuver?.type || 'turn';
      const modifier = s.maneuver?.modifier;
      const streetName = s.name || '';
      const instruction = buildInstructionText(type, modifier, streetName, destName);
      const location: [number, number] = s.maneuver?.location || [destLon, destLat];

      return {
        type,
        modifier,
        instruction,
        streetName,
        distanceMeters: s.distance || 0,
        location,
      };
    });

    return {
      maneuvers,
      totalDistance: route.distance || 0,
      totalDuration: route.duration || 0,
    };
  } catch (err: any) {
    clearTimeout(timeoutId);
    throw err;
  }
}

// ==========================================
// 5. Maneuver Icon Component
// ==========================================
const ManeuverIconComponent: React.FC<{ type?: string; modifier?: string; className?: string }> = ({ 
  type = 'turn', 
  modifier = 'straight',
  className = 'w-10 h-10' 
}) => {
  const mod = (modifier || '').toLowerCase();
  const t = (type || '').toLowerCase();

  if (t === 'arrive') return <Flag className={className} />;
  if (t === 'roundabout' || t === 'rotary') return <CircleDot className={className} />;
  if (t === 'fork') return <GitFork className={className} />;
  if (mod.includes('uturn')) return <RotateCcw className={className} />;
  if (mod === 'sharp right') {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M12 21V11a4 4 0 0 1 4-4h5" />
        <polyline points="18 4 21 7 18 10" />
      </svg>
    );
  }
  if (mod === 'sharp left') {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M12 21V11a4 4 0 0 0-4-4H3" />
        <polyline points="6 4 3 7 6 10" />
      </svg>
    );
  }
  if (mod === 'slight right') return <ArrowUpRight className={className} strokeWidth={2.75} />;
  if (mod === 'slight left') return <ArrowUpLeft className={className} strokeWidth={2.75} />;
  if (mod === 'right') return <CornerUpRight className={className} strokeWidth={2.75} />;
  if (mod === 'left') return <CornerUpLeft className={className} strokeWidth={2.75} />;
  if (mod === 'straight' || t === 'continue' || t === 'depart') {
    return <ArrowUp className={className} strokeWidth={2.75} />;
  }
  return <Compass className={className} strokeWidth={2.5} />;
};

// ==========================================
// 6. Complete Turn-by-Turn Panel Component
// ==========================================
interface TurnByTurnPanelProps {
  currentStop: RouteStop;
  previousStop?: RouteStop;
  userLocation: GpsLocation | null;
  gpsStatus: 'acquiring' | 'locked' | 'denied';
  gpsErrorMsg: string | null;
  distanceToCurrentFeet: number | null;
  isDark: boolean;
  onOpenOsmAnd: (e: React.MouseEvent) => void;
}

export const TurnByTurnPanel: React.FC<TurnByTurnPanelProps> = ({
  currentStop,
  previousStop,
  userLocation,
  gpsStatus,
  distanceToCurrentFeet,
  isDark,
}) => {
  const [showStatusModal, setShowStatusModal] = useState(false);

  // Live OsmAnd AIDL feed state (from Android Kotlin wrapper)
  const [aidlUpdate, setAidlUpdate] = useState<{
    maneuver: string;
    street: string;
    distanceMeters: number;
    lastReceived: number;
  } | null>(null);

  useEffect(() => {
    (window as any).onOsmAndNavUpdate = (maneuver: string, street: string, distMeters: number) => {
      setAidlUpdate({
        maneuver: maneuver || 'straight',
        street: street || '',
        distanceMeters: typeof distMeters === 'number' ? distMeters : 0,
        lastReceived: Date.now(),
      });
    };
    return () => {
      delete (window as any).onOsmAndNavUpdate;
    };
  }, []);

  const isAidlActive = Boolean(aidlUpdate && Date.now() - aidlUpdate.lastReceived < 20000);

  // Road navigation state
  const [maneuvers, setManeuvers] = useState<NavManeuver[]>([]);
  const [currentManeuverIndex, setCurrentManeuverIndex] = useState(0);
  const [distanceToTurnMeters, setDistanceToTurnMeters] = useState(0);
  const [totalDistanceMeters, setTotalDistanceMeters] = useState(0);
  const [totalDurationSeconds, setTotalDurationSeconds] = useState(0);
  const [isRouting, setIsRouting] = useState(false);
  const [routingError, setRoutingError] = useState<string | null>(null);

  // Simulation mode for testing indoors on Android or desktop
  const [isSimulating, setIsSimulating] = useState(false);
  const simulationRef = useRef<number | null>(null);

  const getStartPoint = useCallback((): { lat: number; lon: number } | null => {
    if (userLocation && isValidCoordinate(userLocation.lat, userLocation.lon)) {
      return { lat: userLocation.lat, lon: userLocation.lon };
    }
    if (previousStop && isValidCoordinate(previousStop.lat, previousStop.lon)) {
      return { lat: previousStop.lat, lon: previousStop.lon };
    }
    if (currentStop && isValidCoordinate(currentStop.lat, currentStop.lon)) {
      return { lat: currentStop.lat - 0.005, lon: currentStop.lon - 0.004 };
    }
    return null;
  }, [userLocation, previousStop, currentStop]);

  // Fetch genuine road route
  const fetchRoute = useCallback(async () => {
    if (!currentStop || !isValidCoordinate(currentStop.lat, currentStop.lon)) {
      setManeuvers([]);
      return;
    }

    const start = getStartPoint();
    if (!start) return;

    setIsRouting(true);
    setRoutingError(null);

    try {
      const route = await fetchOsmRoute(
        start.lat,
        start.lon,
        currentStop.lat,
        currentStop.lon,
        currentStop.name
      );

      if (route.maneuvers.length > 0) {
        setManeuvers(route.maneuvers);
        setCurrentManeuverIndex(0);
        setTotalDistanceMeters(route.totalDistance);
        setTotalDurationSeconds(route.totalDuration);
        setDistanceToTurnMeters(route.maneuvers[0]?.distanceMeters || 0);
      }
    } catch (err: any) {
      console.warn('Road routing error:', err);
      setRoutingError(err.message || 'Routing unavailable');
    } finally {
      setIsRouting(false);
    }
  }, [currentStop, getStartPoint]);

  useEffect(() => {
    setCurrentManeuverIndex(0);
    fetchRoute();
  }, [currentStop?.id, currentStop?.lat, currentStop?.lon]);

  // Vehicle progress tracking via GPS
  useEffect(() => {
    if (isSimulating || maneuvers.length === 0 || !userLocation) return;
    const currentM = maneuvers[currentManeuverIndex];
    if (!currentM) return;

    const [turnLon, turnLat] = currentM.location;
    const dist = calculateDistanceMeters(userLocation.lat, userLocation.lon, turnLat, turnLon);

    if (dist < 25 && currentManeuverIndex < maneuvers.length - 1) {
      setCurrentManeuverIndex((idx) => idx + 1);
      const nextM = maneuvers[currentManeuverIndex + 1];
      setDistanceToTurnMeters(nextM ? nextM.distanceMeters : 0);
    } else {
      setDistanceToTurnMeters(Math.max(0, Math.round(dist)));
    }
  }, [userLocation, maneuvers, currentManeuverIndex, isSimulating]);

  // Simulation timer
  useEffect(() => {
    if (!isSimulating || maneuvers.length === 0) {
      if (simulationRef.current) {
        window.clearInterval(simulationRef.current);
        simulationRef.current = null;
      }
      return;
    }

    let currentDist = maneuvers[currentManeuverIndex]?.distanceMeters || 300;
    setDistanceToTurnMeters(currentDist);

    simulationRef.current = window.setInterval(() => {
      currentDist -= 20;
      if (currentDist <= 20) {
        setCurrentManeuverIndex((prev) => {
          if (prev >= maneuvers.length - 1) {
            setIsSimulating(false);
            return prev;
          }
          const nextIdx = prev + 1;
          currentDist = maneuvers[nextIdx]?.distanceMeters || 200;
          return nextIdx;
        });
      }
      setDistanceToTurnMeters(Math.max(10, currentDist));
      setTotalDistanceMeters((tot) => Math.max(0, tot - 20));
      setTotalDurationSeconds((dur) => Math.max(0, dur - 1.5));
    }, 800);

    return () => {
      if (simulationRef.current) window.clearInterval(simulationRef.current);
    };
  }, [isSimulating, maneuvers, currentManeuverIndex]);

  const currentManeuver = maneuvers[currentManeuverIndex] || null;
  const nextManeuver = maneuvers[currentManeuverIndex + 1] || null;

  const activeManeuverType = isAidlActive && aidlUpdate
    ? (aidlUpdate.maneuver.includes('roundabout') ? 'roundabout' : 'turn')
    : currentManeuver?.type || 'turn';

  const activeManeuverModifier = isAidlActive && aidlUpdate
    ? aidlUpdate.maneuver
    : currentManeuver?.modifier || 'straight';

  const activeInstructionText = isAidlActive && aidlUpdate
    ? (aidlUpdate.street ? `Turn onto ${aidlUpdate.street}` : aidlUpdate.maneuver)
    : currentManeuver?.instruction || (currentStop.streetName ? `Proceed along route to ${currentStop.streetName}` : 'Proceed toward customer destination');

  const activeStreetName = isAidlActive && aidlUpdate
    ? aidlUpdate.street
    : currentManeuver?.streetName || currentStop.streetName || currentStop.fullAddress || '';

  const activeDistanceToNextTurn = isAidlActive && aidlUpdate
    ? formatDistance(aidlUpdate.distanceMeters)
    : formatDistance(distanceToTurnMeters) || '0 ft';

  const hasValidCoords = isValidCoordinate(currentStop.lat, currentStop.lon);
  const distanceToStopFormatted = distanceToCurrentFeet !== null && hasValidCoords
    ? formatDistance(distanceToCurrentFeet / 3.28084)
    : formatDistance(totalDistanceMeters) || null;

  const isArrived = distanceToCurrentFeet !== null && distanceToCurrentFeet <= 50;

  return (
    <>
      {/* 
        Substantially Taller, Full-Width Driver-Grade Turn-by-Turn Card
        - Zero text truncation (no truncate, no nowrap, no ellipses)
        - Multi-line wrap enabled for any street name length
        - High-contrast AMOLED black & amber/orange styling
      */}
      <div 
        className={`w-full rounded-3xl border-2 transition-all shadow-2xl relative mb-3.5 flex flex-col ${
          isArrived
            ? 'bg-emerald-950/95 border-emerald-400 text-white shadow-emerald-950/90'
            : isDark 
              ? 'bg-neutral-950 border-neutral-800 text-white shadow-neutral-950/95' 
              : 'bg-neutral-900 border-neutral-700 text-white shadow-neutral-500/40'
        }`}
      >
        {/* Amber accent top bar */}
        <div className="w-full h-1.5 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-400 rounded-t-3xl" />

        {/* 1. Header Bar: Engine Source, Destination Metrics & Test Drive Control */}
        <div className="px-4 py-2.5 flex items-center justify-between border-b border-neutral-800/90 gap-2 flex-wrap">
          {/* Active Status Badge */}
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5 shrink-0">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                isAidlActive ? 'bg-emerald-400' : isSimulating ? 'bg-amber-400' : 'bg-orange-400'
              }`} />
              <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${
                isAidlActive ? 'bg-emerald-400' : isSimulating ? 'bg-amber-400' : 'bg-orange-500'
              }`} />
            </span>
            <span className="font-mono font-black uppercase tracking-wider text-[11px] text-neutral-300">
              {isAidlActive 
                ? 'OsmAnd Native AIDL' 
                : isSimulating 
                  ? 'Simulated Drive Active' 
                  : isRouting 
                    ? 'Updating Road Route...' 
                    : 'OpenStreetMap Road Routing'}
            </span>
          </div>

          {/* Test Drive Button for Instant In-Phone Verification */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsSimulating((s) => !s)}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-xl text-[11px] font-black uppercase tracking-wider transition-all active:scale-95 ${
                isSimulating 
                  ? 'bg-amber-400 text-black shadow-lg shadow-amber-950/60 animate-pulse' 
                  : 'bg-neutral-900 hover:bg-neutral-800 text-amber-400 border border-neutral-700'
              }`}
              title={isSimulating ? 'Stop test navigation simulation' : 'Simulate road navigation directly on your phone'}
            >
              {isSimulating ? (
                <>
                  <Square className="w-3 h-3 fill-current" />
                  <span>Pause Test</span>
                </>
              ) : (
                <>
                  <Play className="w-3 h-3 fill-current" />
                  <span>Test Drive</span>
                </>
              )}
            </button>

            <button
              onClick={() => setShowStatusModal(true)}
              className="p-1 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
              title="Navigation details & instructions"
            >
              <Info className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 2. Primary Turn Section: Prominent Maneuver Arrow + Distance to Next Turn */}
        <div className="p-4 sm:p-5 flex items-center justify-between gap-4 border-b border-neutral-800/60">
          {/* Prominent Maneuver Arrow Container (Substantial space, high-contrast) */}
          <div 
            className={`w-18 h-18 sm:w-22 sm:h-22 rounded-2xl flex items-center justify-center shrink-0 border-2 shadow-xl transition-all ${
              isArrived
                ? 'bg-emerald-500 border-emerald-300 text-black shadow-emerald-500/50'
                : isAidlActive
                  ? 'bg-emerald-500/25 border-emerald-400 text-emerald-400'
                  : 'bg-amber-400 border-amber-300 text-black shadow-amber-400/20'
            }`}
          >
            {isArrived ? (
              <CheckCircle2 className="w-11 h-11 sm:w-13 sm:h-13 stroke-[3] text-black" />
            ) : (
              <ManeuverIconComponent 
                type={activeManeuverType}
                modifier={activeManeuverModifier}
                className="w-11 h-11 sm:w-13 sm:h-13 stroke-[3]" 
              />
            )}
          </div>

          {/* Distance to NEXT TURN (Clearly Distinguished from Distance to Customer) */}
          <div className="flex-1 text-right min-w-0">
            <div className="text-[11px] font-black uppercase tracking-widest text-amber-400 font-mono mb-0.5">
              {isArrived ? 'ARRIVAL' : 'DISTANCE TO NEXT TURN'}
            </div>
            <div className="font-black text-4xl sm:text-5xl font-mono text-white tracking-tight leading-none drop-shadow">
              {isArrived ? '0 FT' : activeDistanceToNextTurn}
            </div>

            {/* Total Remaining Distance to the Customer (Clearly separated) */}
            {distanceToStopFormatted && (
              <div className="text-xs font-semibold text-neutral-300 mt-1.5 font-mono">
                Customer Stop: <span className="font-bold text-white">{distanceToStopFormatted}</span>
                {totalDurationSeconds > 0 ? ` • ~${formatDuration(totalDurationSeconds)}` : ''}
              </div>
            )}
          </div>
        </div>

        {/* 3. Full-Width Driving Instruction (Multi-Line Wrapping, Zero Truncation) */}
        <div className="p-4 sm:p-5 space-y-2">
          {/* Complete Turn Instruction Text - No truncate, wraps cleanly */}
          <h2 className="text-2xl sm:text-3xl font-black text-amber-300 tracking-tight leading-tight whitespace-normal break-words">
            {activeInstructionText}
          </h2>

          {/* Road / Street Name Pill (Multi-Line Safe) */}
          {activeStreetName && (
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-neutral-900 border border-neutral-700/80 text-white font-bold text-xs sm:text-sm max-w-full whitespace-normal break-words">
              <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
              <span className="break-words">Road: {activeStreetName}</span>
            </div>
          )}
        </div>

        {/* 4. Upcoming Next Turn Preview Strip ("THEN" Maneuver) */}
        {nextManeuver && !isArrived && (
          <div className="px-4 py-3 bg-neutral-900/95 border-t border-neutral-800 rounded-b-3xl flex items-start gap-3 text-xs sm:text-sm font-semibold text-neutral-300 whitespace-normal break-words">
            <span className="text-[10px] font-black uppercase tracking-wider text-black bg-amber-400 px-2 py-0.5 rounded-md shrink-0 mt-0.5">
              THEN
            </span>
            <div className="w-5 h-5 flex items-center justify-center shrink-0 text-amber-400 mt-0.5">
              <ManeuverIconComponent 
                type={nextManeuver.type}
                modifier={nextManeuver.modifier}
                className="w-4 h-4 stroke-[2.75]" 
              />
            </div>
            <div className="flex-1 min-w-0 whitespace-normal break-words text-neutral-200">
              <span className="font-mono text-amber-400 font-bold">In {formatDistance(nextManeuver.distanceMeters)}:</span>{' '}
              <span>{nextManeuver.instruction}</span>
            </div>
          </div>
        )}

        {/* 5. Geofence Arrival Banner */}
        {isArrived && (
          <div className="p-3 bg-emerald-500 text-black font-black text-sm text-center tracking-wide uppercase rounded-b-3xl flex items-center justify-center gap-2">
            <CheckCircle2 className="w-5 h-5 stroke-[3]" />
            <span>ARRIVED AT CUSTOMER DESTINATION</span>
          </div>
        )}

        {/* Routing Error Notice */}
        {routingError && (
          <div className="px-4 py-2 bg-red-950/80 border-t border-red-900 text-xs text-red-300 flex items-center justify-between">
            <span>Routing server: {routingError}</span>
            <button
              onClick={fetchRoute}
              className="underline text-red-200 flex items-center gap-1 font-bold"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Retry
            </button>
          </div>
        )}
      </div>

      {/* Navigation Architecture & In-Phone Testing Guide Modal */}
      {showStatusModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-3xl border border-neutral-700 bg-neutral-900 text-white shadow-2xl p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-orange-600 flex items-center justify-center text-white shrink-0">
                  <Compass className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-black text-base">True Road Navigation</h3>
                  <p className="text-xs text-neutral-400">Full-text driving directions without map tiles</p>
                </div>
              </div>
              <button
                onClick={() => setShowStatusModal(false)}
                className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs text-neutral-300">
              <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="font-bold text-amber-400 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" />
                  <span>OpenStreetMap (OSRM) Road Engine</span>
                </div>
                <p>
                  Calculates genuine road network turns with exact street names and step distances. Compass bearings like &quot;Head North&quot; are replaced with actual maneuvers (&quot;Turn left onto Main Street&quot;).
                </p>
                <p className="text-emerald-400 font-semibold">
                  ✓ 100% Free & Open-Source (No API keys or costs)
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="font-bold text-amber-300">How to Verify on Android:</div>
                <ol className="list-decimal pl-4 space-y-1.5 text-neutral-400">
                  <li>Tap the <strong>Test Drive</strong> button at the top right of the navigation card.</li>
                  <li>Watch the distance count down to zero and observe each maneuver transition into the next road turn.</li>
                  <li>Notice that long road names wrap naturally across multiple lines with zero ellipses or clipping.</li>
                  <li>When you drive on the road with GPS on, the distance updates continuously from device GPS hardware.</li>
                </ol>
              </div>
            </div>

            <button
              onClick={() => setShowStatusModal(false)}
              className="w-full mt-5 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-sm transition-all"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
};
