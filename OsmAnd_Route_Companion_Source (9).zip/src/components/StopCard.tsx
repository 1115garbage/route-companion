import React from 'react';
import { RouteStop, AppSettings } from '../types/route';
import { getNavigationLinks, triggerHaptic } from '../utils/voiceAndHaptics';
import { TurnByTurnPanel } from './TurnByTurnPanel';
import { GpsLocation } from '../utils/useGpsTracker';
import { getStopHouseNumber } from '../utils/gpxParser';
import { 
  ChevronLeft, 
  SkipForward, 
  Compass,
  List
} from 'lucide-react';

interface StopCardProps {
  stop: RouteStop;
  previousStop?: RouteStop;
  nextStop?: RouteStop;
  userLocation: GpsLocation | null;
  gpsStatus: 'acquiring' | 'locked' | 'denied';
  gpsErrorMsg: string | null;
  distanceToCurrentFeet: number | null;
  isWithinGeofence: boolean;
  isSharedLocationWithPrevious: boolean;
  isSharedLocationWithNext: boolean;
  autoArrivalStatus: string;
  currentIndex: number;
  totalStops: number;
  completedCount: number;
  skippedCount: number;
  settings: AppSettings;
  onSkip: () => void;
  onPrevious: () => void;
  onJumpToStopList: () => void;
}

export const StopCard: React.FC<StopCardProps> = ({
  stop,
  previousStop,
  userLocation,
  gpsStatus,
  gpsErrorMsg,
  distanceToCurrentFeet,
  currentIndex,
  totalStops,
  settings,
  onSkip,
  onPrevious,
  onJumpToStopList,
}) => {
  const isDark = settings.theme === 'amoled-black';
  const { osmandUri } = getNavigationLinks(stop.lat, stop.lon, stop.name);

  // Extract true house number from the customer's delivery address data (never stop sequence e.g. "002")
  const displayHouseNumber = getStopHouseNumber(stop, currentIndex);

  const openOsmAnd = (e: React.MouseEvent) => {
    e.preventDefault();
    triggerHaptic('tap');

    if (!stop.lat || !stop.lon || (stop.lat === 0 && stop.lon === 0)) {
      return;
    }

    // 1. Prefer native Android Bridge
    try {
      const bridge = (window as any).AndroidBridge;
      if (bridge && typeof bridge.openOsmAnd === 'function') {
        bridge.openOsmAnd(stop.lat, stop.lon);
        return;
      }
    } catch (err) {}

    // 2. Safe browser fallback
    try {
      window.location.href = osmandUri;
    } catch (err) {}
  };

  return (
    <div className="flex flex-col h-full justify-between pb-safe select-none">
      {/* 1. Turn-by-Turn Navigation Panel at the very top */}
      <div className="shrink-0">
        <TurnByTurnPanel
          currentStop={stop}
          previousStop={previousStop}
          userLocation={userLocation}
          gpsStatus={gpsStatus}
          gpsErrorMsg={gpsErrorMsg}
          distanceToCurrentFeet={distanceToCurrentFeet}
          isDark={isDark}
          onOpenOsmAnd={openOsmAnd}
        />
      </div>

      {/* 2. Stop Number and Total Stops in a Small Area */}
      <div className="shrink-0 flex items-center justify-between px-1 py-1 mb-1">
        <button
          onClick={onJumpToStopList}
          className="flex items-center gap-1.5 text-xs font-mono font-bold text-neutral-400 hover:text-white transition-colors"
          title="Open Stop List"
        >
          <span className="text-emerald-400">STOP {currentIndex + 1} OF {totalStops}</span>
          <List className="w-3.5 h-3.5 text-neutral-500" />
        </button>

        {currentIndex > 0 && (
          <button
            onClick={onPrevious}
            className="flex items-center gap-1 text-[11px] font-semibold text-neutral-400 hover:text-white px-2 py-1 rounded bg-neutral-900 border border-neutral-800 transition-colors"
            title="Return to previous customer"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            <span>Prev</span>
          </button>
        )}
      </div>

      {/* 3 & 4. Main Minimal Display: Customer Name (Large) + Yellow House-Number Block (Very Large) */}
      <div className="flex-1 flex flex-col items-center justify-center my-auto py-4 text-center">
        {/* Customer's Name in Large Text */}
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight leading-tight mb-4 px-2 max-w-md break-words">
          {stop.name}
        </h1>

        {/* Yellow House-Number Block with Very Large Number */}
        <div 
          className="bg-amber-400 text-black border-2 border-amber-300 rounded-3xl px-8 py-5 flex items-center justify-center shadow-2xl min-w-[200px] max-w-[320px] transition-transform active:scale-95"
        >
          <span className="text-6xl sm:text-7xl font-black font-mono tracking-tighter leading-none">
            {displayHouseNumber}
          </span>
        </div>

        {/* Delivery Address Context */}
        {stop.fullAddress && (
          <p className="text-xs sm:text-sm font-semibold text-neutral-400 mt-3 px-4 max-w-md break-words">
            {stop.fullAddress}
          </p>
        )}

        {/* 8. Open in OsmAnd Button - Small and Secondary to the House Number */}
        <div className="mt-4">
          <a
            href={osmandUri}
            onClick={openOsmAnd}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white text-xs font-medium transition-colors"
            title="Open in OsmAnd"
          >
            <Compass className="w-3.5 h-3.5 text-orange-400" />
            <span>Open in OsmAnd</span>
          </a>
        </div>
      </div>

      {/* 7. Large Orange SKIP CUSTOMER Button at the Bottom */}
      <div className="shrink-0 pt-2">
        <button
          onClick={onSkip}
          className="w-full h-18 rounded-2xl flex items-center justify-center gap-3 font-black text-xl tracking-wide uppercase bg-amber-500 hover:bg-amber-400 text-black border-2 border-amber-300 shadow-xl shadow-amber-950/50 transition-all active:scale-[0.98]"
        >
          <SkipForward className="w-7 h-7 stroke-[3]" />
          <span>Skip Customer</span>
        </button>
      </div>
    </div>
  );
};
