/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { RouteData, RouteStop, AppSettings } from './types/route';
import { parseGPX, getStopHouseNumber, isValidCoordinate } from './utils/gpxParser';
import { SAMPLE_GPX_ROUTES } from './utils/sampleRoutes';
import { triggerHaptic, announceStop, requestWakeLock, releaseWakeLock, cancelTurnAnnouncements } from './utils/voiceAndHaptics';
import { StopCard } from './components/StopCard';
import { GpxImportModal } from './components/GpxImportModal';
import { RouteListDrawer } from './components/RouteListDrawer';
import { SettingsModal } from './components/SettingsModal';
import { RouteCompletionView } from './components/RouteCompletionView';
import { ExportModal } from './components/ExportModal';
import { useGpsTracker, GpsLocation } from './utils/useGpsTracker';
import { calculateDistanceMeters } from './utils/navigationService';
import { 
  Compass, 
  Upload, 
  RotateCcw,
  Sparkles,
  CheckCircle2
} from 'lucide-react';

const STORAGE_KEY = 'osmand_route_assistant_v1';
const SETTINGS_KEY = 'osmand_route_assistant_settings_v1';

const DEFAULT_SETTINGS: AppSettings = {
  theme: 'amoled-black',
  voiceAnnouncement: true,
  hapticFeedback: true,
  keepScreenAwake: true,
  extraLargeText: false,
  arrivalRadiusMeters: 75, // Configurable arrival proximity window default (75 meters)
  arrivalConfirmFeet: 246, // Configurable arrival confirmation threshold default (75m = 246 ft)
  turnWarningDistancesFeet: [600], // Early advance turn warning distance in feet default (600 ft)
};

export default function App() {
  // Load settings from localStorage
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(SETTINGS_KEY);
      if (saved) {
        const parsedSettings = JSON.parse(saved);
        const mergedSettings = { ...DEFAULT_SETTINGS, ...parsedSettings };
        // Migrate the previous built-in 500 ft default to 600 ft. Preserve other custom values.
        // Older releases used [500] or [500, 200] as their default warning configuration.
        if (
          Array.isArray(parsedSettings.turnWarningDistancesFeet) &&
          (JSON.stringify(parsedSettings.turnWarningDistancesFeet) === JSON.stringify([500]) ||
           JSON.stringify(parsedSettings.turnWarningDistancesFeet) === JSON.stringify([500, 200]))
        ) {
          mergedSettings.turnWarningDistancesFeet = [600];
        }
        return mergedSettings;
      }
    } catch (e) {
      // fallback
    }
    return DEFAULT_SETTINGS;
  });

  // Load route data from localStorage or initialize with sample route
  const [routeData, setRouteData] = useState<RouteData | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && Array.isArray(parsed.stops) && parsed.stops.length > 0) {
          // Sanitize/re-extract house numbers so any stale "002" stop sequence numbers
          // are restored to the genuine house number extracted from the customer's delivery address!
          const healedStops = parsed.stops.map((s: RouteStop, idx: number) => {
            const trueHouseNumber = getStopHouseNumber(s, idx);
            return {
              ...s,
              houseNumber: trueHouseNumber !== '—' ? trueHouseNumber : (s.houseNumber && !/^0+\d+$/.test(s.houseNumber) ? s.houseNumber : ''),
            };
          });
          return {
            ...parsed,
            stops: healedStops,
          };
        }
      }
    } catch (e) {
      // fallback
    }

    // Default: initialize with first sample route so app is immediately usable
    try {
      const defaultPreset = SAMPLE_GPX_ROUTES[0];
      const parsed = parseGPX(defaultPreset.gpxXml, defaultPreset.title);
      return {
        id: defaultPreset.id,
        name: parsed.routeName,
        filename: `${defaultPreset.id}.gpx`,
        stops: parsed.stops,
        currentIndex: 0,
        importedAt: Date.now(),
        lastUpdated: Date.now(),
      };
    } catch (e) {
      return null;
    }
  });

  // Modals & Drawers state
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [skipToast, setSkipToast] = useState<{ message: string; previousIndex: number } | null>(null);
  const [arrivalToast, setArrivalToast] = useState<string | null>(null);

  // Central customer display index - kept on current customer while stopped at driveway/curb,
  // transitioning to next customer only upon confirmed vehicle departure!
  const [displayedStopIndex, setDisplayedStopIndex] = useState<number>(() => {
    return routeData ? routeData.currentIndex : 0;
  });

  const diagLogRef = useRef<(msg: string) => void>(() => {});

  // Centralized, diagnostic-traced customer display updater
  const changeDisplayedStop = useCallback((newIdx: number, reason: string, extraDiagnostics?: string) => {
    const currentCust = routeData && routeData.stops[displayedStopIndex];
    const nextCust = routeData && routeData.stops[newIdx];
    const validCoords = currentCust ? isValidCoordinate(Number(currentCust.lat), Number(currentCust.lon)) : false;
    const diagMsg = `[DisplayChange] #${displayedStopIndex} (${currentCust?.id || 'none'}: ${currentCust?.name || ''}) -> #${newIdx} (${nextCust?.id || 'none'}: ${nextCust?.name || ''}) | Reason: ${reason} | ValidCoords: ${validCoords} | NavIdx: ${routeData?.currentIndex ?? 'none'}${extraDiagnostics ? ` | ${extraDiagnostics}` : ''}`;
    console.log(diagMsg);
    diagLogRef.current(diagMsg);
    setDisplayedStopIndex(newIdx);
  }, [routeData, displayedStopIndex]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Direct Android file picker import handler
  const handleDirectFileImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const cleanFileName = file.name.replace(/\.[^/.]+$/, '');
      const { stops, routeName } = parseGPX(text, cleanFileName);

      if (stops.length === 0) {
        throw new Error('No waypoints found in the selected GPX file.');
      }

      if (settings.hapticFeedback) triggerHaptic('complete');

      // Replace sample customers with the imported customers
      const newRoute: RouteData = {
        id: `route-${Date.now().toString(36)}`,
        name: routeName || file.name,
        filename: file.name,
        stops: stops, // exact file order preserved
        currentIndex: 0,
        importedAt: Date.now(),
        lastUpdated: Date.now(),
      };

      setRouteData(newRoute);
      changeDisplayedStop(0, 'direct_file_import');
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(newRoute));
      } catch (err) {
        console.error('Storage error', err);
      }

      setArrivalToast(`Imported ${file.name} (${stops.length} stops)`);
      setTimeout(() => setArrivalToast(null), 4000);
    } catch (err: any) {
      setArrivalToast(err.message || 'Failed to read or parse GPX file.');
      setTimeout(() => setArrivalToast(null), 4000);
    } finally {
      if (e.target) {
        e.target.value = '';
      }
    }
  };

  // Sync route data to localStorage whenever it changes
  useEffect(() => {
    if (routeData) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(routeData));
      } catch (e) {
        console.error('Failed to save route to localStorage', e);
      }
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
  }, [routeData]);

  // Sync settings to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch (e) {
      console.error('Failed to save settings', e);
    }
  }, [settings]);

  // Handle Screen WakeLock
  useEffect(() => {
    if (settings.keepScreenAwake) {
      requestWakeLock();
    } else {
      releaseWakeLock();
    }

    return () => {
      releaseWakeLock();
    };
  }, [settings.keepScreenAwake]);

  // Voice announcement on displayed customer change (upon departure to next customer or same-address transition)
  const isFirstMount = useRef(true);
  useEffect(() => {
    if (isFirstMount.current) {
      isFirstMount.current = false;
      return;
    }
    if (settings.voiceAnnouncement && routeData && routeData.stops[displayedStopIndex]) {
      const current = routeData.stops[displayedStopIndex];
      const houseNumber = getStopHouseNumber(current, displayedStopIndex);
      announceStop(current.name, houseNumber !== '—' ? houseNumber : '');
    }
  }, [displayedStopIndex, settings.voiceAnnouncement]);

  const isDark = settings.theme === 'amoled-black';

  // Automatic GPS Arrival Advance (within configured arrival proximity window)
  const arrivedAtTimestampRef = useRef<number>(0);
  const handleAutoArrive = () => {
    if (!routeData) return;
    if (settings.hapticFeedback) triggerHaptic('complete');

    const prevIdx = routeData.currentIndex;
    const arrivedStop = routeData.stops[prevIdx];
    const nextIndex = prevIdx + 1;
    const dispIdxBefore = displayedStopIndex;
    const dispStopBefore = routeData.stops[dispIdxBefore];

    arrivedAtTimestampRef.current = Date.now();

    // Targeted diagnostic logging before and after arrival
    const diagMsg = `[AutoArrival] Stop #${prevIdx} (${arrivedStop?.id || 'none'}: ${arrivedStop?.name || ''}) ARRIVED | NavIndex: ${prevIdx} -> ${nextIndex} | DisplayedStop: #${dispIdxBefore} (${dispStopBefore?.id || 'none'}: ${dispStopBefore?.name || ''}) (Pinned while stopped)`;
    console.log(diagMsg);
    diagLogRef.current(diagMsg);

    // Check if next customer shares the same address / coordinates (< 25m, e.g. Stops 22 & 23)
    const nextStop = routeData.stops[nextIndex];
    const isSameAddress = Boolean(
      arrivedStop && nextStop &&
      isValidCoordinate(arrivedStop.lat, arrivedStop.lon) &&
      isValidCoordinate(nextStop.lat, nextStop.lon) &&
      calculateDistanceMeters(arrivedStop.lat, arrivedStop.lon, nextStop.lat, nextStop.lon) < 25
    );

    setRouteData((prev) => {
      if (!prev) return null;
      const updatedStops = [...prev.stops];

      // Mark current stop as completed
      if (updatedStops[prevIdx]) {
        updatedStops[prevIdx] = {
          ...updatedStops[prevIdx],
          status: 'completed',
          statusTimestamp: Date.now(),
        };
      }

      return {
        ...prev,
        stops: updatedStops,
        currentIndex: nextIndex,
        lastUpdated: Date.now(),
      };
    });

    // Keep current customer displayed while vehicle is stopped at driveway/curb until departure.
    // Displayed customer and active navigation stop are maintained independently.
    // Consecutive stops at the same address (e.g. Stops 22 & 23) transition after service dwell or manual pick up.

    if (arrivedStop) {
      setArrivalToast(`Auto-Arrived: #${arrivedStop.orderIndex} ${arrivedStop.name}`);
      setTimeout(() => {
        setArrivalToast(null);
      }, 3500);
    }
  };

  // Mark Customer as Picked Up (Manual confirmation)
  // Mark Customer as Picked Up (Manual confirmation)
  const lastMarkPickedUpTimeRef = useRef<number>(0);
  const handleMarkPickedUp = () => {
    if (!routeData) return;
    const now = Date.now();
    // Guard against repeated rapid events or double clicks completing multiple customers
    if (now - lastMarkPickedUpTimeRef.current < 750) return;
    lastMarkPickedUpTimeRef.current = now;

    if (settings.hapticFeedback) triggerHaptic('complete');
    cancelTurnAnnouncements();

    const currentIdx = routeData.currentIndex;
    if (currentIdx >= routeData.stops.length) return;

    const targetIdx = displayedStopIndex < currentIdx ? displayedStopIndex : currentIdx;
    const pickedUpStop = routeData.stops[targetIdx];

    // Find next uncompleted customer
    let nextIndex = Math.max(currentIdx, targetIdx + 1);
    while (nextIndex < routeData.stops.length && routeData.stops[nextIndex].status === 'completed') {
      nextIndex++;
    }

    const nextStop = routeData.stops[nextIndex];
    const isSameAddress = Boolean(
      pickedUpStop && nextStop &&
      isValidCoordinate(pickedUpStop.lat, pickedUpStop.lon) &&
      isValidCoordinate(nextStop.lat, nextStop.lon) &&
      calculateDistanceMeters(pickedUpStop.lat, pickedUpStop.lon, nextStop.lat, nextStop.lon) < 25
    );

    setRouteData((prev) => {
      if (!prev || targetIdx >= prev.stops.length) return prev;
      const updatedStops = [...prev.stops];

      // Mark stop as completed
      if (updatedStops[targetIdx]) {
        updatedStops[targetIdx] = {
          ...updatedStops[targetIdx],
          status: 'completed',
          statusTimestamp: Date.now(),
        };
      }

      return {
        ...prev,
        stops: updatedStops,
        currentIndex: nextIndex,
        lastUpdated: Date.now(),
      };
    });

    // Consecutive stops at identical/shared coordinates (e.g. Stop 22 & Stop 23):
    // Completing Stop 22 transitions display to Stop 23 to service the second customer at that address.
    // For distinct addresses, keep the completed customer displayed while stopped at the curb until departure!
    if (isSameAddress) {
      changeDisplayedStop(nextIndex, 'same_address_manual_pickup');
    }

    if (pickedUpStop) {
      setArrivalToast(`Picked Up: #${pickedUpStop.orderIndex} ${pickedUpStop.name}`);
      setTimeout(() => {
        setArrivalToast(null);
      }, 3500);
    }
  };

  // Skip Customer Immediately
  const handleSkipCustomer = () => {
    if (!routeData) return;
    if (settings.hapticFeedback) triggerHaptic('skip');

    const skippedStop = routeData.stops[routeData.currentIndex];
    const prevIdx = routeData.currentIndex;
    const nextIndex = prevIdx + 1;

    setRouteData((prev) => {
      if (!prev) return null;
      const updatedStops = [...prev.stops];

      if (updatedStops[prev.currentIndex]) {
        updatedStops[prev.currentIndex] = {
          ...updatedStops[prev.currentIndex],
          status: 'skipped',
          statusTimestamp: Date.now(),
        };
      }

      return {
        ...prev,
        stops: updatedStops,
        currentIndex: nextIndex,
        lastUpdated: Date.now(),
      };
    });

    changeDisplayedStop(nextIndex, 'manual_skip');

    // Show temporary Undo toast
    if (skippedStop) {
      setSkipToast({
        message: `Skipped: #${skippedStop.orderIndex} ${skippedStop.name}`,
        previousIndex: prevIdx,
      });
      setTimeout(() => {
        setSkipToast(null);
      }, 4000);
    }
  };

  // Return to Previous Customer
  const handlePreviousCustomer = () => {
    if (!routeData || routeData.currentIndex <= 0) return;
    if (settings.hapticFeedback) triggerHaptic('undo');

    const prevIdx = Math.max(0, routeData.currentIndex - 1);
    setRouteData((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        currentIndex: prevIdx,
        lastUpdated: Date.now(),
      };
    });
    changeDisplayedStop(prevIdx, 'manual_previous');
  };

  // Undo accidental skip from toast
  const handleUndoSkip = () => {
    if (!skipToast || !routeData) return;
    if (settings.hapticFeedback) triggerHaptic('undo');

    const restoreIndex = skipToast.previousIndex;
    setRouteData((prev) => {
      if (!prev) return null;
      const updatedStops = [...prev.stops];
      if (updatedStops[restoreIndex]) {
        updatedStops[restoreIndex] = {
          ...updatedStops[restoreIndex],
          status: 'pending',
        };
      }
      return {
        ...prev,
        stops: updatedStops,
        currentIndex: restoreIndex,
        lastUpdated: Date.now(),
      };
    });
    changeDisplayedStop(restoreIndex, 'undo_skip');
    setSkipToast(null);
  };

  // Jump to specific stop from list
  const handleJumpToStop = (index: number) => {
    if (!routeData) return;
    if (settings.hapticFeedback) triggerHaptic('tap');
    const validIndex = Math.max(0, Math.min(index, routeData.stops.length));

    setRouteData((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        currentIndex: validIndex,
        lastUpdated: Date.now(),
      };
    });
    changeDisplayedStop(validIndex, 'manual_jump_to_stop');
  };

  // Reset route progress to Stop 1
  const handleResetProgress = () => {
    if (!routeData) return;
    if (settings.hapticFeedback) triggerHaptic('tap');

    setRouteData((prev) => {
      if (!prev) return null;
      const resetStops = prev.stops.map((s) => ({
        ...s,
        status: 'pending' as const,
        statusTimestamp: undefined,
      }));
      return {
        ...prev,
        stops: resetStops,
        currentIndex: 0,
        lastUpdated: Date.now(),
      };
    });
    changeDisplayedStop(0, 'reset_progress');
  };

  // Handle successful import of new GPX
  const handleImportSuccess = (stops: RouteStop[], routeName: string, filename: string) => {
    if (settings.hapticFeedback) triggerHaptic('tap');
    const newRoute: RouteData = {
      id: `route-${Date.now().toString(36)}`,
      name: routeName,
      filename,
      stops,
      currentIndex: 0,
      importedAt: Date.now(),
      lastUpdated: Date.now(),
    };
    setRouteData(newRoute);
    changeDisplayedStop(0, 'import_success');
  };

  // Clear current route
  const handleClearRoute = () => {
    setRouteData(null);
    changeDisplayedStop(0, 'clear_route');
  };

  const currentStop = routeData && routeData.currentIndex < routeData.stops.length
    ? routeData.stops[routeData.currentIndex]
    : null;

  const previousStop = routeData && routeData.currentIndex > 0
    ? routeData.stops[routeData.currentIndex - 1]
    : null;

  const nextStop = routeData && routeData.currentIndex < routeData.stops.length - 1
    ? routeData.stops[routeData.currentIndex + 1]
    : null;

  // The customer stop currently displayed on the central screen
  const displayedStop = routeData && displayedStopIndex < routeData.stops.length
    ? routeData.stops[displayedStopIndex]
    : currentStop;

  // Route context for parallel road rejection and driving distance tracking
  const [routeCoordinates, setRouteCoordinates] = useState<[number, number][]>([]);
  const [roadRemainingMeters, setRoadRemainingMeters] = useState<number | null>(null);

  // Clear route context when active stop changes
  useEffect(() => {
    setRouteCoordinates([]);
    setRoadRemainingMeters(null);
  }, [currentStop?.id]);

  // Backup route data before simulation so exiting restores original state cleanly
  const backupRouteDataRef = useRef<RouteData | null>(null);

  const handleSimulationStart = useCallback(() => {
    if (routeData && !backupRouteDataRef.current) {
      backupRouteDataRef.current = JSON.parse(JSON.stringify(routeData));
    }
  }, [routeData]);

  const handleExitSimulation = useCallback(() => {
    if (backupRouteDataRef.current) {
      setRouteData(backupRouteDataRef.current);
      backupRouteDataRef.current = null;
    }
  }, []);

  // Real GPS hardware tracking & configurable arrival engine with full route simulation
  const {
    location: userLocation,
    gpsStatus,
    gpsErrorMsg,
    distanceToCurrentFeet,
    isWithinGeofence,
    isConfirmedArrival,
    isSharedLocationWithPrevious,
    isSharedLocationWithNext,
    autoArrivalStatus,
    arrivalRadiusMeters,
    arrivalConfirmFeet,
    isPassedWithoutCompletion,
    isSimulatingGps,
    isSimPaused,
    simSpeedMultiplier,
    startFullRouteSimulation,
    pauseSimulation,
    resumeSimulation,
    setSimulationSpeed,
    restartSimulation,
    stopGpsSimulation,
    simulateApproachAndPass,
    simulateApproachAndArrive,
    simulateCurbsidePassThrough,
    diagLogs,
    addDiagLog,
  } = useGpsTracker(
    currentStop, 
    previousStop, 
    nextStop, 
    handleAutoArrive, 
    settings.arrivalRadiusMeters ?? 75.0,
    (settings.arrivalConfirmFeet != null ? settings.arrivalConfirmFeet * 0.3048 : 75.0),
    roadRemainingMeters,
    routeCoordinates,
    routeData?.stops,
    handleJumpToStop,
    handleResetProgress,
    handleSimulationStart,
    handleExitSimulation
  );

  // Link logger ref so changeDisplayedStop can log to test drive diagnostic panel
  diagLogRef.current = addDiagLog;

  // Departure detection: keeps the arrived customer displayed on the central screen
  // while the truck is in front of the house (stopped or curbside pickup),
  // and transitions to the next customer ONLY when reliable GPS movement confirms departure!
  const consecutiveDepartCountRef = useRef<number>(0);
  const minDistanceToServicedStopRef = useRef<number>(Infinity);
  const lastServicedStopIdRef = useRef<string | null>(null);
  const serviceParkedAnchorRef = useRef<{ lat: number; lon: number } | null>(null);
  const lastLocForSpeedRef = useRef<GpsLocation | null>(null);

  useEffect(() => {
    if (!routeData) return;
    const currentNavIdx = routeData.currentIndex;
    if (displayedStopIndex >= currentNavIdx) {
      consecutiveDepartCountRef.current = 0;
      minDistanceToServicedStopRef.current = Infinity;
      serviceParkedAnchorRef.current = null;
      lastLocForSpeedRef.current = null;
      return;
    }

    const servicedStop = routeData.stops[displayedStopIndex];
    if (!servicedStop || !isValidCoordinate(Number(servicedStop.lat), Number(servicedStop.lon))) {
      // Missing or invalid coordinates must NEVER advance the display!
      // Retain the current customer's display and return safely.
      return;
    }

    // Reset tracking state when transitioning to a new serviced customer
    if (servicedStop.id !== lastServicedStopIdRef.current) {
      lastServicedStopIdRef.current = servicedStop.id;
      minDistanceToServicedStopRef.current = Infinity;
      consecutiveDepartCountRef.current = 0;
      serviceParkedAnchorRef.current = null;
      lastLocForSpeedRef.current = null;
    }

    // If consecutive stops share identical coordinates / address (< 25m, e.g. Stops 22 & 23),
    // do NOT advance the display while stationary at the property.
    // Transition occurs when the driver marks Stop 22 as picked up!
    const nextNavStop = routeData.stops[currentNavIdx];
    const isSameAddress = Boolean(
      servicedStop && nextNavStop &&
      isValidCoordinate(Number(servicedStop.lat), Number(servicedStop.lon)) &&
      isValidCoordinate(Number(nextNavStop.lat), Number(nextNavStop.lon)) &&
      calculateDistanceMeters(servicedStop.lat, servicedStop.lon, nextNavStop.lat, nextNavStop.lon) < 25
    );
    if (isSameAddress) {
      // Hold display on current customer while at the shared address.
      return;
    }

    if (!userLocation || !isValidCoordinate(Number(userLocation.lat), Number(userLocation.lon))) {
      return;
    }

    // Discard inaccurate or degraded GPS fixes (> 25m accuracy error)
    // to strictly prevent GPS drift from ever triggering premature advancement
    if (userLocation.accuracy && userLocation.accuracy > 25.0) {
      return;
    }

    // Minimum dwell safeguard: vehicle must be present at the stop for at least 4.0 seconds
    // after arrival was declared before departure can even begin to evaluate
    const timeSinceArrival = Date.now() - (arrivedAtTimestampRef.current || 0);
    const inDwellWindow = !isSimulatingGps && timeSinceArrival < 12000;

    // Calculate effective vehicle speed:
    // Uses reported hardware speed if available, or computes inter-fix speed from consecutive GPS coordinates
    let computedSpeedMph: number | null = null;
    const prevLoc = lastLocForSpeedRef.current;
    if (prevLoc && isValidCoordinate(Number(prevLoc.lat), Number(prevLoc.lon))) {
      const dt = Math.max(0.4, ((userLocation.timestamp || Date.now()) - (prevLoc.timestamp || Date.now())) / 1000);
      const interFixDist = calculateDistanceMeters(prevLoc.lat, prevLoc.lon, userLocation.lat, userLocation.lon);
      computedSpeedMph = (interFixDist / dt) * 2.23694;
    }
    lastLocForSpeedRef.current = userLocation;

    const rawSpeed = (userLocation.speed !== null && !isNaN(userLocation.speed) && userLocation.speed >= 0)
      ? userLocation.speed
      : null;
    const effectiveSpeedMph = rawSpeed !== null ? rawSpeed : computedSpeedMph;

    const distFromServicedMeters = calculateDistanceMeters(
      userLocation.lat,
      userLocation.lon,
      servicedStop.lat,
      servicedStop.lon
    );

    if (distFromServicedMeters < minDistanceToServicedStopRef.current) {
      minDistanceToServicedStopRef.current = distFromServicedMeters;
    }
    const minSeen = minDistanceToServicedStopRef.current;

    // LOCKING THE CURBSIDE STOPPED POSITION:
    // When the vehicle is stopped or crawling (< 3.5 mph), or near closest approach,
    // continually lock serviceParkedAnchorRef to where the truck is ACTUALLY stopped/servicing!
    const isStoppedOrCrawlingAtCurb = (rawSpeed !== null && rawSpeed < 3.5) ||
      (effectiveSpeedMph !== null && effectiveSpeedMph < 3.5) ||
      distFromServicedMeters <= minSeen + 3.0;

    if (!serviceParkedAnchorRef.current || isStoppedOrCrawlingAtCurb) {
      serviceParkedAnchorRef.current = { lat: userLocation.lat, lon: userLocation.lon };
    }

    const displacementFromAnchor = calculateDistanceMeters(
      serviceParkedAnchorRef.current.lat,
      serviceParkedAnchorRef.current.lon,
      userLocation.lat,
      userLocation.lon
    );

    // =========================================================================
    // 1. VEHICLE IS STATIONARY, DWELLING, OR AT THE CUSTOMER ADDRESS:
    // Under NO circumstances can a stationary or parked vehicle advance the display!
    // Conditions for stationary/at stop:
    // - In dwell window (< 4s since arrival)
    // - Vehicle is stopped or slow crawl (< 3.0 mph)
    // - OR vehicle displacement from parked spot is < 18 meters (~59 feet)
    // =========================================================================
    const isStationarySpeed = (rawSpeed !== null && rawSpeed < 3.0) ||
      (effectiveSpeedMph !== null && effectiveSpeedMph < 3.0);
    const isAtParkedAnchor = displacementFromAnchor < 18.0;

    if (!isSimulatingGps && (inDwellWindow || isStationarySpeed || isAtParkedAnchor)) {
      consecutiveDepartCountRef.current = 0;
      return; // CRITICAL: Stop here! Vehicle is at the customer address. Keep customer displayed.
    }

    // =========================================================================
    // 2. ACTUAL DEPARTURE VERIFICATION:
    // Vehicle must have physically accelerated and driven away from the stop:
    // - Actively driving at road speed (>= 3.5 mph, or simulation actively driving)
    // - Moved at least 22 meters (~72 feet) away from the parked anchor point
    // - Distance from the customer's coordinates has expanded (>= minSeen + 12.0m, and >= 25.0m)
    // =========================================================================
    const isActivelyDriving = isSimulatingGps || (effectiveSpeedMph !== null && effectiveSpeedMph >= 5.0);
    const hasMovedPastAnchor = displacementFromAnchor >= 30.0;
    const isExpandingDistance = distFromServicedMeters >= minSeen + 20.0 && distFromServicedMeters >= 35.0;

    const isDeparting = isActivelyDriving && hasMovedPastAnchor && isExpandingDistance;

    if (isDeparting) {
      consecutiveDepartCountRef.current += 1;
      // Require 3 consecutive verified GPS updates (2 in simulation) of driving away
      // to ensure single GPS multipath jumps or drift never cause a premature display change
      const requiredConfirmations = isSimulatingGps ? 2 : 3;
      if (consecutiveDepartCountRef.current >= requiredConfirmations) {
        consecutiveDepartCountRef.current = 0;
        serviceParkedAnchorRef.current = null;
        lastLocForSpeedRef.current = null;

        const extraDiag = `Speed: ${effectiveSpeedMph?.toFixed(1) ?? 'N/A'}mph | DistServiced: ${Math.round(distFromServicedMeters)}m | MinSeen: ${Math.round(minSeen)}m | DisplAnchor: ${Math.round(displacementFromAnchor)}m | Accuracy: ±${userLocation.accuracy?.toFixed(1) ?? 'N/A'}m | Dwell: ${(timeSinceArrival / 1000).toFixed(1)}s`;
        changeDisplayedStop(currentNavIdx, 'gps_verified_departure', extraDiag);
      }
    } else {
      consecutiveDepartCountRef.current = 0;
    }
  }, [userLocation, routeData, displayedStopIndex, isSimulatingGps, changeDisplayedStop]);

  const isRouteFinished = Boolean(
    routeData && 
    routeData.currentIndex >= routeData.stops.length && 
    displayedStopIndex >= routeData.stops.length
  );

  const completedCount = routeData ? routeData.stops.filter((s) => s.status === 'completed').length : 0;
  const skippedCount = routeData ? routeData.stops.filter((s) => s.status === 'skipped').length : 0;

  return (
    <div 
      className={`h-dvh max-h-dvh w-full overflow-hidden flex flex-col font-sans transition-colors duration-150 ${
        isDark 
          ? 'bg-black text-white' 
          : 'bg-white text-black'
      }`}
    >
      {/* Hidden File Picker Input for Android File Picker */}
      <input
        ref={fileInputRef}
        type="file"
        onChange={handleDirectFileImport}
        className="hidden"
      />

      {/* Main Screen Container - Fitted mobile viewport starting flush from top */}
      <main className="flex-1 w-full max-w-md mx-auto flex flex-col px-2.5 pt-1 pb-1 sm:px-3 sm:py-1.5 relative overflow-hidden">
        {/* Auto-Arrival Banner (Confirms automatic arrival without requiring manual input) */}
        {arrivalToast && (
          <div className="absolute top-4 left-4 right-4 z-30 animate-in slide-in-from-top duration-200">
            <div className="bg-emerald-500 text-black px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2 border-2 border-emerald-300">
              <CheckCircle2 className="w-4 h-4 stroke-[3] shrink-0" />
              <span className="text-xs font-black truncate">
                {arrivalToast}
              </span>
            </div>
          </div>
        )}

        {/* Undo Toast when a customer was skipped */}
        {skipToast && (
          <div className="absolute top-4 left-4 right-4 z-30 animate-in slide-in-from-top duration-200">
            <div className="bg-amber-400 text-black px-4 py-2.5 rounded-2xl shadow-2xl flex items-center justify-between border-2 border-amber-300">
              <span className="text-xs font-bold truncate max-w-[240px]">
                {skipToast.message}
              </span>
              <button
                onClick={handleUndoSkip}
                className="flex items-center gap-1 px-2.5 py-1 bg-black text-amber-300 rounded-lg text-xs font-black uppercase tracking-wider hover:bg-neutral-900 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Undo</span>
              </button>
            </div>
          </div>
        )}

        {/* Case 1: Route finished / all customers visited and departed */}
        {isRouteFinished && routeData ? (
          <RouteCompletionView
            stops={routeData.stops}
            routeName={routeData.name}
            isDark={isDark}
            onRestart={handleResetProgress}
            onJumpToStop={handleJumpToStop}
            onLoadNewRoute={() => setIsImportOpen(true)}
          />
        ) : (currentStop || displayedStop) && routeData ? (
          /* Case 2: Active customer stop card with independent display state */
          <StopCard
            displayedCustomer={displayedStop || currentStop!}
            displayedIndex={displayedStopIndex}
            navStop={currentStop || undefined}
            navIndex={routeData.currentIndex}
            stop={displayedStop || currentStop!}
            currentIndex={displayedStopIndex}
            allStops={routeData.stops}
            onSelectStop={handleJumpToStop}
            previousStop={previousStop || undefined}
            nextStop={nextStop || undefined}
            userLocation={userLocation}
            gpsStatus={gpsStatus}
            gpsErrorMsg={gpsErrorMsg}
            distanceToCurrentFeet={distanceToCurrentFeet}
            isWithinGeofence={isWithinGeofence}
            isConfirmedArrival={isConfirmedArrival}
            isSharedLocationWithPrevious={isSharedLocationWithPrevious}
            isSharedLocationWithNext={isSharedLocationWithNext}
            autoArrivalStatus={autoArrivalStatus}
            totalStops={routeData.stops.length}
            completedCount={completedCount}
            skippedCount={skippedCount}
            settings={settings}
            onMarkPickedUp={handleMarkPickedUp}
            onSkip={handleSkipCustomer}
            onPrevious={handlePreviousCustomer}
            onJumpToStopList={() => setIsDrawerOpen(true)}
            arrivalRadiusMeters={arrivalRadiusMeters}
            arrivalConfirmFeet={arrivalConfirmFeet}
            isPassedWithoutCompletion={isPassedWithoutCompletion}
            simulateApproachAndPass={simulateApproachAndPass}
            simulateApproachAndArrive={simulateApproachAndArrive}
            simulateCurbsidePassThrough={simulateCurbsidePassThrough}
            isSimulatingGps={isSimulatingGps}
            isSimPaused={isSimPaused}
            simSpeedMultiplier={simSpeedMultiplier}
            startFullRouteSimulation={startFullRouteSimulation}
            pauseSimulation={pauseSimulation}
            resumeSimulation={resumeSimulation}
            setSimulationSpeed={setSimulationSpeed}
            restartSimulation={restartSimulation}
            stopGpsSimulation={stopGpsSimulation}
            onRouteCoordinatesUpdate={setRouteCoordinates}
            onRoadRemainingUpdate={setRoadRemainingMeters}
            diagLogs={diagLogs}
            onOpenSettings={() => setIsSettingsOpen(true)}
          />
        ) : (
          /* Case 3: No route loaded */
          <div className="flex-1 flex flex-col items-center justify-center text-center p-6 space-y-4 my-auto">
            <img 
              src="/icon-192.png" 
              alt="Garbage Route" 
              className="w-20 h-20 rounded-3xl border-2 border-emerald-400/80 shadow-2xl object-cover" 
            />
            <div>
              <h2 className="text-2xl font-black text-white">Garbage Route</h2>
              <p className="text-xs text-neutral-400 mt-1 max-w-xs">
                Import a customer GPX file from OsmAnd or pick a built-in delivery route to begin.
              </p>
            </div>
            <div className="space-y-2 w-full max-w-xs">
              <button
                onClick={() => setIsImportOpen(true)}
                className="w-full py-3.5 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-950/40"
              >
                <Upload className="w-4 h-4" />
                <span>Import GPX File</span>
              </button>
              <button
                onClick={() => {
                  const defaultPreset = SAMPLE_GPX_ROUTES[0];
                  const parsed = parseGPX(defaultPreset.gpxXml, defaultPreset.title);
                  handleImportSuccess(parsed.stops, parsed.routeName, `${defaultPreset.id}.gpx`);
                }}
                className="w-full py-3 px-4 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-200 font-bold text-xs flex items-center justify-center gap-2 transition-all"
              >
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Load Sample Route (20 Stops)</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Import Modal */}
      <GpxImportModal
        isOpen={isImportOpen}
        isDark={isDark}
        onClose={() => setIsImportOpen(false)}
        onImportSuccess={handleImportSuccess}
      />

      {/* Route List Drawer */}
      {routeData && (
        <RouteListDrawer
          isOpen={isDrawerOpen}
          isDark={isDark}
          stops={routeData.stops}
          currentIndex={routeData.currentIndex}
          routeName={routeData.name}
          onClose={() => setIsDrawerOpen(false)}
          onSelectStop={handleJumpToStop}
          onResetRoute={handleResetProgress}
        />
      )}

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        isDark={isDark}
        settings={settings}
        onClose={() => setIsSettingsOpen(false)}
        onUpdateSettings={(newSettings) => setSettings((s) => ({ ...s, ...newSettings }))}
        onOpenImport={() => setIsImportOpen(true)}
        onResetProgress={handleResetProgress}
        onClearRoute={handleClearRoute}
        onOpenExport={() => setIsExportOpen(true)}
      />

      {/* Export / APK Modal */}
      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        isDark={isDark}
      />
    </div>
  );
}
