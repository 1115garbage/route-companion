import { useState, useEffect, useRef, useCallback } from 'react';
import { RouteStop } from '../types/route';
import { calculateDistanceMeters, calculateBearing, calculateDistanceToPolylineMeters } from './navigationService';
import { triggerHaptic } from './voiceAndHaptics';
import { isSharedProperty } from './gpxParser';

export interface GpsLocation {
  lat: number;
  lon: number;
  accuracy: number;
  speed: number | null; // mph
  heading: number | null;
  timestamp: number;
}

export interface UseGpsTrackerReturn {
  location: GpsLocation | null;
  gpsStatus: 'acquiring' | 'locked' | 'denied';
  gpsErrorMsg: string | null;
  distanceToCurrentMeters: number | null;
  distanceToCurrentFeet: number | null;
  isWithinGeofence: boolean;
  isWithinArrivalConfirmZone: boolean;
  isConfirmedArrival: boolean;
  isSharedLocationWithPrevious: boolean;
  isSharedLocationWithNext: boolean;
  autoArrivalStatus: string;
  arrivalRadiusMeters: number;
  arrivalConfirmFeet: number;
  arrivalConfirmMeters: number;
  isPassedWithoutCompletion: boolean;
  arrivalHeading: number | null;
  // Full Route Simulation Engine
  isSimulatingGps: boolean;
  isSimPaused: boolean;
  simSpeedMultiplier: number;
  startFullRouteSimulation: (startStopIndex?: number, speedMultiplier?: number) => void;
  pauseSimulation: () => void;
  resumeSimulation: () => void;
  setSimulationSpeed: (multiplier: number) => void;
  restartSimulation: () => void;
  stopGpsSimulation: () => void;
  // Legacy simulation helpers
  simulateApproachAndPass: () => void;
  simulateApproachAndArrive: () => void;
  simulateCurbsidePassThrough: () => void;
  diagLogs: string[];
  addDiagLog: (msg: string) => void;
}

// Configurable constants and safeguards
export const DEFAULT_ARRIVAL_RADIUS_METERS = 75.0; // Broad approach/proximity window only
export const DEFAULT_ARRIVAL_CONFIRM_METERS = 30 * 0.3048; // Exact 30-foot arrival radius
const MAX_ACCURACY_THRESHOLD_METERS = 60.0; // Retain degraded fixes for multi-fix smoothing
const COOLDOWN_MS = 5000; // Minimum time between auto-advances (5 seconds)
const PASSING_DISTANCE_INCREASE_METERS = 18.0; // Distance must expand by 18m (~60ft) from closest point to confirm vehicle passed

/**
 * Validate latitude and longitude coordinates
 */
export function isValidCoordinate(lat: number, lon: number): boolean {
  return (
    !isNaN(lat) &&
    !isNaN(lon) &&
    lat >= -90 &&
    lat <= 90 &&
    lon >= -180 &&
    lon <= 180 &&
    !(lat === 0 && lon === 0)
  );
}

/**
 * Calculates whether the straight line path between two consecutive GPS fixes
 * passed within radiusMeters of destination coordinates.
 */
export function checkSegmentPassesPoint(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
  destLat: number,
  destLon: number,
  radiusMeters: number
): { passed: boolean; minDistance: number; t: number } {
  const latRad = (destLat * Math.PI) / 180;
  const cosLat = Math.cos(latRad);
  const mPerDegLat = 111132.92;
  const mPerDegLon = 111412.84 * cosLat;

  const x1 = (lon1 - destLon) * mPerDegLon;
  const y1 = (lat1 - destLat) * mPerDegLat;
  const x2 = (lon2 - destLon) * mPerDegLon;
  const y2 = (lat2 - destLat) * mPerDegLat;

  const dx = x2 - x1;
  const dy = y2 - y1;
  const lenSq = dx * dx + dy * dy;

  if (lenSq === 0) {
    const d = Math.sqrt(x1 * x1 + y1 * y1);
    return { passed: d <= radiusMeters, minDistance: d, t: 0 };
  }

  const t = -(x1 * dx + y1 * dy) / lenSq;

  if (t > 0 && t < 1) {
    const projX = x1 + t * dx;
    const projY = y1 + t * dy;
    const minDistance = Math.sqrt(projX * projX + projY * projY);
    return { passed: minDistance <= radiusMeters, minDistance, t };
  }

  const d1 = Math.sqrt(x1 * x1 + y1 * y1);
  const d2 = Math.sqrt(x2 * x2 + y2 * y2);
  const minDistance = Math.min(d1, d2);
  return { passed: minDistance <= radiusMeters, minDistance, t };
}

export function useGpsTracker(
  currentStop: RouteStop | null,
  previousStop: RouteStop | null,
  nextStop: RouteStop | null,
  onAutoAdvance: (stopId?: string, arrivalPos?: { lat: number; lon: number }) => void,
  arrivalRadiusMeters: number = DEFAULT_ARRIVAL_RADIUS_METERS,
  arrivalConfirmMeters: number = DEFAULT_ARRIVAL_CONFIRM_METERS,
  roadRemainingMeters?: number | null,
  routeCoordinates?: [number, number][],
  allStops?: RouteStop[],
  onJumpToStop?: (index: number) => void,
  onResetProgress?: () => void,
  onSimulationStart?: () => void,
  onExitSimulation?: () => void,
  onSharedPropertyDeparted?: () => void
): UseGpsTrackerReturn {
  const [location, setLocation] = useState<GpsLocation | null>(null);
  const [gpsStatus, setGpsStatus] = useState<'acquiring' | 'locked' | 'denied'>('acquiring');
  const [gpsErrorMsg, setGpsErrorMsg] = useState<string | null>(null);
  const [arrivalStateDesc, setArrivalStateDesc] = useState<string>('Monitoring GPS');
  const [isPassedWithoutCompletion, setIsPassedWithoutCompletion] = useState<boolean>(false);

  const [isConfirmedArrival, setIsConfirmedArrival] = useState<boolean>(false);
  const [arrivalHeading, setArrivalHeading] = useState<number | null>(null);
  const lastApproachHeadingRef = useRef<number | null>(null);

  // Full Route Simulation state
  const [isSimulatingGps, setIsSimulatingGps] = useState(false);
  const [isSimPaused, setIsSimPaused] = useState(false);
  const [simSpeedMultiplier, setSimSpeedMultiplier] = useState(1);
  const simIntervalRef = useRef<number | null>(null);
  const isSimulatingGpsRef = useRef(false);
  const isQuickSimulationRef = useRef(false);
  const isSimPausedRef = useRef(false);
  const simSpeedMultiplierRef = useRef(1);
  const simPolylineIdxRef = useRef(0);
  const simSegProgressRef = useRef(0);
  const isDwellRef = useRef(false);
  const dwellRemainingMsRef = useRef(0);
  const lastSimTickTimeRef = useRef(Date.now());
  const simLocationRef = useRef<GpsLocation | null>(null);
  const lastSimStopIdRef = useRef<string | null>(null);

  // Safeguard & Tracking Refs
  const minDistanceSeenRef = useRef<number>(Infinity); // Legacy missed-stop tracking; preserved for turnaround behavior
  const minConfirmedArrivalDistanceRef = useRef<number>(Infinity);
  const recentArrivalFixesRef = useRef<GpsLocation[]>([]);
  const passAwayCountRef = useRef<number>(0);
  const confirmedInsideCountRef = useRef<number>(0);
  const firstInsideTimestampRef = useRef<number>(0);
  const enteredArrivalZoneRef = useRef<boolean>(false);
  const consecutiveInsideCountRef = useRef<number>(0);
  const consecutiveCloseCountRef = useRef<number>(0);
  const consecutivePassCountRef = useRef<number>(0);
  const consecutiveMissedCountRef = useRef<number>(0);
  const lastLocationRef = useRef<GpsLocation | null>(null);
  const lastDistanceRef = useRef<number | null>(null);
  const lastAdvanceTimestampRef = useRef<number>(0);
  const lastAdvancedStopIdRef = useRef<string | null>(null);
  const isAdvancingRef = useRef<boolean>(false);
  const departurePendingRef = useRef<boolean>(false);
  const activeStopIdRef = useRef<string | null>(null);
  const advancedStopIdsSetRef = useRef<Set<string>>(new Set());

  // Test Drive Diagnostic Logs
  const [diagLogs, setDiagLogs] = useState<string[]>([]);
  const addDiagLog = useCallback((msg: string) => {
    const time = new Date().toLocaleTimeString();
    const entry = `[${time}] ${msg}`;
    console.log(`[TestDriveDiag] ${entry}`);
    setDiagLogs((prev) => [entry, ...prev.slice(0, 49)]);
  }, []);

  // Keep stable refs to latest props to prevent watchPosition re-binding
  const currentStopRef = useRef(currentStop);
  currentStopRef.current = currentStop;

  const previousStopRef = useRef(previousStop);
  previousStopRef.current = previousStop;

  const nextStopRef = useRef(nextStop);
  nextStopRef.current = nextStop;

  const onAutoAdvanceRef = useRef(onAutoAdvance);
  onAutoAdvanceRef.current = onAutoAdvance;

  const arrivalRadiusRef = useRef(arrivalRadiusMeters);
  arrivalRadiusRef.current = arrivalRadiusMeters;

  const arrivalConfirmMetersRef = useRef(arrivalConfirmMeters);
  arrivalConfirmMetersRef.current = arrivalConfirmMeters;

  const roadRemainingMetersRef = useRef(roadRemainingMeters);
  roadRemainingMetersRef.current = roadRemainingMeters;

  const routeCoordinatesRef = useRef(routeCoordinates);
  const isAwaitingNewRouteRef = useRef(false);
  const routeWaitStartTimeRef = useRef(0);

  useEffect(() => {
    routeCoordinatesRef.current = routeCoordinates;
    if (routeCoordinates && routeCoordinates.length >= 2) {
      isAwaitingNewRouteRef.current = false;
      simPolylineIdxRef.current = 0;
      simSegProgressRef.current = 0;
    }
  }, [routeCoordinates]);

  const allStopsRef = useRef(allStops);
  allStopsRef.current = allStops;

  const onJumpToStopRef = useRef(onJumpToStop);
  onJumpToStopRef.current = onJumpToStop;

  const onResetProgressRef = useRef(onResetProgress);
  onResetProgressRef.current = onResetProgress;

  const onSimulationStartRef = useRef(onSimulationStart);
  onSimulationStartRef.current = onSimulationStart;

  const onExitSimulationRef = useRef(onExitSimulation);
  onExitSimulationRef.current = onExitSimulation;

  const onSharedPropertyDepartedRef = useRef(onSharedPropertyDeparted);
  onSharedPropertyDepartedRef.current = onSharedPropertyDeparted;

  // Shared property check using strict multi-tier property matcher
  const isSharedLocationWithPrevious = Boolean(
    currentStop && previousStop && isSharedProperty(previousStop, currentStop)
  );

  const isSharedLocationWithNext = Boolean(
    currentStop && nextStop && isSharedProperty(currentStop, nextStop)
  );

  const isSharedLocationWithPreviousRef = useRef(isSharedLocationWithPrevious);
  isSharedLocationWithPreviousRef.current = isSharedLocationWithPrevious;

  // Shared-property departure tracking refs
  const hasDepartedSharedPropertyRef = useRef<boolean>(false);
  const consecutiveSharedDepartCountRef = useRef<number>(0);
  const lastSharedDepartDistRef = useRef<number | null>(null);
  const sharedPropertyAnchorRef = useRef<{ lat: number; lon: number } | null>(null);
  const arrivalIndicationTokenRef = useRef<number>(0);

  // Reset tracking state whenever the active customer changes
  useEffect(() => {
    const newStopId = currentStop?.id || null;
    if (newStopId !== activeStopIdRef.current) {
      activeStopIdRef.current = newStopId;
      minDistanceSeenRef.current = Infinity;
      minConfirmedArrivalDistanceRef.current = Infinity;
      recentArrivalFixesRef.current = [];
      passAwayCountRef.current = 0;
      confirmedInsideCountRef.current = 0;
      firstInsideTimestampRef.current = 0;
      enteredArrivalZoneRef.current = false;
      consecutiveInsideCountRef.current = 0;
      consecutiveCloseCountRef.current = 0;
      consecutivePassCountRef.current = 0;
      consecutiveMissedCountRef.current = 0;
      lastDistanceRef.current = null;
      lastLocationRef.current = null;
      isAdvancingRef.current = false;
      setIsPassedWithoutCompletion(false);

      // Reset shared-property departure state on stop transition
      hasDepartedSharedPropertyRef.current = false;
      consecutiveSharedDepartCountRef.current = 0;
      lastSharedDepartDistRef.current = null;

      // Handle multiple customers at the same property (e.g. Stop 22 & Stop 23):
      // The driver is already physically at this property from previous delivery!
      if (isSharedLocationWithPreviousRef.current) {
        if (previousStopRef.current && isValidCoordinate(previousStopRef.current.lat, previousStopRef.current.lon)) {
          sharedPropertyAnchorRef.current = { lat: previousStopRef.current.lat, lon: previousStopRef.current.lon };
        } else if (currentStop && isValidCoordinate(currentStop.lat, currentStop.lon)) {
          sharedPropertyAnchorRef.current = { lat: currentStop.lat, lon: currentStop.lon };
        }
        departurePendingRef.current = false;
        arrivalIndicationTokenRef.current += 1;
        setIsConfirmedArrival(true);
        setArrivalStateDesc(`At property · Shared Address: ${currentStop?.name || 'Customer'}`);
        return;
      }

      sharedPropertyAnchorRef.current = null;
      setIsConfirmedArrival(false);

      // If driver is currently inside the departure zone of the PREVIOUS stop at activation (and not a shared address),
      // track departure from previous stop to prevent immediate re-trigger.
      if (
        location &&
        previousStopRef.current &&
        isValidCoordinate(previousStopRef.current.lat, previousStopRef.current.lon)
      ) {
        const d = calculateDistanceMeters(location.lat, location.lon, previousStopRef.current.lat, previousStopRef.current.lon);
        departurePendingRef.current = d <= 35.0;
      } else {
        departurePendingRef.current = false;
      }
    }
  }, [currentStop?.id]);

  /**
   * Core Arrival & Missed Stop Decision Engine
   * Evaluates current GPS location against verified coordinates of currentStop.
   * Separates 500-foot proximity window from confirmed arrival at the customer address.
   */
  const processLocationUpdate = useCallback((currentLoc: GpsLocation) => {
    const activeStop = currentStopRef.current;
    if (!activeStop) {
      setArrivalStateDesc('No Active Route');
      return;
    }

    // 1. Verify Destination Coordinates
    if (!isValidCoordinate(activeStop.lat, activeStop.lon)) {
      setArrivalStateDesc('Invalid Destination Coordinates (Manual Skip)');
      return;
    }

    // 2. Reject stale updates (> 4.5s old)
    if (Date.now() - currentLoc.timestamp > 4500) {
      return;
    }

    // 3. Ignore only extremely poor fixes. Moderately degraded fixes remain available
    // for short-history smoothing, avoiding indefinite waits for a perfect GPS fix.
    if (currentLoc.accuracy > MAX_ACCURACY_THRESHOLD_METERS) {
      setArrivalStateDesc(`GPS signal weak · tracking continues (±${Math.round(currentLoc.accuracy * 3.28084)} ft)`);
      lastLocationRef.current = currentLoc;
      lastDistanceRef.current = calculateDistanceMeters(currentLoc.lat, currentLoc.lon, activeStop.lat, activeStop.lon);
      return;
    }

    const proximityRadius = arrivalRadiusRef.current || DEFAULT_ARRIVAL_RADIUS_METERS;
    const baseConfirmRadius = arrivalConfirmMetersRef.current || DEFAULT_ARRIVAL_CONFIRM_METERS;
    const rawDistanceToDestination = calculateDistanceMeters(
      currentLoc.lat,
      currentLoc.lon,
      activeStop.lat,
      activeStop.lon
    );
    const feetToDestination = Math.round(rawDistanceToDestination * 3.28084);

    // Preserve the original raw-distance tracking used by missed-stop/turnaround logic.
    const distToDestination = rawDistanceToDestination;
    const prevLoc = lastLocationRef.current;
    const prevDist = lastDistanceRef.current;
    const now = Date.now();
    if (currentLoc.accuracy <= 30.0) {
      if (distToDestination < minDistanceSeenRef.current) minDistanceSeenRef.current = distToDestination;
      if (prevLoc && isValidCoordinate(prevLoc.lat, prevLoc.lon)) {
        const displacement = calculateDistanceMeters(prevLoc.lat, prevLoc.lon, currentLoc.lat, currentLoc.lon);
        if (displacement < 120.0) {
          const segCheck = checkSegmentPassesPoint(prevLoc.lat, prevLoc.lon, currentLoc.lat, currentLoc.lon,
            activeStop.lat, activeStop.lon, baseConfirmRadius);
          if (segCheck.minDistance < minDistanceSeenRef.current) minDistanceSeenRef.current = segCheck.minDistance;
        }
      }
    }

    // A separate median-filtered history is used only for arrival authorization.
    const history = recentArrivalFixesRef.current;
    history.push(currentLoc);
    while (history.length > 5) history.shift();
    const recent = history.slice(-3);
    const median = (values: number[]) => {
      const sorted = [...values].sort((a, b) => a - b);
      return sorted[Math.floor(sorted.length / 2)];
    };
    const smoothedLat = recent.length >= 3 ? median(recent.map((f) => f.lat)) : currentLoc.lat;
    const smoothedLon = recent.length >= 3 ? median(recent.map((f) => f.lon)) : currentLoc.lon;
    const smoothedDistanceToDestination = calculateDistanceMeters(
      smoothedLat, smoothedLon, activeStop.lat, activeStop.lon
    );
    const smoothedFeetToDestination = Math.round(smoothedDistanceToDestination * 3.28084);
    if (recent.length >= 3 && recent[recent.length - 1].timestamp - recent[0].timestamp >= 1000 &&
        smoothedDistanceToDestination < minConfirmedArrivalDistanceRef.current) {
      minConfirmedArrivalDistanceRef.current = smoothedDistanceToDestination;
    }

    // 4. Prevent immediate cascade / double advance
    if (isAdvancingRef.current) return;
    if (now - lastAdvanceTimestampRef.current < COOLDOWN_MS) return;
    if (lastAdvancedStopIdRef.current === activeStop.id) return;

    // 5. Shared Location Handling (Multi-unit building or shared entrance e.g. Stop 22 & Stop 23)
    if (isSharedLocationWithPreviousRef.current && !hasDepartedSharedPropertyRef.current) {
      const anchor = sharedPropertyAnchorRef.current || (previousStopRef.current && isValidCoordinate(previousStopRef.current.lat, previousStopRef.current.lon) ? previousStopRef.current : (activeStop && isValidCoordinate(activeStop.lat, activeStop.lon) ? activeStop : null));

      if (anchor && isValidCoordinate(anchor.lat, anchor.lon)) {
        const distFromAnchor = calculateDistanceMeters(currentLoc.lat, currentLoc.lon, anchor.lat, anchor.lon);
        const displacement = (prevLoc && isValidCoordinate(prevLoc.lat, prevLoc.lon))
          ? calculateDistanceMeters(prevLoc.lat, prevLoc.lon, currentLoc.lat, currentLoc.lon)
          : null;
        const timeDelta = prevLoc ? Math.max(0.4, (currentLoc.timestamp - prevLoc.timestamp) / 1000) : 1.0;
        const compSpeed = displacement !== null ? (displacement / timeDelta) * 2.23694 : null;
        const effSpeed = currentLoc.speed !== null ? currentLoc.speed : compSpeed;

        const lastDepartDist = lastSharedDepartDistRef.current;
        const isQualifyingFix =
          currentLoc.accuracy <= 25.0 &&
          distFromAnchor > 25.0 &&
          effSpeed !== null && effSpeed >= 4.0 &&
          displacement !== null && displacement >= 1.5 &&
          (lastDepartDist === null || distFromAnchor >= lastDepartDist + 0.8);

        if (isQualifyingFix) {
          consecutiveSharedDepartCountRef.current += 1;
          lastSharedDepartDistRef.current = distFromAnchor;

          if (consecutiveSharedDepartCountRef.current >= 2) {
            // CONFIRMED DEPARTURE FROM SHARED PROPERTY!
            hasDepartedSharedPropertyRef.current = true;
            departurePendingRef.current = false;
            setIsConfirmedArrival(false);
            consecutiveCloseCountRef.current = 0;
            consecutivePassCountRef.current = 0;
            consecutiveMissedCountRef.current = 0;
            minDistanceSeenRef.current = Infinity;
            lastApproachHeadingRef.current = null;
            consecutiveSharedDepartCountRef.current = 0;
            lastSharedDepartDistRef.current = null;

            onSharedPropertyDepartedRef.current?.();
            // Continue past this block into ordinary GPS navigation flow!
          } else {
            // Awaiting second consecutive qualifying fix
            lastLocationRef.current = currentLoc;
            lastDistanceRef.current = distToDestination;
            return;
          }
        } else {
          // Reset departure sequence if any qualification check fails
          consecutiveSharedDepartCountRef.current = 0;
          lastSharedDepartDistRef.current = null;
        }
      }

      if (!hasDepartedSharedPropertyRef.current) {
        departurePendingRef.current = false;
        setIsConfirmedArrival(true);
        setArrivalStateDesc(`At property · ${activeStop.name}`);
        lastLocationRef.current = currentLoc;
        lastDistanceRef.current = distToDestination;
        minDistanceSeenRef.current = distToDestination;
        consecutiveMissedCountRef.current = 0;
        consecutiveCloseCountRef.current = 0;
        consecutivePassCountRef.current = 0;
        return;
      }
    }

    // Calculate inter-fix displacement and effective speed (in mph)
    const displacementMeters = (prevLoc && isValidCoordinate(prevLoc.lat, prevLoc.lon))
      ? calculateDistanceMeters(prevLoc.lat, prevLoc.lon, currentLoc.lat, currentLoc.lon)
      : null;
    const timeDeltaSec = prevLoc ? Math.max(0.4, (currentLoc.timestamp - prevLoc.timestamp) / 1000) : 1.0;
    const computedSpeedMph = displacementMeters !== null ? (displacementMeters / timeDeltaSec) * 2.23694 : null;
    const effectiveSpeedMph = currentLoc.speed !== null ? currentLoc.speed : computedSpeedMph;
    const isStationaryOrCrawl = effectiveSpeedMph === null || effectiveSpeedMph <= 15.0;

    // Track vehicle approach heading during active driving movement
    if (effectiveSpeedMph !== null && effectiveSpeedMph >= 3.0) {
      if (currentLoc.heading !== null) {
        lastApproachHeadingRef.current = currentLoc.heading;
      } else if (prevLoc && isValidCoordinate(prevLoc.lat, prevLoc.lon) && displacementMeters !== null && displacementMeters > 3.0) {
        lastApproachHeadingRef.current = calculateBearing(prevLoc.lat, prevLoc.lon, currentLoc.lat, currentLoc.lon);
      }
    }

    // 6. Departure Latch (if activated while already near previous stop)
    if (departurePendingRef.current) {
      const prevStop = previousStopRef.current;
      if (prevStop && isValidCoordinate(prevStop.lat, prevStop.lon)) {
        const distFromPrev = calculateDistanceMeters(currentLoc.lat, currentLoc.lon, prevStop.lat, prevStop.lon);
        // Vehicle is departing previous stop ONLY when it has driven away from it (> 28m away AND moving at driving speed)
        const isDrivingAway = distFromPrev > 28.0 && (effectiveSpeedMph === null || effectiveSpeedMph >= 3.0 || isSimulatingGpsRef.current);
        if (isDrivingAway) {
          departurePendingRef.current = false;
        } else {
          setArrivalStateDesc(`At previous stop · Departing...`);
          return;
        }
      } else {
        departurePendingRef.current = false;
      }
    }

    // 7. Parallel Road Rejection (Avoid triggering arrival when driving on an adjacent parallel road)
    const roadDist = roadRemainingMetersRef.current;
    if (roadDist !== undefined && roadDist !== null && roadDist > Math.max(proximityRadius * 2.0, 150)) {
      setArrivalStateDesc(`Parallel Road / Route Distance ${Math.round(roadDist * 3.28084)} ft`);
      return;
    }

    if (routeCoordinatesRef.current && routeCoordinatesRef.current.length > 1) {
      const distToPolyline = calculateDistanceToPolylineMeters(currentLoc.lat, currentLoc.lon, routeCoordinatesRef.current);
      // If vehicle has drifted > 38m (~125 ft) from delivery street polyline while distToDestination > 35m:
      if (distToPolyline > 38.0 && distToDestination > 35.0) {
        setArrivalStateDesc(`Parallel Road · ${feetToDestination} ft to customer`);
        return;
      }
    }

    // HYBRID ARRIVAL CONFIRMATION
    // The user-selected confirmation radius (30 ft default) is applied here.
    // A median of three consecutive fixes smooths ordinary GPS jitter. Stopping
    // and rolling past are both supported; heading and speed do not independently decide arrival.
    const confirmRadius = Math.max(5, baseConfirmRadius);
    // Keep the legacy confirmation boundary for missed-stop/turnaround decisions unchanged.
    const effectiveConfirmZone = 75.0 + Math.min(Math.max(0, (currentLoc.accuracy || 5) - 5), 8.0); // Preserve legacy missed-stop/turnaround boundary
    const isInsideConfirmZone = distToDestination <= effectiveConfirmZone;
    const isInsideArrivalRadius = smoothedDistanceToDestination <= confirmRadius;
    const isInsideProximity = distToDestination <= proximityRadius;
    const isMovingAway = prevDist !== null && distToDestination > prevDist + 1.2;

    let isReliablyArrived = false;
    let arrivalReason = '';
    const enoughHistory = recent.length >= 3 &&
      (recent[recent.length - 1].timestamp - recent[0].timestamp) >= 1000;

    if (isInsideArrivalRadius && enoughHistory) {
      confirmedInsideCountRef.current += 1;
      if (!firstInsideTimestampRef.current) firstInsideTimestampRef.current = currentLoc.timestamp;
      if (confirmedInsideCountRef.current >= 2 &&
          currentLoc.timestamp - firstInsideTimestampRef.current >= 1000) {
        isReliablyArrived = true;
        arrivalReason = `Confirmed at customer (${smoothedFeetToDestination} ft, GPS history)`;
      } else {
        setArrivalStateDesc(`Near customer (${smoothedFeetToDestination} ft) · confirming GPS history`);
      }
    } else if (isInsideArrivalRadius) {
      setArrivalStateDesc(`Near customer (${smoothedFeetToDestination} ft) · collecting GPS readings`);
      confirmedInsideCountRef.current = 0;
    } else {
      confirmedInsideCountRef.current = 0;
      firstInsideTimestampRef.current = 0;
    }

    // Rolling pass: establish a close approach from smoothed fixes, then require
    // two outward fixes. No heading assumption, so either travel direction works.
    if (!isReliablyArrived && enoughHistory && minConfirmedArrivalDistanceRef.current <= confirmRadius) {
      const movedAwayFromClosest = smoothedDistanceToDestination >= minConfirmedArrivalDistanceRef.current + 4.0;
      if (movedAwayFromClosest && isMovingAway) {
        passAwayCountRef.current += 1;
        if (passAwayCountRef.current >= 2) {
          isReliablyArrived = true;
          arrivalReason = `Passed customer after close approach (${Math.round(minConfirmedArrivalDistanceRef.current * 3.28084)} ft closest)`;
        }
      } else {
        passAwayCountRef.current = 0;
      }
    } else {
      passAwayCountRef.current = 0;
    }

    // Hard distance guard: no distant turn or noisy GPS jump can complete a stop.
    if (isReliablyArrived && smoothedDistanceToDestination > confirmRadius + 8.0) {
      isReliablyArrived = false;
      confirmedInsideCountRef.current = 0;
      passAwayCountRef.current = 0;
    }

    if (!isReliablyArrived && isInsideProximity && !isInsideArrivalRadius) {
      setArrivalStateDesc(`Approaching customer: ${smoothedFeetToDestination} ft`);
      consecutiveMissedCountRef.current = 0;
    }

    // Case 4: Genuinely Missed Destination
    // Strict multi-condition check to prevent false turnaround triggers:
    // 1) Vehicle NEVER reached inside confirmation zone (minDistanceSeenRef.current > effectiveConfirmZone)
    // 2) Vehicle was within proximity window (minDistanceSeenRef.current <= proximityRadius)
    // 3) Vehicle is now completely outside proximity window (distToDestination > proximityRadius * 1.15)
    // 4) Distance has expanded substantially from closest approach (> 65m / 215+ ft expansion)
    // 5) Vehicle is moving at road cruising speed (> 15 mph) heading away from customer
    // 6) Inconclusive evidence -> continue tracking, NEVER declare missed prematurely!
    if (currentLoc.accuracy <= 30.0 && !isReliablyArrived && !isInsideConfirmZone && minDistanceSeenRef.current <= proximityRadius && minDistanceSeenRef.current > effectiveConfirmZone) {
      const isOutsideProximity = distToDestination > proximityRadius * 1.15;
      const isExpandingSignificantly = distToDestination >= minDistanceSeenRef.current + 65.0;
      const isCruisingSpeed = effectiveSpeedMph !== null && effectiveSpeedMph > 15.0;

      const bearingToDest = calculateBearing(currentLoc.lat, currentLoc.lon, activeStop.lat, activeStop.lon);
      let headingPointsAway = false;
      if (currentLoc.heading !== null) {
        const diff = Math.abs(currentLoc.heading - bearingToDest);
        const normalizedDiff = diff > 180 ? 360 - diff : diff;
        headingPointsAway = normalizedDiff > 75;
      } else if (prevDist !== null) {
        headingPointsAway = distToDestination > prevDist + 2.0;
      }

      if (isOutsideProximity && isExpandingSignificantly && isCruisingSpeed && (isMovingAway || headingPointsAway)) {
        consecutiveMissedCountRef.current += 1;
        if (consecutiveMissedCountRef.current >= 5) {
          setIsPassedWithoutCompletion(true);
          setArrivalStateDesc(`Missed stop (${feetToDestination} ft) · Recalculating...`);
          lastLocationRef.current = currentLoc;
          lastDistanceRef.current = distToDestination;
          return;
        }
      } else {
        consecutiveMissedCountRef.current = 0;
      }
    } else {
      consecutiveMissedCountRef.current = 0;
    }

    // ========================================================
    // EXECUTE CONFIRMED ARRIVAL
    // ========================================================
    if (isReliablyArrived) {
      if (isSimulatingGpsRef.current && !isQuickSimulationRef.current) {
        // Full-route simulation owns its dwell sequence. Quick Test Drive cases
        // use the same confirmed-arrival callback as live GPS driving.
        return;
      }
      if (advancedStopIdsSetRef.current.has(activeStop.id)) {
        return;
      }
      advancedStopIdsSetRef.current.add(activeStop.id);
      addDiagLog(`Live GPS Arrival: Stop ${activeStop.id} arrived via ${arrivalReason}`);
      isAdvancingRef.current = true;
      lastAdvanceTimestampRef.current = now;
      lastAdvancedStopIdRef.current = activeStop.id;
      consecutiveCloseCountRef.current = 0;
      consecutivePassCountRef.current = 0;
      minDistanceSeenRef.current = Infinity;
      minConfirmedArrivalDistanceRef.current = Infinity;
      recentArrivalFixesRef.current = [];
      passAwayCountRef.current = 0;
      confirmedInsideCountRef.current = 0;
      firstInsideTimestampRef.current = 0;
      setIsPassedWithoutCompletion(false);
      const lockedHeading = currentLoc.heading ?? lastApproachHeadingRef.current;
      setArrivalHeading(lockedHeading);
      const currentToken = ++arrivalIndicationTokenRef.current;
      setIsConfirmedArrival(true);
      departurePendingRef.current = true;

      setArrivalStateDesc(`Arrived: ${arrivalReason}`);
      triggerHaptic('complete');
      onAutoAdvanceRef.current(activeStop.id, { lat: currentLoc.lat, lon: currentLoc.lon });

      setTimeout(() => {
        if (arrivalIndicationTokenRef.current === currentToken) {
          setIsConfirmedArrival(false);
        }
      }, 3000);
      return;
    }

    // General navigation tracking outside 500ft window
    if (distToDestination > proximityRadius) {
      setArrivalStateDesc(`${feetToDestination} ft to customer (Window: ${Math.round(proximityRadius * 3.28084)} ft)`);
    }

    lastLocationRef.current = currentLoc;
    lastDistanceRef.current = distToDestination;
  }, []);

  // Mount native Android GPS watcher
  useEffect(() => {
    if (typeof window === 'undefined' || !('geolocation' in navigator)) {
      setGpsStatus('denied');
      setGpsErrorMsg('GPS hardware not supported by this browser.');
      return;
    }

    setGpsStatus('acquiring');

    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        if (isSimulatingGpsRef.current) return;

        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;
        const accuracy = pos.coords.accuracy || 8;
        const speed = pos.coords.speed !== null && pos.coords.speed >= 0
          ? Math.round(pos.coords.speed * 2.23694)
          : null;
        const heading = pos.coords.heading !== null && !isNaN(pos.coords.heading)
          ? pos.coords.heading
          : null;

        const currentLoc: GpsLocation = {
          lat,
          lon,
          accuracy,
          speed,
          heading,
          timestamp: pos.timestamp || Date.now(),
        };

        setLocation(currentLoc);
        setGpsStatus('locked');
        setGpsErrorMsg(null);

        processLocationUpdate(currentLoc);
      },
      (err) => {
        if (isSimulatingGpsRef.current) return;
        setGpsStatus('denied');
        setGpsErrorMsg(err.message || 'GPS hardware access denied.');
      },
      {
        enableHighAccuracy: true,
        maximumAge: 1000,
        timeout: 10000,
      }
    );

    return () => {
      try {
        navigator.geolocation.clearWatch(watchId);
      } catch (e) {}
    };
  }, [processLocationUpdate, isSimulatingGps]);

  // Clean up any running simulation on unmount
  useEffect(() => {
    return () => {
      if (simIntervalRef.current) {
        window.clearInterval(simIntervalRef.current);
      }
    };
  }, []);

  /**
   * Continuous Full Route Simulation Engine
   * Smoothly navigates the actual road polyline from stop to stop,
   * modulates speed (cruise vs curbside), tests turnarounds, dwells at customers,
   * and auto-advances until the complete delivery route is finished.
   */
  const tickSimulation = useCallback(() => {
    if (!isSimulatingGpsRef.current) return;

    const now = Date.now();
    const dt = Math.min(0.25, Math.max(0.04, (now - lastSimTickTimeRef.current) / 1000));
    lastSimTickTimeRef.current = now;

    if (isSimPausedRef.current) {
      return;
    }

    const activeStop = currentStopRef.current;
    if (!activeStop || !isValidCoordinate(activeStop.lat, activeStop.lon)) {
      if (simIntervalRef.current) {
        window.clearInterval(simIntervalRef.current);
        simIntervalRef.current = null;
      }
      setIsSimulatingGps(false);
      isSimulatingGpsRef.current = false;
      setArrivalStateDesc('Full Route Simulation Completed!');
      return;
    }

    // Detect customer stop transition
    if (activeStop.id !== lastSimStopIdRef.current) {
      lastSimStopIdRef.current = activeStop.id;
      isDwellRef.current = false;
      dwellRemainingMsRef.current = 0;
      isAwaitingNewRouteRef.current = true;
      routeWaitStartTimeRef.current = now;
      routeCoordinatesRef.current = [];
      simPolylineIdxRef.current = 0;
      simSegProgressRef.current = 0;
      setIsConfirmedArrival(false);
      setIsPassedWithoutCompletion(false);

      // Multi-unit property with identical coordinates (e.g. 6633 Laraway Rd Apt A & Apt B)
      if (isSharedLocationWithPreviousRef.current) {
        isAwaitingNewRouteRef.current = false;
        isDwellRef.current = true;
        dwellRemainingMsRef.current = 2400;
        const sharedLoc: GpsLocation = {
          lat: activeStop.lat,
          lon: activeStop.lon,
          accuracy: 2.5,
          speed: 0,
          heading: simLocationRef.current?.heading || 0,
          timestamp: now,
        };
        simLocationRef.current = sharedLoc;
        setLocation(sharedLoc);
        processLocationUpdate(sharedLoc);
        return;
      }
    }

    // Stop Dwell phase (vehicle pulled over at customer address)
    if (isDwellRef.current) {
      dwellRemainingMsRef.current -= (dt * 1000) * simSpeedMultiplierRef.current;

      if (dwellRemainingMsRef.current <= 0) {
        isDwellRef.current = false;

        // Check if this was the last stop on the route
        if (allStopsRef.current && allStopsRef.current.length > 0) {
          const currentIdx = allStopsRef.current.findIndex((s) => s.id === activeStop.id);
          if (currentIdx !== -1 && currentIdx >= allStopsRef.current.length - 1) {
            // Reached final customer of route
            if (simIntervalRef.current) {
              window.clearInterval(simIntervalRef.current);
              simIntervalRef.current = null;
            }
            setIsSimulatingGps(false);
            isSimulatingGpsRef.current = false;
            setArrivalStateDesc('Full Route Simulation Completed!');
            return;
          }
        }

        // Auto-advance to the next customer stop (strictly once per stop!)
        if (!advancedStopIdsSetRef.current.has(activeStop.id)) {
          advancedStopIdsSetRef.current.add(activeStop.id);
          addDiagLog(`Sim Arrival: Stop ${activeStop.id} dwell completed -> advancing`);
          onAutoAdvanceRef.current(activeStop.id, simLocationRef.current ? { lat: simLocationRef.current.lat, lon: simLocationRef.current.lon } : undefined);
        }
      } else {
        // Emit 0 mph stopped location at customer
        if (simLocationRef.current) {
          const stoppedLoc: GpsLocation = {
            ...simLocationRef.current,
            speed: 0,
            timestamp: now,
          };
          setLocation(stoppedLoc);
          processLocationUpdate(stoppedLoc);
        }
      }
      return;
    }

    // Awaiting new route calculation from the vehicle's current position to the new stop
    if (isAwaitingNewRouteRef.current) {
      if (now - routeWaitStartTimeRef.current > 3500) {
        // Fallback safeguard if routing takes longer than 3.5s
        isAwaitingNewRouteRef.current = false;
      } else {
        if (simLocationRef.current) {
          const waitingLoc: GpsLocation = {
            ...simLocationRef.current,
            speed: 0,
            timestamp: now,
          };
          setLocation(waitingLoc);
          processLocationUpdate(waitingLoc);
        }
        return;
      }
    }

    // Active Driving phase along real road polyline
    const poly = routeCoordinatesRef.current;
    let curLat: number;
    let curLon: number;
    let curHeading = simLocationRef.current?.heading || 0;

    if (poly && poly.length >= 2) {
      let pIdx = simPolylineIdxRef.current;

      // Reached destination endpoint
      if (pIdx >= poly.length - 1) {
        const [destLon, destLat] = poly[poly.length - 1];
        curLat = destLat;
        curLon = destLon;
        const [prevLon, prevLat] = poly[Math.max(0, poly.length - 2)];
        curHeading = calculateBearing(prevLat, prevLon, curLat, curLon);

        const distToEndToDest = calculateDistanceMeters(curLat, curLon, activeStop.lat, activeStop.lon);
        const baseConfirmRadius = arrivalConfirmMetersRef.current || DEFAULT_ARRIVAL_CONFIRM_METERS;
        const effectiveConfirmZone = baseConfirmRadius;

        // ONLY initiate arrival if vehicle has reached within arrival confirmation zone of customer coordinates!
        // Completing a maneuver, passing an intersection, or reaching an intermediate polyline end must NEVER count as arrival if still miles/hundreds of feet away!
        const simulationApproachLimit = Math.max(effectiveConfirmZone, arrivalRadiusRef.current || DEFAULT_ARRIVAL_RADIUS_METERS);
        if (distToEndToDest <= simulationApproachLimit) {
          // Test Drive represents the final curbside leg to the mapped customer pin.
          // Snap the simulated vehicle to the pin, then use the normal arrival callback.
          const arrivedLoc: GpsLocation = {
            lat: activeStop.lat,
            lon: activeStop.lon,
            accuracy: 2.5,
            speed: 0,
            heading: curHeading,
            timestamp: now,
          };
          simLocationRef.current = arrivedLoc;
          setLocation(arrivedLoc);
          processLocationUpdate(arrivedLoc);

          // Advance active navigation stop immediately on arrival so background routing begins,
          // while middle display continues holding the arrived customer during dwell!
          const lockedHeading = curHeading ?? lastApproachHeadingRef.current;
          setArrivalHeading(lockedHeading);
          setIsConfirmedArrival(true);
          if (!advancedStopIdsSetRef.current.has(activeStop.id)) {
            advancedStopIdsSetRef.current.add(activeStop.id);
            addDiagLog(`Sim Arrival: Stop ${activeStop.id} reached destination -> auto-advancing nav (Heading: ${lockedHeading?.toFixed(0) ?? 'none'}°)`);
            onAutoAdvanceRef.current(activeStop.id, arrivedLoc ? { lat: arrivedLoc.lat, lon: arrivedLoc.lon } : undefined);
          }

          // Initiate arrival dwell
          isDwellRef.current = true;
          dwellRemainingMsRef.current = 2200;
          return;
        } else {
          // Intermediate route end reached while still away from customer (e.g. turnaround point or partial route):
          // Keep vehicle holding along current road, do NOT declare arrival or auto-advance!
          const intermediateLoc: GpsLocation = {
            lat: curLat,
            lon: curLon,
            accuracy: 2.5,
            speed: 0,
            heading: curHeading,
            timestamp: now,
          };
          simLocationRef.current = intermediateLoc;
          setLocation(intermediateLoc);
          processLocationUpdate(intermediateLoc);
          return;
        }
      }

      // Calculate target driving speed:
      // 32 mph cruise along road, slowing to 18 mph / 11 mph approaching customer curbside
      const [ptLon, ptLat] = poly[pIdx];
      const distToDest = calculateDistanceMeters(ptLat, ptLon, activeStop.lat, activeStop.lon);
      let targetSpeedMph = 32;
      if (distToDest < 35) {
        targetSpeedMph = 11;
      } else if (distToDest < 85) {
        targetSpeedMph = 18;
      }

      const speedMps = (targetSpeedMph * 0.44704) * simSpeedMultiplierRef.current;
      const distanceStep = speedMps * dt;
      let remainingStep = distanceStep;

      while (remainingStep > 0 && pIdx < poly.length - 1) {
        const [lon0, lat0] = poly[pIdx];
        const [lon1, lat1] = poly[pIdx + 1];
        const segDist = calculateDistanceMeters(lat0, lon0, lat1, lon1);
        const segDistLeft = segDist * (1 - simSegProgressRef.current);

        if (remainingStep < segDistLeft && segDist > 0.01) {
          simSegProgressRef.current += remainingStep / segDist;
          remainingStep = 0;
          curLat = lat0 + (lat1 - lat0) * simSegProgressRef.current;
          curLon = lon0 + (lon1 - lon0) * simSegProgressRef.current;
          curHeading = calculateBearing(lat0, lon0, lat1, lon1);
        } else {
          remainingStep -= segDistLeft;
          pIdx += 1;
          simPolylineIdxRef.current = pIdx;
          simSegProgressRef.current = 0;
          curLat = lat1;
          curLon = lon1;
          if (pIdx < poly.length - 1) {
            const [nextLon, nextLat] = poly[pIdx + 1];
            curHeading = calculateBearing(lat1, lon1, nextLat, nextLon);
          } else {
            curHeading = calculateBearing(lat0, lon0, lat1, lon1);
          }
        }
      }

      const simLoc: GpsLocation = {
        lat: curLat!,
        lon: curLon!,
        accuracy: 2.5,
        speed: targetSpeedMph,
        heading: curHeading,
        timestamp: now,
      };
      if (curHeading !== null) {
        lastApproachHeadingRef.current = curHeading;
      }
      simLocationRef.current = simLoc;
      setLocation(simLoc);
      processLocationUpdate(simLoc);

    } else {
      // Polyline loading from OSRM:
      if (!simLocationRef.current) {
        // Initial simulation start: initialize near first stop approach
        const mPerDegLat = 111132.92;
        simLocationRef.current = {
          lat: activeStop.lat - (200 / mPerDegLat),
          lon: activeStop.lon,
          accuracy: 2.5,
          speed: 0,
          heading: 0,
          timestamp: now,
        };
      }
      const cur = simLocationRef.current;
      // Hold position on the road at speed 0 awaiting the road route from OSRM
      // Never straight-line interpolate across buildings or declare premature arrival!
      const holdLoc: GpsLocation = {
        ...cur,
        speed: 0,
        timestamp: now,
      };
      simLocationRef.current = holdLoc;
      setLocation(holdLoc);
      processLocationUpdate(holdLoc);
    }
  }, [processLocationUpdate]);

  /**
   * Start Full Route Simulation from specified stop (defaults to Stop 1 / index 0)
   * Places vehicle at an authentic road approach location, not right on the doorstep at 32 MPH.
   */
  const startFullRouteSimulation = useCallback((startStopIndex: number = 0, speedMultiplier: number = 1) => {
    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    onSimulationStartRef.current?.();

    const targetIdx = startStopIndex !== undefined ? startStopIndex : 0;
    if (startStopIndex !== undefined && onJumpToStopRef.current) {
      onJumpToStopRef.current(targetIdx);
    }

    const mult = speedMultiplier || 1;
    simSpeedMultiplierRef.current = mult;
    setSimSpeedMultiplier(mult);

    isSimulatingGpsRef.current = true;
    isQuickSimulationRef.current = false;
    setIsSimulatingGps(true);
    isSimPausedRef.current = false;
    setIsSimPaused(false);

    setGpsStatus('locked');
    setGpsErrorMsg(null);
    setIsPassedWithoutCompletion(false);
    setIsConfirmedArrival(false);

    simPolylineIdxRef.current = 0;
    simSegProgressRef.current = 0;
    isDwellRef.current = false;
    dwellRemainingMsRef.current = 0;
    lastSimStopIdRef.current = null;
    lastSimTickTimeRef.current = Date.now();
    advancedStopIdsSetRef.current.clear();
    recentArrivalFixesRef.current = [];
    minConfirmedArrivalDistanceRef.current = Infinity;
    minDistanceSeenRef.current = Infinity;
    confirmedInsideCountRef.current = 0;
    passAwayCountRef.current = 0;
    firstInsideTimestampRef.current = 0;
    isAdvancingRef.current = false;
    lastAdvanceTimestampRef.current = 0;
    lastAdvancedStopIdRef.current = null;

    // Determine realistic starting vehicle position along the approach road
    const stopsList = allStopsRef.current || [];
    const targetStop = stopsList[targetIdx] || currentStopRef.current;

    if (targetStop && isValidCoordinate(targetStop.lat, targetStop.lon)) {
      let approachLat: number;
      let approachLon: number;
      let initialHeading: number;

      if (targetIdx > 0 && stopsList[targetIdx - 1]) {
        // Continue from previous customer's position
        const prevPt = stopsList[targetIdx - 1];
        approachLat = prevPt.lat;
        approachLon = prevPt.lon;
        initialHeading = calculateBearing(prevPt.lat, prevPt.lon, targetStop.lat, targetStop.lon);
      } else {
        // Starting Stop 1: calculate approach along road towards Stop 1
        const secondStop = stopsList[targetIdx + 1];
        if (secondStop && isValidCoordinate(secondStop.lat, secondStop.lon)) {
          const dLat = secondStop.lat - targetStop.lat;
          const dLon = secondStop.lon - targetStop.lon;
          const dist = calculateDistanceMeters(targetStop.lat, targetStop.lon, secondStop.lat, secondStop.lon);
          if (dist > 25) {
            // Approach vector ~350m back from opposite direction
            const mPerDegLat = 111132.92;
            const mPerDegLon = 111412.84 * Math.cos((targetStop.lat * Math.PI) / 180);
            approachLat = targetStop.lat - (dLat / dist) * (350 / mPerDegLat) * mPerDegLat;
            approachLon = targetStop.lon - (dLon / dist) * (350 / mPerDegLon) * mPerDegLon;
            initialHeading = calculateBearing(approachLat, approachLon, targetStop.lat, targetStop.lon);
          } else {
            approachLat = targetStop.lat + 0.0035;
            approachLon = targetStop.lon;
            initialHeading = 180;
          }
        } else {
          approachLat = targetStop.lat + 0.0035;
          approachLon = targetStop.lon;
          initialHeading = 180;
        }
      }

      const initialLoc: GpsLocation = {
        lat: approachLat,
        lon: approachLon,
        accuracy: 2.5,
        speed: 28,
        heading: initialHeading,
        timestamp: Date.now(),
      };
      simLocationRef.current = initialLoc;
      setLocation(initialLoc);
      processLocationUpdate(initialLoc);
    } else {
      simLocationRef.current = null;
    }

    simIntervalRef.current = window.setInterval(tickSimulation, 100);
  }, [tickSimulation, processLocationUpdate]);

  const pauseSimulation = useCallback(() => {
    isSimPausedRef.current = true;
    setIsSimPaused(true);
    if (simLocationRef.current) {
      const pausedLoc: GpsLocation = {
        ...simLocationRef.current,
        speed: 0,
        timestamp: Date.now(),
      };
      simLocationRef.current = pausedLoc;
      setLocation(pausedLoc);
    }
  }, []);

  const resumeSimulation = useCallback(() => {
    isSimPausedRef.current = false;
    setIsSimPaused(false);
    lastSimTickTimeRef.current = Date.now();
  }, []);

  const setSimulationSpeed = useCallback((multiplier: number) => {
    simSpeedMultiplierRef.current = multiplier;
    setSimSpeedMultiplier(multiplier);
  }, []);

  const restartSimulation = useCallback(() => {
    if (onJumpToStopRef.current) {
      onJumpToStopRef.current(0);
    } else if (onResetProgressRef.current) {
      onResetProgressRef.current();
    }
    simPolylineIdxRef.current = 0;
    simSegProgressRef.current = 0;
    isDwellRef.current = false;
    dwellRemainingMsRef.current = 0;
    lastSimStopIdRef.current = null;
    simLocationRef.current = null;
    lastSimTickTimeRef.current = Date.now();
    isSimPausedRef.current = false;
    setIsSimPaused(false);
    advancedStopIdsSetRef.current.clear();
  }, []);

  const stopGpsSimulation = useCallback(() => {
    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }
    isSimulatingGpsRef.current = false;
    isQuickSimulationRef.current = false;
    setIsSimulatingGps(false);
    isSimPausedRef.current = false;
    setIsSimPaused(false);
    simLocationRef.current = null;
    lastSimStopIdRef.current = null;
    lastLocationRef.current = null;
    minDistanceSeenRef.current = Infinity;
    isAdvancingRef.current = false;
    onExitSimulationRef.current?.();
  }, []);

  /**
   * Interactive Simulator 1: Quick Curbside Stop single-step test
   */
  const simulateApproachAndArrive = useCallback(() => {
    const activeStop = currentStopRef.current;
    if (!activeStop || !isValidCoordinate(activeStop.lat, activeStop.lon)) return;

    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    isSimulatingGpsRef.current = true;
    recentArrivalFixesRef.current = [];
    minConfirmedArrivalDistanceRef.current = Infinity;
    minDistanceSeenRef.current = Infinity;
    confirmedInsideCountRef.current = 0;
    passAwayCountRef.current = 0;
    firstInsideTimestampRef.current = 0;
    isAdvancingRef.current = false;
    lastAdvanceTimestampRef.current = 0;
    lastAdvancedStopIdRef.current = null;
    advancedStopIdsSetRef.current.clear();
    isQuickSimulationRef.current = true;
    setIsSimulatingGps(true);
    setGpsStatus('locked');
    setGpsErrorMsg(null);
    setIsPassedWithoutCompletion(false);
    setIsConfirmedArrival(false);

    const latMeters = 111132.92;
    const destLat = activeStop.lat;
    const destLon = activeStop.lon;

    const waypoints = [
      { offset: -180, speed: 25 }, // 590 ft out: lets the 500 ft approach warning trigger
      { offset: -150, speed: 22 }, // Crosses the 500 ft approach boundary
      { offset: -65, speed: 18 },  // Slowing down
      { offset: -25, speed: 8 },   // Near the driveway
      { offset: -8, speed: 0 },    // Within the agreed 30 ft arrival radius
      { offset: -8, speed: 0 },    // Second close fix confirms the stopped arrival
      { offset: +2, speed: 7 },    // Pulling away after confirmed arrival
    ];
    let step = 0;

    simIntervalRef.current = window.setInterval(() => {
      if (step >= waypoints.length) {
        if (simIntervalRef.current) {
          window.clearInterval(simIntervalRef.current);
          simIntervalRef.current = null;
        }
        setIsSimulatingGps(false);
        isSimulatingGpsRef.current = false;
        isQuickSimulationRef.current = false;
        return;
      }

      const wp = waypoints[step];
      const simLat = destLat + (wp.offset / latMeters);
      const simLon = destLon;

      const simLoc: GpsLocation = {
        lat: simLat,
        lon: simLon,
        accuracy: 3,
        speed: wp.speed,
        heading: 0,
        timestamp: Date.now(),
      };

      setLocation(simLoc);
      processLocationUpdate(simLoc);

      step += 1;
    }, 1100);
  }, [processLocationUpdate]);

  /**
   * Interactive Simulator 2: Curbside Pass-Through Delivery (rolls past at ~10 mph)
   */
  const simulateCurbsidePassThrough = useCallback(() => {
    const activeStop = currentStopRef.current;
    if (!activeStop || !isValidCoordinate(activeStop.lat, activeStop.lon)) return;

    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    isSimulatingGpsRef.current = true;
    recentArrivalFixesRef.current = [];
    minConfirmedArrivalDistanceRef.current = Infinity;
    minDistanceSeenRef.current = Infinity;
    confirmedInsideCountRef.current = 0;
    passAwayCountRef.current = 0;
    firstInsideTimestampRef.current = 0;
    isAdvancingRef.current = false;
    lastAdvanceTimestampRef.current = 0;
    lastAdvancedStopIdRef.current = null;
    advancedStopIdsSetRef.current.clear();
    isQuickSimulationRef.current = true;
    setIsSimulatingGps(true);
    setGpsStatus('locked');
    setGpsErrorMsg(null);
    setIsPassedWithoutCompletion(false);
    setIsConfirmedArrival(false);

    const latMeters = 111132.92;
    const destLat = activeStop.lat;
    const destLon = activeStop.lon;

    const waypoints = [
      { offset: -180, speed: 18 }, // Include the 500 ft approach-warning trigger
      { offset: -150, speed: 16 },
      { offset: -28, speed: 14 },
      { offset: -5, speed: 10 },  // Within 30 ft of the mapped stop
      { offset: +5, speed: 10 },
      { offset: +18, speed: 16 }, // Multiple fixes establish the pass
    ];
    let step = 0;

    simIntervalRef.current = window.setInterval(() => {
      if (step >= waypoints.length) {
        if (simIntervalRef.current) {
          window.clearInterval(simIntervalRef.current);
          simIntervalRef.current = null;
        }
        setIsSimulatingGps(false);
        isSimulatingGpsRef.current = false;
        isQuickSimulationRef.current = false;
        return;
      }

      const wp = waypoints[step];
      const simLat = destLat + (wp.offset / latMeters);
      const simLon = destLon + (2 / (latMeters * Math.cos(destLat * Math.PI / 180)));

      const simLoc: GpsLocation = {
        lat: simLat,
        lon: simLon,
        accuracy: 3,
        speed: wp.speed,
        heading: 0,
        timestamp: Date.now(),
      };

      setLocation(simLoc);
      processLocationUpdate(simLoc);

      step += 1;
    }, 1100);
  }, [processLocationUpdate]);

  /**
   * Interactive Simulator 3: Drive Past at 28 mph -> triggers Turnaround
   */
  const simulateApproachAndPass = useCallback(() => {
    const activeStop = currentStopRef.current;
    if (!activeStop || !isValidCoordinate(activeStop.lat, activeStop.lon)) return;

    if (simIntervalRef.current) {
      window.clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    isSimulatingGpsRef.current = true;
    recentArrivalFixesRef.current = [];
    minConfirmedArrivalDistanceRef.current = Infinity;
    minDistanceSeenRef.current = Infinity;
    confirmedInsideCountRef.current = 0;
    passAwayCountRef.current = 0;
    firstInsideTimestampRef.current = 0;
    isAdvancingRef.current = false;
    lastAdvanceTimestampRef.current = 0;
    lastAdvancedStopIdRef.current = null;
    advancedStopIdsSetRef.current.clear();
    isQuickSimulationRef.current = true;
    setIsSimulatingGps(true);
    setGpsStatus('locked');
    setGpsErrorMsg(null);

    const latMeters = 111132.92;
    const destLat = activeStop.lat;
    const destLon = activeStop.lon;

    const waypoints = [
      { offset: -180, speed: 28 }, // Include the 500 ft approach-warning trigger
      { offset: -150, speed: 28 },
      { offset: -100, speed: 28 },
      { offset: -45, speed: 28 },
      { offset: 0, speed: 28 },
      { offset: 70, speed: 28 },
      { offset: 125, speed: 28 },
      { offset: 160, speed: 28 },
    ];
    let step = 0;

    simIntervalRef.current = window.setInterval(() => {
      if (step >= waypoints.length) {
        if (simIntervalRef.current) {
          window.clearInterval(simIntervalRef.current);
          simIntervalRef.current = null;
        }
        setIsSimulatingGps(false);
        isSimulatingGpsRef.current = false;
        isQuickSimulationRef.current = false;
        return;
      }

      const wp = waypoints[step];
      const simLat = destLat + (wp.offset / latMeters);
      const simLon = destLon + (12 / (latMeters * Math.cos(destLat * Math.PI / 180)));

      const simLoc: GpsLocation = {
        lat: simLat,
        lon: simLon,
        accuracy: 4,
        speed: wp.speed,
        heading: 0,
        timestamp: Date.now(),
      };

      setLocation(simLoc);
      processLocationUpdate(simLoc);

      step += 1;
    }, 1200);
  }, [processLocationUpdate]);

  // Calculated reactive metrics for UI display
  let distanceToCurrentMeters: number | null = null;
  let distanceToCurrentFeet: number | null = null;
  let isWithinGeofence = false;
  let isWithinArrivalConfirmZone = false;

  const currentConfirmRadius = arrivalConfirmMetersRef.current || DEFAULT_ARRIVAL_CONFIRM_METERS;

  if (location && currentStop && isValidCoordinate(currentStop.lat, currentStop.lon)) {
    distanceToCurrentMeters = calculateDistanceMeters(location.lat, location.lon, currentStop.lat, currentStop.lon);
    distanceToCurrentFeet = Math.round(distanceToCurrentMeters * 3.28084);
    isWithinGeofence = distanceToCurrentMeters <= arrivalRadiusMeters;
    isWithinArrivalConfirmZone = distanceToCurrentMeters <= currentConfirmRadius;
  }

  let finalArrivalStatus = arrivalStateDesc;
  if (gpsStatus === 'denied') {
    finalArrivalStatus = 'GPS Disabled';
  } else if (gpsStatus === 'acquiring') {
    finalArrivalStatus = 'Acquiring Satellites...';
  } else if (isConfirmedArrival) {
    finalArrivalStatus = `Arrived at Stop (${distanceToCurrentFeet} ft)`;
  } else if (isPassedWithoutCompletion) {
    finalArrivalStatus = `Passed stop (${distanceToCurrentFeet} ft) · Recalculating...`;
  } else if (isSimulatingGps) {
    finalArrivalStatus = `Simulating Road Progress (${distanceToCurrentFeet} ft)`;
  } else if (isWithinArrivalConfirmZone) {
    finalArrivalStatus = `In delivery zone (${distanceToCurrentFeet} ft / ${Math.round(currentConfirmRadius * 3.28084)} ft)`;
  } else if (isWithinGeofence) {
    finalArrivalStatus = isSharedLocationWithPrevious
      ? 'Shared Address · Tap Skip when done'
      : `Customer nearby (${distanceToCurrentFeet} ft / ${Math.round(arrivalRadiusMeters * 3.28084)} ft window)`;
  }

  return {
    location,
    gpsStatus,
    gpsErrorMsg,
    distanceToCurrentMeters,
    distanceToCurrentFeet,
    isWithinGeofence,
    isWithinArrivalConfirmZone,
    isConfirmedArrival,
    isSharedLocationWithPrevious,
    isSharedLocationWithNext,
    autoArrivalStatus: finalArrivalStatus,
    arrivalRadiusMeters,
    arrivalConfirmFeet: Math.round(currentConfirmRadius * 3.28084),
    arrivalConfirmMeters: currentConfirmRadius,
    isPassedWithoutCompletion,
    arrivalHeading,
    isSimulatingGps,
    isSimPaused,
    simSpeedMultiplier,
    startFullRouteSimulation,
    pauseSimulation,
    resumeSimulation,
    setSimulationSpeed,
    restartSimulation,
    stopGpsSimulation,
    simulateApproachAndPass,
    simulateApproachAndArrive,
    simulateCurbsidePassThrough,
    diagLogs,
    addDiagLog,
  };
}
