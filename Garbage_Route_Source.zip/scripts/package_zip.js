import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

async function main() {
  console.log('Packaging complete OsmAnd Route Companion Source ZIP...');
  const zip = new JSZip();

  function addFile(filePath, zipPath) {
    if (fs.existsSync(filePath)) {
      const content = fs.readFileSync(filePath);
      zip.file(zipPath || filePath, content);
    }
  }

  function addDir(dir, prefix = '') {
    if (!fs.existsSync(dir)) return;
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      if (entry.name === 'node_modules' || entry.name === '.git' || entry.name === '.aistudio' || entry.name.endsWith('.zip')) {
        continue;
      }
      const fullPath = path.join(dir, entry.name);
      const relPath = prefix ? `${prefix}/${entry.name}` : entry.name;
      if (entry.isDirectory()) {
        addDir(fullPath, relPath);
      } else {
        const content = fs.readFileSync(fullPath);
        zip.file(relPath, content);
      }
    }
  }

  // 1. Add all root config & doc files
  const rootFiles = [
    'index.html',
    'package.json',
    'tsconfig.json',
    'vite.config.ts',
    '.env.example',
    '.gitignore',
    'metadata.json',
    'README.md',
    'EXPORT_AND_BUILD_GUIDE.md',
  ];
  for (const f of rootFiles) {
    addFile(f, f);
  }

  // 2. Add complete src directory
  addDir('src', 'src');

  // 3. Add scripts directory
  addDir('scripts', 'scripts');

  // 3b. Add public directory assets
  addDir('public', 'public');

  // 4. Add clean GitHub Actions workflows
  addDir('.github', '.github');

  // 4. Ensure Android assets contain freshly compiled web distribution
  if (fs.existsSync('dist')) {
    const assetsDistDir = 'android/app/src/main/assets/dist';
    if (!fs.existsSync(assetsDistDir)) {
      fs.mkdirSync(assetsDistDir, { recursive: true });
    }
    const distFiles = fs.readdirSync('dist');
    for (const file of distFiles) {
      if (file.endsWith('.zip')) continue;
      const srcPath = path.join('dist', file);
      const stat = fs.statSync(srcPath);
      if (stat.isFile()) {
        fs.copyFileSync(srcPath, path.join('android/app/src/main/assets', file));
        fs.copyFileSync(srcPath, path.join(assetsDistDir, file));
      } else if (stat.isDirectory()) {
        fs.cpSync(srcPath, path.join('android/app/src/main/assets', file), { recursive: true });
        fs.cpSync(srcPath, path.join(assetsDistDir, file), { recursive: true });
      }
    }
  }

  // Remove any stale zip files from assets to avoid APK bloat
  const staleZips = [
    'android/app/src/main/assets/Garbage_Route_Source.zip',
    'android/app/src/main/assets/OsmAnd_Route_Companion_Source.zip',
    'android/app/src/main/assets/osmand-route-companion.zip',
    'android/app/src/main/assets/dist/Garbage_Route_Source.zip',
    'android/app/src/main/assets/dist/OsmAnd_Route_Companion_Source.zip',
    'android/app/src/main/assets/dist/osmand-route-companion.zip',
    'public/osmand-route-companion.zip',
    'dist/osmand-route-companion.zip',
  ];
  for (const sz of staleZips) {
    if (fs.existsSync(sz)) {
      try { fs.unlinkSync(sz); } catch (e) {}
    }
  }

  // 5. Add native Android wrapper with compiled assets
  addDir('android', 'android');

  // 6. Generate zip archive
  console.log('Generating ZIP binary...');
  const buffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  const destinations = [
    'Garbage_Route_Source.zip',
    'public/Garbage_Route_Source.zip',
    'dist/Garbage_Route_Source.zip',
    'OsmAnd_Route_Companion_Source.zip',
    'public/OsmAnd_Route_Companion_Source.zip',
    'dist/OsmAnd_Route_Companion_Source.zip',
  ];

  for (const dest of destinations) {
    const dir = path.dirname(dest);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(dest, buffer);
    console.log(`Wrote ${buffer.length} bytes to ${dest}`);
  }

  console.log('Successfully packaged updated Garbage Route Source ZIP!');
}

main().catch((err) => {
  console.error('Error packaging zip:', err);
  process.exit(1);
});
