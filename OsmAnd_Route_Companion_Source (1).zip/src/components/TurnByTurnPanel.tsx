import React, { useState, useEffect, useRef, useCallback } from 'react';
import { RouteStop } from '../types/route';
import { GpsLocation } from '../utils/useGpsTracker';
import { 
  NavManeuver, 
  fetchOsmRoute, 
  calculateDistanceMeters, 
  calculateDistanceToPolylineMeters, 
  formatDistance, 
  formatDuration 
} from '../utils/navigationService';
import { 
  Compass, 
  Play, 
  Square, 
  RotateCcw, 
  X, 
  Info, 
  CheckCircle2, 
  Sparkles,
  CornerUpRight, 
  CornerUpLeft, 
  ArrowUp, 
  ArrowUpRight, 
  ArrowUpLeft,
  CircleDot, 
  GitFork, 
  Flag,
  Navigation
} from 'lucide-react';

function isValidCoordinate(lat: number, lon: number): boolean {
  return (
    !isNaN(lat) &&
    !isNaN(lon) &&
    lat >= -90 &&
    lat <= 90 &&
    lon >= -180 &&
    lon <= 180 &&
    !(lat === 0 && lon === 0)
  );
}

// ==========================================
// 1. Maneuver Icon Component with Prominent U-Turn
// ==========================================
export const ManeuverIconComponent: React.FC<{ type?: string; modifier?: string; className?: string }> = ({ 
  type = 'turn', 
  modifier = 'straight',
  className = 'w-10 h-10' 
}) => {
  const mod = (modifier || '').toLowerCase();
  const t = (type || '').toLowerCase();

  if (t === 'arrive') return <Flag className={className} />;
  if (t === 'roundabout' || t === 'rotary') return <CircleDot className={className} />;
  if (t === 'fork') return <GitFork className={className} />;
  
  // Prominent driver-grade U-turn symbol
  if (mod.includes('uturn') || mod === 'uturn') {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M9 19V9a5 5 0 0 1 10 0v7" />
        <polyline points="6 16 9 19 12 16" />
      </svg>
    );
  }
  
  if (mod === 'sharp right') {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M12 21V11a4 4 0 0 1 4-4h5" />
        <polyline points="18 4 21 7 18 10" />
      </svg>
    );
  }
  if (mod === 'sharp left') {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M12 21V11a4 4 0 0 0-4-4H3" />
        <polyline points="6 4 3 7 6 10" />
      </svg>
    );
  }
  if (mod === 'slight right') return <ArrowUpRight className={className} strokeWidth={2.75} />;
  if (mod === 'slight left') return <ArrowUpLeft className={className} strokeWidth={2.75} />;
  if (mod === 'right') return <CornerUpRight className={className} strokeWidth={2.75} />;
  if (mod === 'left') return <CornerUpLeft className={className} strokeWidth={2.75} />;
  if (mod === 'straight' || t === 'continue' || t === 'depart') {
    return <ArrowUp className={className} strokeWidth={2.75} />;
  }
  return <Compass className={className} strokeWidth={2.5} />;
};

// ==========================================
// 2. Complete Turn-by-Turn Panel Component
// ==========================================
export interface TurnByTurnPanelProps {
  currentStop: RouteStop;
  previousStop?: RouteStop;
  userLocation: GpsLocation | null;
  gpsStatus: 'acquiring' | 'locked' | 'denied';
  gpsErrorMsg: string | null;
  distanceToCurrentFeet: number | null;
  isDark: boolean;
  onOpenOsmAnd: (e: React.MouseEvent) => void;
  arrivalRadiusMeters?: number;
  isWithinGeofence?: boolean;
  autoArrivalStatus?: string;
  isPassedWithoutCompletion?: boolean;
  simulateApproachAndPass?: () => void;
  simulateApproachAndArrive?: () => void;
  isSimulatingGps?: boolean;
  stopGpsSimulation?: () => void;
}

export const TurnByTurnPanel: React.FC<TurnByTurnPanelProps> = ({
  currentStop,
  previousStop,
  userLocation,
  distanceToCurrentFeet,
  isDark,
  arrivalRadiusMeters = 50,
  isWithinGeofence = false,
  autoArrivalStatus,
  isPassedWithoutCompletion = false,
  simulateApproachAndPass,
  simulateApproachAndArrive,
  isSimulatingGps = false,
  stopGpsSimulation,
}) => {
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [showTestMenu, setShowTestMenu] = useState(false);

  // Live OsmAnd AIDL feed state (from Android Kotlin wrapper)
  const [aidlUpdate, setAidlUpdate] = useState<{
    maneuver: string;
    street: string;
    distanceMeters: number;
    lastReceived: number;
  } | null>(null);

  useEffect(() => {
    (window as any).onOsmAndNavUpdate = (maneuver: string, street: string, distMeters: number) => {
      setAidlUpdate({
        maneuver: maneuver || 'straight',
        street: street || '',
        distanceMeters: typeof distMeters === 'number' ? distMeters : 0,
        lastReceived: Date.now(),
      });
    };
    return () => {
      delete (window as any).onOsmAndNavUpdate;
    };
  }, []);

  const isAidlActive = Boolean(aidlUpdate && Date.now() - aidlUpdate.lastReceived < 20000);

  // Road navigation state
  const [maneuvers, setManeuvers] = useState<NavManeuver[]>([]);
  const [routeCoordinates, setRouteCoordinates] = useState<[number, number][]>([]);
  const [currentManeuverIndex, setCurrentManeuverIndex] = useState(0);
  const [distanceToTurnMeters, setDistanceToTurnMeters] = useState(0);
  const [totalDistanceMeters, setTotalDistanceMeters] = useState(0);
  const [totalDurationSeconds, setTotalDurationSeconds] = useState(0);
  const [isRouting, setIsRouting] = useState(false);
  const [routingError, setRoutingError] = useState<string | null>(null);
  const [rerouteBadge, setRerouteBadge] = useState<string | null>(null);

  // Tracking and Debounce Refs for recalculations
  const lastRerouteTimeRef = useRef<number>(0);
  const lastReroutePosRef = useRef<{ lat: number; lon: number } | null>(null);
  const minDistanceToDestRef = useRef<number>(Infinity);
  const currentStopIdRef = useRef<string | null>(null);

  // Determine starting point: live GPS if valid, else previous stop, else realistic approach offset
  const getStartPoint = useCallback((): { lat: number; lon: number; heading: number | null } | null => {
    if (userLocation && isValidCoordinate(userLocation.lat, userLocation.lon)) {
      return { 
        lat: userLocation.lat, 
        lon: userLocation.lon, 
        heading: userLocation.heading ?? null 
      };
    }
    if (previousStop && isValidCoordinate(previousStop.lat, previousStop.lon)) {
      return { 
        lat: previousStop.lat, 
        lon: previousStop.lon, 
        heading: null 
      };
    }
    if (currentStop && isValidCoordinate(currentStop.lat, currentStop.lon)) {
      // 0.005 deg offset (~500m) approach vector
      return { 
        lat: currentStop.lat - 0.005, 
        lon: currentStop.lon - 0.004, 
        heading: 35 
      };
    }
    return null;
  }, [userLocation, previousStop, currentStop]);

  // Primary Road Route Fetcher
  const fetchRoute = useCallback(async (customStart?: { lat: number; lon: number; heading?: number | null }, reasonTag?: string) => {
    if (!currentStop || !isValidCoordinate(currentStop.lat, currentStop.lon)) {
      setManeuvers([]);
      setRouteCoordinates([]);
      return;
    }

    const start = customStart || getStartPoint();
    if (!start) return;

    setIsRouting(true);
    setRoutingError(null);

    try {
      const route = await fetchOsmRoute(
        start.lat,
        start.lon,
        currentStop.lat,
        currentStop.lon,
        currentStop.name,
        start.heading
      );

      if (route.maneuvers.length > 0) {
        setManeuvers(route.maneuvers);
        setRouteCoordinates(route.coordinates);
        setCurrentManeuverIndex(0);
        setTotalDistanceMeters(route.totalDistance);
        setTotalDurationSeconds(route.totalDuration);
        setDistanceToTurnMeters(route.maneuvers[0]?.distanceMeters || 0);

        lastRerouteTimeRef.current = Date.now();
        lastReroutePosRef.current = { lat: start.lat, lon: start.lon };

        if (reasonTag) {
          setRerouteBadge(reasonTag);
          setTimeout(() => setRerouteBadge(null), 5000);
        } else if (route.hasUturn) {
          setRerouteBadge('U-Turn Route Active');
          setTimeout(() => setRerouteBadge(null), 5000);
        }
      }
    } catch (err: any) {
      console.warn('Road routing error:', err);
      setRoutingError(err.message || 'Routing unavailable');
    } finally {
      setIsRouting(false);
    }
  }, [currentStop, getStartPoint]);

  // Initial Route Fetch on active customer change
  useEffect(() => {
    const stopId = currentStop?.id || null;
    if (stopId !== currentStopIdRef.current) {
      currentStopIdRef.current = stopId;
      setCurrentManeuverIndex(0);
      minDistanceToDestRef.current = Infinity;
      lastReroutePosRef.current = null;
      lastRerouteTimeRef.current = 0;
      setRerouteBadge(null);
      fetchRoute();
    }
  }, [currentStop?.id, currentStop?.lat, currentStop?.lon, fetchRoute]);

  // Real-time Vehicle Progress & Intelligent Recalculation Engine
  useEffect(() => {
    if (!userLocation || !isValidCoordinate(userLocation.lat, userLocation.lon)) return;
    if (!currentStop || !isValidCoordinate(currentStop.lat, currentStop.lon)) return;

    const now = Date.now();
    const distToDest = calculateDistanceMeters(userLocation.lat, userLocation.lon, currentStop.lat, currentStop.lon);

    // Track minimum distance seen for this destination
    if (distToDest < minDistanceToDestRef.current) {
      minDistanceToDestRef.current = distToDest;
    }

    // ========================================================
    // INTELLIGENT RECALCULATION TRIGGER
    // 1. Driver passed destination without completing stop (missed stop)
    // 2. OR driver deviated significantly (> 45m) off planned route polyline
    // ========================================================
    const timeSinceLastReroute = now - lastRerouteTimeRef.current;
    const distFromLastReroute = lastReroutePosRef.current
      ? calculateDistanceMeters(userLocation.lat, userLocation.lon, lastReroutePosRef.current.lat, lastReroutePosRef.current.lon)
      : Infinity;

    // Condition A: Missed destination (passed without arrival confirmation)
    const isPassedAddress = Boolean(
      isPassedWithoutCompletion ||
      (minDistanceToDestRef.current <= 80 && distToDest >= minDistanceToDestRef.current + 22)
    );

    // Condition B: Off-route deviation from polyline (> 45 meters)
    let isOffRoute = false;
    if (routeCoordinates.length > 1) {
      const distToPolyline = calculateDistanceToPolylineMeters(userLocation.lat, userLocation.lon, routeCoordinates);
      isOffRoute = distToPolyline > 45 && distToDest > 30;
    }

    if ((isPassedAddress || isOffRoute) && timeSinceLastReroute > 3500 && distFromLastReroute > 15 && !isRouting) {
      const reason = isPassedAddress ? 'Passed Stop · Recalculating' : 'Off-Route · Rerouting';
      minDistanceToDestRef.current = distToDest;
      fetchRoute(
        { lat: userLocation.lat, lon: userLocation.lon, heading: userLocation.heading },
        reason
      );
      return;
    }

    // ========================================================
    // MANEUVER PROGRESSION ALONG ACTIVE ROUTE
    // Advance to next turn as driver approaches maneuver waypoint
    // ========================================================
    if (maneuvers.length > 0 && currentManeuverIndex < maneuvers.length) {
      const currentM = maneuvers[currentManeuverIndex];
      if (currentM) {
        const [turnLon, turnLat] = currentM.location;
        const distToWaypoint = calculateDistanceMeters(userLocation.lat, userLocation.lon, turnLat, turnLon);

        if (distToWaypoint < 25 && currentManeuverIndex < maneuvers.length - 1) {
          setCurrentManeuverIndex((idx) => idx + 1);
          const nextM = maneuvers[currentManeuverIndex + 1];
          setDistanceToTurnMeters(nextM ? nextM.distanceMeters : 0);
        } else {
          setDistanceToTurnMeters(Math.max(0, Math.round(distToWaypoint)));
        }
      }
    }
  }, [userLocation, currentStop, maneuvers, currentManeuverIndex, routeCoordinates, isPassedWithoutCompletion, isRouting, fetchRoute]);

  const currentManeuver = maneuvers[currentManeuverIndex] || null;
  const nextManeuver = maneuvers[currentManeuverIndex + 1] || null;

  const activeManeuverType = isAidlActive && aidlUpdate
    ? (aidlUpdate.maneuver.includes('roundabout') ? 'roundabout' : 'turn')
    : currentManeuver?.type || 'turn';

  const activeManeuverModifier = isAidlActive && aidlUpdate
    ? aidlUpdate.maneuver
    : currentManeuver?.modifier || 'straight';

  const activeInstructionText = isAidlActive && aidlUpdate
    ? (aidlUpdate.street ? `Turn onto ${aidlUpdate.street}` : aidlUpdate.maneuver)
    : currentManeuver?.instruction || (currentStop.streetName ? `Proceed along route to ${currentStop.streetName}` : 'Proceed toward customer destination');

  const activeStreetName = isAidlActive && aidlUpdate
    ? aidlUpdate.street
    : currentManeuver?.streetName || currentStop.streetName || currentStop.fullAddress || '';

  const activeDistanceToNextTurn = isAidlActive && aidlUpdate
    ? formatDistance(aidlUpdate.distanceMeters)
    : formatDistance(distanceToTurnMeters) || '0 ft';

  const hasValidCoords = isValidCoordinate(currentStop.lat, currentStop.lon);
  const distanceToStopFormatted = distanceToCurrentFeet !== null && hasValidCoords
    ? formatDistance(distanceToCurrentFeet / 3.28084)
    : formatDistance(totalDistanceMeters) || null;

  const arrivalZoneFeet = Math.round((arrivalRadiusMeters || 50) * 3.28084);
  const isArrived = Boolean(
    isWithinGeofence ||
    (distanceToCurrentFeet !== null && distanceToCurrentFeet <= arrivalZoneFeet)
  );

  return (
    <>
      {/* 
        Substantially Taller, Full-Width Driver-Grade Turn-by-Turn Card
        - Zero text truncation (no truncate, no nowrap, no ellipses)
        - Multi-line wrap enabled for any street name length
        - High-contrast AMOLED black & amber/orange styling
        - Legal U-turn & block rerouting support
      */}
      <div 
        className={`w-full rounded-3xl border-2 transition-all shadow-2xl relative mb-3.5 flex flex-col ${
          isArrived
            ? 'bg-emerald-950/95 border-emerald-400 text-white shadow-emerald-950/90'
            : isDark 
              ? 'bg-neutral-950 border-neutral-800 text-white shadow-neutral-950/95' 
              : 'bg-neutral-900 border-neutral-700 text-white shadow-neutral-500/40'
        }`}
      >
        {/* Amber accent top bar */}
        <div className="w-full h-1.5 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-400 rounded-t-3xl" />

        {/* 1. Header Bar: Engine Source, Reroute Status & In-Phone Simulation Controls */}
        <div className="px-4 py-2.5 flex items-center justify-between border-b border-neutral-800/90 gap-2 flex-wrap">
          {/* Active Status Badge */}
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5 shrink-0">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                isAidlActive ? 'bg-emerald-400' : isSimulatingGps ? 'bg-amber-400' : 'bg-orange-400'
              }`} />
              <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${
                isAidlActive ? 'bg-emerald-400' : isSimulatingGps ? 'bg-amber-400' : 'bg-orange-500'
              }`} />
            </span>
            <span className="font-mono font-black uppercase tracking-wider text-[11px] text-neutral-300">
              {rerouteBadge
                ? rerouteBadge
                : isAidlActive 
                  ? 'OsmAnd Native AIDL' 
                  : isSimulatingGps
                    ? 'Test Simulation Active'
                    : isRouting 
                      ? 'Recalculating Road Route...' 
                      : 'OpenStreetMap Road Routing'}
            </span>
          </div>

          {/* Test Drive Controls with instant Arrival & Missed-Stop U-turn testing */}
          <div className="flex items-center gap-2 relative">
            {isSimulatingGps ? (
              <button
                onClick={() => {
                  if (stopGpsSimulation) stopGpsSimulation();
                }}
                className="flex items-center gap-1.5 px-3 py-1 rounded-xl text-[11px] font-black uppercase tracking-wider bg-amber-400 text-black shadow-lg shadow-amber-950/60 animate-pulse transition-all active:scale-95"
                title="Pause active simulation"
              >
                <Square className="w-3 h-3 fill-current" />
                <span>Stop Test</span>
              </button>
            ) : (
              <div className="relative">
                <button
                  onClick={() => setShowTestMenu((v) => !v)}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-xl text-[11px] font-black uppercase tracking-wider bg-neutral-900 hover:bg-neutral-800 text-amber-400 border border-neutral-700 transition-all active:scale-95"
                  title="Test in-phone without driving"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>Test Drive</span>
                </button>

                {/* Test Drive Dropdown Menu */}
                {showTestMenu && (
                  <div className="absolute right-0 top-full mt-2 w-56 bg-neutral-900 border border-neutral-700 rounded-2xl shadow-2xl p-2 z-40 space-y-1.5 animate-in fade-in zoom-in-95 duration-150">
                    <button
                      onClick={() => {
                        setShowTestMenu(false);
                        if (simulateApproachAndArrive) {
                          simulateApproachAndArrive();
                        } else if (simulateApproachAndPass) {
                          simulateApproachAndPass();
                        }
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-white hover:bg-neutral-800 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>Approach & Stop</span>
                      </div>
                      <span className="text-[10px] text-neutral-400 uppercase font-mono">Arrival</span>
                    </button>

                    <button
                      onClick={() => {
                        setShowTestMenu(false);
                        if (simulateApproachAndPass) {
                          simulateApproachAndPass();
                        }
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-white hover:bg-neutral-800 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <RotateCcw className="w-4 h-4 text-amber-400 shrink-0" />
                        <span>Miss Stop & Reroute</span>
                      </div>
                      <span className="text-[10px] text-amber-400 uppercase font-mono">U-Turn</span>
                    </button>
                  </div>
                )}
              </div>
            )}

            <button
              onClick={() => setShowStatusModal(true)}
              className="p-1 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
              title="Navigation details & instructions"
            >
              <Info className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 2. Primary Turn Section: Prominent Maneuver Arrow + Distance to Next Turn */}
        <div className="p-4 sm:p-5 flex items-center justify-between gap-4 border-b border-neutral-800/60">
          {/* Prominent Maneuver Arrow Container (Substantial space, high-contrast) */}
          <div 
            className={`w-18 h-18 sm:w-22 sm:h-22 rounded-2xl flex items-center justify-center shrink-0 border-2 shadow-xl transition-all ${
              isArrived
                ? 'bg-emerald-500 border-emerald-300 text-black shadow-emerald-500/50'
                : isAidlActive
                  ? 'bg-emerald-500/25 border-emerald-400 text-emerald-400'
                  : 'bg-amber-400 border-amber-300 text-black shadow-amber-400/20'
            }`}
          >
            {isArrived ? (
              <CheckCircle2 className="w-11 h-11 sm:w-13 sm:h-13 stroke-[3] text-black" />
            ) : (
              <ManeuverIconComponent 
                type={activeManeuverType}
                modifier={activeManeuverModifier}
                className="w-11 h-11 sm:w-13 sm:h-13 stroke-[3]" 
              />
            )}
          </div>

          {/* Distance to NEXT TURN (Clearly Distinguished from Distance to Customer) */}
          <div className="flex-1 text-right min-w-0">
            <div className="text-[11px] font-black uppercase tracking-widest text-amber-400 font-mono mb-0.5">
              DISTANCE TO NEXT TURN
            </div>
            <div className="font-black text-4xl sm:text-5xl font-mono text-white tracking-tight leading-none drop-shadow">
              {activeDistanceToNextTurn}
            </div>

            {/* Total Remaining Distance to the Customer (Clearly separated) */}
            {distanceToStopFormatted && (
              <div className="text-xs font-semibold text-neutral-300 mt-1.5 font-mono">
                Customer Stop: <span className="font-bold text-white">{distanceToStopFormatted}</span>
                {totalDurationSeconds > 0 ? ` • ~${formatDuration(totalDurationSeconds)}` : ''}
              </div>
            )}

            {/* Live Auto-Arrival & Missed Destination Status */}
            {autoArrivalStatus && (
              <div className="text-[11px] font-mono font-medium text-amber-300/90 mt-1 truncate">
                {autoArrivalStatus}
              </div>
            )}
          </div>
        </div>

        {/* 3. Full-Width Driving Instruction (Multi-Line Wrapping, Zero Truncation) */}
        <div className="p-4 sm:p-5 space-y-2">
          {/* Complete Turn Instruction Text - No truncate, wraps cleanly */}
          <h2 className="text-2xl sm:text-3xl font-black text-amber-300 tracking-tight leading-tight whitespace-normal break-words">
            {activeInstructionText}
          </h2>

          {/* Road / Street Name Pill (Multi-Line Safe) */}
          {activeStreetName && (
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-neutral-900 border border-neutral-700/80 text-white font-bold text-xs sm:text-sm max-w-full whitespace-normal break-words">
              <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
              <span className="break-words">Road: {activeStreetName}</span>
            </div>
          )}
        </div>

        {/* 4. Upcoming Next Turn Preview Strip ("THEN" Maneuver) */}
        {nextManeuver && !isArrived && (
          <div className="px-4 py-3 bg-neutral-900/95 border-t border-neutral-800 rounded-b-3xl flex items-start gap-3 text-xs sm:text-sm font-semibold text-neutral-300 whitespace-normal break-words">
            <span className="text-[10px] font-black uppercase tracking-wider text-black bg-amber-400 px-2 py-0.5 rounded-md shrink-0 mt-0.5">
              THEN
            </span>
            <div className="w-5 h-5 flex items-center justify-center shrink-0 text-amber-400 mt-0.5">
              <ManeuverIconComponent 
                type={nextManeuver.type}
                modifier={nextManeuver.modifier}
                className="w-4 h-4 stroke-[2.75]" 
              />
            </div>
            <div className="flex-1 min-w-0 whitespace-normal break-words text-neutral-200">
              <span className="font-mono text-amber-400 font-bold">In {formatDistance(nextManeuver.distanceMeters)}:</span>{' '}
              <span>{nextManeuver.instruction}</span>
            </div>
          </div>
        )}

        {/* 5. Geofence Arrival Banner */}
        {isArrived && (
          <div className="p-3 bg-emerald-500 text-black font-black text-sm text-center tracking-wide uppercase rounded-b-3xl flex items-center justify-center gap-2">
            <CheckCircle2 className="w-5 h-5 stroke-[3]" />
            <span>ARRIVED WITHIN {arrivalZoneFeet} FT GEOFENCE</span>
          </div>
        )}

        {/* Routing Error Notice */}
        {routingError && (
          <div className="px-4 py-2 bg-red-950/80 border-t border-red-900 text-xs text-red-300 flex items-center justify-between">
            <span>Routing server: {routingError}</span>
            <button
              onClick={() => fetchRoute()}
              className="underline text-red-200 flex items-center gap-1 font-bold"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Retry
            </button>
          </div>
        )}
      </div>

      {/* Navigation Architecture & In-Phone Testing Guide Modal */}
      {showStatusModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-3xl border border-neutral-700 bg-neutral-900 text-white shadow-2xl p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-orange-600 flex items-center justify-center text-white shrink-0">
                  <Compass className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-black text-base">True Road Navigation</h3>
                  <p className="text-xs text-neutral-400">Intelligent Rerouting & Legal Maneuvers</p>
                </div>
              </div>
              <button
                onClick={() => setShowStatusModal(false)}
                className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs text-neutral-300">
              <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="font-bold text-amber-400 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" />
                  <span>Legal Maneuvers & Missed Destinations</span>
                </div>
                <p>
                  Calculates genuine OpenStreetMap driving routes with exact road names, turn angles, and step distances.
                </p>
                <ul className="list-disc pl-4 space-y-1 text-neutral-400">
                  <li><strong>Legal U-Turns:</strong> If a U-turn is legal and practical at the crossover or intersection, the app instructs &quot;Make a U-turn when possible&quot;.</li>
                  <li><strong>Around the Block:</strong> If a U-turn is illegal, divided, or restricted, the app routes you around the block via legal side streets.</li>
                  <li><strong>No Accidental Advance:</strong> Passing an address without stopping does not mark the customer complete; it recalculates the return route.</li>
                </ul>
              </div>

              <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="font-bold text-amber-300">How to Test on Android:</div>
                <ol className="list-decimal pl-4 space-y-1.5 text-neutral-400">
                  <li>Tap <strong>Test Drive</strong> in the navigation header.</li>
                  <li>Select <strong>Approach & Stop</strong> to verify confirmed arrival and automatic stop advancement.</li>
                  <li>Select <strong>Miss Stop & Reroute</strong> to simulate driving past without stopping. Watch the app keep the active customer and instantly recalculate a legal return route.</li>
                  <li>While driving on the road, the app automatically tracks your real-time GPS position.</li>
                </ol>
              </div>
            </div>

            <button
              onClick={() => setShowStatusModal(false)}
              className="w-full mt-5 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-sm transition-all"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
};
